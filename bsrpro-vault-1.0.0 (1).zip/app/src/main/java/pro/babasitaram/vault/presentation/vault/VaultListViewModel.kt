package pro.babasitaram.vault.presentation.vault

import pro.babasitaram.vault.R

import android.content.Context
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.core.util.EntrySearch
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions

import androidx.compose.foundation.layout.*
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.core.util.L

enum class ListFilter(val label: String) { ALL("All"), WEBSITE("Website"), MOBILE_APP("Mobile App"), STRONG("Strong"), WEAK("Weak"), STARRED("Starred") }
enum class SortMode(val label: String) { NAME("Name"), UPDATED("Recently updated"), USED("Recently used"), STRENGTH("Strength") }

val CATEGORIES = listOf("work", "personal", "banking", "social", "other")
private const val PAGE_SIZE = 200

@Stable
data class VaultListUiState(
    val entries: List<VaultEntry> = emptyList(),
    val filteredCount: Int = 0,
    val totalCount: Int = 0,
    val websiteCount: Int = 0,
    val mobileAppCount: Int = 0,
    val query: String = "",
    val category: String? = null,
    val folderId: String? = null,
    val filter: ListFilter = ListFilter.ALL,
    val sort: SortMode = SortMode.NAME,
    val grouped: Boolean = false,
    val folders: List<Folder> = emptyList(),
    val biometricEnabled: Boolean = false,
    val showCategories: Boolean = true,
    val canLoadMore: Boolean = false
)

fun VaultEntry.strengthBucket(): String = strength.ifBlank { PasswordStrength.bucket(password) }

@OptIn(FlowPreview::class)
@HiltViewModel
class VaultListViewModel @Inject constructor(
    private val repository: VaultRepository,
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val biometric: BiometricAuthenticator,
    private val biometricStore: BiometricSessionKeyStore,
    private val lockVault: LockVaultUseCase,
    private val clipboard: ClipboardActions,
    private val saveEntry: SaveEntryUseCase,
    private val activityLog: ActivityLogStore,
    private val autoBackup: pro.babasitaram.vault.data.backup.AutoBackupManager,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val query = MutableStateFlow("")
    private val category = MutableStateFlow<String?>(null)
    private val folderId = MutableStateFlow<String?>(null)
    private val filter = MutableStateFlow(ListFilter.ALL)
    private val sort = MutableStateFlow(SortMode.NAME)
    private val grouped = MutableStateFlow(false)
    private val renderLimit = MutableStateFlow(PAGE_SIZE)
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    private val debouncedQuery = query.debounce { if (it.isEmpty()) 0L else 200L }

    private data class Controls(
        val query: String,
        val category: String?,
        val folderId: String?,
        val filter: ListFilter,
        val sort: SortMode
    )

    // kotlinx.coroutines only has typed combine() overloads up to 5 flows, so inputs are grouped.
    private val controls: Flow<Controls> = combine(query, category, folderId, filter, sort) { q, c, fId, f, sortMode ->
        Controls(q, c, fId, f, sortMode)
    }

    private val computedVisible: StateFlow<List<VaultEntry>> = combine(
        repository.entries,
        debouncedQuery,
        controls
    ) { entries, debounced, ctl ->
        val base = entries.filter { e ->
            // Vault shows passwords / logins / cards / identities only; TOTP, Notes and Mobiles have their own screens
            !e.isNote && !e.isFolderMarker && !e.isHiddenVault && e.recordType.lowercase() !in SEPARATE_TYPES &&
            (ctl.category == null || e.category.equals(ctl.category, ignoreCase = true)) &&
                (ctl.folderId == null || e.folderId == ctl.folderId) &&
                when (ctl.filter) {
                    ListFilter.ALL -> true
                    ListFilter.STRONG -> e.strengthBucket() == "strong"
                    ListFilter.WEAK -> e.strengthBucket() == "weak"
                    ListFilter.STARRED -> e.starred
                    ListFilter.WEBSITE -> e.isWebsiteLogin
                    ListFilter.MOBILE_APP -> e.isMobileAppLinked
                }
        }
        val searched = if (debounced.isBlank()) base else EntrySearch.filter(base, debounced)
        when (ctl.sort) {
            // Sort keys are computed once per entry (sortedBy re-evaluates its selector on every comparison).
            SortMode.NAME -> searched.map { it.title.lowercase() to it }.sortedBy { it.first }.map { it.second }
            SortMode.UPDATED -> searched.sortedByDescending { it.updatedAt }
            SortMode.USED -> searched.sortedByDescending { it.lastUsedAt }
            SortMode.STRENGTH -> searched.map { PasswordStrength.score(it.password) to it }.sortedByDescending { it.first }.map { it.second }
        }
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())   // one shared filter+sort pass instead of three

    private val visible: Flow<List<VaultEntry>> = combine(computedVisible, renderLimit) { list, limit -> list.take(limit) }

    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds

    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode

    val selectableIds: StateFlow<Set<String>> = computedVisible
        .map { list -> list.map { it.id }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptySet())

    private val display: Flow<Triple<Boolean, Boolean, Boolean>> = combine(grouped, settings.settings) { g, cfg ->
        Triple(g, cfg.biometricEnabled, cfg.showCategoryChips)
    }

    // kotlinx.coroutines only ships typed combine() overloads up to 5 flows, so controls+display are paired first.
    private val controlsAndDisplay = combine(controls, display) { ctl, disp -> ctl to disp }

    val state: StateFlow<VaultListUiState> = combine(
        visible,
        computedVisible,
        repository.entries,
        repository.folders,
        controlsAndDisplay
    ) { shown, matching, all, folders, pair ->
        val ctl = pair.first
        val disp = pair.second
        val loginEntries = all.filter { e ->
            !e.isNote && !e.isFolderMarker && !e.isHiddenVault && e.recordType.lowercase() !in SEPARATE_TYPES
        }
        VaultListUiState(
            entries = shown,
            filteredCount = matching.size,
            totalCount = loginEntries.size,
            websiteCount = loginEntries.count { it.isWebsiteLogin },
            mobileAppCount = loginEntries.count { it.isMobileAppLinked },
            query = ctl.query,
            category = ctl.category,
            folderId = ctl.folderId,
            filter = ctl.filter,
            sort = ctl.sort,
            grouped = disp.first,
            folders = folders,
            biometricEnabled = disp.second,
            showCategories = disp.third,
            canLoadMore = shown.size < matching.size
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), VaultListUiState())

    private fun resetRenderLimit() { renderLimit.value = PAGE_SIZE; exitSelection() }
    fun loadMore() { renderLimit.value = renderLimit.value + PAGE_SIZE }
    fun setQuery(value: String) { query.value = value; resetRenderLimit() }
    fun setCategory(value: String?) { category.value = if (category.value == value) null else value; resetRenderLimit() }
    fun setFolder(value: String?) { folderId.value = if (folderId.value == value) null else value; resetRenderLimit() }
    fun setFilter(value: ListFilter) { filter.value = value; resetRenderLimit() }
    fun setSort(value: SortMode) { sort.value = value; resetRenderLimit() }
    fun toggleGrouped() { grouped.value = !grouped.value; resetRenderLimit() }

    fun beginSelection(id: String) {
        _selectionMode.value = true
        _selectedIds.update { it + id }
    }

    fun toggleSelection(id: String) {
        if (!_selectionMode.value) {
            beginSelection(id)
            return
        }
        _selectedIds.update { current -> if (id in current) current - id else current + id }
    }

    fun toggleSelectAll() {
        val ids = selectableIds.value
        if (ids.isEmpty()) return
        _selectedIds.value = if (_selectedIds.value.containsAll(ids)) emptySet() else ids
        _selectionMode.value = true
    }

    fun exitSelection() {
        _selectedIds.value = emptySet()
        _selectionMode.value = false
    }

    fun deleteSelected() {
        val ids = selectedIds.value.toList()
        if (ids.isEmpty()) return
        launchCatching {
            var failed = false
            runCatching { repository.softDeleteAll(ids) }.onFailure { failed = true }
            autoBackup.requestBackup()
            activityLog.record("Bulk move to Bin", "${ids.size} Vault entries moved to trash")
            exitSelection()
            _messages.send(
                if (failed) context.getString(R.string.selection_delete_failed)
                else context.getString(R.string.selection_deleted_to_bin, ids.size)
            )
        }
    }

    fun favoriteSelected() {
        val selected = selectedIds.value
        if (selected.isEmpty()) return
        launchCatching {
            val current = selectableIds.value
                .asSequence()
                .mapNotNull(repository::entry)
                .filter { it.id in selected }
                .toList()
            val now = System.currentTimeMillis()
            runCatching { repository.upsertAll(current.map { it.copy(starred = !it.starred, updatedAt = now) }) }
            autoBackup.requestBackup()
            activityLog.record("Bulk favorite", "Updated favorites for ${current.size} Vault entries")
            exitSelection()
            _messages.send(context.getString(R.string.selection_favorite_done, current.size))
        }
    }

    fun createFolder(name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        launchCatching {
            val now = System.currentTimeMillis()
            val existing = repository.folders.value.firstOrNull { it.name.equals(clean, ignoreCase = true) }
            if (existing != null) {
                _messages.send(context.getString(R.string.vault_folder_exists))
                return@launchCatching
            }
            val folder = Folder(
                id = "folder-$now-${clean.hashCode().toUInt().toString(16)}",
                name = clean,
                createdAt = now,
                updatedAt = now
            )
            when (val result = repository.upsertFolder(folder)) {
                is pro.babasitaram.vault.core.util.VaultResult.Success -> _messages.send(context.getString(R.string.vault_folder_created))
                is pro.babasitaram.vault.core.util.VaultResult.Failure -> _messages.send(result.error.message ?: context.getString(R.string.vault_folder_create_failed))
                pro.babasitaram.vault.core.util.VaultResult.Loading -> Unit
            }
        }
    }

    fun removeFolder(folder: Folder) {
        launchCatching {
            when (val result = repository.deleteFolder(folder.id)) {
                is pro.babasitaram.vault.core.util.VaultResult.Success -> _messages.send(context.getString(R.string.vault_folder_removed))
                is pro.babasitaram.vault.core.util.VaultResult.Failure -> _messages.send(result.error.message ?: context.getString(R.string.vault_folder_remove_failed))
                pro.babasitaram.vault.core.util.VaultResult.Loading -> Unit
            }
        }
    }

    fun copyPassword(entry: VaultEntry) = launchCatching { activityLog.record("Copy password", context.getString(R.string.vault_field_copied)); _messages.send(clipboard.copy(entry.password, context.getString(R.string.p15_password))) }
    fun copyUsername(entry: VaultEntry) = launchCatching { activityLog.record("Copy username", context.getString(R.string.vault_field_copied)); _messages.send(clipboard.copy(entry.username, context.getString(R.string.p15_username))) }
    fun copyTotp(entry: VaultEntry) = launchCatching { activityLog.record("Copy TOTP", "Authenticator code copied"); _messages.send(clipboard.copy(entry.totp, L.s(R.string.nav_totp))) }

    fun delete(entry: VaultEntry) {
        launchCatching {
            try {
                repository.softDelete(entry.id)
                activityLog.record("Move to Bin", "Vault entry moved to trash")
                _messages.send(context.getString(R.string.p15_move_to_bin))
            } catch (e: VaultError) {
                _messages.send(e.message ?: context.getString(R.string.vault_move_failed))
            }
        }
    }

    fun toggleStar(entry: VaultEntry) {
        launchCatching {
            saveEntry(entry.copy(starred = !entry.starred), existing = entry)
            activityLog.record(if (entry.starred) "Remove favorite" else "Add favorite", "Vault entry favorite changed")
            _messages.send(if (entry.starred) context.getString(R.string.vault_removed_favorite) else context.getString(R.string.vault_added_favorite))
        }
    }

    fun lock() = launchCatching { lockVault() }

    fun toggleBiometric(activity: FragmentActivity) {
        launchCatching {
            if (settings.current().biometricEnabled) {
                biometricStore.clearAllCredentials()
                settings.update { it.copy(biometricEnabled = false) }
                _messages.send(context.getString(R.string.vault_biometric_disabled))
                return@launchCatching
            }
            if (biometric.availability() != BiometricAvailability.Available) {
                _messages.send(context.getString(R.string.vault_biometric_setup))
                return@launchCatching
            }
            try {
                val cipher = biometricStore.createEncryptCipher()
                biometric.authenticateWithCipher(
                    activity = activity,
                    cipher = cipher,
                    title = L.s(R.string.vault_enable_biometric),
                    negativeButtonText = L.s(R.string.p18_common_use_device_pin),
                    subtitle = L.s(R.string.p18_common_confirm_it_s_you)
                ).collect { result ->
                    when (result) {
                        is AuthResult.Success -> session.withPassword { master ->
                            biometricStore.saveCredentialAfterAuthentication(cipher, master)
                            biometricStore.saveSessionMetadata(
                                BiometricSessionKeyStore.SessionMetadata(
                                    issuedAtWallMs = System.currentTimeMillis(),
                                    expiresAtWallMs = session.sessionExpiresAtWallMs(),
                                    backgroundedAtWallMs = 0L
                                )
                            )
                            settings.update { it.copy(biometricEnabled = true) }
                            _messages.send(context.getString(R.string.vault_biometric_enabled))
                        }
                        AuthResult.FallbackRequested -> biometric.authenticate(
                            activity, "Enable quick unlock", "Use fingerprint, face or device PIN"
                        ).collect { fallback ->
                            if (fallback is AuthResult.Success) {
                                val authorizedCipher = biometricStore.createEncryptCipher()
                                session.withPassword { master ->
                                    biometricStore.saveCredentialAfterAuthentication(authorizedCipher, master)
                                    biometricStore.saveSessionMetadata(
                                        BiometricSessionKeyStore.SessionMetadata(
                                            issuedAtWallMs = System.currentTimeMillis(),
                                            expiresAtWallMs = session.sessionExpiresAtWallMs(),
                                            backgroundedAtWallMs = 0L
                                        )
                                    )
                                    settings.update { it.copy(biometricEnabled = true) }
                                    _messages.send(context.getString(R.string.vault_biometric_enabled))
                                }
                            }
                        }
                        is AuthResult.Error -> _messages.send(result.message)
                        AuthResult.Failed, AuthResult.Cancelled -> Unit
                    }
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (t: Throwable) {
                _messages.send(t.message ?: context.getString(R.string.vault_biometric_setup))
            }
        }
    }
}


private val SEPARATE_TYPES = setOf("note", "totp", "mobile")
