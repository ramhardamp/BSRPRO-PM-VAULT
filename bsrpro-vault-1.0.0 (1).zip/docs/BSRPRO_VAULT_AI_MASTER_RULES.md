# BSRPRO Vault — Master AI Development Rules

**Project:** BSRPRO Vault
**Application Type:** Native Password Manager
**Role of AI:** Senior Developer + Security Engineer + QA Engineer + Performance Engineer + UI/UX Engineer
**Primary Rule:** पहले समझो → फिर जांचो → फिर fix करो → उसी समय verify करो → document करो → तभी आगे बढ़ो।

---

# 1. ABSOLUTE SOURCE OF TRUTH

`Fix.md` इस project का primary functional source of truth है।

इसके अलावा:

`BSRPRO_VAULT_AI_MASTER_RULES.md`

इस document में project के permanent development rules, security rules, workflow, change-control और historical record रहेगा।

### हर task शुरू करने से पहले:

1. `Fix.md` पढ़ो।
2. यह Master Rules document पढ़ो।
3. पिछले fixes/history पढ़ो।
4. Current code को समझो।
5. User द्वारा बताई गई exact समस्या identify करो।
6. तभी code touch करो।

**बिना context पढ़े सीधे code बदलना STRICTLY PROHIBITED है।**

---

# 2. ONE-DOCUMENT HISTORY RULE

हर build/fix की history इसी एक master document में maintain होगी।

अलग-अलग:

- Fix1.md
- Fix2.md
- Fix3.md
- FinalFix.md
- LatestFix.md

जैसी files बनाकर history को scatter मत करो।

हर completed change को इसी document के:

`CHANGE HISTORY`

section में append/update करो।

हर entry में:

- Build/version
- Date
- Reported problem
- Root cause
- Files changed
- Exact logic changed
- Why it was changed
- Test performed
- Result
- Regression risk
- Rollback information
- Backup/reference
- Final status

लिखना जरूरी है।

इससे अगर भविष्य में कोई bug वापस आए तो पहले देखो कि यह logic पहले कब बदला था और क्यों बदला था।

---

# 3. USER BUG = ONLY THAT FEATURE FIRST

जब user कहता है:

> "AutoFill में problem है"

तो सबसे पहले केवल AutoFill system को trace करो।

दूसरे unrelated features को modify मत करो।

### Required investigation:

`User Report → Feature Boundary → Relevant Files → Call Flow → Root Cause → Fix → Test`

उदाहरण:

AutoFill issue होने पर:

- AutoFill Service
- service lifecycle
- request handling
- credential matching
- biometric/PIN authentication
- autofill response
- browser/app detection
- background process
- timeout
- race condition
- service restart
- logs/errors

check करो।

Backup, UI, database या unrelated feature तभी touch करो जब actual root cause उससे directly जुड़ा हो।

---

# 4. NO RANDOM FIXING

किसी एक bug को fix करने के नाम पर:

- unrelated code refactor
- UI redesign
- database rewrite
- package change
- encryption change
- backup format change
- dependency replacement

मत करो।

अगर ऐसा change वास्तव में आवश्यक है तो पहले document करो:

**Why this change is required**

और फिर impact analysis करो।

---

# 5. ROOT CAUSE FIRST

हर bug के लिए केवल symptom fix स्वीकार नहीं है।

गलत:

> "AutoFill slow था इसलिए 2 second delay हटाया।"

सही:

> Request lifecycle में duplicate initialization + unnecessary authentication wait मिला → duplicate initialization हटाया → authentication flow optimized किया → lifecycle/restart tests किए।

हर fix में:

**Symptom → Root Cause → Correct Fix → Verification**

होना चाहिए।

---

# 6. STOP CONDITION

अगर user द्वारा बताई गई समस्या का कारण code में स्पष्ट नहीं है:

**Guess करके code मत बदलो।**

पहले:

- relevant files inspect करो
- call flow trace करो
- logs/errors check करो
- dependency/API behavior verify करो
- existing implementation समझो

अगर फिर भी required behavior अस्पष्ट है और कोई safe assumption संभव नहीं है, user से clarification मांगो।

लेकिन केवल इसलिए clarification मत मांगो क्योंकि investigation करने में मेहनत लगती है।

---

# 7. CHANGE BEFORE/AFTER RULE

हर code modification से पहले identify करो:

### BEFORE

Current behavior क्या है?

### AFTER

Expected behavior क्या होना चाहिए?

### CHANGE

कौन-सी exact logic बदलेगी?

### RISK

इस change से कौन-कौन से existing features प्रभावित हो सकते हैं?

फिर implementation करो।

---

# 8. IMMEDIATE VERIFICATION RULE

सबसे महत्वपूर्ण rule:

**एक change करके उसे बिना verify किए अगले change पर मत जाओ।**

हर meaningful code change के तुरंत बाद:

1. Compile/type/syntax check
2. Relevant static checks
3. Relevant runtime test
4. Error/log check
5. Regression check

करो।

अगर error मिला:

**STOP → FIX → VERIFY AGAIN**

फिर आगे बढ़ो।

इससे अंत में दोबारा पूरा audit करने की जरूरत कम होगी।

---

# 9. DEAD/OLD CODE RULE

अगर नया logic पुराने logic को replace करता है तो पुराना dead implementation:

- duplicate function
- unused class
- obsolete listener
- duplicate service
- unused import
- old fallback
- unreachable branch

सिर्फ इसलिए मत छोड़ो कि "शायद काम आएगा"।

लेकिन delete करने से पहले verify करो कि वह कहीं दूसरे feature द्वारा use नहीं हो रहा।

यदि uncertain हो तो पहले reference/search करके verify करो।

---

# 10. NO DOUBLE IMPLEMENTATION

एक feature के लिए दो competing implementations मत रखो।

उदाहरण:

अगर नया AutoFill authentication flow बनाया गया है और पुराना flow अब use नहीं होता, तो दोनों को parallel रखने से:

- race condition
- duplicate callback
- inconsistent state
- unpredictable behavior

हो सकता है।

एक authoritative implementation रखो।

---

# 11. DATA SAFETY — HIGHEST PRIORITY

Password manager में:

**DATA LOSS IS MORE SERIOUS THAN A UI BUG.**

किसी भी change से:

- passwords
- usernames
- notes
- credentials
- encryption keys
- backup files
- history
- settings
- user database

delete/corrupt/overwrite नहीं होने चाहिए।

Database schema बदलने से पहले migration plan आवश्यक है।

---

# 12. BACKUP SAFETY

Backup system में:

### कभी भी:

- existing valid backup को failed backup से overwrite मत करो।
- incomplete backup को valid backup मत मानो।
- corrupt backup को silently replace मत करो।
- failed restore के बाद backup modify मत करो।

### Preferred flow:

`Create Temporary Backup → Validate → Encrypt → Verify → Atomic Replace`

अगर किसी step में failure हो:

`Keep Previous Valid Backup`

---

# 13. RESTORE SAFETY

Restore से पहले:

1. Backup exists?
2. File readable?
3. Format valid?
4. Version supported?
5. Encryption valid?
6. Master Password/key valid?
7. Data integrity valid?

तभी restore करो।

Failure पर original user database सुरक्षित रहना चाहिए।

---

# 14. AUTOMATIC BACKUP RULE

Automatic backup:

- background में चले
- UI freeze न करे
- repeated prompts न दे
- unnecessary duplicate backups न बनाए
- selected folder/permission का सम्मान करे
- failed backup पर old valid backup सुरक्षित रखे

Backup operation interrupt हो जाए तो recovery mechanism होना चाहिए।

---

# 15. AUTOMATIC RESTORE / REINSTALL

Reinstall recovery में:

1. Backup location detect करो।
2. Valid backup detect करो।
3. Backup metadata/version verify करो।
4. Master Password/key से decrypt करने की कोशिश करो।
5. Password गलत हो तो backup को touch मत करो।
6. Clear error/status दो।
7. Valid होने पर safe restore करो।

Possible errors:

- No backup found
- Folder unavailable
- Permission denied
- Wrong Master Password
- Decryption failed
- Corrupt backup
- Unsupported backup version
- Integrity check failed

---

# 16. SECURITY RULES

Password Manager में security को convenience के लिए कमजोर मत करो।

Never:

- plaintext passwords logs में डालो
- master password store करो
- encryption key hardcode करो
- secrets source code में रखो
- sensitive data unnecessarily clipboard में रखो
- insecure random generator use करो
- authentication bypass करो
- biometric result को केवल UI state मानकर trust करो

Encryption/key handling existing architecture के साथ compatible और secure रहनी चाहिए।

---

# 17. AUTOFILL RULES

AutoFill को:

- fast
- reliable
- deterministic
- lifecycle-safe

रखो।

Check:

- service binding
- initialization
- duplicate requests
- request cancellation
- authentication
- biometric
- PIN fallback
- process death
- force stop
- app restart
- device restart
- browser restart
- timeout
- credential matching
- multiple accounts
- wrong website/app matching
- repeated refill

Unnecessary sleep/delay/polling हटाओ।

लेकिन security authentication को केवल speed के लिए bypass मत करो।

---

# 18. AUTHENTICATION RULE

Authentication state को properly manage करो।

Possible states clearly defined हों:

`Unauthenticated → Authenticating → Authenticated → Locked → Expired`

Race conditions रोकें।

Biometric failure, cancellation, timeout और fallback correctly handle हों।

---

# 19. PERFORMANCE RULE

UI thread को heavy काम के लिए block मत करो।

Database, encryption, backup, compression, migration आदि उचित background mechanism में चलें।

लेकिन "background" का मतलब uncontrolled thread creation नहीं है।

Use project-appropriate:

- Coroutines
- WorkManager
- structured concurrency
- lifecycle-aware operations

जहाँ applicable हो।

---

# 20. LANGUAGE / TECHNOLOGY RULE

पहले project की actual technology identify करो।

उदाहरण:

- Kotlin/Java → Android
- JavaScript/TypeScript → Extension/Web/PWA
- Flutter/Dart → Flutter
- React Native → JS/TS + native bridge

**Project की existing technology को बिना कारण दूसरी language/framework में migrate मत करो।**

अगर code Kotlin में है तो Kotlin standards follow करो।

अगर JavaScript/TypeScript है तो उसी ecosystem के standards follow करो।

अगर नया code existing architecture में जोड़ना है तो उसी architecture/pattern को follow करो।

---

# 21. LANGUAGE UPDATE RULE

अगर काम के दौरान newer API/library/language feature उपलब्ध मिले:

पहले check करो:

- project compatibility
- min SDK
- target SDK
- browser compatibility
- existing dependencies
- migration risk
- security benefit
- performance benefit

केवल "नया है" इसलिए upgrade मत करो।

यदि upgrade जरूरी है तो अलग change के रूप में document करो और regression test करो।

---

# 22. BUILD & DEPENDENCY RULE

कोई dependency जोड़ने से पहले:

- क्या इसकी वास्तव में जरूरत है?
- क्या existing dependency से काम हो सकता है?
- security reputation?
- maintenance?
- package size?
- compatibility?
- license?

check करो।

Unnecessary dependency prohibited है।

---

# 23. ERROR HANDLING

हर important operation में meaningful error handling हो।

Silent failure नहीं।

लेकिन user को internal stack trace या sensitive information मत दिखाओ।

Developer logs में भी secrets नहीं होने चाहिए।

---

# 24. LOGGING RULE

Production code में:

- password
- master password
- encryption key
- token
- backup contents
- personal credential data

log नहीं होना चाहिए।

Debug logging केवल जरूरत होने पर और safe form में।

Final production build में unnecessary debug logs हटाओ।

---

# 25. TESTING RULE

हर feature के लिए minimum:

### Normal case

काम करता है?

### Failure case

गलत input पर सुरक्षित रहता है?

### Restart case

restart के बाद काम करता है?

### Recovery case

failure के बाद वापस काम करता है?

### Regression case

दूसरा feature नहीं टूटा?

### Security case

कोई bypass/data exposure तो नहीं?

---

# 26. LARGE DATA TEST

Password manager को केवल 5 passwords से test मत करो।

जहाँ applicable हो:

- hundreds of credentials
- large history
- large backup
- duplicate sites
- multiple accounts
- repeated AutoFill requests

के साथ test करो।

---

# 27. USER-REPORTED BUG WORKFLOW

जब user बोले:

> "इस feature में problem है"

AI का exact workflow:

### STEP 1

User की complaint को एक exact issue statement में बदलो।

### STEP 2

Feature boundary तय करो।

### STEP 3

उस feature से जुड़े files/functions/classes खोजो।

### STEP 4

Call flow trace करो।

### STEP 5

Logs/errors inspect करो।

### STEP 6

Historical CHANGE HISTORY check करो।

### STEP 7

देखो यह logic पहले क्यों बदला गया था।

### STEP 8

Root cause identify करो।

### STEP 9

Minimal safe fix बनाओ।

### STEP 10

Code change करो।

### STEP 11

तुरंत compile/static/runtime verification करो।

### STEP 12

Related regression tests करो।

### STEP 13

PASS होने पर ही next task करो।

### STEP 14

इस change को उसी Master Document में record करो।

---

# 28. DO NOT FIX A DIFFERENT FEATURE

अगर user ने AutoFill कहा है और investigation में Backup का unrelated bug दिख गया:

पहले AutoFill पूरा करो।

Backup issue को अलग "Discovered Issue" में record करो।

बिना permission unrelated feature बदलना नहीं है, जब तक वह AutoFill root cause न हो।

---

# 29. SECURITY-SENSITIVE AREA RULE

इन areas में extra caution:

- Master Password
- Encryption
- Key derivation
- Biometric
- PIN
- AutoFill authentication
- Backup encryption
- Database migration
- Credential storage

इनमें cosmetic या experimental changes नहीं।

पहले existing implementation समझो।

---

# 30. ROLLBACK RULE

हर risky change के लिए पता होना चाहिए:

**अगर नया code fail हुआ तो previous working implementation पर कैसे लौटेंगे?**

Git history, previous build या backup reference उपलब्ध रखें।

लेकिन production में पुराने insecure/dead code को blindly restore मत करो।

---

# 31. GIT / VERSION CONTROL

हर meaningful stable milestone को version/commit से identify करो।

Commit message meaningful हो:

`fix: autofill biometric timeout`

या

`fix: atomic encrypted backup restore`

ऐसा नहीं:

`update`
`changes`
`final`
`new`

---

# 32. BUILD HISTORY

हर final build को identify करो:

`Version / Build Number / Date / Commit`

और Master Document में record करो।

उदाहरण:

| Build | Change                 | Result |
| ----- | ---------------------- | ------ |
| 1.0.1 | AutoFill lifecycle fix | PASS   |
| 1.0.2 | Backup atomic write    | PASS   |
| 1.0.3 | Biometric timeout fix  | PASS   |

---

# 33. CHANGE HISTORY FORMAT

हर change के लिए:

```text
## CHANGE ENTRY

Build:
Date:

Reported Problem:

Affected Feature:

Root Cause:

Files Changed:

Functions/Classes Changed:

Previous Logic:

New Logic:

Why This Fix Is Safe:

Security Impact:

Data Impact:

Performance Impact:

Tests Performed:

Regression Tests:

Result:

Rollback Reference:

Status:
PASS / PARTIAL / FAILED

```

---

# 34. FAILED CHANGE RULE

अगर change fail हो:

उसको छुपाना नहीं है।

Document करो:

- क्या किया
- क्यों fail हुआ
- क्या वापस rollback किया
- नया approach क्या होगा

Failed attempt को history से delete मत करो।

यह future developer को वही गलती दोहराने से बचाएगा।

---

# 35. DISCOVERED BUG RULE

काम करते समय कोई दूसरा bug मिले:

उसे तुरंत fix करना आवश्यक नहीं है।

पहले:

`DISCOVERED ISSUES`

में record करो।

अगर वह current issue का root cause है → fix करो।

अगर unrelated है → user approval/appropriate task मिलने तक untouched रखो।

---

# 36. SMALL AI / LOW-CAPABILITY AI RULE

अगर कोई AI project को पूरी तरह समझने में सक्षम नहीं है:

उसे sensitive/core architecture बदलने की अनुमति नहीं है।

वह:

- documentation पढ़ सकता है
- issue identify कर सकता है
- analysis दे सकता है
- safe minor changes कर सकता है

लेकिन बिना complete context के:

- encryption
- database schema
- backup format
- authentication
- AutoFill security
- migration

नहीं बदले।

---

# 37. SENIOR AI / ADVANCED DEVELOPER RULE

यदि capable Senior AI/Developer available है:

वह केवल requested bug fix तक सीमित नहीं रहेगा बल्कि:

- root cause
- architecture
- security
- performance
- regression
- maintainability

भी evaluate करेगा।

लेकिन फिर भी **scope creep नहीं करेगा**।

---

# 38. NO FAKE COMPLETION

AI कभी यह न कहे:

> "Fixed"

जब तक actual verification न हुई हो।

Status केवल:

`VERIFIED PASS`

तभी दें जब test evidence available हो।

अगर test नहीं चल पाया:

`NOT VERIFIED`

लिखें।

---

# 39. CLOUD / TIME / RESOURCE LIMIT RULE

अगर available execution/cloud/tool time या context limit के कारण पूरा task complete करना संभव नहीं है:

काम silently अधूरा छोड़कर final मत कहो।

पहले बताओ:

- क्या complete हुआ
- क्या बाकी है
- कहाँ limitation आई
- कितना काम realistically बाकी है
- कौन-सा part सुरक्षित है
- कौन-सा part touch नहीं किया गया

अगर current environment में build/ZIP संभव नहीं है तो स्पष्ट बताओ।

**Never pretend that ZIP/build was created or tested when it was not.**

---

# 40A. FINAL ZIP NAMING RULE

Final ZIP का filename हमेशा इसी fixed base name से शुरू और समाप्त होगा:

`BSRPRO PM Android.<SEQUENTIAL_NUMBER>.zip`

उदाहरण:

- `BSRPRO PM Android.1.zip`
- `BSRPRO PM Android.2.zip`
- `BSRPRO PM Android.3.zip`
- `BSRPRO PM Android.4.zip`

### Mandatory rules

1. हर नया final ZIP पिछले final ZIP से sequential number में **+1** होगा।
2. Base name हमेशा exactly **`BSRPRO PM Android`** रहेगा।
3. Number के बाद `.zip` के अलावा कोई दूसरा suffix/prefix नहीं होगा।
4. `final`, `fixed`, `polished`, `updated`, `cl-updated`, date, time, build name, commit hash या कोई अन्य पहचान filename में नहीं जोड़ी जाएगी।
5. यदि ZIP के अंदर build/version/commit पहचान चाहिए तो वह Master Document/CHANGE HISTORY में दर्ज होगी, filename में नहीं।
6. ZIP बनाने से पहले अगला sequential number history और उपलब्ध final ZIPs से verify करना आवश्यक है।
7. किसी पुराने ZIP को overwrite नहीं करना है; नया milestone नया sequential number लेगा।
8. ZIP बनने के बाद उसी exact filename से archive extraction/integrity verification करना होगा।

**Golden filename format:** `BSRPRO PM Android.1.zip → BSRPRO PM Android.2.zip → BSRPRO PM Android.3.zip → ...`

---

# 40. FINAL ZIP RULE

Final ZIP तभी बनाओ जब:

- requested fixes complete हों
- build succeeds
- relevant tests pass हों
- no critical security issue हो
- no known data-loss risk हो
- no unresolved compile error हो
- required files मौजूद हों
- ZIP contents verify किए गए हों

ZIP बनाने के बाद ZIP को खोलकर verify करो कि files वास्तव में मौजूद हैं।

---

# 41. FINAL POLISH

Final release से पहले:

- TODO
- FIXME
- placeholder
- dead code
- duplicate implementation
- debug logs
- unused imports
- unused dependency
- broken reference
- unnecessary permission
- obsolete migration
- stale comments

check करो।

लेकिन किसी potentially-used code को केवल "unused दिख रहा है" के आधार पर delete मत करो।

---

# 42. ZERO REGRESSION POLICY

Existing working functionality को preserve करना है।

हर fix के बाद पूछो:

> "क्या इस change से कोई existing feature टूट सकता है?"

अगर हाँ:

- test करो
- guard करो
- migration दो
- rollback तैयार रखो

---

# 43. USER DATA FIRST

Priority हमेशा:

**User Data Safety > Security > Correctness > Reliability > Performance > UI Polish**

लेकिन security को data safety के खिलाफ sacrifice नहीं करना है।

---

# 44. FINAL AUDIT

Final build से पहले पूरा project audit करो:

### Core

[ ] Master Password
[ ] Encryption
[ ] Credential storage
[ ] Add/Edit/Delete
[ ] Search
[ ] History

### AutoFill

[ ] Fast AutoFill
[ ] Authentication
[ ] Biometric
[ ] PIN fallback
[ ] Service restart
[ ] Process death
[ ] Correct matching

### Backup

[ ] Automatic backup
[ ] Manual backup
[ ] Encryption
[ ] Atomic write
[ ] Automatic restore
[ ] Reinstall recovery
[ ] Wrong password
[ ] Corrupt backup
[ ] Version migration

### Security

[ ] No plaintext secrets
[ ] Secure key handling
[ ] Secure authentication
[ ] Clipboard protection
[ ] Session locking
[ ] No sensitive logs

### Reliability

[ ] Crash checks
[ ] ANR checks
[ ] Race conditions
[ ] Large database
[ ] Restart/recovery
[ ] Permission failure

### Code

[ ] No TODO
[ ] No placeholder
[ ] No duplicate logic
[ ] No unnecessary dependency
[ ] No dead code
[ ] No debug code

### Release

[ ] Build PASS
[ ] Runtime PASS
[ ] Regression PASS
[ ] Security PASS
[ ] ZIP verified
[ ] CHANGE HISTORY updated

---

# 45. FINAL RESPONSE FORMAT TO USER

हर completed task के बाद concise report:

```text
TASK:
क्या fix किया गया।

ROOT CAUSE:
असल समस्या क्या थी।

CHANGED:
कौन-सी files/logic बदली।

VERIFICATION:
क्या-क्या test हुआ।

RESULT:
PASS / PARTIAL / FAILED

DATA SAFETY:
No data loss / Risk identified

SECURITY:
PASS / Issue

REGRESSION:
PASS / Issue

BUILD:
Build number/version

HISTORY:
Master document में entry update की गई।

```

---

# 46. GOLDEN RULE

## THINK BEFORE CODE.

## READ BEFORE CHANGE.

## TRACE BEFORE FIX.

## FIX ONLY THE ACTUAL PROBLEM.

## VERIFY IMMEDIATELY AFTER EVERY CHANGE.

## NEVER SACRIFICE USER DATA OR SECURITY.

## NEVER CLAIM PASS WITHOUT TESTING.

## DOCUMENT EVERY IMPORTANT CHANGE IN ONE MASTER HISTORY.

## NEVER MAKE THE USER EXPLAIN THE SAME PROJECT CONTEXT AGAIN.

---

# PROJECT OPERATING PRINCIPLE

इस project को ऐसे maintain करो जैसे यह production में लाखों users का real password manager हो।

हर future developer/AI को इस document को देखकर समझ आना चाहिए:

- project क्या है
- कौन-सी technology है
- कौन-सा feature कैसे काम करता है
- कौन-सी समस्या पहले आई थी
- उसका root cause क्या था
- कौन-सा code बदला गया
- क्यों बदला गया
- कौन-सा solution fail हुआ
- कौन-सा solution काम किया
- कौन-सा backup/build safe है
- किसी पुराने bug के वापस आने पर कहाँ से investigation शुरू करनी है

**इस document का उद्देश्य AI को अधिक code लिखवाना नहीं, बल्कि AI को गलत code लिखने से रोकना है।**

यदि कोई instruction इस document से conflict करे, तो पहले conflict identify करो और user से clarification लो।

**BSRPRO Vault को हमेशा Safe → Correct → Tested → Documented → Production Ready अवस्था में आगे बढ़ाओ।**
---

# 48. CHANGE HISTORY — UNIFIED AUTOFILL AUTHORITY

## CHANGE ENTRY

Build:
BSRPRO PM Android Twelve (source milestone; APK build not verified in this environment)

Date:
2026-10-06

Reported Problem:
Autofill authentication behaved like a separate session with its own timer, while the vault had additional session/background timing. This could cause an Autofill unlock prompt even though the vault was already authenticated and made the authentication model harder to reason about.

Affected Feature:
Android Autofill authentication/session handling.

Root Cause:
`AutofillSessionGate` owned an independent elapsed-time expiry window (`autofillSessionSeconds`) in addition to `SessionKeyStore`, which already owns the actual decrypted vault session and its expiry.

Files Changed:
- `app/src/main/java/pro/babasitaram/vault/autofill/AutofillSessionGate.kt`
- `app/src/main/java/pro/babasitaram/vault/autofill/AutofillAuthActivity.kt`
- `app/src/main/java/pro/babasitaram/vault/autofill/VaultAutofillService.kt`
- `app/src/main/java/pro/babasitaram/vault/core/model/VaultSettings.kt`
- `app/src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt`
- `docs/FIX_MD_STATUS.md`

Functions/Classes Changed:
- `AutofillSessionGate.isValid/touch/clear`
- Autofill service/auth activity session checks
- Settings presentation for the separate Autofill duration

Previous Logic:
Autofill had a separate short-lived gate whose expiry was controlled by `autofillSessionSeconds`. The gate could expire while the vault session was still valid, causing another Autofill authentication flow.

New Logic:
`SessionKeyStore` is the single authoritative authentication/session state. `AutofillSessionGate` is now only a compatibility facade and does not own an expiry clock. Autofill `touch()` no longer extends a second timer. The separate Autofill unlock-duration control is removed from the Settings UI; its persisted field remains only for backward-compatible migration.

Why This Fix Is Safe:
No vault database, credential records, encryption format, backup format, restore format, or master-password data is changed. The change removes a competing in-memory Autofill timer rather than changing stored vault data.

Security Impact:
Improves consistency by preventing a second Autofill-only authentication state from diverging from the real vault session. Autofill still requires a valid authenticated vault session before sensitive datasets are returned.

Data Impact:
No data migration. No credential/database/backup changes.

Performance Impact:
Removes an independent Autofill timer and its lifecycle/broadcast bookkeeping. Autofill uses the existing vault session validity check.

Tests Performed:
- Source inspection of Autofill service, authentication activity, session store, auto-lock controller, settings, and restore flow.
- Static reference search after edits.
- Web verification against current Android Autofill documentation for authenticated datasets and inline fallback behavior.
- Android/Gradle compilation: NOT VERIFIED in this environment because Android SDK/Gradle executable is unavailable.
- Device runtime Autofill test: NOT VERIFIED.

Regression Tests:
NOT RUN — requires Android build/device execution.

Result:
PARTIAL — source change applied; build/runtime evidence unavailable in this environment.

Rollback Reference:
Previous source package: BSRPRO-PM-Android.11.zip. The entire working tree was copied before editing.

Status:
PARTIAL


# PERMANENT APP-LOGIN BACKUP/RESTORE SAFETY RULE

Native Android app-login credentials are a protected data boundary. Backup/import/restore code MUST NOT silently remove or downgrade an existing app login. Unless the user explicitly deletes the credential, preserve its `appPackage`, `appName`, `loginUri`, `appPin`, `isPrimaryAppLogin`, and existing password when an incoming backup omits those fields or omits the record. Incoming non-empty credential changes remain authoritative. This rule must be checked before any future backup, restore, import, migration, or Autofill-related code change.

# PERMANENT AUTOFILL DEADLINE RULE

`AutofillService.onFillRequest()` is a short-deadline framework callback. Never perform KDF, vault decryption, Keystore credential restore, backup I/O, network I/O, or other potentially slow work inside the request path merely to obtain an authenticated session.

Required pattern:

`FillRequest → parse/match fast → return response/dataset → user authentication in authentication activity when needed → authenticated Dataset result`

A slow process-death restore belongs after the user selects the authenticated Autofill action, not inside `onFillRequest`. A timeout workaround must never hide a lifecycle/deadline root cause.

# PERMANENT SINGLE VAULT LOCK-TIMER RULE

There is exactly one authoritative vault authentication expiry: `SessionKeyStore`.

`backgroundGraceSeconds` and any legacy Autofill duration fields may remain only for backward-compatible storage/migration. They must not own a second expiry clock, background lock job, or independent authentication state.

Changing the Vault auto-lock setting must apply to the active authenticated session immediately. Backgrounding the app must not restart, shorten, or replace the same session countdown. Process-death recovery may use an encrypted biometric credential only within the same absolute session expiry.

# CHANGE HISTORY — BUILD FOURTEEN SOURCE FIX

## CHANGE ENTRY

Build:
BSRPRO PM Android Fourteen (source artifact; APK/build not verified)

Date:
2026-10-06

Reported Problems:
1. Android password fill/autofill/keyboard suggestion repeatedly produced zero useful result. User device log showed repeated `onFillRequest`, successful parsing for `com.jio.jpp1`, then cancellation and `build timeout — request deadline guard` before a response.
2. A 15-minute vault/background configuration could lock earlier than expected after closing and reopening the app because two separate timeout policies existed.
3. Login/setup, loading, lock/biometric and Autofill authentication UI needed consistent BSRPRO branding/layout.

Root Causes:
- `VaultAutofillService` performed a potentially slow persisted-session restore inside the short-deadline `onFillRequest` path. The 3.5s restore + 4.25s outer guard could outlive Android's request window, producing the exact supplied cancellation/empty-response pattern.
- `vaultSessionSeconds` and `backgroundGraceSeconds` were both treated as active lock policies. Background lifecycle could start a second timer independent of the absolute session.
- Branding was implemented separately on several authentication/loading surfaces.

Files Changed:
- `app/src/main/java/pro/babasitaram/vault/autofill/VaultAutofillService.kt`
- `app/src/main/java/pro/babasitaram/vault/autofill/AutofillDatasetFactory.kt`
- `app/src/main/java/pro/babasitaram/vault/autofill/AutofillAuthActivity.kt`
- `app/src/main/java/pro/babasitaram/vault/core/crypto/SessionKeyStore.kt`
- `app/src/main/java/pro/babasitaram/vault/core/security/AutoLockController.kt`
- `app/src/main/java/pro/babasitaram/vault/domain/usecase/RestorePersistedSessionUseCase.kt`
- `app/src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsViewModel.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/setup/SetupScreen.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/root/StartupSplash.kt`
- relevant Autofill/session tests and unified lock static test
- this master history and `docs/FIX_MD_STATUS.md` / `docs/CHANGELOG_1.0.0.md`

Exact Logic Changed:
- `onFillRequest` no longer performs persisted-session restore/KDF/Keystore work. It returns the locked authentication dataset immediately when the in-memory session is unavailable.
- Settings are cached from the `SettingsRepository` flow in the Autofill service so the request callback does not wait for DataStore I/O.
- The BSRPRO logo is used as the fallback icon for the Autofill suggestion instead of an alphabet avatar when no target-app icon exists.
- `SessionKeyStore` gained an active-session timeout update API plus an expiry-version signal so `AutoLockController` reschedules its one expiry job when the user changes the timeout.
- `AutoLockController` no longer has a background timer. Backgrounding only records process-death metadata.
- Persisted session restore uses the same absolute session expiry and no longer expires solely because the app was backgrounded.
- Settings now exposes one authoritative `Vault auto-lock` control. The old background timeout is retained only as a compatibility mirror.
- Authentication/setup/loading surfaces use consistent centered BSRPRO branding.

Why:
The Autofill request path must finish quickly and deterministically; user authentication belongs after the framework displays/selects the authenticated Autofill action. A single vault timeout avoids conflicting lock semantics and makes 15-minute behavior predictable across foreground/background. UI changes are limited to directly affected authentication/loading surfaces.

Data Safety:
No vault database, credential records, master-password format, encryption format, V3 backup format, or restore data schema was changed. Existing app-login backup protection from Build Thirteen remains in place.

Security:
No authentication bypass was added. Locked Autofill still requires the authentication dataset flow. Process-death recovery still depends on the existing encrypted biometric credential and the same absolute session expiry.

Verification:
- Static source checks: PASS.
- Edited Kotlin brace/syntax-structure checks: PASS.
- ZIP integrity test (`unzip -t`): PASS.
- Android Gradle compile: NOT VERIFIED — Android SDK/Gradle executable unavailable in authoring sandbox.
- Unit tests: NOT RUN — Android build runner unavailable.
- Device Autofill/keyboard/lock runtime: NOT VERIFIED. The supplied device log was used for root-cause analysis; runtime confirmation remains required.

Rollback:
Previous source artifact: `BSRPRO PM Android Thirteen.zip`.
Working tree was copied before Build Fourteen changes.

Final Status:
SOURCE APPLIED — BUILD/DEVICE VERIFICATION PENDING.

---

# CHANGE HISTORY — BUILD SIXTEEN SOURCE FIX

## BSRPRO PM Android Sixteen (source artifact; APK/build not verified)

**Date:** 2026-10-06

**Reported problem:** Bin screen was visually oversized and exposed confusing global `Restore all` and `Empty Bin` actions. User requested checkbox selection for one/many restore or permanent delete, Select all, single-item delete, and a cleaner UI/logic.

**Root cause:** UI exposed repository-wide operations instead of selection-aware operations; repository had no selected-ID restore/permanent-delete methods.

**Files changed:**
- `app/src/main/java/pro/babasitaram/vault/domain/repository/VaultRepository.kt`
- `app/src/main/java/pro/babasitaram/vault/data/repository/VaultRepositoryImpl.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/bin/BinViewModel.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/bin/BinScreen.kt`
- `app/src/test/java/pro/babasitaram/vault/data/VaultRepositoryImplTest.kt`
- `docs/FIX_MD_STATUS.md`
- `docs/CHANGELOG_1.0.0.md`

**Exact logic changed:**
- Added `restoreSelected(ids)` and `permanentlyDelete(ids)` repository operations.
- Each operation performs one encrypted write and publishes the resulting vault state.
- Bin UI now has a master checkbox, per-entry checkboxes, selected count, selected Restore, selected permanent Delete, and a per-entry permanent-delete icon.
- Permanent deletion remains confirmation-protected.
- Automatic 30-day cleanup is unchanged.

**Why:** provide predictable, granular, non-destructive restore and explicit destructive deletion without exposing an accidental whole-bin delete action.

**Verification:** existing source regression suite 78/78 PASS; item-action audit PASS; production polish source gate PASS. New repository regression tests added for selected restore and selected permanent delete. Android compile/device runtime NOT VERIFIED in this sandbox due missing Android SDK/Gradle executable.

**Rollback:** revert the Build Sixteen changes above or use the previous Build Fifteen source ZIP as the known prior source reference.


---

# CHANGE HISTORY — DEVICE CREDENTIAL FALLBACK (NO-BIOMETRIC DEVICES)

## CHANGE ENTRY

**Build/version:** 1.0.0 (versionCode 30 unchanged) — source fix, APK/device NOT VERIFIED
**Date:** 2026-10-07

**Reported problem:** On devices with no fingerprint/face hardware (but with a working Android PIN/Pattern/Password) unlock showed "Biometric hardware unavailable" and the user was pushed to Master Password.

**Root cause:** `BiometricAuthenticator.availability()` and `authenticate()` already use `BIOMETRIC_STRONG or DEVICE_CREDENTIAL`, so the UI correctly offered quick unlock. But every crypto-bound path (`authenticateWithCipher`, used by LockViewModel, AutofillAuthActivity, SettingsViewModel, VaultListViewModel) is `BIOMETRIC_STRONG` only (CryptoObject cannot be combined with DEVICE_CREDENTIAL below API 30). On a device without a usable biometric that prompt returns `ERROR_HW_NOT_PRESENT / ERROR_HW_UNAVAILABLE / ERROR_NO_BIOMETRICS` (and `ERROR_LOCKOUT*`). `mapAuthError` turned these into `AuthResult.Error`, which every caller shows as an error message instead of using the already-existing device-credential fallback (reached only via `FallbackRequested`).

**Files changed:**
- `core/security/BiometricAuthenticator.kt` — new `isBiometricSensorUnusable()`; `mapAuthError` maps those codes to `FallbackRequested`.
- `presentation/lock/LockViewModel.kt`, `autofill/AutofillAuthActivity.kt` — `FallbackRequested` from the credential prompt itself no longer silently ignored (Master Password shown; never stuck).
- `test/.../BiometricAuthenticatorTest.kt` — lockout test updated; added no-hardware, no-device-credential, cancel tests.

**Exact logic changed:** biometric-sensor-unusable error codes => `FallbackRequested` => existing flow calls `authenticate()` (system prompt, `BIOMETRIC_STRONG or DEVICE_CREDENTIAL`) => Success => Key B (24h auth window, `AUTH_BIOMETRIC_STRONG or AUTH_DEVICE_CREDENTIAL` on API 30+) decrypts the stored master credential. `ERROR_NO_DEVICE_CREDENTIAL`, cancel and wrong-credential behaviour unchanged (still Error / Cancelled / not unlocked).

**Security:** App never reads/stores device PIN/Pattern/Password; only Android's system prompt result is used. Device PIN is NOT the internal App PIN (`AppPinStore`) — the two are not merged.

**Known gap:** API 26–29. `BIOMETRIC_STRONG or DEVICE_CREDENTIAL` is reported unsupported by AndroidX Biometric on API 28–29, so `availability()` is `Unsupported` there and Master Password is used. A legacy `KeyguardManager.createConfirmDeviceCredentialIntent` path is NOT implemented yet.

**Test performed:** JVM unit tests added (not executed — no Android SDK/Gradle in sandbox). Real-device matrix (fingerprint, face, PIN-only, pattern-only, password-only, biometric+PIN, cancel, wrong PIN, process kill, credential removed) NOT RUN.

**Result:** PARTIAL — code fix applied, unverified on devices.

**Regression risk:** Biometric lockout now offers device credential (Android-recommended). Master Password, backup/restore, AutoFill dataset auth, internal PIN untouched.


---

# CHANGE HISTORY — UNLOCK SPEED (EMPTY LIST AFTER UNLOCK)

## CHANGE ENTRY

**Build/version:** 1.0.0 (versionCode 30 unchanged) — source fix, NOT built/device-tested
**Date:** 2026-10-07

**Reported problem:** After unlock, passwords/entries appear late.

**Root cause:** `UnlockVaultUseCase` called `session.unlock()` (which flips `isUnlocked`, the trigger for `RootViewModel` navigation) BEFORE `repository.setData()`. The vault screen opened with an empty list and filled once setData/publish finished. Post-unlock housekeeping (`cleanupExpiredTrash`, rate-limit reset, session metadata, a second `settings.current()`) also ran before the unlock call returned. The single PBKDF2 (600k) derivation is required by the unchanged V3 format and was not touched.

**Files changed:** `domain/usecase/VaultSessionUseCases.kt` (`UnlockVaultUseCase.invoke`).

**Exact logic changed:** read settings once; `setData()` first, then `session.unlock()`, then housekeeping. Same operations, new order.

**Known remaining cost:** KDF itself (~0.3–1.5s, slower with non-ASCII master password via manual HMAC loop); biometric unlock still re-derives it. Caching a Keystore-wrapped derived key would remove that but changes stored secrets — NOT done.

**Test performed:** none (no Android SDK/Gradle in sandbox). **Result:** PARTIAL — unverified.

**Regression risk:** low; if `setData` throws, session stays locked (safer than before).


---

# CHANGE HISTORY — SENIOR REVIEW PASS (STABILITY / SMOOTHNESS)

## CHANGE ENTRY

**Build/version:** 1.0.0 (versionCode 30 unchanged) — source only, NOT built/device-tested
**Date:** 2026-10-07

**Scope reviewed:** project static tools (bracket_check 0 issues; all_fixes_regression 78/78; item_action_audit PASS; production_polish_audit PASS; static_audit/symbol_check hits manually verified as false positives: fully-qualified names / named arguments); grep for runBlocking, GlobalScope, `!!`, logging, manifest (allowBackup=false, cleartext off, minify+shrink on release, autofill/tile services permission-protected).

**Fixes:**
- `presentation/files/FileDetailScreen.kt`: `entry!!` after a null check on delegated state -> `entry ?: return` (removes a possible NPE if state changes between the two reads).
- `presentation/vault/VaultListViewModel.kt`: NAME and STRENGTH sorts compute keys once per entry instead of inside the comparator (less CPU on large vaults).

**Reviewed, left unchanged:** `AutoBackupManager.runBlockingRecovery()` — every call chain found (`findRestorableBackup`, backup read-back) runs on Dispatchers.IO; still a latent ANR risk if ever called from Main; recommend converting to suspend later. Autofill logcat logging is gated to debug builds and logs structure only.

**Test performed:** static tools above only (no Android SDK/Gradle in sandbox). **Result:** PARTIAL — unverified at runtime.


---

# CHANGE HISTORY — REMOVE runBlocking FROM BACKUP DISCOVERY

## CHANGE ENTRY

**Build/version:** 1.0.0 (versionCode 30 unchanged) — source only, NOT built/device-tested
**Date:** 2026-10-07

**Problem (latent):** `AutoBackupManager.findMediaStoreBackup()` called `runBlocking(Dispatchers.IO)` to run `recoverQuarantinedBackup()`. All current callers were on IO, but any Main-thread caller would block (ANR), and `runBlocking` inside coroutines can starve the dispatcher.

**Files changed:** `data/backup/AutoBackupManager.kt`

**Exact logic changed:**
- `findBackupFile()` is now `suspend` and runs its whole body inside `withContext(Dispatchers.IO)`.
- `findMediaStoreBackup()` is now `suspend` and calls `recoverQuarantinedBackup()` directly; `runBlockingRecovery()` deleted. No `runBlocking` remains in the project.
- `BackupFileDiscovery.safelyFind` is now `inline` so its lambda can call suspend functions. Same exceptions caught (SecurityException, IOException); CancellationException still propagates.
- Callers (`findRestorableBackup`, `verifyPersistedBackup`) were already suspend; the readback in `verifyPersistedBackup` now also reads off the caller's thread.

**Behaviour:** backup file naming (`BSRPRO.Vault`), V3 format, recovery order unchanged.

**Test performed:** bracket check 0 issues; source regression 78/78; polish gate PASS. Not compiled (no Android SDK/Gradle). **Result:** PARTIAL.

**Regression risk:** low, but compile is unverified — if the build fails, check `AutoBackupManager.kt` lines ~300-325 first.


---

# CHANGE HISTORY — QUICK UNLOCK WITHOUT PBKDF2 + API 28-29 DEVICE CREDENTIAL

## CHANGE ENTRY

**Build/version:** 1.0.0 (versionCode 30 unchanged) — source only, NOT built/device-tested
**Date:** 2026-10-07

### A. Biometric / device-credential unlock no longer re-runs the 600k PBKDF2
**Reported problem:** unlock is slow; biometric unlock still derived the vault key from the password every time.
**Design (V3 / vault file format UNCHANGED):**
- `VaultCrypto.decryptWithDerivedKey()` — decrypt with an already derived key; returns null on salt mismatch / GCM failure (never throws) so the normal path takes over.
- `FileVaultBlobStore.readFile()` — if the in-memory key cache matches (fingerprint = SHA-256(salt || password)) and the file salt matches, uses the fast path; otherwise PBKDF2 as before.
- `VaultBlobStore.exportKeyBlob()/primeKeyFromBlob()` (default no-op in the interface) — blob = salt || key || fingerprint; priming only succeeds when the blob is bound to the supplied password.
- `BiometricSessionKeyStore.saveDerivedKey()/loadDerivedKey()/hasDerivedKey()/clearDerivedKey()` — the blob is wrapped by Keystore Key B (same protection class as the already stored master credential: hardware-backed, user-authentication required, 24h window). New pref `biometric_derived_key_v1`. Cleared everywhere the credential is cleared/replaced (`clearSecureCredential`, `clearAllCredentials`, `resetForSecurityChange`, new `saveCredentialAfterAuthentication`), therefore also on master-password change.
- `UnlockVaultUseCase(password, quick = false)` — `quick=true` ONLY from biometric/device-credential paths (LockViewModel non-master method, AutofillAuthActivity prepared credential, RestorePersistedSessionUseCase). Loads+primes before reading; after a successful quick unlock stores the key if missing or stale. First quick unlock after enabling biometric is still one full KDF.
**Security:** no new secret class; the derived key is never written in plaintext; master-password unlock and Emergency Access never use the fast path; wrong password still rejected (fingerprint mismatch -> PBKDF2 -> GCM failure).

### B. API 26-29 device PIN/Pattern/Password
**Root cause:** AndroidX Biometric reports `BIOMETRIC_STRONG|DEVICE_CREDENTIAL` as UNSUPPORTED on API 28-29, so `availability()` returned Unsupported and Master Password was used.
**Fix:** `needsLegacyCredentialPrompt(sdk, combinedResult, deviceSecure)`; when true `availability()` is Available and `authenticate()` runs `legacyAuthenticate`: strong biometric (if enrolled) with a "use device PIN" button, otherwise `KeyguardManager.createConfirmDeviceCredentialIntent` via `activityResultRegistry`. RESULT_OK only means "system verified the user"; the real gate is Keystore Key B (time-bound), so a spoofed result decrypts nothing. App never reads/stores the PIN/Pattern/Password. No secure lock screen -> clear `ERROR_NO_DEVICE_CREDENTIAL` error, Master Password stays available.

**Files changed:** `core/crypto/VaultCrypto.kt`, `data/local/blob/VaultBlobStore.kt`, `core/security/BiometricSessionKeyStore.kt`, `core/security/BiometricAuthenticator.kt`, `domain/usecase/VaultSessionUseCases.kt`, `domain/usecase/RestorePersistedSessionUseCase.kt`, `presentation/lock/LockViewModel.kt`, `autofill/AutofillAuthActivity.kt`; tests: `FileVaultBlobStoreTest` (+4), `BiometricAuthenticatorTest` (+2).

**Test performed:** bracket check 0 issues, source regression 78/78; new JVM tests written but NOT executed (no Android SDK/Gradle in sandbox). Device matrix NOT run. **Result:** PARTIAL.
**If build fails, check first:** `BiometricAuthenticator.kt` (confirmDeviceCredential / legacyAuthenticate), `VaultSessionUseCases.kt` (UnlockVaultUseCase).
**If biometric unlock misbehaves:** clear the derived key (`BiometricSessionKeyStore.clearDerivedKey()`) — the app then simply uses PBKDF2 as before.
**Regression risk:** medium-low. V3 format, backups, Master Password flow unchanged.
