# Signing setup (fixed key) -- Phase 18

Format: Issue -> Fix -> Logic. NOT compiled, NOT device-tested.

## Issue
GitHub runner har baar naya debug key banata hai => har APK ki signature alag => naya APK purani app ke ooper install nahi hota ("App not installed"), uninstall karna padta hai aur vault data jata hai.

## Fix
Ek fixed keystore GitHub Secrets me. Build wahi key use karta hai => har APK same signature => seedha UPDATE.

## Logic (ek baar karna hai)
1. Apne PC par keystore banao (JDK ka `keytool`):
   `keytool -genkeypair -v -keystore bsrpro-release.jks -alias bsrpro -keyalg RSA -keysize 2048 -validity 10000`
   (password aur naam-wagairah poochega; password yaad rakho)
2. Base64 me badlo:
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("bsrpro-release.jks")) | Set-Clipboard`
   - Linux: `base64 -w0 bsrpro-release.jks`  |  Mac: `base64 -i bsrpro-release.jks`
3. GitHub repo > Settings > Secrets and variables > Actions > New repository secret. 4 secrets:
   - `BSR_KEYSTORE_BASE64` = upar wala base64 text
   - `BSR_KEYSTORE_PASSWORD` = keystore password
   - `BSR_KEY_ALIAS` = `bsrpro`
   - `BSR_KEY_PASSWORD` = key password (keytool me alag na diya ho to wahi keystore password)
4. Actions me build chalao. Log me "Fixed signing key use ho rahi hai" aur Verify step me signer certificate SHA-256 dikhega; har build me SAME hona chahiye.

## Zaroori
- `bsrpro-release.jks` + passwords ki 2 safe copy rakho (pen drive / cloud). Khoya to is app ko kabhi update nahi kar paoge.
- Keystore kabhi repo me commit mat karo (`.gitignore` me `*.jks` hai).
- Pehli baar (purani random-key wali app se is key par) EK BAAR uninstall karna padega. Pehle backup (Downloads/BSRPRO_Backups/BSRPRO.Vault) aur Recovery Key sambhal lo. Uske baad hamesha update ke ooper.
- `versionCode` = 30 + GitHub run number, isliye naya build hamesha purane se bada hota hai (downgrade block nahi hota).
