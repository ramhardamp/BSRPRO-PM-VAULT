package pro.babasitaram.vault.data.backup

import kotlin.test.Test
import kotlin.test.assertEquals
import pro.babasitaram.vault.core.model.VaultEntry

/** Backup ON karte waqt import ka merge rule: naya aaye, newer aaye, Bin / local-newer kabhi overwrite na ho. */
class BackupMergeRulesTest {
    private fun e(id: String, updatedAt: Long, deletedAt: Long = 0L) =
        VaultEntry(id = id, title = id, updatedAt = updatedAt, deletedAt = deletedAt)

    @Test
    fun unknown_entry_is_imported() {
        val out = BackupMergeRules.selectImportable(local = emptyList(), backup = listOf(e("a", 10)))
        assertEquals(listOf("a"), out.map { it.id })
    }

    @Test
    fun newer_backup_replaces_older_local_but_older_backup_does_not() {
        val local = listOf(e("a", 10), e("b", 50))
        val out = BackupMergeRules.selectImportable(local, listOf(e("a", 20), e("b", 40)))
        assertEquals(listOf("a"), out.map { it.id })
    }

    @Test
    fun entry_in_bin_is_not_resurrected() {
        val local = listOf(e("a", 10, deletedAt = 99))
        val out = BackupMergeRules.selectImportable(local, listOf(e("a", 500)))
        assertEquals(emptyList(), out)
    }

    @Test
    fun equal_timestamp_keeps_local() {
        val out = BackupMergeRules.selectImportable(listOf(e("a", 10)), listOf(e("a", 10)))
        assertEquals(emptyList(), out)
    }
}
