package pro.babasitaram.vault.data.backup

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings

/**
 * "All files access" (MANAGE_EXTERNAL_STORAGE, Android 11+).
 * Isse app Downloads/BSRPRO_Backups/BSRPRO.Vault ko seedha file ki tarah padh/likh sakti hai -- bina folder picker ke,
 * aur reinstall ke baad bhi purani backup file dikh jati hai (MediaStore me purani install ki file nahi dikhti).
 * Permission na mile to purana MediaStore tareeka chalta rehta hai (kuch toota nahi).
 */
object AllFilesAccess {
    fun supported(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
    fun granted(): Boolean = supported() && runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
    fun needed(): Boolean = supported() && !granted()

    /** Is app ke liye permission screen kholta hai; na khule to general "All files access" list. */
    fun request(context: Context) {
        if (!supported()) return
        val newTask = if (context is android.app.Activity) 0 else Intent.FLAG_ACTIVITY_NEW_TASK
        val direct = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${context.packageName}")).addFlags(newTask)
        runCatching { context.startActivity(direct) }.onFailure {
            runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(newTask)) }
        }
    }
}
