@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.setup

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Card
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import pro.babasitaram.vault.presentation.settings.RecoveryKeyPdf
import pro.babasitaram.vault.presentation.settings.printRecoveryKey
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.presentation.components.PasswordField
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import pro.babasitaram.vault.core.util.L

@Composable
fun SetupScreen(vm: SetupViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val recoveryPdf = rememberLauncherForActivityResult(CreateDocument("application/pdf")) { uri ->
        val key = state.recoveryKey
        if (uri != null && key != null) {
            runCatching { RecoveryKeyPdf.write(context, uri, key) }
                .onFailure {
                    android.widget.Toast.makeText(context, context.getString(pro.babasitaram.vault.R.string.p17_recovery_save_failed), android.widget.Toast.LENGTH_LONG).show()
                }
        }
    }

    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Logo: poori width me BEECH me (pehle Column ke start par chipak kar kone me aata tha) aur bada (80dp -> 128dp)
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(pro.babasitaram.vault.R.drawable.brand_logo),
                    contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_brand_accessibility),
                    modifier = Modifier.size(128.dp)
                )
            }
            Text(
                androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_148),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            Text(
                stringResource(R.string.p18_setup_your_master_password_encrypts_everyt),
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Center
            )
            // Sirf vault banane ka form (backup/restore options Settings > Backup me hain)
            PasswordField(
                password, { password = it }, stringResource(R.string.p17_loc_074),
                showStrength = true, enabled = !state.busy,
                imeAction = androidx.compose.ui.text.input.ImeAction.Next
            )
            PasswordField(
                confirm, { confirm = it }, stringResource(R.string.p18_setup_confirm_master_password),
                enabled = !state.busy,
                // Keyboard Done = Create vault
                onImeAction = { if (!state.busy && password.isNotEmpty()) vm.create(password, confirm) }
            )
            Text(
                L.s(R.string.p18_setup_minimum_characters_with_upper_lower, PasswordStrength.MIN_MASTER_LENGTH),
                style = MaterialTheme.typography.labelSmall
            )
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = { vm.create(password, confirm) },
                enabled = !state.busy && password.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_149))
            }
            // Backup / restore / folder ke options login (setup) screen se hata diye -- ab sirf Settings > Backup se operate hote hain
        }
    }

    state.recoveryKey?.let { key ->
        AlertDialog(
            onDismissRequest = { vm.dismissRecoveryKey() },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_151), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_152))
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                key.chunked(4).joinToString(" "),
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.titleMedium
                            )
                            IconButton(
                                onClick = {
                                    vm.copySecret(key, "Recovery key")
                                }
                            ) { Icon(Icons.Default.ContentCopy, "Copy recovery key") }
                        }
                    }
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_153), color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = { recoveryPdf.launch(context.getString(pro.babasitaram.vault.R.string.p17_loc_018)) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_019)) }
            },
            dismissButton = {
                TextButton(onClick = { printRecoveryKey(context, key) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_020)) }
            }
        )
    }
}
