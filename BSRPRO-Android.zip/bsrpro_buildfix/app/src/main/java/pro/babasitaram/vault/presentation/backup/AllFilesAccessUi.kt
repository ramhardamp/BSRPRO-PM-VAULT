package pro.babasitaram.vault.presentation.backup

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import pro.babasitaram.vault.R
import pro.babasitaram.vault.data.backup.AllFilesAccess

/**
 * Auto-backup switch ka handler (Settings aur Backup screen dono me same).
 * ON karte waqt "All files access" nahi mili ho to pehle wahi screen kholta hai; wapas aane par
 * (mili ya nahi, dono me) [onSync] import + export ek hi file me chalata hai. Mili hui ho to seedha [onToggle].
 */
@Composable
fun rememberAutoBackupToggle(
    onToggle: (Boolean) -> Unit,
    onAwaitingAccess: () -> Unit,
    onSync: () -> Unit
): (Boolean) -> Unit {
    val context = LocalContext.current
    var awaiting by rememberSaveable { mutableStateOf(false) }
    val sync by rememberUpdatedState(onSync)
    LifecycleResumeEffect(Unit) {
        if (awaiting) {
            awaiting = false
            sync()
        }
        onPauseOrDispose { }
    }
    return { on ->
        if (on && AllFilesAccess.needed()) {
            awaiting = true
            onAwaitingAccess()
            AllFilesAccess.request(context)
        } else onToggle(on)
    }
}

/** Switch ke neeche: backup file kahan rakhi hai + (zaroorat ho to) "All files access" dene ka button. */
@Composable
fun AutoBackupLocationNote(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var needed by remember { mutableStateOf(AllFilesAccess.needed()) }
    LifecycleResumeEffect(Unit) {
        needed = AllFilesAccess.needed()
        onPauseOrDispose { }
    }
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            stringResource(R.string.bk_auto_location_note),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (needed) {
            Text(
                stringResource(R.string.bk_allow_access_body),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = { AllFilesAccess.request(context) }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.bk_allow_access_btn))
            }
        }
    }
}
