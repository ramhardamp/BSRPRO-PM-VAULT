# Autofill Customer Mobile/Recharge Form Fix

## Problem
Recharge/POS forms such as `Customer mobile number` and `Confirm mobile number` were being inferred as login username/password fields. This could cause a saved username or password to appear in a customer's phone-number form.

## Fix
- Added transaction/customer-field denylist in `AutofillParser`.
- `Customer mobile`, `Customer phone`, `Confirm mobile`, recipient/beneficiary/receiver/contact/alternate phone labels are ignored unless the app explicitly supplies a credential autofill hint.
- Username-before-password positional fallback now refuses to promote these fields to a synthetic username.
- Added regression tests for customer mobile and confirmation mobile fields.

## Intended behavior
- Normal login `username` / `email` / `mobile number` remains eligible when it is actually a credential field.
- Recharge/customer mobile fields receive no BSRPRO username/password dataset.
- The autofill Save request also receives no credential fields from these ignored customer forms.

Android Autofill guidance recommends explicit autofill hints where available; the new rule is a defensive heuristic for apps that expose ambiguous native fields without reliable hints.
