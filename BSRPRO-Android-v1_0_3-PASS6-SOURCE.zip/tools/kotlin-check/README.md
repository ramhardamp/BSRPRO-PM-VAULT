# kotlin-check (sandbox harness — NOT a Gradle build)

Asli app ki pure-Kotlin source files ko `kotlinc` se compile karke unka logic chalata hai
(`VaultEntry`, `AutofillMatcher`, `SafeRegex`, `PublicSuffix`, `PendingSaveStore`, editor `toEntry`).
`stubs/` me sirf `kotlinx.serialization`, `javax.inject`, `AutofillId`, `@Stable` ke khali stubs hain.

JUnit/Gradle ka REPLACEMENT NAHI: asli tests `app/src/test/...` me hain aur Gradle me hi chalte hain.

Chalane ka tareeka (kotlinc 2.0.x chahiye, https://github.com/JetBrains/kotlin/releases):
  B=app/src/main/java/pro/babasitaram/vault
  kotlinc -nowarn -jvm-target 17 tools/kotlin-check/stubs/*.kt \
    $B/core/model/VaultEntry.kt $B/core/model/Folder.kt $B/core/util/{HiddenVault,UrlUtils,Totp,PublicSuffix}.kt \
    $B/autofill/model/AutofillField.kt $B/autofill/{AutofillMatcher,PendingSaveStore,SafeRegex}.kt \
    tools/kotlin-check/tests/AndroidLogicCheck.kt tools/kotlin-check/tests/EditorTargetCheck.kt \
    <EntryEditorViewModel.kt ke top-level helpers (titleFromUrl .. toEntry) ko EditorHelpers.kt me nikaal kar> -d out
  java -cp out:<kotlinc>/lib/kotlin-stdlib.jar AndroidLogicCheckKt
