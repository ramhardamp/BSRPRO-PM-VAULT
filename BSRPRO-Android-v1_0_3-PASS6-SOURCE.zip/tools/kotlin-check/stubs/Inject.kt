package javax.inject
@Target(AnnotationTarget.CONSTRUCTOR, AnnotationTarget.FIELD)
annotation class Inject
@Target(AnnotationTarget.CLASS)
annotation class Singleton
