package androidx.compose.runtime
annotation class Stable
