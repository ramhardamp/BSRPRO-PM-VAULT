// Sirf compile-check harness ke liye stubs (asli app me kotlinx.serialization / javax.inject jars aate hain).
package kotlinx.serialization
@Target(AnnotationTarget.CLASS, AnnotationTarget.PROPERTY, AnnotationTarget.VALUE_PARAMETER)
annotation class SerialName(val value: String)
@Target(AnnotationTarget.CLASS)
annotation class Serializable
@Target(AnnotationTarget.PROPERTY)
annotation class Transient
