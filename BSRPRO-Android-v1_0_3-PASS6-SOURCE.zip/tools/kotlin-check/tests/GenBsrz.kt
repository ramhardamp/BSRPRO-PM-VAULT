import pro.babasitaram.vault.core.crypto.VaultPlaintext
import java.io.File
fun main(args: Array<String>) {
    val dir = File(args[0]); dir.mkdirs()
    // realistic ~60 KB payload with unicode + target field
    val entries = (1..300).joinToString(",") { i ->
        """{"id":"e$i","title":"Sitē $i – परीक्षण","url":"https://site$i.com","username":"user$i@mail.com","password":"p@ss\"w\\ord$i","type":"login","target":{"kind":"website","origin":"https://site$i.com"},"notes":"line1\nline2 ✓"}"""
    }
    val json = """{"schema":"BSRPRO.Vault.Payload","version":3,"entries":[$entries],"folders":[]}"""
    File(dir, "plain.json").writeText(json)
    val packed = VaultPlaintext.pack(json)
    File(dir, "packed.txt").writeText(packed)
    File(dir, "small_packed.txt").writeText(VaultPlaintext.pack("""{"a":1}"""))
    println("json=${json.length} packed=${packed.length} startsWithMarker=${packed.startsWith(VaultPlaintext.MARKER)} roundtrip=${VaultPlaintext.unpack(packed) == json}")
}
