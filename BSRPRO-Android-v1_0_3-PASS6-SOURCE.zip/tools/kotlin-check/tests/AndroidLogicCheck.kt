// Standalone harness (JUnit jars sandbox me nahi mil sakte). Asli app ke SAME source files compile hoti hain
// (VaultEntry, AutofillMatcher, SafeRegex, PublicSuffix, ...). Yeh JUnit tests ka port hai, Gradle run NAHI.
import pro.babasitaram.vault.autofill.*
import pro.babasitaram.vault.core.model.*
import pro.babasitaram.vault.core.util.*

var pass = 0; var fail = 0
fun ok(name: String, c: Boolean) { if (c) { pass++; println("PASS $name") } else { fail++; println("FAIL $name") } }
fun ids(r: List<EntryMatch>) = r.map { it.entry.id }

fun e(id: String, url: String = "", user: String = "u", pw: String = "p", pkg: String = "", used: Long = 0, title: String = id) =
    VaultEntry(id = id, title = title, url = url, username = user, password = pw, appPackage = pkg, lastUsedAt = used)

fun main() {
    editorChecks(::ok)
    pendingChecks(::ok)
    // ---------- target.kind model (AND-05 replaced): type stays "login"; routing by target.kind ----------
    val web = VaultEntry(type = "login", url = "https://site.com", target = EntryTarget("website", origin = "https://site.com"))
    val app = VaultEntry(type = "login", appPackage = "com.x", target = EntryTarget("android_package", packageName = "com.x"))
    ok("kind: website entry", web.isWebsiteLogin && !web.isAppLogin && web.targetKind == "website")
    ok("kind: app entry", app.isAppLogin && !app.isWebsiteLogin && app.targetKind == "android_package")
    ok("kind: explicit target wins over data", VaultEntry(url = "https://a.com", appPackage = "com.x", target = EntryTarget("android_package", packageName = "com.x")).isAppLogin)
    ok("kind: untagged derives from data (read-only)", VaultEntry(appPackage = "com.x").isAppLogin && VaultEntry(url = "https://a.com").isWebsiteLogin && VaultEntry(url = "androidapp://com.x").isAppLogin && VaultEntry().targetKind.isEmpty())
    ok("kind: unknown target.kind ignored", VaultEntry(url = "https://a.com", target = EntryTarget("weird")).isWebsiteLogin)
    ok("kind: targetPackage/targetOrigin accessors", app.targetPackage == "com.x" && web.targetOrigin == "https://site.com" && VaultEntry(url = "androidapp://com.z").targetPackage == "com.z")
    ok("kind: old type=app/website values are NOT interpreted", !VaultEntry(type = "app").isAppLogin && !VaultEntry(type = "website", appPackage = "p").isWebsiteLogin)

    // ---------- existing AutofillMatcherTest behaviour (regression) ----------
    val entries = listOf(
        e("gh", "https://github.com/login"), e("sub", "https://accounts.github.com"),
        e("evil", "https://evil-github.com"), e("other", "https://example.org"),
        e("app", pkg = "com.example.bank"), e("legacy", url = "androidapp://com.example.legacy"),
        VaultEntry(id = "note", title = "n", url = "https://github.com", isNote = true, notes = "x"),
        VaultEntry(id = "marker", metaType = "folder", url = "https://github.com")
    )
    val r = AutofillMatcher.match(entries, "com.android.chrome", "www.github.com")
    ok("web: exact + related only", ids(r) == listOf("gh", "sub") && r.map { it.kind } == listOf(MatchKind.EXACT, MatchKind.RELATED))
    ok("lookalikes never match", AutofillMatcher.match(entries, "com.android.chrome", "github.com.evil.io").isEmpty() && AutofillMatcher.match(entries, "com.android.chrome", "gitub.com").isEmpty())
    ok("native app by package / androidapp url", ids(AutofillMatcher.match(entries, "com.example.bank", null)) == listOf("app") && ids(AutofillMatcher.match(entries, "com.example.legacy", null)) == listOf("legacy"))
    val rx = VaultEntry(id = "rx", title = "rx", username = "u", password = "p", customFields = listOf(CustomField("autofillRegex", "^(m|login)\\.shop\\.in$")))
    ok("custom regex still matches (x3, cached)", (1..3).all { ids(AutofillMatcher.match(listOf(rx), "x", "login.shop.in")) == listOf("rx") } && AutofillMatcher.match(listOf(rx), "x", "evil.shop.in").isEmpty())
    val bad = VaultEntry(id = "bad", title = "bad", username = "u", password = "p", customFields = listOf(CustomField("autofillRegex", "([unclosed")))
    ok("invalid regex never throws/matches", (1..2).all { AutofillMatcher.match(listOf(bad), "x", "anything.com").isEmpty() })
    val hid = VaultEntry(id = "h1", url = "https://a.com", username = "u", password = "p", tags = listOf("hidden-vault"))
    ok("hidden vault never matched", AutofillMatcher.match(listOf(hid), "com.android.chrome", "a.com").isEmpty())
    val ranked = listOf(e("b", "https://site.com", used = 5), e("a", "https://site.com", used = 5), e("c", "https://site.com", used = 9), e("sub", "https://login.site.com", used = 99))
    ok("ranking exact>used>alpha", ids(AutofillMatcher.match(ranked, "x", "site.com")) == listOf("c", "a", "b", "sub"))

    // ---------- routing by target.kind in the matcher ----------
    val wEntry = VaultEntry(id = "w", title = "w", username = "u", password = "p", url = "https://shop.com", type = "login", target = EntryTarget("website", origin = "https://shop.com"))
    val aEntry = VaultEntry(id = "a", title = "a", username = "u", password = "p", appPackage = "com.shop.app", type = "login", target = EntryTarget("android_package", packageName = "com.shop.app"))
    val both2 = listOf(wEntry, aEntry)
    ok("android: browser request -> website entry", ids(AutofillMatcher.match(both2, "com.android.chrome", "shop.com")) == listOf("w"))
    ok("android: app request -> app entry", ids(AutofillMatcher.match(both2, "com.shop.app", null)) == listOf("a"))
    ok("android: BOTH kinds autofill (app pkg + web domain reported)", ids(AutofillMatcher.match(both2, "com.shop.app", "shop.com")).toSet() == setOf("w", "a"))
    ok("website entry never matches by package", AutofillMatcher.match(listOf(wEntry.copy(appPackage = "com.shop.app")), "com.shop.app", null).isEmpty())
    ok("app entry never matches by web domain", AutofillMatcher.match(listOf(aEntry.copy(url = "https://shop.com")), "com.android.chrome", "shop.com").isEmpty())
    ok("app entry: package is not turned into a URL", AutofillMatcher.match(listOf(aEntry), "com.android.chrome", "com.shop.app").isEmpty())

    // ---------- AND-04: SafeRegex ----------
    SafeRegex.resetForTest()
    ok("legit subdomain regex allowed", !SafeRegex.hasNestedQuantifier("([a-z0-9-]+\\.)*example\\.com") && SafeRegex.containsMatch("([a-z0-9-]+\\.)*example\\.com", "a.b.example.com"))
    ok("legit alternation allowed", !SafeRegex.hasNestedQuantifier("^(m|login)\\.shop\\.in$"))
    for (p in listOf("(a+)+$", "(.*)*x", "(\\w+\\s*)+$", "(a+|b)+$", "(a{1,5})+$", "([a-z]+)*$"))
        ok("static filter rejects nested: $p", SafeRegex.hasNestedQuantifier(p))
    for (p in listOf("(foo|bar)+\\.com", "a+b+c+", "(ab)+", "(a+)?b", "(a{2})+", "(\\.[a-z]+)+\\.com\$".replace("\\\$", "$")))
        println("INFO  hasNested($p) = ${SafeRegex.hasNestedQuantifier(p)}")
    ok("(foo|bar)+ not flagged", !SafeRegex.hasNestedQuantifier("(foo|bar)+\\.com"))
    ok("(a+)? not flagged", !SafeRegex.hasNestedQuantifier("(a+)?b"))
    ok("(a{2})+ not flagged (fixed count)", !SafeRegex.hasNestedQuantifier("(a{2})+"))
    ok("char class contents ignored", !SafeRegex.hasNestedQuantifier("[(+*)]+x"))
    ok("escaped parens ignored", !SafeRegex.hasNestedQuantifier("\\(a+\\)+"))

    // Static filter ki seema: kuch patterns filter se nikal jate hain. Asli guarantee time-box hai.
    // `(.*a){25}` filter pass karta hai (fixed count, body literal par khatam) par JDK 21 par bhi ~1 s leta hai.
    val nasty = "(.*a){25}"
    val host = "a".repeat(24) + "!"
    ok("slow pattern passes static filter (isliye time-box zaroori)", !SafeRegex.hasNestedQuantifier(nasty))
    val tr = System.nanoTime(); Regex(nasty).containsMatchIn(host); val rawMs = (System.nanoTime() - tr) / 1_000_000
    println("INFO  raw (unguarded) evaluation took ${rawMs} ms")
    ok("raw regex really is slow here (>=150ms) so test is meaningful", rawMs >= 150)
    val t0 = System.nanoTime()
    val res = SafeRegex.containsMatch(nasty, host)
    val ms = (System.nanoTime() - t0) / 1_000_000
    println("INFO  guarded evaluation took ${ms} ms (budget ${SafeRegex.BUDGET_NANOS / 1_000_000} ms)")
    ok("time-box aborts slow regex (<150ms, no match)", !res && ms < 150)
    println("INFO  ((a+)b?)+$ static flagged = ${SafeRegex.hasNestedQuantifier("((a+)b?)+$")} (JDK memoizes it; time-box is the backstop)")
    val t1 = System.nanoTime()
    ok("rejected pattern is never re-run (fast)", !SafeRegex.containsMatch(nasty, host) && (System.nanoTime() - t1) / 1_000_000 < 20)
    ok("length cap", !SafeRegex.containsMatch("a".repeat(SafeRegex.MAX_PATTERN_LENGTH + 1), "aaa.com"))
    ok("host length cap", !SafeRegex.containsMatch("a", "a".repeat(SafeRegex.MAX_HOST_LENGTH + 1)))
    ok("empty inputs false", !SafeRegex.containsMatch("", "a.com") && !SafeRegex.containsMatch("a", ""))
    // matcher-level: nested regex entry must not hang / match
    val redos = VaultEntry(id = "rd", title = "rd", username = "u", password = "p", url = "https://zzz.com",
        customFields = listOf(CustomField("autofillRegex", "(a+)+$")))
    val t2 = System.nanoTime()
    val rr = AutofillMatcher.match(listOf(redos), "x", "a".repeat(40) + "!.com")
    ok("matcher survives ReDoS regex quickly", rr.isEmpty() && (System.nanoTime() - t2) / 1_000_000 < 400)

    // ---------- AND-04: PublicSuffix / related ----------
    ok("github.io is public suffix", PublicSuffix.isPublicSuffix("github.io"))
    ok("co.uk / com.au / co.in public suffix", listOf("co.uk", "com.au", "co.in", "gov.in", "co.jp").all { PublicSuffix.isPublicSuffix(it) })
    ok("TLD alone public suffix", PublicSuffix.isPublicSuffix("com") && PublicSuffix.isPublicSuffix("in"))
    ok("google.com / bbc.co.uk subdomain base NOT suffix", !PublicSuffix.isPublicSuffix("google.com") && !PublicSuffix.isPublicSuffix("bbc.co.uk"))
    ok("IP literal detected", PublicSuffix.isIpLiteral("192.168.1.5") && PublicSuffix.isIpLiteral("::1") && !PublicSuffix.isIpLiteral("1.2.3.com"))
    ok("related: accounts.google.com <-> google.com", PublicSuffix.isRelated("accounts.google.com", "google.com") && PublicSuffix.isRelated("google.com", "accounts.google.com"))
    ok("NOT related: evil.github.io vs github.io", !PublicSuffix.isRelated("evil.github.io", "github.io"))
    ok("NOT related: a.co.uk vs co.uk", !PublicSuffix.isRelated("a.co.uk", "co.uk"))
    ok("NOT related: sibling subdomains", !PublicSuffix.isRelated("a.example.com", "b.example.com"))
    ok("NOT related: IP parent", !PublicSuffix.isRelated("x.10.0.0.1", "10.0.0.1"))
    val ghio = e("ghio", "https://github.io")
    ok("entry github.io no longer matches *.github.io", AutofillMatcher.match(listOf(ghio), "com.android.chrome", "alice.github.io").isEmpty())
    ok("entry github.io still EXACT for github.io", ids(AutofillMatcher.match(listOf(ghio), "com.android.chrome", "github.io")) == listOf("ghio"))
    val usr = e("alice", "https://alice.github.io")
    ok("entry alice.github.io: exact only for itself", ids(AutofillMatcher.match(listOf(usr), "c", "alice.github.io")) == listOf("alice") && AutofillMatcher.match(listOf(usr), "c", "bob.github.io").isEmpty())

    println("\nANDROID LOGIC CHECK: $pass passed, $fail failed")
    if (fail > 0) kotlin.system.exitProcess(1)
}

// ---------- AND-02: PendingSaveStore ----------
fun pendingChecks(ok: (String, Boolean) -> Unit) {
    var now = 1_000_000L
    val st = PendingSaveStore().also { it.clock = { now } }
    fun p(pkg: String, user: String = "u", dom: String? = null) = PendingSave(pkg, dom, user, "pw", now)
    ok("pending: empty peek null", st.peek() == null)
    st.put(p("a")); st.put(p("b")); st.put(p("c"))
    ok("pending: 3 slots, newest first", st.size() == 3 && st.peek()?.packageName == "c")
    st.put(p("d"))
    ok("pending: 4th drops oldest (still 3)", st.size() == 3)
    st.clear()
    ok("pending: clear removes only consumed (newest) slot", st.size() == 2 && st.peek()?.packageName == "c")
    st.clear(); st.clear(); st.clear()
    ok("pending: clear on empty is safe", st.size() == 0 && st.peek() == null)
    st.put(p("x", "same")); st.put(p("x", "same"))
    ok("pending: same app+user replaces own slot (no duplicate)", st.size() == 1)
    st.put(p("x", "other"))
    ok("pending: different user = new slot", st.size() == 2)
    st.clearAll()
    ok("pending: clearAll", st.size() == 0)
    // sliding TTL
    st.put(p("t")); now += 4 * 60_000L
    ok("pending: alive at 4 min", st.peek() != null)            // touch resets window
    now += 4 * 60_000L
    ok("pending: sliding - alive 8 min after put because it was used at 4", st.peek() != null)
    now += 6 * 60_000L   // 14 min since put, last touch at 8 -> 6 min idle > 5 => expired
    ok("pending: idle > 5 min expires", st.peek() == null)
    // absolute cap
    st.put(p("cap")); var alive = true
    repeat(5) { now += 4 * 60_000L; if (st.peek() == null) alive = false }   // keeps touching every 4 min
    ok("pending: absolute 15 min cap even when used", !alive || st.peek() == null)
    st.put(p("n", "u", "www.shop.com"))
    val c = st.peek()!!.toCandidate()
    ok("pending: web capture -> website target, no package", c.target?.kind == "website" && c.target?.origin == "https://shop.com" && c.appPackage.isEmpty())
    st.put(p("com.bank.app")); val c2 = st.peek()!!.toCandidate()
    ok("pending: app capture -> android_package target, no url", c2.target?.kind == "android_package" && c2.target?.packageName == "com.bank.app" && c2.url.isEmpty() && c2.type == "login")
    st.put(p("att")); st.attach("id9")
    ok("pending: attach sets existingId on newest", st.peek()?.existingId == "id9")
}
