// Editor ke target.kind logic ka standalone check (EditorHelpers.kt = EntryEditorViewModel.kt ke asli top-level helpers).
import pro.babasitaram.vault.core.model.*
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.editor.*

fun editorChecks(ok: (String, Boolean) -> Unit) {
    // website login
    val w = EditorForm(title = "GitHub", url = "https://www.GitHub.com:443/login?x=1", username = "u", password = "p").toEntry(null)
    ok("editor: website -> type=login, kind=website", w.type == "login" && w.target?.kind == "website")
    ok("editor: website origin normalised", w.target?.origin == "https://www.github.com")
    ok("editor: website keeps url, no package/uri", w.url.startsWith("https://www.GitHub.com") && w.appPackage.isEmpty() && w.loginUri.isEmpty())
    // app login
    val a = EditorForm(title = "Bank", appPackage = "com.example.bank", appName = "Bank", targetKind = "android_package", username = "u", password = "p").toEntry(null)
    ok("editor: app -> type=login, kind=android_package", a.type == "login" && a.target?.kind == "android_package" && a.target?.packageName == "com.example.bank")
    ok("editor: app has NO url and NO androidapp:// uri", a.url.isEmpty() && a.loginUri.isEmpty() && a.target?.origin.isNullOrEmpty())
    ok("editor: app isAppLogin / not website", a.isAppLogin && !a.isWebsiteLogin)
    ok("editor: website isWebsiteLogin / not app", w.isWebsiteLogin && !w.isAppLogin)
    // website form with a leftover package -> package dropped (ONE target)
    val both = EditorForm(title = "x", url = "https://site.com", appPackage = "com.x", appName = "X", username = "u", password = "p").toEntry(null)
    ok("editor: website kind clears leftover package", both.target?.kind == "website" && both.appPackage.isEmpty() && both.appName.isEmpty())
    // package alone (no mode) -> app
    val onlyPkg = EditorForm(appPackage = "com.y", username = "u", password = "p").toEntry(null)
    ok("editor: package alone -> android_package", onlyPkg.target?.kind == "android_package" && onlyPkg.url.isEmpty())
    // edit round trip keeps kind
    val back = a.toForm()
    ok("editor: toForm carries kind and mode=app", back.targetKind == "android_package" && modeFor(back, "") == "app")
    val again = back.copy(username = "changed").toEntry(a)
    ok("editor: re-save keeps app kind & package", again.target == a.target && again.url.isEmpty())
    val wf = w.toForm()
    ok("editor: website round trip keeps kind", modeFor(wf, "") == "login" && wf.toEntry(w).target?.kind == "website")
    // non-login record keeps its target untouched
    val card = EditorForm(recordType = "card", title = "Card", cardNumber = "4111111111111111").toEntry(null)
    ok("editor: card has no target and keeps type blank", card.target == null && card.type.isEmpty())
    // origin helper never builds an origin from a package / androidapp uri
    ok("UrlUtils.originOf: androidapp:// -> empty", UrlUtils.originOf("androidapp://com.x").isEmpty())
    ok("UrlUtils.originOf: bare host -> https", UrlUtils.originOf("Example.com/path") == "https://example.com")
    ok("UrlUtils.originOf: port kept, default dropped", UrlUtils.originOf("http://a.com:8080/x") == "http://a.com:8080" && UrlUtils.originOf("https://a.com:443") == "https://a.com")
    ok("UrlUtils.originOf: ftp / junk -> empty", UrlUtils.originOf("ftp://a.com").isEmpty() && UrlUtils.originOf("").isEmpty())
}
