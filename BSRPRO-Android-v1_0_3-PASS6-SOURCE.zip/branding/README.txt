PREMIUM DEVOTIONAL BRAND PACK — FINAL ROUND VERSION

The logo is circular and the area outside the circle is transparent. No four-corner frame/boundary is included.

website/ — static website
extension/ — Chrome/Edge Manifest V3 source
android_project/ — Android Studio source for APK/AAB
master-transparent.png — transparent circular master

Source: premium_devotional_brand_pack_final.zip. Circular logo, transparent outside the circle.
Ext icons: icons/icon16/32/48/128.png. Android: res/drawable-nodpi/brand_logo.png + mipmap-*/ic_launcher_foreground.png (logo = 64% of canvas, adaptive-icon safe zone).
