# BSRPRO Two-Client Documentation Rule

This project has one vault product and two clients: Android and Browser Extension.

Before changing either client, read the shared master contract, backup/import/export contract and senior audit checklist in `docs/shared/`.

If a change affects a shared contract, update and audit BOTH clients in the same change. Do not rely on chat memory to reconstruct the contract.
