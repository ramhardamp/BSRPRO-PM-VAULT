# BSRPRO Senior Android + Extension Audit Checklist

## Android
- V3/V4 golden crypto vectors
- APK build, signing and verification
- process death/restart
- biometric/device-credential fallback
- autofill session/expiry
- Room/storage migration
- backup staging and recovery
- SAF/MediaStore permission/revocation
- import preview/commit/rollback
- stable IDs, folders and app-login metadata

## Extension
- MV3 service-worker lifecycle
- Chrome/Firefox API compatibility
- WebCrypto V3/V4 vectors
- import merge and ID collision behavior
- folder merge
- unknown-field preservation
- concurrent save + auto-backup
- download completion/failure behavior
- wrong-password/corrupt/truncated backup handling
- large-vault limits
- autofill/save/update flows

## Release gate
One failing audit resets the clean counter to zero. Five consecutive complete clean audits are required before certification. Device/browser runtime testing remains mandatory in addition to source-level tests.
