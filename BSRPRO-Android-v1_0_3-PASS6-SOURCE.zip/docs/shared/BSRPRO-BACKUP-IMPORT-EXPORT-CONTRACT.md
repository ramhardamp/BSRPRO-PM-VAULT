# BSRPRO Backup / Import / Export Contract

## V4 policy
V4 is the current export/automatic-backup writer. V3 is retained for backward-compatible restore. The cryptographic parameters remain identical; the version is explicit in the authenticated header and payload schema.

## Cross-platform invariants
1. `BSRPRO.Vault` is the canonical encrypted container.
2. V3 and V4 headers are canonical and authenticated as AAD.
3. Stable entry IDs are preserved when there is no collision.
4. Folder IDs and folder records survive merge imports.
5. All entry fields survive import/export, including future fields.
6. An import cannot silently delete records/folders absent from the import.
7. Automatic backup cannot silently replace a known-good non-empty backup with an empty vault.
8. Automatic backups are serialized and throttled/coalesced.

## Known fixed defects from the deep audit
- Extension generated a new ID for every imported record: **fixed**.
- Extension overwrite used a field allow-list and could lose fields: **fixed**.
- Extension import replaced the entire folder set: **fixed**.
- Extension auto-backup throttle was 0 ms: **fixed to 15 seconds with serialization**.
- Extension auto-backup now performs cryptographic pre-publication read-back verification.
- Android and Extension now write V4 while both retain V3 readers.

## Not enabled yet
V4 does not enable `BSRZ1` compressed export. Compression remains a separate interoperability gate.
