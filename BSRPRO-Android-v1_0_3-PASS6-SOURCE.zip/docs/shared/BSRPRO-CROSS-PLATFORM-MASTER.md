# BSRPRO Cross-Platform Master Contract

Android and Browser Extension are two clients of one BSRPRO Password Manager vault.

## Current backup versions
- **V4 is the current writer.**
- **V3 remains a supported reader.**
- Legacy encrypted `.vaultbak` formats remain readable where already supported.

## V3/V4 crypto contract
Both V3 and V4 use the same cryptographic primitives:
- PBKDF2-HMAC-SHA256, 600000 iterations
- AES-256-GCM
- 128-bit authentication tag
- 16-byte salt
- 12-byte IV
- canonical header authenticated as GCM AAD

V4 is a new versioned envelope/schema, not a destructive replacement. A V4 reader must continue to read V3.

## Shared entry contract
Stable `id` plus all known entry fields must survive Android → Extension → Android and Extension → Android → Extension round trips. Unknown/future fields must not be silently discarded.

## Import contract
- Parse and validate before mutation.
- Default is merge.
- Preserve imported IDs when unique.
- Generate a new ID only for a real ID collision.
- Never replace the entire folder set during a merge import.
- Overwrite must preserve every imported field, including app-login metadata, history and future fields.
- Failed writes must leave the previous vault intact.

## Backup contract
- Never overwrite a known-good non-empty backup with an accidental empty vault.
- Serialize concurrent automatic backup requests.
- Coalesce rapid changes.
- Encrypt with current V4.
- Cryptographically decrypt/read-back the generated container before publication.
- Preserve V3 restore compatibility.

## Compression
`BSRZ1:` is supported for reading on Android. Do not enable compressed exports until the Extension reader is implemented and both directions have interoperability tests.

## Mandatory change propagation
Any change to crypto, schema, IDs, folders, import/export, backup, migration, compression, history or deleted-record semantics must be audited in BOTH clients before release.
