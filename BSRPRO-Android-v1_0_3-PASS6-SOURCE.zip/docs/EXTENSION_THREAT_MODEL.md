# Extension threat model (EXT-01, EXT-02, EXT-11) — Fix.md format

Status: **DOCUMENTED (fix pass #2)**. Yeh sach likhta hai ki kya bachaya jata hai aur kya NAHI.

## EXT-01 — Remember me / Auto-unlock
- **Issue:** master password `chrome.storage.local` me `chrome.runtime.id` se "encrypt" hota hai. Extension ID secret nahi hai, isliye yeh **obfuscation hai, security boundary nahi**.
- **Fix:** duration fixed **30 din** (`RememberPolicy.DEFAULT_EXPIRY_DAYS = 30`), selector aur "Always" hata diye; disk par 30 din se door expiry mile to seedha 30 din par clamp (grandfather / notice nahi). Settings me saaf warning.
- **Logic:** jiske paas browser profile ki files hain wo is blob se master password nikal sakta hai. Sirf personal device par use karein. Stronger options (session-only, WebAuthn/OS keystore) alag product decision hain, abhi nahi.

## EXT-02 — PIN unlock
- **Issue:** alag HMAC VERIFIER disk par padha tha (offline guess oracle) aur PIN verify popup me hota tha.
- **Fix:** VERIFIER hata diya (sahi PIN = AES-GCM tag verify); PIN unlock background me (`PIN_UNLOCK`), master password response me kabhi nahi; `SET_SESSION` se `pinVerified` bypass hata.
- **Logic:** 6-digit PIN ke 10^6 combos hain. Jo attacker `chrome.storage.local` copy kar le, uske liye 5-attempt/60s lockout sirf software state hai (bypass ho sakta hai). PIN = convenience; shared / untrusted PC par PIN mat rakhein.

## EXT-11 — Share link
- **Design (badla nahi):** `share.html#<ciphertext>|<key>`: key aur ciphertext ek hi URL me. **Link = secret.** Jisne link dekha wo padh leta hai; expiry (`exp`) sirf receiver ki JS check karti hai (server-side enforce nahi).
- **Pass #1 me kiya:** `share-inject.js` har site se hataya, `web_accessible_resources` hataye.
- **Rakhna:** link sirf trusted channel se bhejein; sensitive entries ke liye share mat karein. Design badalna (key ko fragment se alag kar dena / server) alag decision hai.
