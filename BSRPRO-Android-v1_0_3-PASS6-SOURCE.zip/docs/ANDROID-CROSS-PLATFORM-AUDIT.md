# Android Cross-Platform Audit — Fixed State

- V4 is the current writer.
- V3 remains readable.
- Stable IDs, folders and complete entry fields are part of the shared contract.
- Android backup transaction/recovery protections remain authoritative.
- Compression remains disabled for export until Extension BSRZ1 support exists.

Android source-level regression suite passes; actual APK/device certification still requires a build-capable Android SDK/emulator environment.
