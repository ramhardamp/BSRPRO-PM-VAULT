package pro.babasitaram.vault.core.model

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.editor.EditorForm
import pro.babasitaram.vault.presentation.editor.modeFor
import pro.babasitaram.vault.presentation.editor.toEntry
import pro.babasitaram.vault.presentation.editor.toForm

/**
 * Entry model: type is always "login"; WHERE it applies is target.kind
 *  - "website"         -> origin      (browser data, Website logins section)
 *  - "android_package" -> packageName (Android app data, App logins section)
 * Old type=app/website values are NOT interpreted (no runtime migration).
 */
class AppLoginTypeTest {
    private val web = VaultEntry(type = "login", url = "https://site.com", target = EntryTarget("website", origin = "https://site.com"))
    private val app = VaultEntry(type = "login", appPackage = "com.x", target = EntryTarget("android_package", packageName = "com.x"))

    @Test fun `target kind decides the section`() {
        assertTrue(web.isWebsiteLogin); assertFalse(web.isAppLogin)
        assertTrue(app.isAppLogin); assertFalse(app.isWebsiteLogin)
        assertEquals("website", web.targetKind); assertEquals("android_package", app.targetKind)
    }

    @Test fun `explicit target wins over leftover data`() {
        assertTrue(VaultEntry(url = "https://a.com", appPackage = "com.x", target = EntryTarget("android_package", packageName = "com.x")).isAppLogin)
        assertTrue(VaultEntry(url = "https://a.com", appPackage = "com.x", target = EntryTarget("website", origin = "https://a.com")).isWebsiteLogin)
    }

    @Test fun `untagged entries are only read from their data and never rewritten`() {
        assertTrue(VaultEntry(appPackage = "com.jio.jpp1").isAppLogin)
        assertTrue(VaultEntry(url = "https://site.com").isWebsiteLogin)
        assertTrue(VaultEntry(url = "androidapp://com.x").isAppLogin)
        assertEquals("", VaultEntry().targetKind)
        assertNull(VaultEntry(appPackage = "com.x").target)
    }

    @Test fun `old type values and unknown kinds are ignored`() {
        assertFalse(VaultEntry(type = "app").isAppLogin)
        assertFalse(VaultEntry(type = "website", appPackage = "com.x").isWebsiteLogin)
        assertTrue(VaultEntry(url = "https://a.com", target = EntryTarget("weird")).isWebsiteLogin)
    }

    @Test fun `target accessors never mix package and url`() {
        assertEquals("com.x", app.targetPackage)
        assertEquals("https://site.com", web.targetOrigin)
        assertEquals("com.z", VaultEntry(url = "androidapp://com.z").targetPackage)
    }

    // ── editor ──
    @Test fun `website login is saved as type login with a website target`() {
        val e = EditorForm(title = "GitHub", url = "https://www.GitHub.com:443/login?x=1", username = "u", password = "p").toEntry(null)
        assertEquals("login", e.type)
        assertEquals("website", e.target?.kind)
        assertEquals("https://www.github.com", e.target?.origin)
        assertEquals("", e.appPackage); assertEquals("", e.loginUri)
    }

    @Test fun `app login is saved with a package target and no URL`() {
        val e = EditorForm(title = "Bank", appPackage = "com.example.bank", appName = "Bank", targetKind = "android_package", username = "u", password = "p").toEntry(null)
        assertEquals("login", e.type)
        assertEquals("android_package", e.target?.kind)
        assertEquals("com.example.bank", e.target?.packageName)
        assertEquals("", e.url)
        assertEquals("", e.loginUri)          // a package name is never turned into a URI
        assertEquals("", e.target?.origin)
    }

    @Test fun `website kind drops a leftover package so one entry has one target`() {
        val e = EditorForm(url = "https://site.com", appPackage = "com.x", appName = "X", username = "u", password = "p").toEntry(null)
        assertEquals("website", e.target?.kind)
        assertEquals("", e.appPackage); assertEquals("", e.appName)
    }

    @Test fun `package alone becomes an app login`() {
        val e = EditorForm(appPackage = "com.y", username = "u", password = "p").toEntry(null)
        assertEquals("android_package", e.target?.kind); assertEquals("", e.url)
    }

    @Test fun `edit round trip keeps the kind`() {
        val a = EditorForm(title = "Bank", appPackage = "com.example.bank", targetKind = "android_package", username = "u", password = "p").toEntry(null)
        val form = a.toForm()
        assertEquals("android_package", form.targetKind)
        assertEquals("app", modeFor(form, ""))
        assertEquals(a.target, form.copy(username = "changed").toEntry(a).target)
        val w = EditorForm(url = "https://site.com", username = "u", password = "p").toEntry(null)
        assertEquals("login", modeFor(w.toForm(), ""))
    }

    @Test fun `non-login records keep no target`() {
        val c = EditorForm(recordType = "card", title = "Card", cardNumber = "4111111111111111").toEntry(null)
        assertNull(c.target); assertEquals("", c.type)
    }

    @Test fun `origin is never built from a package or androidapp uri`() {
        assertEquals("", UrlUtils.originOf("androidapp://com.x"))
        assertEquals("https://example.com", UrlUtils.originOf("Example.com/path"))
        assertEquals("http://a.com:8080", UrlUtils.originOf("http://a.com:8080/x"))
        assertEquals("https://a.com", UrlUtils.originOf("https://a.com:443"))
        assertEquals("", UrlUtils.originOf("ftp://a.com")); assertEquals("", UrlUtils.originOf(""))
    }
}
