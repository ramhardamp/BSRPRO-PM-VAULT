package pro.babasitaram.vault.core.util

import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class PublicSuffixTest {
    @Test fun `shared hosting and country suffixes are public`() {
        assertTrue(listOf("github.io", "co.uk", "com.au", "co.in", "gov.in", "co.jp", "herokuapp.com", "com", "in").all(PublicSuffix::isPublicSuffix))
        assertFalse(PublicSuffix.isPublicSuffix("google.com")); assertFalse(PublicSuffix.isPublicSuffix("bbc.co.uk"))
    }

    @Test fun `ip literals`() {
        assertTrue(PublicSuffix.isIpLiteral("192.168.1.5")); assertTrue(PublicSuffix.isIpLiteral("::1"))
        assertFalse(PublicSuffix.isIpLiteral("1.2.3.com"))
    }

    @Test fun `related only when the shared parent is a registrable domain`() {
        assertTrue(PublicSuffix.isRelated("accounts.google.com", "google.com"))
        assertTrue(PublicSuffix.isRelated("google.com", "accounts.google.com"))
        assertFalse(PublicSuffix.isRelated("evil.github.io", "github.io"))
        assertFalse(PublicSuffix.isRelated("a.co.uk", "co.uk"))
        assertFalse(PublicSuffix.isRelated("a.example.com", "b.example.com"))
        assertFalse(PublicSuffix.isRelated("x.10.0.0.1", "10.0.0.1"))
    }
}
