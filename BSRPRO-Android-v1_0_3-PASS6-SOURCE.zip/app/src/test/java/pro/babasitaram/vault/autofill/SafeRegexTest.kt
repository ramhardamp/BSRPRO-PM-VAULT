package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

class SafeRegexTest {
    @BeforeEach fun reset() = SafeRegex.resetForTest()

    @Test fun `legit patterns still work`() {
        assertTrue(SafeRegex.containsMatch("^(m|login)\\.shop\\.in$", "login.shop.in"))
        assertTrue(SafeRegex.containsMatch("([a-z0-9-]+\\.)*example\\.com", "a.b.example.com"))
        assertFalse(SafeRegex.containsMatch("^(m|login)\\.shop\\.in$", "evil.shop.in"))
    }

    @Test fun `classic nested quantifiers are rejected by the static filter`() {
        for (p in listOf("(a+)+$", "(.*)*x", "(\\w+\\s*)+$", "(a+|b)+$", "(a{1,5})+$", "([a-z]+)*$"))
            assertTrue(SafeRegex.hasNestedQuantifier(p), p)
    }

    @Test fun `harmless groups are not flagged`() {
        for (p in listOf("(foo|bar)+\\.com", "a+b+c+", "(ab)+", "(a+)?b", "(a{2})+", "[(+*)]+x", "\\(a+\\)+"))
            assertFalse(SafeRegex.hasNestedQuantifier(p), p)
    }

    @Test fun `a slow pattern that passes the filter is stopped by the time box`() {
        val pattern = "(.*a){25}"            // fixed count, body ends in a literal: filter passes, JDK still needs ~1 s
        val host = "a".repeat(24) + "!"
        assertFalse(SafeRegex.hasNestedQuantifier(pattern))
        val t0 = System.nanoTime()
        assertFalse(SafeRegex.containsMatch(pattern, host))
        assertTrue((System.nanoTime() - t0) / 1_000_000 < 400)
        val t1 = System.nanoTime()           // rejected patterns are never re-run
        assertFalse(SafeRegex.containsMatch(pattern, host))
        assertTrue((System.nanoTime() - t1) / 1_000_000 < 50)
    }

    @Test fun `length caps empty and invalid input never throw`() {
        assertFalse(SafeRegex.containsMatch("a".repeat(SafeRegex.MAX_PATTERN_LENGTH + 1), "aaa.com"))
        assertFalse(SafeRegex.containsMatch("a", "a".repeat(SafeRegex.MAX_HOST_LENGTH + 1)))
        assertFalse(SafeRegex.containsMatch("", "a.com")); assertFalse(SafeRegex.containsMatch("a", ""))
        assertFalse(SafeRegex.containsMatch("([unclosed", "anything.com"))
    }
}
