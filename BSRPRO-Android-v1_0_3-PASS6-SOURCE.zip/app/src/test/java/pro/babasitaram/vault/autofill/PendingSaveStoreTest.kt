package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class PendingSaveStoreTest {
    private var now = 1_000_000L
    private fun store() = PendingSaveStore().also { it.clock = { now } }
    private fun p(pkg: String = "com.android.chrome", domain: String? = "www.example.com", user: String = "me") =
        PendingSave(pkg, domain, user, "pw", now)

    @Test fun `expires after the idle ttl`() {
        val s = store(); s.put(p())
        now += PendingSaveStore.TTL_MS
        assertEquals("pw", s.peek()?.password)      // exactly at the edge is still alive (and touches it)
        now += PendingSaveStore.TTL_MS + 1
        assertNull(s.peek())
    }

    @Test fun `ttl is sliding - use resets the idle window`() {
        val s = store(); s.put(p())
        now += 4 * 60_000L; assertEquals("pw", s.peek()?.password)
        now += 4 * 60_000L; assertEquals("pw", s.peek()?.password)   // 8 min after put, 4 min idle
        now += 6 * 60_000L; assertNull(s.peek())                      // 6 min idle
    }

    @Test fun `absolute age cap applies even when used`() {
        val s = store(); s.put(p())
        repeat(4) { now += 4 * 60_000L; s.peek() }                    // 16 min, always touched
        assertNull(s.peek())
    }

    @Test fun `queue holds three and newest is consumed first`() {
        val s = store()
        s.put(p(pkg = "a", domain = null)); s.put(p(pkg = "b", domain = null)); s.put(p(pkg = "c", domain = null))
        assertEquals("c", s.peek()?.packageName)
        s.put(p(pkg = "d", domain = null))
        assertEquals(3, s.size())                                     // oldest ("a") dropped
        s.clear(); assertEquals("c", s.peek()?.packageName)
        s.clear(); s.clear(); assertNull(s.peek())
    }

    @Test fun `same app and user replaces its own slot`() {
        val s = store(); s.put(p(pkg = "x", domain = null, user = "u")); s.put(p(pkg = "x", domain = null, user = "u"))
        assertEquals(1, s.size())
        s.put(p(pkg = "x", domain = null, user = "other")); assertEquals(2, s.size())
    }

    @Test fun `attach and clear`() {
        val s = store(); s.put(p()); s.attach("id-1")
        assertEquals("id-1", s.peek()?.existingId)
        s.clear(); assertNull(s.peek())
    }

    @Test fun `clearAll empties the queue`() {
        val s = store(); s.put(p(pkg = "a", domain = null)); s.put(p(pkg = "b", domain = null))
        s.clearAll(); assertEquals(0, s.size()); assertNull(s.peek())
    }

    @Test fun `web candidate gets https url website target and title from the domain`() {
        val c = p().toCandidate()
        assertEquals("Example", c.title); assertEquals("https://example.com", c.url); assertEquals("", c.appPackage)
        assertEquals("login", c.type); assertEquals("website", c.target?.kind); assertEquals("https://example.com", c.target?.origin)
        assertEquals("me", c.username)
    }

    @Test fun `app candidate preserves captured PIN separately from password`() {
        val candidate = p(domain = null, pkg = "com.example.bank").copy(password = "web-pass", appPin = "0420").toCandidate()
        assertEquals("web-pass", candidate.password); assertEquals("0420", candidate.appPin)
    }

    @Test fun `app candidate is keyed by package with no url`() {
        val c = p(domain = null, pkg = "com.example.bank").toCandidate()
        assertEquals("Bank", c.title); assertEquals("com.example.bank", c.appPackage); assertEquals("", c.url)
        assertEquals("android_package", c.target?.kind); assertEquals("com.example.bank", c.target?.packageName)
        assertTrue(c.isAppLogin)
    }
}
