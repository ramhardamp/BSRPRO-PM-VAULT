package pro.babasitaram.vault.core.crypto

/**
 * GENERATED from the browser extension's real src/crypto.js (see tools/golden/gen.js).
 * salt[i] = saltStart + i, iv[i] = ivStart + i (mod 256).
 */
data class GoldenVector(
    val plaintext: String,
    val password: String,
    val saltStart: Int,
    val ivStart: Int,
    val encoded: String // legacy: base64(salt||iv||ct); v3: JSON container
) {
    val salt: ByteArray get() = ByteArray(16) { ((saltStart + it) and 255).toByte() }
    val iv: ByteArray get() = ByteArray(12) { ((ivStart + it) and 255).toByte() }
}

object GoldenVectors {
    val LEGACY = listOf(
        GoldenVector(
            plaintext = """hello""",
            password = """password""",
            saltStart = 1,
            ivStart = 101,
            encoded = """AQIDBAUGBwgJCgsMDQ4PEGVmZ2hpamtsbW5vcJ3+C+ZWL3Q4XqVnerDVHToVqoJY6w=="""
        ),
        GoldenVector(
            plaintext = """__VAULT_CANARY__""",
            password = """correct horse battery staple""",
            saltStart = 20,
            ivStart = 120,
            encoded = """FBUWFxgZGhscHR4fICEiI3h5ent8fX5/gIGCg5K1f6QdwwidUxD+jPQSI7Du51PKRPxKPbR8YH/f6pnH"""
        ),
        GoldenVector(
            plaintext = """{"entries":[{"id":"1","title":"Gmail","password":"p@ss"}]}""",
            password = """Master#Pass123456""",
            saltStart = 40,
            ivStart = 140,
            encoded = """KCkqKywtLi8wMTIzNDU2N4yNjo+QkZKTlJWWl51gTRhCVNTeiQWUG+9jxmAeHvEserDPzcdjBxlBPY5R+NCNHgqe7ufE2CSUZXUAC9URTdaEZzrrNb+bpXnFE2PAPVXWbJbvsWVW"""
        ),
        GoldenVector(
            plaintext = """पासवर्ड 🔐 ünïcode""",
            password = """पासवर्ड-🔑-Ünï""",
            saltStart = 60,
            ivStart = 160,
            encoded = """PD0+P0BBQkNERUZHSElKS6ChoqOkpaanqKmqqzINNhkuk2rtcbNy+HB9kAVfT7trAn3jZlN5x8P+Ji9ase05l0ZpLB4swN65kcRXLuF8wdM="""
        )
    )

    val V3 = listOf(
        GoldenVector(
            plaintext = """{"schema":"BSRPRO.Vault.Payload","version":3,"entries":[{"id":"a1","title":"Bank","username":"u","password":"p"}]}""",
            password = """V3-Backup-Password!""",
            saltStart = 80,
            ivStart = 180,
            encoded = """{"header":{"format":"BSRPRO.Vault","version":3,"kdf":"PBKDF2-HMAC-SHA256","iterations":600000,"salt":"UFFSU1RVVldYWVpbXF1eXw==","iv":"tLW2t7i5uru8vb6/","cipher":"AES-256-GCM","tagBits":128},"ciphertext":"HgpjwZfw2hoPYzp8+8y21jzHa8gmKSigHcyPoAwWro5nn6e+71d0aGBmbFteK3qLIRnAVtcY8CWVMKDCTmiDpUMU+VQh87pOhIIfp76cAsBTL9/qanIlfEkQ3dqGwEqR4tunT3EkrmYnaC54MOjcIsLw94/HMeZ8BKp5RvqjLPP41w=="}"""
        ),
        GoldenVector(
            plaintext = """{"version":"2.0","app":"BABASITARAMPro","count":1,"entries":[{"id":"b2","title":"Mail","appPackage":"com.example.app"}],"folders":[{"id":"f1","name":"Work"}]}""",
            password = """पासवर्ड-V3""",
            saltStart = 120,
            ivStart = 220,
            encoded = """{"header":{"format":"BSRPRO.Vault","version":3,"kdf":"PBKDF2-HMAC-SHA256","iterations":600000,"salt":"eHl6e3x9fn+AgYKDhIWGhw==","iv":"3N3e3+Dh4uPk5ebn","cipher":"AES-256-GCM","tagBits":128},"ciphertext":"KokfSs0c+8wk5RmyeLBeyJMSqEnV2NLl2ErYp7l3PDBWJFbFmckZtpEat0llJtGRObAzSNK5pfpABVkimfmAtq2B/2BK89i+Fq6XD5yeVouJF07+8NSOixv4TdFdc0EUbOZbrlbD28z6+aUSRZBQ3lRxOaONIbI/yJrmNQVyE6cHJCYzcPqzEnAJ9os/ivreCz3DN9fHpSWyOnf7mTAgxxJiNYrH2t4NM5FlNA1M"}"""
        )
    )
    val V4 = listOf(
        GoldenVector(
            plaintext = """{"schema":"BSRPRO.Vault.Payload","version":4,"entries":[{"id":"a1","title":"Bank","username":"u","password":"p"}]}""",
            password = """V4-Backup-Password!""",
            saltStart = 80,
            ivStart = 180,
            encoded = """{"header":{"format":"BSRPRO.Vault","version":4,"kdf":"PBKDF2-HMAC-SHA256","iterations":600000,"salt":"UFFSU1RVVldYWVpbXF1eXw==","iv":"tLW2t7i5uru8vb6/","cipher":"AES-256-GCM","tagBits":128},"ciphertext":"vONKMfb5WgdM5jX3Yn+SvYonHf5rcQ6KrkkZllO89OQJ4JBr9ZC1YCIHtbNjzKlQnJ3U7vZkgro8jgZUPwU5YauDvkhMOERf4A9Gwd2mDe0Vuv9qlj9of45uOdKfh6r0G27bpkJXhw+Bu7JyLpVmMhffYfSfzc1nSq3AYQxNTvoFqQ=="}"""
        ),
        GoldenVector(
            plaintext = """{"version":"2.0","app":"BABASITARAMPro","count":1,"entries":[{"id":"b2","title":"Mail","appPackage":"com.example.app"}],"folders":[{"id":"f1","name":"Work"}]}""",
            password = """पासवर्ड-V4""",
            saltStart = 120,
            ivStart = 220,
            encoded = """{"header":{"format":"BSRPRO.Vault","version":4,"kdf":"PBKDF2-HMAC-SHA256","iterations":600000,"salt":"eHl6e3x9fn+AgYKDhIWGhw==","iv":"3N3e3+Dh4uPk5ebn","cipher":"AES-256-GCM","tagBits":128},"ciphertext":"Zdv03WJwvP+iasGho5sSFvC48xK2RFkLhZmqSwoJROKN0JSAwfS/cKzOd5bjt7uZKN7JerQJ+sUhNm5QYuJGbzdGfkJZqOHb7w+2517/3OAnTK9OGFlaYD1XEpwZo6gdEoeaC4EPQMvGIsSfOBJUvJLBDYSQr+HGzSnv8r01wIiThW26LOtH7CBWKyPYE0zd217SOsY8lwok5rYCqKDurfrUI8zJcza0qnj662RS"}"""
        )
    )

}
