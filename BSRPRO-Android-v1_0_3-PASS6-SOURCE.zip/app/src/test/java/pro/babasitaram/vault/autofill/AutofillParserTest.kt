package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.autofill.model.AutofillFieldType.NEW_PASSWORD
import pro.babasitaram.vault.autofill.model.AutofillFieldType.OTP
import pro.babasitaram.vault.autofill.model.AutofillFieldType.PIN
import pro.babasitaram.vault.autofill.model.AutofillFieldType.PASSWORD
import pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME
import pro.babasitaram.vault.autofill.model.FieldHints
import androidx.compose.foundation.lazy.*

class AutofillParserTest {
    private fun c(h: FieldHints) = AutofillParser.classify(h)

    private val textPassword = 0x81           // TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_PASSWORD
    private val webPassword = 0xe1            // TYPE_TEXT_VARIATION_WEB_PASSWORD
    private val emailInput = 0x21             // TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    private val numberPassword = 0x12         // TYPE_CLASS_NUMBER | TYPE_NUMBER_VARIATION_PASSWORD

    @Test fun `explicit autofill hints win`() {
        assertEquals(PASSWORD, c(FieldHints(autofillHints = listOf("password"))))
        assertEquals(NEW_PASSWORD, c(FieldHints(autofillHints = listOf("newPassword"))))
        assertEquals(USERNAME, c(FieldHints(autofillHints = listOf("username"))))
        assertEquals(USERNAME, c(FieldHints(autofillHints = listOf("emailAddress"))))
        assertEquals(OTP, c(FieldHints(autofillHints = listOf("smsOTPCode"))))
    }

    @Test fun `html autocomplete attribute is honoured`() {
        assertEquals(OTP, c(FieldHints(htmlAutocomplete = "one-time-code")))
        assertEquals(NEW_PASSWORD, c(FieldHints(htmlAutocomplete = "new-password")))
        assertEquals(PASSWORD, c(FieldHints(htmlAutocomplete = "current-password")))
        assertEquals(USERNAME, c(FieldHints(htmlAutocomplete = "section-login username")))
    }

    @Test fun `password input types`() {
        assertEquals(PASSWORD, c(FieldHints(inputType = textPassword)))
        assertEquals(PASSWORD, c(FieldHints(inputType = webPassword)))
        assertEquals(PIN, c(FieldHints(inputType = numberPassword)))
        assertEquals(PASSWORD, c(FieldHints(htmlType = "password")))
    }

    @Test fun `PIN hint is recognized only with a 4 to 6 character limit`() {
        assertEquals(PIN, c(FieldHints(hint = "Enter PIN", maxLength = 4)))
        assertEquals(PIN, c(FieldHints(htmlName = "securityPin", maxLength = 6)))
        assertNull(c(FieldHints(hint = "PIN", maxLength = 8)))
    }

    @Test fun `confirm and new password fields are not filled with the old password`() {
        assertEquals(NEW_PASSWORD, c(FieldHints(inputType = numberPassword, hint = "New PIN", maxLength = 4)))
        assertEquals(NEW_PASSWORD, c(FieldHints(inputType = textPassword, idEntry = "confirm_password")))
        assertEquals(NEW_PASSWORD, c(FieldHints(inputType = textPassword, hint = "Repeat password")))
    }

    @Test fun `otp is detected from ids and hints`() {
        assertEquals(OTP, c(FieldHints(idEntry = "otp_code")))
        assertEquals(OTP, c(FieldHints(hint = "Verification code")))
        assertEquals(OTP, c(FieldHints(htmlName = "totpPin")))
        assertEquals(OTP, c(FieldHints(idEntry = "twoFactorCode")))
    }

    @Test fun `username keywords incl camelCase`() {
        assertEquals(USERNAME, c(FieldHints(idEntry = "user_email")))
        assertEquals(USERNAME, c(FieldHints(htmlType = "email")))
        assertEquals(USERNAME, c(FieldHints(inputType = emailInput)))
        assertEquals(PASSWORD, c(FieldHints(idEntry = "loginPassword")))
    }

    @Test fun `unrelated fields are ignored`() {
        assertNull(c(FieldHints(hint = "Search", inputType = 1)))
        assertNull(c(FieldHints(idEntry = "address_line", inputType = 1)))
    }

    @Test fun `a plain text field before the password becomes the username`() {
        val items = listOf(
            "a" to FieldHints(inputType = 1),
            "b" to FieldHints(inputType = textPassword)
        )
        assertEquals(listOf("a" to USERNAME, "b" to PASSWORD), AutofillParser.resolve(items))
    }

    @Test fun `plain text before numeric PIN can be inferred as username`() {
        val items = listOf("u" to FieldHints(inputType = 1), "pin" to FieldHints(inputType = numberPassword))
        assertEquals(listOf("u" to USERNAME, "pin" to PIN), AutofillParser.resolve(items))
    }

    @Test fun `the heuristic does not override an explicit username or touch non-text fields`() {
        val explicit = listOf(
            "x" to FieldHints(inputType = 1),
            "u" to FieldHints(autofillHints = listOf("username")),
            "p" to FieldHints(inputType = textPassword)
        )
        assertEquals(listOf("x" to null, "u" to USERNAME, "p" to PASSWORD), AutofillParser.resolve(explicit))

        val multiline = listOf("m" to FieldHints(inputType = 0x20001), "p" to FieldHints(inputType = textPassword))
        assertEquals(listOf("m" to null, "p" to PASSWORD), AutofillParser.resolve(multiline))
    }
    @Test fun `recharge screen does not classify generic mobile field as username`() {
        val items = listOf(
            "title" to FieldHints(hint = "Recharge number", inputType = 0),
            "mobile" to FieldHints(hint = "Enter mobile number", inputType = 1)
        )
        val resolved = AutofillParser.resolve(items, "recharge number")
        assertTrue(resolved.none { it.second == USERNAME || it.second == PASSWORD })
    }

    @Test fun `recharge mobile remains ignored when only the mobile field is present`() {
        val items = listOf("mobile" to FieldHints(hint = "Enter mobile number", inputType = 1))
        assertEquals(listOf("mobile" to null), AutofillParser.resolve(items, "Recharge number"))
    }

}

/** Extra field-name words used by Indian banking / retail native apps. */
class AutofillParserNativeWordsTest {

    @Test fun `customer and confirmation mobile fields are never login credentials`() {
        assertNull(c(FieldHints(hint = "Customer mobile number", inputType = 1)))
        assertNull(c(FieldHints(hint = "Confirm mobile number", inputType = 1)))
        assertNull(c(FieldHints(idEntry = "customerMobileNumber", inputType = 1)))
    }

    @Test fun `customer mobile fields do not become username by password fallback`() {
        val items = listOf(
            "mobile" to FieldHints(hint = "Customer mobile number", inputType = 1),
            "confirm" to FieldHints(hint = "Confirm mobile number", inputType = 1)
        )
        assertTrue(AutofillParser.resolve(items).all { it.second == null })
    }

    private fun cls(id: String? = null, hint: String? = null, input: Int = 0) =
        AutofillParser.classify(pro.babasitaram.vault.autofill.model.FieldHints(idEntry = id, hint = hint, inputType = input))

    @Test fun `customer employee and retailer ids are usernames`() {
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(id = "etCustomerId"))
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(hint = "Employee code"))
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(hint = "Retailer ID"))
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(id = "mobileNo"))
    }

    @Test fun `password words still win`() {
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.PASSWORD, cls(hint = "Customer password"))
    }

    @Test fun `PIN field with no declared limit is still a PIN`() {
        assertEquals(PIN, c(FieldHints(hint = "Enter your PIN")))
        assertEquals(PIN, c(FieldHints(idEntry = "et_mpin", inputType = 2)))
    }

    @Test fun `postal PIN code and long numeric passwords are not PIN fields`() {
        assertNull(c(FieldHints(hint = "PIN code", maxLength = 6)))
        assertEquals(PASSWORD, c(FieldHints(inputType = numberPassword, maxLength = 12)))
    }
}
