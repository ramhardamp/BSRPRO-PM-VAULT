package pro.babasitaram.vault.domain

import io.mockk.mockk
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.autofill.PendingSave
import pro.babasitaram.vault.autofill.PendingSaveStore
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.core.security.VaultClipboardManager
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase

/** AND-02: only an explicit MANUAL lock drops pending autofill saves; automatic locks keep them. */
class LockClearsPendingSavesTest {
    private fun store() = PendingSaveStore().also { it.put(PendingSave("com.x", null, "u", "pw", 1L)) }
    private fun lock(p: PendingSaveStore) = LockVaultUseCase(
        SessionKeyStore(), mockk<VaultBlobStore>(relaxed = true), mockk<VaultRepository>(relaxed = true),
        mockk<VaultClipboardManager>(relaxed = true), mockk<BiometricSessionKeyStore>(relaxed = true), null, p
    )

    @Test fun `manual lock clears the pending queue`() = runTest {
        val p = store(); lock(p)("Manual"); assertEquals(0, p.size())
    }

    @Test fun `default reason is manual`() = runTest {
        val p = store(); lock(p)(); assertEquals(0, p.size())
    }

    @Test fun `auto lock and session expiry keep pending saves`() = runTest {
        val a = store(); lock(a)("Auto"); assertEquals(1, a.size())
        val b = store(); lock(b)("Session expired"); assertEquals(1, b.size())
    }
}
