package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/** AND-02 process-death: JVM me fake persistence se (Keystore device par hi chalta hai). */
class PendingSavePersistenceTest {
    private class Fake : PendingSavePersistence {
        var bytes: ByteArray? = null
        var writes = 0
        override fun write(plain: ByteArray?) { bytes = plain; writes++ }
        override fun read(): ByteArray? = bytes
    }

    private var now = 5_000_000L
    private fun store(f: Fake) = PendingSaveStore().also { it.clock = { now }; it.attachPersistence(f) }
    private fun p(pkg: String = "com.android.chrome", domain: String? = "www.example.com", user: String = "me") =
        PendingSave(pkg, domain, user, "pw-$user", now, existingId = null, appPin = "1234")

    @Test fun `slot survives process death`() {
        val f = Fake()
        store(f).put(p())
        val revived = store(f)                       // naya process = naya store, wahi persistence
        val got = revived.peek()
        assertEquals("pw-me", got?.password)
        assertEquals("www.example.com", got?.webDomain)
        assertEquals("1234", got?.appPin)
    }

    @Test fun `null domain and existingId round trip`() {
        val f = Fake()
        val s = store(f); s.put(p(pkg = "com.app.x", domain = null)); s.attach("id-7")
        val got = store(f).peek()
        assertNull(got?.webDomain)
        assertEquals("id-7", got?.existingId)
    }

    @Test fun `ttl still applies after restore`() {
        val f = Fake()
        store(f).put(p())
        now += PendingSaveStore.TTL_MS + 1
        assertNull(store(f).peek())
    }

    @Test fun `consume and clearAll remove persisted data`() {
        val f = Fake()
        val s = store(f); s.put(p(user = "a")); s.put(p(user = "b"))
        s.clear()
        assertEquals("pw-a", store(f).peek()?.password)
        s.clearAll()
        assertNull(f.bytes)
        assertNull(store(f).peek())
    }

    @Test fun `corrupt data is ignored and wiped`() {
        val f = Fake(); f.bytes = byteArrayOf(9, 9, 9)
        val s = store(f)
        assertNull(s.peek())
        assertNull(f.bytes)
    }

    @Test fun `slots captured before attach are kept newest`() {
        val f = Fake()
        store(f).put(p(user = "old"))
        val s = PendingSaveStore().also { it.clock = { now } }
        s.put(p(user = "fresh"))
        s.attachPersistence(f)
        assertEquals("pw-fresh", s.peek()?.password)
        assertEquals(2, s.size())
        assertTrue(f.writes > 0)
    }
}
