package pro.babasitaram.vault.data

import java.io.File
import java.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore

class FileVaultBlobStoreTest {
    @TempDir
    lateinit var dir: File

    private val pw = "Master#Pass123456".toCharArray()
    private fun store() = FileVaultBlobStore(dir, Dispatchers.IO)
    private fun data(n: Int) = VaultData(
        listOf(VaultEntry(id = "id$n", title = "Entry $n", password = "pw$n", appPackage = "com.app$n")),
        listOf(Folder(id = "f", name = "Work"))
    )
    private fun salt(f: File) = Base64.getDecoder().decode(f.readText().trim()).copyOfRange(0, 16)

    @Test
    fun `no vault until first write`() = runTest {
        val s = store()
        assertFalse(s.exists())
        s.write(data(1), pw)
        assertTrue(s.exists())
    }

    @Test
    fun `write then read round trips entries and folders`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val back = s.read(pw)
        assertEquals(data(1), back)
    }

    @Test
    fun `wrong password is rejected`() = runTest {
        val s = store()
        s.write(data(1), pw)
        assertThrows<VaultError.InvalidMasterPassword> { s.read("wrong-password".toCharArray()) }
    }

    @Test
    fun `read without a vault fails with VaultNotFound`() = runTest {
        assertThrows<VaultError.VaultNotFound> { store().read(pw) }
    }

    @Test
    fun `saves reuse the derived key but still produce fresh ciphertext`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val first = File(dir, "vault.blob").readText()
        val salt1 = salt(File(dir, "vault.blob"))
        s.write(data(2), pw)
        assertArrayEquals(salt1, salt(File(dir, "vault.blob")))
        assertTrue(first != File(dir, "vault.blob").readText())
        assertEquals(data(2), s.read(pw))
    }

    @Test
    fun `writing with a new password re-derives and invalidates the old one`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val salt1 = salt(File(dir, "vault.blob"))
        val other = "Another#Pass987654".toCharArray()
        s.write(data(1), other)
        assertFalse(salt1.contentEquals(salt(File(dir, "vault.blob"))))
        assertThrows<VaultError.InvalidMasterPassword> { s.read(pw) }
        assertEquals(data(1), s.read(other))
    }

    @Test
    fun `previous two versions are kept as backups`() = runTest {
        val s = store()
        s.write(data(1), pw)
        s.write(data(2), pw)
        s.write(data(3), pw)
        assertTrue(VaultCrypto.decryptBlocking(File(dir, "vault.blob").readText().trim(), pw).contains("Entry 3"))
        assertTrue(VaultCrypto.decryptBlocking(File(dir, "vault.blob.bak").readText().trim(), pw).contains("Entry 2"))
        assertTrue(VaultCrypto.decryptBlocking(File(dir, "vault.blob.bak2").readText().trim(), pw).contains("Entry 1"))
    }

    @Test
    fun `corrupted main file falls back to the previous version`() = runTest {
        val s = store()
        s.write(data(1), pw)
        s.write(data(2), pw)
        File(dir, "vault.blob").writeText("###not-a-vault###")
        assertEquals(data(1), store().read(pw))
    }

    @Test
    fun `leftover tmp file from a crash is ignored and the next write succeeds`() = runTest {
        val s = store()
        s.write(data(1), pw)
        File(dir, "vault.blob.tmp").writeText("half written garbage")
        assertEquals(data(1), store().read(pw))
        s.write(data(2), pw)
        assertEquals(data(2), s.read(pw))
        assertFalse(File(dir, "vault.blob.tmp").exists())
    }

    @Test
    fun `raw read and write move the blob unchanged`() = runTest {
        val s = store()
        s.write(data(1), pw)
        val raw = s.readRaw()!!
        val other = FileVaultBlobStore(File(dir, "copy").also { it.mkdirs() }, Dispatchers.IO)
        other.writeRaw(raw)
        assertEquals(data(1), other.read(pw))
    }

    @Test
    fun `deleteAll removes everything`() = runTest {
        val s = store()
        s.write(data(1), pw)
        s.write(data(2), pw)
        s.deleteAll()
        assertFalse(s.exists())
        assertEquals(0, dir.listFiles()!!.size)
    }

    // ── quick-unlock derived key (skips PBKDF2) ──

    @Test
    fun `exported key blob primes a fresh store and the vault still reads correctly`() = runTest {
        val a = store()
        a.write(data(1), pw)
        val blob = a.exportKeyBlob(pw)!!
        val b = store()
        assertTrue(b.primeKeyFromBlob(pw, blob))
        assertEquals(data(1), b.read(pw))
    }

    @Test
    fun `key blob v2 has a version byte and carries no password-derived data`() = runTest {
        val a = store()
        a.write(data(1), pw)
        val blob = a.exportKeyBlob(pw)!!
        assertEquals(1 + 16 + 32 + 32, blob.size)
        assertEquals(2, blob[0].toInt())
        // export is still refused for a password that does not own the cache
        assertNull(a.exportKeyBlob("Another#Pass999999".toCharArray()))
        // truncated / unknown version are rejected (no reader for older layouts)
        val b = store()
        assertFalse(b.primeKeyFromBlob(pw, blob.copyOf(blob.size - 1)))
        assertFalse(b.primeKeyFromBlob(pw, blob.copyOf().also { it[0] = 1 }))
        // an unprimed store still needs the real password
        assertThrows<VaultError.InvalidMasterPassword> { b.read("Another#Pass999999".toCharArray()) }
    }

    @Test
    fun `old v1 layout salt-key-sha256 is rejected not migrated`() = runTest {
        val a = store()
        a.write(data(1), pw)
        val v2 = a.exportKeyBlob(pw)!!
        val legacyShape = v2.copyOfRange(1, v2.size)           // salt||key||mac  (80 bytes, old size)
        val b = store()
        assertFalse(b.primeKeyFromBlob(pw, legacyShape))
        assertEquals(data(1), b.read(pw))                      // normal PBKDF2 path still works
    }

    @Test
    fun `a primed store never accepts a wrong password`() = runTest {
        val a = store()
        a.write(data(1), pw)
        val b = store()
        assertTrue(b.primeKeyFromBlob(pw, a.exportKeyBlob(pw)!!))
        assertThrows<VaultError.InvalidMasterPassword> { b.read("Another#Pass999999".toCharArray()) }
        assertEquals(data(1), b.read(pw))
    }

    @Test
    fun `corrupted key blob fails the MAC and the normal password path still works`() = runTest {
        val a = store()
        a.write(data(1), pw)
        val bad = a.exportKeyBlob(pw)!!.also { it[20] = (it[20].toInt() xor 0x55).toByte() } // inside the key bytes
        val b = store()
        assertFalse(b.primeKeyFromBlob(pw, bad))      // HMAC(key, ...) no longer matches
        assertEquals(data(1), b.read(pw))             // PBKDF2 path succeeds
        assertTrue(store().primeKeyFromBlob(pw, b.exportKeyBlob(pw)!!))
    }
}
