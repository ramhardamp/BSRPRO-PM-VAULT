package pro.babasitaram.vault.presentation

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.editor.EditorForm
import pro.babasitaram.vault.presentation.editor.effectiveTitle
import pro.babasitaram.vault.presentation.editor.titleFromUrl
import pro.babasitaram.vault.presentation.editor.toEntry
import pro.babasitaram.vault.presentation.editor.toForm
import pro.babasitaram.vault.presentation.editor.withPickedApp

/** Save paths A-D from the audit: which forms are accepted and where each value ends up. */
class EditorSavePathsTest {

    // ── Path A: empty form ──
    @Test fun `A - empty form has no title so it is rejected with a clear message path`() {
        assertEquals("", EditorForm().effectiveTitle())
        assertEquals("", EditorForm(username = "bob", password = "x").effectiveTitle())
    }

    // ── Path B: Android app picker ──
    @Test fun `B - picking an app fills title and keeps the website empty`() {
        val f = EditorForm().withPickedApp("JioPOS Plus", "com.jio.jpp1")
        assertEquals("JioPOS Plus", f.title)
        assertEquals("JioPOS Plus", f.appName)
        assertEquals("com.jio.jpp1", f.appPackage)
        assertEquals("", f.url)
    }

    @Test fun `B - app entry saves without any URL`() {
        val form = EditorForm(username = "9876543210", password = "pw").withPickedApp("JioPOS Plus", "com.jio.jpp1")
        val e = form.copy(title = form.effectiveTitle()).toEntry(null)
        assertEquals("JioPOS Plus", e.title)
        assertEquals("", e.url)
        assertEquals("JioPOS Plus", e.appName)
        assertEquals("com.jio.jpp1", e.appPackage)
        assertTrue(e.isAppEntry)
    }

    @Test fun `B - a title the user typed is kept when picking an app`() {
        val f = EditorForm(title = "Shop login").withPickedApp("JioPOS Plus", "com.jio.jpp1")
        assertEquals("Shop login", f.title)
    }

    @Test fun `B - changing the app replaces the auto title but not a custom one`() {
        val first = EditorForm().withPickedApp("App One", "com.one")
        assertEquals("App Two", first.withPickedApp("App Two", "com.two").title)
        val custom = first.copy(title = "My title")
        assertEquals("My title", custom.withPickedApp("App Two", "com.two").title)
    }

    @Test fun `B - effective title falls back to the app name even if title is blank`() {
        assertEquals("JioPOS Plus", EditorForm(title = "  ", appName = "JioPOS Plus", appPackage = "com.jio.jpp1").effectiveTitle())
    }

    // ── Path C: website ──
    @Test fun `C - title is derived from the website`() {
        assertEquals("Google", EditorForm(url = "https://accounts.google.com/signin").effectiveTitle())
        assertEquals("Jio", EditorForm(url = "jio.com").effectiveTitle())
        assertEquals("Hdfcbank", EditorForm(url = "https://netbanking.hdfcbank.co.in").effectiveTitle())
    }

    @Test fun `C - website entry keeps appPackage empty`() {
        val e = EditorForm(url = "https://github.com", username = "bob", password = "p").let { it.copy(title = it.effectiveTitle()) }.toEntry(null)
        assertEquals("Github", e.title)
        assertEquals("https://github.com", e.url)
        assertEquals("", e.appPackage)
        assertFalse(e.isAppEntry)
    }

    @Test fun `C - typed title wins over derived one`() {
        assertEquals("Work mail", EditorForm(title = "Work mail", url = "https://google.com").effectiveTitle())
    }

    @Test fun `titleFromUrl returns empty for junk`() {
        assertEquals("", titleFromUrl(""))
        assertEquals("", titleFromUrl("localhost"))
    }

    // ── Path D: imported entry opened and saved ──
    @Test fun `D - imported entry without a title can still be saved from its website or app`() {
        val imported = VaultEntry(id = "i1", title = "", url = "https://example.org", username = "u", password = "p")
        assertEquals("Example", imported.toForm().effectiveTitle())
        val nativeImport = VaultEntry(id = "i2", title = "", appName = "Some Bank", appPackage = "com.some.bank")
        assertEquals("Some Bank", nativeImport.toForm().effectiveTitle())
    }

    @Test fun `D - round trip keeps every mapped field`() {
        val src = VaultEntry(
            id = "x", title = "T", url = "https://a.com", username = "u", password = "p", mobile = "123", totp = "JBSWY3DPEHPK3PXP",
            notes = "n", category = "work", tags = listOf("t1", "t2"), appPin = "1234"
        )
        val back = src.toForm().toEntry(src)
        // ONE target per login: website origin is derived, type becomes "login", nothing else changes
        assertEquals(src.copy(type = "login", target = pro.babasitaram.vault.core.model.EntryTarget("website", origin = "https://a.com")), back)
    }

    @Test fun `D - a legacy website+app record keeps ONE target when re-saved`() {
        val linked = VaultEntry(id = "x", url = "https://a.com", appPackage = "com.a", appName = "A", username = "u", password = "p")
        val back = linked.toForm().toEntry(linked)
        assertEquals("website", back.target?.kind)
        assertEquals("", back.appPackage)
        assertEquals("", back.loginUri)
    }

    // ── card / identity / note titles ──
    @Test fun `card and identity titles come from the holder or name`() {
        assertEquals("Ram Kumar", EditorForm(recordType = "card", cardholder = "Ram Kumar").effectiveTitle())
        assertEquals("Sita Devi", EditorForm(recordType = "identity", fullName = "Sita Devi").effectiveTitle())
        assertEquals("", EditorForm(recordType = "note").effectiveTitle())
    }
}
