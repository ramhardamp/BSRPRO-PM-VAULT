package pro.babasitaram.vault.core.util

object UrlUtils {
    /** "https://www.Example.com/login?x=1" → "example.com"; "" if it can't be parsed. */
    fun domainOf(url: String): String {
        var s = url.trim().lowercase()
        if (s.isEmpty()) return ""
        s = s.substringAfter("://", s)
        s = s.substringBefore('/').substringBefore('?').substringBefore('#').substringAfterLast('@').substringBefore(':')
        return s.removePrefix("www.")
    }

    /**
     * "https://www.Example.com:8443/login?x=1" -> "https://www.example.com:8443"; "" if there is no usable host.
     * Used for `target.origin` of a website login. A bare "example.com" is read as https.
     * Never builds an origin from an Android package name or an androidapp:// URI.
     */
    fun originOf(url: String): String {
        val t = url.trim()
        if (t.isEmpty() || t.startsWith("androidapp://", ignoreCase = true)) return ""
        val scheme = if (t.contains("://")) t.substringBefore("://").lowercase() else "https"
        if (scheme != "http" && scheme != "https") return ""
        var rest = t.substringAfter("://", t)
        rest = rest.substringBefore('/').substringBefore('?').substringBefore('#').substringAfterLast('@')
        val host = rest.substringBefore(':').lowercase()
        if (host.isEmpty() || host.any { it.isWhitespace() }) return ""
        val port = rest.substringAfter(':', "").takeIf { it.isNotEmpty() && it.all(Char::isDigit) }
        val defaultPort = (scheme == "https" && port == "443") || (scheme == "http" && port == "80")
        return "$scheme://$host" + if (port != null && !defaultPort) ":$port" else ""
    }

    fun toOpenable(url: String): String {
        val t = url.trim()
        return if (t.contains("://")) t else "https://$t"
    }
}
