package pro.babasitaram.vault.autofill

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AND-02 (process-death). [PendingSaveStore] ke slots ko process kill ke baad bhi bacha ke rakhta hai.
 * Contract: write(null) = file delete; read() = null jab kuch nahi / kharab ho.
 * Plaintext KABHI disk par nahi jata: sirf Keystore-wrapped (AES-256-GCM) bytes.
 */
interface PendingSavePersistence {
    fun write(plain: ByteArray?)
    fun read(): ByteArray?
}

/**
 * Android Keystore AES-GCM key (non-exportable, user-auth NAHI, kyunki autofill service vault locked hone par
 * bhi save capture karti hai). File `noBackupFilesDir` me => cloud/device backup me nahi jati.
 * Keystore tabhi chhua jata hai jab sach me koi pending save ho (file na ho to read/delete me Keystore nahi).
 *
 * Honest limit: same app-uid par chalta code Keystore key use kar sakta hai; yeh file-copy / backup / disk-image se
 * bachata hai, compromised app process se nahi. TTL <= 15 min (PendingSaveStore.MAX_AGE_MS) aur consume/lock par delete.
 */
class KeystorePendingPersistence(context: Context) : PendingSavePersistence {

    private val file = File(context.noBackupFilesDir, FILE_NAME)
    private val tmp = File(context.noBackupFilesDir, "$FILE_NAME.tmp")

    @Synchronized
    override fun write(plain: ByteArray?) {
        if (plain == null) {
            file.delete(); tmp.delete()
            return
        }
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())          // Keystore IV khud banata hai
        val iv = cipher.iv
        val out = iv + cipher.doFinal(plain)
        tmp.writeBytes(out)
        if (!tmp.renameTo(file)) {                        // rename fail => purani file hata ke dobara try
            file.delete()
            if (!tmp.renameTo(file)) { tmp.delete(); throw java.io.IOException("pending save persist failed") }
        }
    }

    @Synchronized
    override fun read(): ByteArray? {
        if (!file.exists()) return null                   // Keystore ko chhuye bina
        return try {
            val all = file.readBytes()
            if (all.size <= IV_BYTES + TAG_BYTES) { file.delete(); return null }
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(TAG_BITS, all, 0, IV_BYTES))
            cipher.doFinal(all, IV_BYTES, all.size - IV_BYTES)
        } catch (e: Exception) {
            file.delete()                                  // kharab / key gayab: saaf karo, crash nahi
            null
        }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val spec = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(false)
            .build()
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            .apply { init(spec) }
            .generateKey()
    }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val ALIAS = "bsrpro_pending_save_v1"
        const val FILE_NAME = "pending_saves.bin"
        const val TRANSFORMATION = "AES/GCM/NoPadding"
        const val IV_BYTES = 12
        const val TAG_BITS = 128
        const val TAG_BYTES = 16
    }
}
