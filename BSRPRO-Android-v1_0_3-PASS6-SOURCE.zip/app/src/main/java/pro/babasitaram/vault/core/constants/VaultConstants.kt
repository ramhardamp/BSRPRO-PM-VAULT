package pro.babasitaram.vault.core.constants

/**
 * Constants that MUST stay identical to the browser extension (src/crypto.js).
 * Changing any value here breaks vault / backup compatibility.
 */
object VaultConstants {
    const val APP_NAME = "BSRPRO Vault"

    const val PBKDF2_ITERATIONS = 600_000
    const val AES_KEY_BITS = 256
    const val SALT_BYTES = 16
    const val IV_BYTES = 12
    const val GCM_TAG_BITS = 128
    const val VAULT_CANARY = "__VAULT_CANARY__"

    // V3 backup container: only files carrying this header are accepted,
    // so backups from other apps are rejected.
    const val V3_FORMAT = "BSRPRO.Vault"
    const val V3_VERSION = 3
    const val V4_VERSION = 4
    const val CURRENT_BACKUP_VERSION = V4_VERSION
    const val V3_KDF = "PBKDF2-HMAC-SHA256"
    const val V3_CIPHER = "AES-256-GCM"
    const val V3_BACKUP_FILE_NAME = "BSRPRO.Vault"
}
