package pro.babasitaram.vault.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Mirrors the browser extension's entry JSON. Every field has a default so partial entries decode. */
@Serializable
data class VaultEntry(
    @SerialName("id") val id: String = "",
    @SerialName("title") val title: String = "",
    @SerialName("url") val url: String = "",
    @SerialName("username") val username: String = "",
    @SerialName("password") val password: String = "",
    @SerialName("mobile") val mobile: String = "",
    @SerialName("notes") val notes: String = "",
    @SerialName("totp") val totp: String = "",
    @SerialName("category") val category: String = "other",
    @SerialName("categoryLocked") val categoryLocked: Boolean = false,
    @SerialName("isNote") val isNote: Boolean = false,
    @SerialName("recordType") val recordType: String = "login",
    @SerialName("folderId") val folderId: String = "",
    @SerialName("folder") val folder: String = "",
    @SerialName("type") val type: String = "",
    @SerialName("appPackage") val appPackage: String = "",
    @SerialName("appName") val appName: String = "",
    /** Canonical deep-link for the optional mobile-app target of this same login. */
    @SerialName("loginUri") val loginUri: String = "",
    @SerialName("isPrimaryAppLogin") val isPrimaryAppLogin: Boolean = false,
    @SerialName("starred") val starred: Boolean = false,
    @SerialName("tags") val tags: List<String> = emptyList(),
    @SerialName("customFields") val customFields: List<CustomField> = emptyList(),
    @SerialName("cardNumber") val cardNumber: String = "",
    @SerialName("cardholder") val cardholder: String = "",
    @SerialName("cardExpiry") val cardExpiry: String = "",
    @SerialName("cardCvv") val cardCvv: String = "",
    @SerialName("fullName") val fullName: String = "",
    @SerialName("email") val email: String = "",
    @SerialName("phone") val phone: String = "",
    @SerialName("address") val address: String = "",
    @SerialName("idNumber") val idNumber: String = "",
    @SerialName("idExpiry") val idExpiry: String = "",
    @SerialName("strength") val strength: String = "",
    @SerialName("createdAt") val createdAt: Long = 0L,
    @SerialName("updatedAt") val updatedAt: Long = 0L,
    /** Epoch milliseconds when the entry was moved to trash; 0 means it is active. */
    @SerialName("deletedAt") val deletedAt: Long = 0L,
    @SerialName("lastUsedAt") val lastUsedAt: Long = 0L,
    @SerialName("passwordHistory") val passwordHistory: List<PasswordHistoryItem> = emptyList(),
    @SerialName("editHistory") val editHistory: List<EditHistoryItem> = emptyList(),
    @SerialName("_metaType") val metaType: String? = null,
    @SerialName("appPin") val appPin: String = "",
    /** What this login belongs to: ONE target per entry (website origin XOR Android package). Null = untagged. */
    @SerialName("target") val target: EntryTarget? = null
) {
    val isFolderMarker: Boolean get() = metaType == "folder"
    val isAppEntry: Boolean get() = appPackage.isNotEmpty()
    /**
     * Routing kind of this login (type stays "login"):
     *  - target.kind == "website"         -> [targetOrigin]  (browser / website autofill)
     *  - target.kind == "android_package" -> [targetPackage] (native-app autofill)
     * An entry without a valid target (imported / untagged) is only READ through the data (androidapp:// or package
     * without url => android_package, url => website). Nothing is rewritten and no URL is ever built from a package.
     */
    val targetKind: String get() = when (target?.kind) {
        KIND_WEBSITE -> KIND_WEBSITE
        KIND_ANDROID_PACKAGE -> KIND_ANDROID_PACKAGE
        else -> when {
            url.trim().startsWith("androidapp://", ignoreCase = true) || (appPackage.isNotBlank() && url.isBlank()) -> KIND_ANDROID_PACKAGE
            url.isNotBlank() -> KIND_WEBSITE
            else -> ""
        }
    }
    /** True when [target] carries a valid kind (the entry was tagged by the editor / backup). */
    val hasExplicitTarget: Boolean get() = target?.kind == KIND_WEBSITE || target?.kind == KIND_ANDROID_PACKAGE
    /** Website origin for kind=website (falls back to [url] for untagged entries). */
    val targetOrigin: String get() = target?.origin.orEmpty().ifBlank { url.trim() }
    /** Android package for kind=android_package (falls back to [appPackage] / legacy androidapp:// uri for untagged entries). */
    val targetPackage: String get() = target?.packageName.orEmpty().ifBlank {
        appPackage.trim().ifBlank { url.trim().takeIf { it.startsWith("androidapp://", true) }?.substringAfter("://").orEmpty() }
    }
    val isAppEntryKind: Boolean get() = targetKind == KIND_ANDROID_PACKAGE
    /** Kept for callers: with one target per entry "mobile app linked" == App login. */
    val isMobileAppLinked: Boolean get() = targetKind == KIND_ANDROID_PACKAGE
    /** App login section (Android app data). */
    val isAppLogin: Boolean get() = targetKind == KIND_ANDROID_PACKAGE
    /** Website login section (browser data). */
    val isWebsiteLogin: Boolean get() = targetKind == KIND_WEBSITE

    companion object {
        const val KIND_WEBSITE = "website"
        const val KIND_ANDROID_PACKAGE = "android_package"
    }
}

@Serializable
data class EntryTarget(
    @SerialName("kind") val kind: String = "",
    /** kind=website: scheme://host[:port]. Never a package name. */
    @SerialName("origin") val origin: String = "",
    /** kind=android_package: the package name. Never turned into a URL. */
    @SerialName("packageName") val packageName: String = ""
)

@Serializable
data class CustomField(val k: String = "", val v: String = "")

@Serializable
data class PasswordHistoryItem(val pw: String = "", val changedAt: Long = 0L)

@Serializable
data class EditHistoryItem(
    val changedAt: Long = 0L,
    val fields: List<String> = emptyList(),
    val source: String = ""
)
