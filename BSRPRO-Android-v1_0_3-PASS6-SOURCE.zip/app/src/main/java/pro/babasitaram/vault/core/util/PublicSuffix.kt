package pro.babasitaram.vault.core.util

/**
 * AND-04: autofill "RELATED" match me parent domain public suffix nahi hona chahiye.
 * Warna entry `github.io` har `*.github.io` (alag-alag logon ki sites) se match hota tha.
 *
 * NOTE: yeh poori Public Suffix List nahi, ek chhoti, safe approximation hai:
 *  - single label (TLD) / khali / IP literal  => related nahi
 *  - country second-level pattern (`co.uk`, `com.au`, `co.in`, ...)  => related nahi
 *  - kuch bade shared-hosting suffixes ([PRIVATE])  => related nahi
 * Poori PSL (publicsuffix.org) asset ke roop me bundle karna ek alag decision hai (size + update cadence).
 */
object PublicSuffix {
    private val SECOND_LEVEL = setOf(
        "co", "com", "org", "net", "gov", "edu", "ac", "or", "ne", "go", "gob", "nic", "mil", "ltd", "plc", "sch", "res", "int"
    )

    private val PRIVATE = setOf(
        "github.io", "gitlab.io", "herokuapp.com", "vercel.app", "netlify.app", "pages.dev", "workers.dev",
        "web.app", "firebaseapp.com", "appspot.com", "blogspot.com", "cloudfront.net", "azurewebsites.net",
        "onrender.com", "ngrok.io", "fly.dev", "glitch.me", "repl.co", "surge.sh", "myshopify.com",
        "amazonaws.com", "s3.amazonaws.com", "execute-api.amazonaws.com"
    )

    fun isIpLiteral(host: String): Boolean {
        val h = host.trim().trim('[', ']')
        if (h.contains(':')) return true   // IPv6
        val parts = h.split('.')
        return parts.size == 4 && parts.all { it.isNotEmpty() && it.length <= 3 && it.all(Char::isDigit) }
    }

    fun isPublicSuffix(domain: String): Boolean {
        val d = domain.trim().lowercase().trim('.')
        if (d.isEmpty() || !d.contains('.')) return true
        if (d in PRIVATE) return true
        val parts = d.split('.')
        return parts.size == 2 && parts[1].length == 2 && parts[0] in SECOND_LEVEL
    }

    /**
     * true agar ek host dusre ka proper sub-domain hai AUR shared parent registrable domain hai
     * (public suffix / IP nahi). [a] aur [b] already lowercase / www-hata hue domains hain (UrlUtils.domainOf).
     */
    fun isRelated(a: String, b: String): Boolean {
        val parent = when {
            a.endsWith(".$b") -> b
            b.endsWith(".$a") -> a
            else -> return false
        }
        return !isPublicSuffix(parent) && !isIpLiteral(parent)
    }
}
