package pro.babasitaram.vault.core.crypto

import java.security.MessageDigest
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.util.VaultError

/** The extension writes two different plaintext schemas inside the same V3 container. */
sealed class V3PayloadResult {
    abstract val entries: List<VaultEntry>
    abstract val folders: List<Folder>

    /** {schema:'BSRPRO.Vault.Payload', version:3, entries[, folders]} (auto-backup) or a bare {entries} object. */
    data class AutoBackup(
        override val entries: List<VaultEntry>,
        override val folders: List<Folder> = emptyList()
    ) : V3PayloadResult()

    /** {version:'2.0', app:'BABASITARAMPro', entries, folders} (manual export) */
    data class ManualExport(
        override val entries: List<VaultEntry>,
        override val folders: List<Folder>
    ) : V3PayloadResult()
}

object V3PayloadParser {
    private const val SCHEMA = "BSRPRO.Vault.Payload"
    private const val APP = "BABASITARAMPro"
    private const val MAX_ENTRIES = 100_000

    fun parse(decryptedJson: String): V3PayloadResult {
        // accepts plain JSON (all existing vaults/backups) and the optional "BSRZ1:" compressed form
        val plainJson = VaultPlaintext.unpack(decryptedJson)
        val obj: JsonObject = try {
            VaultJson.parseToJsonElement(plainJson).jsonObject
        } catch (e: Exception) {
            throw VaultError.InvalidFormat("Payload is not a JSON object")
        }
        val schema = obj["schema"]?.jsonPrimitive?.contentOrNull
        val version = obj["version"]?.jsonPrimitive?.contentOrNull
        val app = obj["app"]?.jsonPrimitive?.contentOrNull
        val hasEntries = obj["entries"] != null

        return try {
            when {
                schema == SCHEMA && version in setOf("3", "4") -> {
                    if (!hasEntries) throw VaultError.InvalidFormat("Missing entries array")
                    V3PayloadResult.AutoBackup(entries(obj), folders(obj))
                }
                app == APP -> {
                    if (!hasEntries) throw VaultError.InvalidFormat("Missing entries array")
                    V3PayloadResult.ManualExport(entries(obj), folders(obj))
                }
                hasEntries -> V3PayloadResult.AutoBackup(entries(obj), folders(obj))
                else -> throw VaultError.InvalidFormat("Unknown V3 payload schema")
            }
        } catch (e: SerializationException) {
            throw VaultError.InvalidFormat("Malformed entry or folder: ${e.message}")
        } catch (e: IllegalArgumentException) {
            throw VaultError.InvalidFormat("Malformed payload: ${e.message}")
        }
    }

    private fun entries(obj: JsonObject): List<VaultEntry> {
        val arr = obj["entries"]?.jsonArray ?: throw VaultError.InvalidFormat("Missing entries array")
        if (arr.size > MAX_ENTRIES) throw VaultError.InvalidFormat("Too many entries")
        val blankIdOccurrences = HashMap<String, Int>()
        return arr.map { el ->
            val e = VaultJson.decodeFromJsonElement(VaultEntry.serializer(), el)
            if (e.id.isNotBlank()) e else {
                // Stable across repeated parsing of the same payload; occurrence disambiguates
                // byte-identical blank-ID records without changing the encrypted V3 container.
                val canonical = VaultJson.encodeToString(VaultEntry.serializer(), e.copy(id = ""))
                val digest = MessageDigest.getInstance("SHA-256")
                    .digest(canonical.toByteArray(Charsets.UTF_8))
                    .joinToString("") { b -> "%02x".format(b) }
                val occurrence = blankIdOccurrences.getOrDefault(digest, 0)
                blankIdOccurrences[digest] = occurrence + 1
                e.copy(id = "legacy-$digest-$occurrence")
            }
        }
    }

    private fun folders(obj: JsonObject): List<Folder> =
        obj["folders"]?.jsonArray?.map { VaultJson.decodeFromJsonElement(Folder.serializer(), it) } ?: emptyList()
}
