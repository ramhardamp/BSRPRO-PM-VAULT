package pro.babasitaram.vault.autofill

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import javax.inject.Inject
import javax.inject.Singleton
import pro.babasitaram.vault.core.model.EntryTarget
import pro.babasitaram.vault.core.model.VaultEntry

/** A credential captured by the autofill save flow, waiting for the user to review it in the editor. */
data class PendingSave(
    val packageName: String,
    val webDomain: String?,
    val username: String,
    val password: String,
    val createdAt: Long,
    val existingId: String? = null,
    val appPin: String = ""
) {
    val displayName: String
        get() = webDomain?.removePrefix("www.")?.ifEmpty { null } ?: packageName.substringAfterLast('.')

    fun toCandidate(): VaultEntry {
        val host = webDomain?.removePrefix("www.")?.takeIf { it.isNotEmpty() }
        val pretty = (host?.substringBefore('.') ?: packageName.substringAfterLast('.'))
            .replaceFirstChar { it.uppercase() }
        return VaultEntry(
            title = pretty,
            url = host?.let { "https://$it" } ?: "",
            type = "login",
            // ONE target: browser capture -> website origin, native-app capture -> android package (never a URL)
            target = if (host != null) EntryTarget(VaultEntry.KIND_WEBSITE, origin = "https://$host")
                     else EntryTarget(VaultEntry.KIND_ANDROID_PACKAGE, packageName = packageName),
            username = username,
            password = password,
            appPin = appPin,
            appPackage = if (host == null) packageName else "",
            appName = if (host == null) pretty else ""
        )
    }
}

/**
 * AND-02. In-memory only (plaintext is NEVER written to disk).
 *  - sliding TTL: a pending save lives [TTL_MS] (5 min) after its last use (peek / attach), so a user who is still
 *    unlocking / reviewing does not lose it; absolute cap [MAX_AGE_MS] (15 min) so it cannot live forever.
 *  - queue of [MAX_SLOTS] (3): a second login no longer overwrites the first. Same app/site + username replaces its
 *    own older slot (no duplicates). Oldest slot is dropped when the queue is full.
 *  - [peek] returns the newest slot; [clear] removes only that consumed slot, so the next one surfaces next.
 *  - [clearAll] is for an explicit (manual) lock. An AUTO lock must not clear: items are captured while locked.
 * Process death: optional [PendingSavePersistence] (Keystore-wrapped, <=15 min) -> [attachPersistence] restores slots.
   Persistence na ho (unit tests) to behavior pehle jaisa: sirf memory.
 */
@Singleton
class PendingSaveStore @Inject constructor() {
    internal var clock: () -> Long = { System.currentTimeMillis() }

    private class Slot(var save: PendingSave, val bornAt: Long, var touchedAt: Long)
    private val slots = ArrayList<Slot>()   // oldest first, newest last

    private fun key(p: PendingSave) = "${p.packageName}|${p.webDomain.orEmpty()}|${p.username}"

    private var persistence: PendingSavePersistence? = null
    private var restored = false

    private fun purge(now: Long): Boolean =
        slots.removeAll { now - it.touchedAt > TTL_MS || now - it.bornAt > MAX_AGE_MS }

    /** Process start par ek baar: disk se bache hue slots wapas (TTL / max-age abhi bhi lagu). */
    @Synchronized
    fun attachPersistence(p: PendingSavePersistence) {
        persistence = p
        if (restored) return
        restored = true
        try {
            val bytes = p.read() ?: return
            val loaded = decode(bytes)
            val live = ArrayList(slots)          // attach se pehle memory me aaye slots newest rakhe jate hain
            slots.clear(); slots.addAll(loaded); slots.addAll(live)
            purge(clock())
            while (slots.size > MAX_SLOTS) slots.removeAt(0)
            persist()
        } catch (e: Exception) {
            try { p.write(null) } catch (_: Exception) {}
        }
    }

    private fun persist() {
        val p = persistence ?: return
        try { p.write(if (slots.isEmpty()) null else encode()) } catch (_: Exception) { /* best-effort: memory copy bacha rehta hai */ }
    }

    private fun encode(): ByteArray {
        val bos = ByteArrayOutputStream()
        DataOutputStream(bos).use { o ->
            o.writeByte(FORMAT_VERSION)
            o.writeInt(slots.size)
            for (s in slots) {
                val v = s.save
                o.writeUTF(v.packageName)
                o.writeBoolean(v.webDomain != null); if (v.webDomain != null) o.writeUTF(v.webDomain)
                o.writeUTF(v.username)
                o.writeUTF(v.password)
                o.writeLong(v.createdAt)
                o.writeBoolean(v.existingId != null); if (v.existingId != null) o.writeUTF(v.existingId)
                o.writeUTF(v.appPin)
                o.writeLong(s.bornAt)
                o.writeLong(s.touchedAt)
            }
        }
        return bos.toByteArray()
    }

    private fun decode(bytes: ByteArray): List<Slot> {
        val out = ArrayList<Slot>()
        DataInputStream(ByteArrayInputStream(bytes)).use { i ->
            if (i.readUnsignedByte() != FORMAT_VERSION) return out
            val n = i.readInt()
            if (n < 0 || n > MAX_SLOTS) return out
            repeat(n) {
                val pkg = i.readUTF()
                val domain = if (i.readBoolean()) i.readUTF() else null
                val user = i.readUTF()
                val pw = i.readUTF()
                val created = i.readLong()
                val existing = if (i.readBoolean()) i.readUTF() else null
                val pin = i.readUTF()
                val born = i.readLong()
                val touched = i.readLong()
                out.add(Slot(PendingSave(pkg, domain, user, pw, created, existing, pin), born, touched))
            }
        }
        return out
    }

    @Synchronized
    fun put(p: PendingSave) {
        val now = clock()
        purge(now)
        slots.removeAll { key(it.save) == key(p) }
        slots.add(Slot(p, now, now))
        while (slots.size > MAX_SLOTS) slots.removeAt(0)
        persist()
    }

    @Synchronized
    fun peek(): PendingSave? {
        val now = clock()
        if (purge(now)) persist()
        val s = slots.lastOrNull() ?: return null
        s.touchedAt = now            // sliding: still being used
        return s.save
    }

    @Synchronized
    fun attach(existingId: String?) {
        val s = slots.lastOrNull() ?: return
        s.save = s.save.copy(existingId = existingId)
        s.touchedAt = clock()
        persist()
    }

    /** Removes the newest (just consumed) slot. */
    @Synchronized
    fun clear() {
        if (slots.isNotEmpty()) slots.removeAt(slots.size - 1)
        persist()
    }

    /** Drops everything (explicit manual lock). */
    @Synchronized
    fun clearAll() {
        slots.clear()
        persist()
    }

    @Synchronized
    fun size(): Int { if (purge(clock())) persist(); return slots.size }

    companion object {
        const val TTL_MS = 5 * 60 * 1000L        // sliding window (unlock + review)
        const val MAX_AGE_MS = 15 * 60 * 1000L   // absolute cap
        const val MAX_SLOTS = 3
        private const val FORMAT_VERSION = 1
    }
}
