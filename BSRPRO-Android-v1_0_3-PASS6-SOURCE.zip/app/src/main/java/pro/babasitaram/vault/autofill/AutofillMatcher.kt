package pro.babasitaram.vault.autofill

import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.PublicSuffix
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.core.util.isHiddenVault

/** EXACT = same domain / same Android package. RELATED = parent or sub-domain (shown with a warning). */
enum class MatchKind { EXACT, RELATED }

data class EntryMatch(val entry: VaultEntry, val kind: MatchKind)

object AutofillMatcher {

    fun match(
        entries: List<VaultEntry>,
        packageName: String,
        webDomain: String?,
        excludedPackages: Set<String> = emptySet(),
        regexEnabled: Boolean = true
    ): List<EntryMatch> {
        if (packageName in excludedPackages) return emptyList()
        val host = webDomain?.let { UrlUtils.domainOf(it) }.orEmpty()
        val out = ArrayList<EntryMatch>()
        for (e in entries) {
            // Hidden Vault entries kabhi autofill me nahi aate (privacy-first default)
            if (e.isHiddenVault) continue
            if (e.isFolderMarker || e.isNote || e.recordType.equals("note", ignoreCase = true)) continue
            if (e.username.isEmpty() && e.password.isEmpty() && e.appPin.isEmpty() && e.totp.isEmpty()) continue
            // Routing by target.kind (website -> origin, android_package -> packageName). Android autofills BOTH kinds.
            // Untagged (imported) entries are routed by their data: either route may match.
            val kind = when {
                e.hasExplicitTarget && e.targetKind == VaultEntry.KIND_ANDROID_PACKAGE -> appKind(e, packageName)
                e.hasExplicitTarget && e.targetKind == VaultEntry.KIND_WEBSITE -> if (host.isNotEmpty()) webKind(e, host, regexEnabled) else null
                else -> appKind(e, packageName) ?: if (host.isNotEmpty()) webKind(e, host, regexEnabled) else null
            }
            if (kind != null) out.add(EntryMatch(e, kind))
        }
        return out.sortedWith(
            compareBy<EntryMatch> { it.kind.ordinal }
                .thenByDescending { it.entry.lastUsedAt }
                .thenByDescending { it.entry.updatedAt }
                .thenBy { it.entry.title.lowercase() }
        )
    }

    private fun webKind(e: VaultEntry, host: String, regexEnabled: Boolean): MatchKind? {
        if (regexEnabled) {
            val regex = e.customFields.firstOrNull { it.k.equals("autofillRegex", ignoreCase = true) }?.v.orEmpty().trim()
            // AND-04: length cap + nested-quantifier filter + 20 ms time-box (SafeRegex); cache bhi wahin hai.
            if (regex.isNotEmpty() && SafeRegex.containsMatch(regex, host)) return MatchKind.EXACT
        }
        val entryHost = UrlUtils.domainOf(e.targetOrigin)
        if (entryHost.isEmpty()) return null
        return when {
            entryHost == host -> MatchKind.EXACT
            // AND-04: parent public suffix (github.io, co.uk ...) ya IP ho to related nahi
            PublicSuffix.isRelated(host, entryHost) -> MatchKind.RELATED
            else -> null
        }
    }

    private fun appKind(e: VaultEntry, packageName: String): MatchKind? {
        val requestedPackage = packageName.trim()
        if (requestedPackage.isEmpty()) return null
        val savedPackage = e.targetPackage.trim()
        return if (savedPackage.isNotEmpty() && savedPackage == requestedPackage) MatchKind.EXACT else null
    }
}

/** What goes into each kind of field. Pure functions so they can be unit-tested. */
object AutofillValues {
    /** If the current code expires within this many seconds, the next period's code is used instead. */
    const val OTP_EDGE_SECONDS = 3

    fun valueFor(type: AutofillFieldType, e: VaultEntry, nowMs: Long): String = when (type) {
        AutofillFieldType.USERNAME -> e.username.ifEmpty { e.email.ifEmpty { e.mobile } }
        // PIN-only logins (bank / telecom apps) still fill a password-typed box
        AutofillFieldType.PASSWORD -> e.password.ifEmpty { e.appPin }
        // No separate PIN stored: a 4-6 digit password is what a PIN box needs
        AutofillFieldType.PIN -> e.appPin.ifEmpty { e.password.takeIf { it.length in 4..6 && it.all(Char::isDigit) }.orEmpty() }
        AutofillFieldType.OTP -> otpFor(e, nowMs)
        AutofillFieldType.NEW_PASSWORD -> ""   // an existing password is never put into a "new password" field
    }

    fun otpFor(e: VaultEntry, nowMs: Long): String {
        if (e.totp.isBlank()) return ""
        val cfg = Totp.parse(e.totp) ?: return ""
        val current = Totp.current(e.totp, nowMs) ?: return ""
        val at = if (current.secondsRemaining <= OTP_EDGE_SECONDS) nowMs + current.secondsRemaining * 1000L else nowMs
        return Totp.generate(cfg, at).orEmpty()
    }
}
