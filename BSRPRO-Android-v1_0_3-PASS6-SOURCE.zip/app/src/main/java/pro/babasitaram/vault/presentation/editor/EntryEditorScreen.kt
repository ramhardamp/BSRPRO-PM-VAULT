@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.editor

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import android.util.LruCache
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.focus.onFocusChanged
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.presentation.components.PasswordField
import pro.babasitaram.vault.presentation.vault.CATEGORIES
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import pro.babasitaram.vault.core.util.L

private fun modeLabel(mode: String) = when (mode) {
    "app" -> "App Login"
    "card" -> "Card"
    "identity" -> "Identity"
    "note" -> "Secure note"
    else -> "Password"
}
private object AppIconCache {
    val icons = LruCache<String, android.graphics.Bitmap>(64)
}

@Composable
fun EntryEditorScreen(onDone: () -> Unit, vm: EntryEditorViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    BackHandler { if (!state.saving) onDone() }
    val form = state.form
    val context = LocalContext.current
    val attachmentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val now = System.currentTimeMillis()
            val name = runCatching {
                context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else "attachment"
                }
            }.getOrNull().orEmpty().ifBlank { "attachment" }
            val mime = context.contentResolver.getType(uri).orEmpty().ifBlank { "application/octet-stream" }
            vm.update { f ->
                f.copy(customFields = f.customFields + listOf(
                    CustomField("attachment_uri_$now", uri.toString()),
                    CustomField("attachment_name_$now", name),
                    CustomField("attachment_mime_$now", mime)
                ))
            }
        }
    }
    var confirmationVisible by remember { mutableStateOf(false) }
    val scroll = rememberScrollState()
    // a validation problem must never be hidden below the fold: jump to the top where the banner is
    LaunchedEffect(state.error) { if (state.error != null) scroll.animateScrollTo(0) }
    LaunchedEffect(state.saved) {
        if (state.saved) {
            confirmationVisible = true
            delay(SAVE_CONFIRMATION_DURATION_MS)
            if (confirmationVisible) {
                confirmationVisible = false
                delay(220L)
                onDone()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.isEdit) stringResource(pro.babasitaram.vault.R.string.p17_edit_entry_title) else stringResource(pro.babasitaram.vault.R.string.p17_new_entry_title)) },
                navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Cancel") } },
                actions = { TextButton(onClick = { vm.save() }, enabled = !state.saving && !state.saved) { Text(stringResource(R.string.p15_save)) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(scroll).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            state.error?.let { msg ->
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium) {
                    Text(
                        msg,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.fillMaxWidth().padding(12.dp)
                    )
                }
            }
            AnimatedVisibility(visible = confirmationVisible, enter = fadeIn(), exit = fadeOut()) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = MaterialTheme.shapes.large) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(saveConfirmationLabel(state.isEdit), modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onSecondaryContainer)
                        IconButton(onClick = { confirmationVisible = false; onDone() }) { Icon(Icons.Default.Close, contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_180)) }
                    }
                }
            }
            // Entry type is fixed by the chooser and shown first, above the title.
            Text(
                L.s(R.string.p18_entry_editor_type, modeLabel(state.mode)),
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.primary
            )
            OutlinedTextField(
                value = form.title,
                onValueChange = { v -> vm.update { it.copy(title = v) } },
                label = { Text(if (state.mode == "app") stringResource(pro.babasitaram.vault.R.string.p17_title_optional) else stringResource(pro.babasitaram.vault.R.string.p17_title)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            when (state.mode) {
                "login" -> {
                    Field("Website URL", form.url, KeyboardType.Uri) { v -> vm.update { it.copy(url = v) } }
                    Field("Username", form.username, KeyboardType.Email) { v -> vm.update { it.copy(username = v) } }
                    PasswordField(
                        value = form.password,
                        onValueChange = { v -> vm.update { it.copy(password = v) } },
                        label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_181),
                        showStrength = true,
                        trailingExtra = {
                            IconButton(onClick = vm::generatePassword) { Icon(Icons.Default.Autorenew, "Generate password") }
                        }
                    )
                }
                "app" -> {
                    AndroidAppPicker(
                        selectedName = form.appName,
                        selectedPackage = form.appPackage,
                        onSelected = { name, pkg -> vm.pickApp(name, pkg) },
                        onClear = { vm.update { it.copy(appName = "", appPackage = "") } }
                    )
                    Field("Username / mobile / ID", form.username, KeyboardType.Email) { v -> vm.update { it.copy(username = v) } }
                    PasswordField(
                        value = form.password,
                        onValueChange = { v -> vm.update { it.copy(password = v) } },
                        label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_181),
                        showStrength = true,
                        trailingExtra = {
                            IconButton(onClick = vm::generatePassword) { Icon(Icons.Default.Autorenew, "Generate password") }
                        }
                    )
                    PasswordField(
                        value = form.appPin,
                        onValueChange = { v -> vm.update { it.copy(appPin = v.filter { it in '0'..'9' }.take(6)) } },
                        label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_182),
                        keyboardType = KeyboardType.NumberPassword
                    )
                }
                "card" -> {
                    Field("Cardholder", form.cardholder) { v -> vm.update { it.copy(cardholder = v) } }
                    Field("Card number", form.cardNumber, KeyboardType.Number) { v -> vm.update { it.copy(cardNumber = v) } }
                    Field("Expiry (MM/YY)", form.cardExpiry) { v -> vm.update { it.copy(cardExpiry = v) } }
                    PasswordField(form.cardCvv, { v -> vm.update { it.copy(cardCvv = v) } }, stringResource(R.string.p15_cvv))
                    PasswordField(
                        value = form.appPin,
                        onValueChange = { v -> vm.update { it.copy(appPin = v.filter { it in '0'..'9' }.take(6)) } },
                        label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_183),
                        keyboardType = KeyboardType.NumberPassword
                    )
                    Field("Bank", form.customValue("Bank")) { v -> vm.update { it.withCustomValue("Bank", v) } }
                }
                "identity" -> {
                    Field("Full name", form.fullName) { v -> vm.update { it.copy(fullName = v) } }
                    Field("Email", form.email, KeyboardType.Email) { v -> vm.update { it.copy(email = v) } }
                    Field("Phone", form.phone, KeyboardType.Phone) { v -> vm.update { it.copy(phone = v) } }
                    Field("Address", form.address, singleLine = false) { v -> vm.update { it.copy(address = v) } }
                    Field("ID number", form.idNumber) { v -> vm.update { it.copy(idNumber = v) } }
                    Field("ID expiry", form.idExpiry) { v -> vm.update { it.copy(idExpiry = v) } }
                }
                else -> {
                    // legacy note records are edited in the Notes editor
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_184), style = MaterialTheme.typography.bodyMedium)
                }
            }

            Text(stringResource(R.string.p15_category), style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(CATEGORIES) { c ->
                    FilterChip(
                        selected = form.category.equals(c, ignoreCase = true),
                        onClick = { vm.update { it.copy(category = c) } },
                        label = { Text(c.replaceFirstChar { ch -> ch.uppercase() }) }
                    )
                }
            }

            if (state.folders.isNotEmpty()) {
                var open by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { open = true }) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_folder_value, state.folders.firstOrNull { it.id == form.folderId }?.name ?: androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_186)))
                    }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_186)) }, onClick = { open = false; vm.update { it.copy(folderId = "") } })
                        state.folders.forEach { f ->
                            DropdownMenuItem(text = { Text(f.name) }, onClick = { open = false; vm.update { it.copy(folderId = f.id) } })
                        }
                    }
                }
            }

            Field("Tags (comma separated)", form.tags) { v -> vm.update { it.copy(tags = v) } }
            run {
                val hidden = pro.babasitaram.vault.core.util.HiddenVault.isHiddenText(form.tags)
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_187), style = MaterialTheme.typography.bodyLarge)
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_188), style = MaterialTheme.typography.bodySmall)
                    }
                    androidx.compose.material3.Switch(
                        checked = hidden,
                        onCheckedChange = { on -> vm.update { it.copy(tags = pro.babasitaram.vault.core.util.HiddenVault.withHidden(it.tags, on)) } }
                    )
                }
            }

            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_189), style = MaterialTheme.typography.labelLarge)
            form.customFields.forEachIndexed { index, field ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = field.k, onValueChange = { v -> vm.update { f -> f.copy(customFields = f.customFields.replaceAt(index, field.copy(k = v))) } },
                        label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_190)) }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = field.v, onValueChange = { v -> vm.update { f -> f.copy(customFields = f.customFields.replaceAt(index, field.copy(v = v))) } },
                        label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_191)) }, singleLine = true, modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { vm.update { f -> f.copy(customFields = f.customFields.filterIndexed { i, _ -> i != index }) } }) {
                        Icon(Icons.Default.Close, "Remove field")
                    }
                }
            }
            TextButton(onClick = { vm.update { it.copy(customFields = it.customFields + CustomField()) } }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_192)) }

            Button(onClick = { vm.save() }, enabled = !state.saving && !state.saved, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p15_save)) }
        }
    }

    state.duplicate?.let { dup ->
        AlertDialog(
            onDismissRequest = vm::dismissDuplicate,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_193), style = MaterialTheme.typography.titleLarge) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_dup_entry_message, dup.title)) },
            confirmButton = { TextButton(onClick = { vm.save(overwrite = dup) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_194)) } },
            dismissButton = {
                Row {
                    TextButton(onClick = { vm.save(skipDuplicateCheck = true) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_195)) }
                    TextButton(onClick = vm::dismissDuplicate) { Text(stringResource(R.string.p15_cancel)) }
                }
            }
        )
    }
}

private fun <T> List<T>.replaceAt(index: Int, value: T): List<T> =
    mapIndexed { i, old -> if (i == index) value else old }

@Composable
private fun AndroidAppPicker(
    selectedName: String,
    selectedPackage: String,
    onSelected: (String, String) -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    data class PickerApp(val name: String, val packageName: String)
    val apps = remember(context) {
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        runCatching {
            context.packageManager.queryIntentActivities(intent, 0)
                .map { it.activityInfo.applicationInfo to context.packageManager.getApplicationLabel(it.activityInfo.applicationInfo).toString() }
                .distinctBy { it.first.packageName }
                .map { (info, label) -> PickerApp(label, info.packageName) }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        }.getOrDefault(emptyList())
    }
    var dialogOpen by remember { mutableStateOf(false) }
    var query by remember(selectedPackage, selectedName) { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter {
            it.name.contains(query.trim(), ignoreCase = true) ||
                it.packageName.contains(query.trim(), ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        OutlinedTextField(
            value = when {
                selectedPackage.isNotBlank() && selectedName.isNotBlank() -> "$selectedName · $selectedPackage"
                selectedPackage.isNotBlank() -> selectedPackage
                selectedName.isNotBlank() -> "$selectedName · Not linked"
                else -> ""
            },
            onValueChange = {},
            readOnly = true,
            leadingIcon = {
                if (selectedPackage.isNotBlank()) {
                    val selectedIcon = remember(context, selectedPackage) {
                        runCatching {
                            context.packageManager
                                .getApplicationIcon(selectedPackage)
                                .toBitmap(96, 96)
                        }.getOrNull()
                    }
                    if (selectedIcon != null) {
                        Surface(
                            shape = MaterialTheme.shapes.medium,
                            tonalElevation = 2.dp,
                            modifier = Modifier.size(52.dp)
                        ) {
                            Image(
                                selectedIcon.asImageBitmap(),
                                contentDescription = selectedName.ifBlank { selectedPackage },
                                modifier = Modifier.fillMaxSize().padding(6.dp)
                            )
                        }
                    }
                }
            },
            label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_196)) },
            placeholder = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_197)) },
            supportingText = {
                Text(when {
                    selectedPackage.isNotBlank() -> androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_package_linked)
                    selectedName.isNotBlank() -> androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_relink_app)
                    else -> androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_select_android_app)
                })
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().clickable { dialogOpen = true }.onFocusChanged { if (it.isFocused) dialogOpen = true }
        )
        OutlinedButton(onClick = { query = ""; dialogOpen = true }, modifier = Modifier.fillMaxWidth()) {
            Text(if (selectedPackage.isBlank()) stringResource(pro.babasitaram.vault.R.string.p17_choose_android_app) else stringResource(pro.babasitaram.vault.R.string.p17_change_android_app))
        }
        if (selectedPackage.isNotBlank()) {
            TextButton(onClick = onClear) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_198)) }
        }
    }

    if (dialogOpen) {
        Dialog(
            onDismissRequest = { dialogOpen = false },
            properties = DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = false
            )
        ) {
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background
            ) {
                Column(Modifier.fillMaxSize()) {
                    TopAppBar(
                        title = {
                            Column {
                                Text(stringResource(pro.babasitaram.vault.R.string.p17_loc_199))
                                Text(
                                    "Select the app that should use this same login",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        navigationIcon = {
                            IconButton(onClick = { dialogOpen = false }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(pro.babasitaram.vault.R.string.p17_loc_180))
                            }
                        }
                    )
                    Column(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = query,
                            onValueChange = { query = it },
                            label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_200)) },
                            placeholder = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_201)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            "${filtered.size} apps",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (filtered.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                                Text(
                                    if (apps.isEmpty()) stringResource(R.string.p18_entry_editor_no_launchable_apps_found_check)
                                    else stringResource(R.string.p18_entry_editor_no_apps_match_your_search),
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
                            ) {
                                items(filtered, key = { it.packageName }, contentType = { "app" }) { app ->
                                    val icon = remember(context, app.packageName) {
                                        AppIconCache.icons.get(app.packageName) ?: runCatching {
                                            context.packageManager.getApplicationIcon(app.packageName).toBitmap(192, 192)
                                        }.getOrNull()?.also { AppIconCache.icons.put(app.packageName, it) }
                                    }
                                    val selected = app.packageName == selectedPackage
                                    Surface(
                                        onClick = { onSelected(app.name, app.packageName); dialogOpen = false },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = MaterialTheme.shapes.large,
                                        tonalElevation = if (selected) 3.dp else 1.dp,
                                        border = if (selected) androidx.compose.foundation.BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null
                                    ) {
                                        Row(
                                            Modifier.fillMaxWidth().padding(16.dp),
                                            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                                        ) {
                                            Surface(
                                                shape = MaterialTheme.shapes.large,
                                                tonalElevation = 2.dp,
                                                modifier = Modifier.size(76.dp)
                                            ) {
                                                if (icon != null) {
                                                    Image(
                                                        icon.asImageBitmap(),
                                                        contentDescription = app.name,
                                                        modifier = Modifier.fillMaxSize().padding(8.dp)
                                                    )
                                                } else {
                                                    Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                                                        Text("◈", style = MaterialTheme.typography.headlineMedium)
                                                    }
                                                }
                                            }
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                                Text(app.name, style = MaterialTheme.typography.titleMedium)
                                                Text(app.packageName, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                                if (selected) {
                                                    Text(stringResource(R.string.p20_selected_uses_this_login), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                                }
                                            }
                                            if (selected) {
                                                Text("✓", style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}
