package pro.babasitaram.vault.autofill

import java.util.concurrent.ConcurrentHashMap

/**
 * AND-04: entry ke custom field `autofillRegex` (backup import se bhi aa sakta hai) FillRequest ke andar chalta hai.
 * Catastrophic backtracking se request deadline cross hoti thi aur system request cancel kar deta tha (purana 8.6 bug).
 *
 * Teen guard:
 *  1. Pattern length cap ([MAX_PATTERN_LENGTH]).
 *  2. Static pre-filter: classic nested-quantifier forms (`(a+)+`, `(.*)*`, `(\w+\s*)+`, `(a+|b)+`) reject.
 *     Yeh sirf fast filter hai, poori guarantee nahi (jaise `(\w+\w)+` pakadna mushkil hai).
 *  3. ASLI guarantee: har evaluation [BUDGET_NANOS] ke time-box me. Budget khatam => match = false,
 *     aur woh pattern aage kabhi chalaya nahi jata.
 *
 * Sahi (legit) patterns jaise `^(m|login)\.shop\.in$` ya `([a-z0-9-]+\.)*example\.com` allow rehte hain.
 */
object SafeRegex {
    const val MAX_PATTERN_LENGTH = 200
    const val MAX_HOST_LENGTH = 253
    const val BUDGET_NANOS = 20_000_000L   // 20 ms per evaluation

    private class Timeout : RuntimeException() {
        override fun fillInStackTrace(): Throwable = this   // cheap: stack trace nahi
    }

    /** CharSequence jo har ~256 reads par deadline check karta hai; Regex engine isi se padhta hai. */
    private class DeadlineChars(private val src: CharSequence, private val deadlineNanos: Long) : CharSequence {
        private var reads = 0
        override val length: Int get() = src.length
        override fun get(index: Int): Char {
            if ((++reads and 0xFF) == 0 && System.nanoTime() > deadlineNanos) throw Timeout()
            return src[index]
        }
        override fun subSequence(startIndex: Int, endIndex: Int): CharSequence =
            DeadlineChars(src.subSequence(startIndex, endIndex), deadlineNanos)
        override fun toString(): String = src.toString()
    }

    private val compiled = ConcurrentHashMap<String, Regex>()
    private val rejected: MutableSet<String> = ConcurrentHashMap.newKeySet()   // unsafe / slow / invalid patterns

    /** Test ke liye: cache + rejected set saaf. */
    internal fun resetForTest() { compiled.clear(); rejected.clear() }

    /** true agar [pattern] ka koi hissa [host] me milta hai. Koi bhi problem (invalid/unsafe/slow) => false, kabhi throw nahi. */
    fun containsMatch(pattern: String, host: String): Boolean {
        if (pattern.isEmpty() || host.isEmpty() || host.length > MAX_HOST_LENGTH) return false
        if (pattern in rejected) return false
        val re = compiled[pattern] ?: compile(pattern) ?: return false
        return try {
            re.containsMatchIn(DeadlineChars(host, System.nanoTime() + BUDGET_NANOS))
        } catch (t: Timeout) {
            markRejected(pattern)
            false
        } catch (t: RuntimeException) {
            false
        }
    }

    private fun compile(pattern: String): Regex? {
        if (pattern.length > MAX_PATTERN_LENGTH || hasNestedQuantifier(pattern)) {
            markRejected(pattern)
            return null
        }
        val r = runCatching { Regex(pattern, RegexOption.IGNORE_CASE) }.getOrNull()
        if (r == null) { markRejected(pattern); return null }
        if (compiled.size > 256) compiled.clear()
        compiled[pattern] = r
        return r
    }

    private fun markRejected(pattern: String) {
        if (rejected.size > 512) rejected.clear()
        rejected.add(pattern)
    }

    private class Frame {
        var hasVarQuant = false      // is group ke andar koi variable quantifier (*, +, {n,}, {n,m})
        var lastAtomVar = false      // current branch ka aakhri atom variable-quantified hai
        var branchEndedVar = false   // pichhli `|` branch variable-quantified atom par khatam hui
    }

    /**
     * Static pre-filter: group jiska body variable quantifier rakhta hai aur body ki (kisi branch ki) akhri cheez bhi
     * variable-quantified hai, aur group khud variable quantifier se quantified hai  =>  nested (catastrophic-prone).
     */
    internal fun hasNestedQuantifier(p: String): Boolean {
        val stack = ArrayList<Frame>()
        stack.add(Frame())
        var i = 0
        val n = p.length
        while (i < n) {
            val c = p[i]
            when {
                c == '\\' -> { stack.last().lastAtomVar = false; i += 2 }
                c == '[' -> {
                    i++
                    if (i < n && p[i] == '^') i++
                    if (i < n && p[i] == ']') i++
                    while (i < n && p[i] != ']') { if (p[i] == '\\') i++; i++ }
                    i++
                    stack.last().lastAtomVar = false
                }
                c == '(' -> { stack.add(Frame()); i++ }
                c == ')' -> {
                    if (stack.size <= 1) return false          // unbalanced: Regex() khud fail karega
                    val inner = stack.removeAt(stack.size - 1)
                    i++
                    val endsVar = inner.lastAtomVar || inner.branchEndedVar
                    if (inner.hasVarQuant && endsVar && variableQuantifierAt(p, i) > 0) return true
                    val parent = stack.last()
                    parent.hasVarQuant = parent.hasVarQuant || inner.hasVarQuant
                    parent.lastAtomVar = false                  // group ek atom hai; quantifier aage handle hoga
                }
                c == '|' -> {
                    val f = stack.last()
                    if (f.lastAtomVar) f.branchEndedVar = true
                    f.lastAtomVar = false
                    i++
                }
                c == '*' || c == '+' -> {
                    val f = stack.last(); f.hasVarQuant = true; f.lastAtomVar = true
                    i++
                    if (i < n && (p[i] == '?' || p[i] == '+')) i++   // lazy / possessive
                }
                c == '?' -> { i++; if (i < n && (p[i] == '?' || p[i] == '+')) i++ }   // optional: variable nahi mana
                c == '{' -> {
                    val len = braceQuantifierLength(p, i)
                    if (len > 0) {
                        val isRange = p.substring(i, i + len).contains(',')
                        if (isRange) { val f = stack.last(); f.hasVarQuant = true; f.lastAtomVar = true }
                        i += len
                        if (i < n && (p[i] == '?' || p[i] == '+')) i++
                    } else { stack.last().lastAtomVar = false; i++ }
                }
                else -> { stack.last().lastAtomVar = false; i++ }
            }
        }
        return false
    }

    /** `{n}`, `{n,}`, `{n,m}` ki length (0 agar yahan brace quantifier nahi). */
    private fun braceQuantifierLength(p: String, start: Int): Int {
        var j = start + 1
        val n = p.length
        var digits = 0
        while (j < n && p[j].isDigit()) { j++; digits++ }
        if (digits == 0) return 0
        if (j < n && p[j] == ',') { j++; while (j < n && p[j].isDigit()) j++ }
        return if (j < n && p[j] == '}') j - start + 1 else 0
    }

    /** index [i] par variable quantifier (`*`, `+`, `{n,}`, `{n,m}`) ho to uski length, warna 0. */
    private fun variableQuantifierAt(p: String, i: Int): Int {
        if (i >= p.length) return 0
        return when (p[i]) {
            '*', '+' -> 1
            '{' -> { val len = braceQuantifierLength(p, i); if (len > 0 && p.substring(i, i + len).contains(',')) len else 0 }
            else -> 0
        }
    }
}
