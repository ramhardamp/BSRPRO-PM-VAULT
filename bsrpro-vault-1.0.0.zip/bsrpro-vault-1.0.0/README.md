
> **1.0.0 build note** — see `docs/CHANGELOG_1.0.0.md` (backup-folder restore fix) and `docs/FEATURE_AUDIT.md` (honest spec status).
> `versionCode` is still **30**: the request said "Code 20", but a lower code cannot be installed over an existing build
> (INSTALL_FAILED_VERSION_DOWNGRADE). To force 20, edit `versionCode` in `app/build.gradle.kts` and uninstall the old app first.
# BSRPRO Vault — Android

Native Android companion for the BSRPRO Password Manager browser extension.
Kotlin · Jetpack Compose · Hilt · MVVM + Clean Architecture · min SDK 26.

## Build
1. Open in Android Studio (Koala+ / JDK 17).
2. If `gradlew` is missing: `gradle wrapper --gradle-version 8.7` (or let Android Studio sync).
3. `./gradlew assembleDebug`

## Status
Current: Phase 16D. Fix.md ka live status `docs/FIX_MD_STATUS.md` me, badlav ki history `docs/CHANGELOG_PHASE16.md` me, extension ka kaam `docs/EXTENSION_UPDATE.md` me.
Source-level checks pass hote hain (`python3 tools/all_fixes_regression.py`), lekin Gradle build aur device test abhi baaki hai: `./gradlew testDebugUnitTest assembleDebug`, phir autofill ko real device par test karein (Chrome, Gmail, banking app).

### Notes
- Autofill: enable under Android Settings → Passwords & autofill → Autofill service → BSRPRO Vault. Pages served over plain `http` never get suggestions.
- OTP fields get the TOTP code of the matching entry (the next period's code if < 3 s are left). Android does not refresh an already shown suggestion, so the code is computed when the list is built.
- Auto-backup writes a V3 `.Vault` file, which is encrypted with the master password; it therefore runs while the vault is unlocked (daily worker + catch-up on unlock).
- The ROADMAP TOTP vector `JBSWY3DPEHPK3PXP @ 1600000000 → 282760` is wrong; the correct code is `368941` (see TotpRoadmapVectorTest).

## Security rules
- Master password is always `CharArray`, wiped after use.
- No INTERNET permission until the optional sync phase.
- Keystore / signing files are git-ignored. Never commit them.
