package pro.babasitaram.vault.presentation.setup

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.domain.usecase.CreateVaultUseCase
import pro.babasitaram.vault.domain.usecase.RestoreBackupUseCase
import pro.babasitaram.vault.domain.usecase.RecoveryKeyUseCase
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.presentation.util.toUserMessage

import androidx.compose.foundation.layout.*
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

@Stable
data class SetupUiState(
    val busy: Boolean = false,
    val error: String? = null,
    val awaitingBackupPassword: Boolean = false,
    val recoveryKey: String? = null,
    val backupFolderUri: String = "",
    /** A backup file was found in the chosen folder / default location. */
    val backupFound: Boolean = false,
    /** The found backup did not open with the typed master password: ask for the backup's own password. */
    val backupMismatch: Boolean = false
)

@HiltViewModel
class SetupViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val createVault: CreateVaultUseCase,
    private val restoreBackup: RestoreBackupUseCase,
    private val recoveryKey: RecoveryKeyUseCase,
    private val clipboard: pro.babasitaram.vault.presentation.util.ClipboardActions,
    private val activityLog: ActivityLogStore,
    private val settings: SettingsRepository,
    private val autoBackup: AutoBackupManager
) : ViewModel() {

    /** Copies a secret through the vault clipboard manager (sensitive flag + auto-clear). */
    fun copySecret(text: String, label: String) {
        launchCatching { clipboard.copy(text, label) }
    }

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()

    private var pendingBackup: String? = null

    init {
        launchCatching { settings.settings.collect { cfg -> _state.update { it.copy(backupFolderUri = cfg.backupFolderUri) } } }
    }

    /**
     * Folder chosen in the "Backup folder" card. Previously this only stored the URI, so an existing
     * BSRPRO.Vault in that folder was never restored and an EMPTY vault got created next to it.
     * Now the folder is scanned right away; if a backup is there and a master password was already
     * typed, it is restored automatically with that password.
     */
    fun onBackupFolderSelected(uri: Uri, typedPassword: String = "") {
        launchCatching {
            settings.update { it.copy(backupFolderUri = uri.toString()) }
            _state.update { it.copy(error = null, busy = true, backupFolderUri = uri.toString()) }
            val found = loadBackupFromSettingsLocation()
            _state.update { it.copy(busy = false, backupFound = found, backupMismatch = false) }
            if (found && typedPassword.isNotEmpty()) attemptRestore(typedPassword, askOnFailure = true)
        }
    }

    /** Reads the best backup (selected folder first, then default locations) into [pendingBackup]. */
    private suspend fun loadBackupFromSettingsLocation(): Boolean {
        val file = (try {
            autoBackup.findRestorableBackup()
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            null
        }) ?: return false
        return try {
            val text = withContext(Dispatchers.IO) {
                if (!file.isFile || file.length() !in 1..MAX_BACKUP_BYTES.toLong()) "" else file.readText(Charsets.UTF_8).trim()
            }
            if (text.isEmpty()) false else { pendingBackup = text; true }
        } finally {
            runCatching { file.delete() }      // private cache copy only; the real backup is never touched
        }
    }

    /**
     * Restores [pendingBackup] with [password]. The backup password becomes the master password (same as the
     * manual restore). Returns true when the vault was created from the backup.
     */
    private suspend fun attemptRestore(password: String, askOnFailure: Boolean): Boolean {
        val text = pendingBackup ?: return false
        val pw = password.toCharArray()
        try {
            _state.update { it.copy(busy = true, error = null) }
            return when (val r = restoreBackup(text, pw)) {
                is VaultResult.Success -> {
                    activityLog.record("Restore completed", "${r.value} records restored from the backup folder during setup")
                    pendingBackup = null
                    _state.update { it.copy(busy = false, awaitingBackupPassword = false, backupMismatch = false, backupFound = false) }
                    true
                }
                is VaultResult.Failure -> {
                    val wrongPassword = r.error is VaultError.InvalidMasterPassword
                    _state.update {
                        it.copy(
                            busy = false,
                            awaitingBackupPassword = askOnFailure,
                            backupMismatch = wrongPassword,
                            error = if (wrongPassword) null else r.error.toUserMessage()
                        )
                    }
                    false
                }
                VaultResult.Loading -> { _state.update { it.copy(busy = false) }; false }
            }
        } finally {
            pw.fill('\u0000')
        }
    }

    fun onBackupTreeSelected(treeUri: Uri, typedPassword: String = "") {
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            try {
                // Fix.md 7.2: exact BSRPRO.Vault pehle; na mile to folder/sub-folder ki baaki .Vault files (header check ke saath).
                // Query + file padhna IO thread par (pehle main thread par chal raha tha).
                val fileUri = withContext(Dispatchers.IO) {
                    pro.babasitaram.vault.data.backup.BackupFolderFinder(context).findBestBackup(treeUri)
                } ?: throw java.io.FileNotFoundException(L.s(R.string.setup_backup_not_found))
                val text = withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() } ?: throw java.io.IOException("Backup cannot be opened")
                    require(bytes.size in 1..MAX_BACKUP_BYTES) { "Backup size is invalid" }
                    String(bytes, Charsets.UTF_8)
                }
                pendingBackup = text
                settings.update { it.copy(backupFolderUri = treeUri.toString()) }
                _state.update { it.copy(busy = false, backupFolderUri = treeUri.toString(), backupFound = true, awaitingBackupPassword = typedPassword.isEmpty()) }
                // Master password already typed on this screen: restore straight away (no extra prompt).
                if (typedPassword.isNotEmpty()) attemptRestore(typedPassword, askOnFailure = true)
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, error = e.message ?: "Backup folder could not be read") }
            }
        }
    }

    /**
     * Creates the vault. If a backup exists in the chosen folder (or the default backup location) and the typed
     * master password opens it, the backup is restored automatically instead of creating an empty vault.
     * [skipBackupCheck] = user explicitly chose "create a new empty vault" (the existing backup file is kept).
     */
    fun create(password: String, confirm: String, skipBackupCheck: Boolean = false) {
        val pw = password.toCharArray()
        val cf = confirm.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            if (!skipBackupCheck && password.isNotEmpty() && pw.contentEquals(cf)) {
                if (pendingBackup == null) {
                    val found = loadBackupFromSettingsLocation()
                    _state.update { it.copy(backupFound = found) }
                }
                if (pendingBackup != null) {
                    if (attemptRestore(password, askOnFailure = true)) {
                        pw.fill('\u0000'); cf.fill('\u0000')
                        return@launchCatching          // restored: RootViewModel switches to the vault screens
                    }
                    if (_state.value.awaitingBackupPassword || _state.value.error != null) {
                        pw.fill('\u0000'); cf.fill('\u0000')
                        return@launchCatching          // waiting for the backup's own password / showing an error
                    }
                }
            }
            val r = createVault(pw, cf)
            pw.fill('\u0000')
            cf.fill('\u0000')
            if (r is VaultResult.Success) {
                activityLog.record("Vault created", "Initial vault setup completed")
                if (!skipBackupCheck) autoBackup.armAutoImport()   // safety net: pick up a backup that appears later
                when (val recovery = recoveryKey.ensureCreated()) {
                    is VaultResult.Success -> _state.update { it.copy(busy = false, recoveryKey = recovery.value) }
                    is VaultResult.Failure -> _state.update { it.copy(busy = false, error = recovery.error.toUserMessage()) }
                    VaultResult.Loading -> Unit
                }
            } else {
                _state.update { it.copy(busy = false, error = (r as? VaultResult.Failure)?.error?.toUserMessage()) }
            }
            // On success the session unlocks and RootViewModel switches to the vault screens.
        }
    }

    fun dismissRecoveryKey() {
        _state.update { it.copy(recoveryKey = null) }
    }

    fun onBackupPicked(uri: Uri) {
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            val text = try {
                withContext(Dispatchers.IO) {
                    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                        ?: throw java.io.IOException("Cannot open file")
                    require(bytes.size <= MAX_BACKUP_BYTES) { "File too large" }
                    String(bytes, Charsets.UTF_8)
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, error = L.s(R.string.p18_setup_could_not_read_the_selected)) }
                return@launchCatching
            }
            pendingBackup = text
            _state.update { it.copy(busy = false, awaitingBackupPassword = true) }
        }
    }

    fun restore(backupPassword: String) {
        val text = pendingBackup ?: return
        val pw = backupPassword.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            val r = restoreBackup(text, pw)
            pw.fill('\u0000')
            if (r is VaultResult.Failure) {
                _state.update { it.copy(busy = false, error = r.error.toUserMessage(), awaitingBackupPassword = true, backupMismatch = false) }
            } else {
                activityLog.record("Restore completed", "Backup restored during setup")
                pendingBackup = null
                _state.update { it.copy(busy = false, awaitingBackupPassword = false) }
            }
        }
    }

    fun cancelRestore() {
        pendingBackup = null
        _state.update { it.copy(awaitingBackupPassword = false, backupMismatch = false, backupFound = false) }
    }

    /** Dialog action "Create new vault": ignores the found backup (file stays untouched) and creates an empty vault. */
    fun createWithoutRestore(password: String, confirm: String) {
        pendingBackup = null
        _state.update { it.copy(awaitingBackupPassword = false, backupMismatch = false, backupFound = false) }
        create(password, confirm, skipBackupCheck = true)
    }

    private companion object {
        const val MAX_BACKUP_BYTES = 50_000_000
    }
}
