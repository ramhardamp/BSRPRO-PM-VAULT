# Phase 15Z — verification round on the newest tree (NOT compiled, NOT device-tested)

Format: Issue -> Fix -> Logic (Fix.md style). Base: uploaded `.bin` = Phase15W tree with the 15X + 15Y changes (versionCode 28).

## 0. Is round me kya hua
- **Issue:** Is round me 8 pending issues + Fix.md dobara aaye, lekin uploaded tree me 15X/15Y reports ke hisaab se ye pehle se fix the.
- **Fix:** Pehle verify kiya (tools: `phase_smart_session_audit.py` patterns, naya `symbol_check.py`). Phir Fix.md 5.2 (size optimisation) app side par implement kiya, section 5 dekho. versionCode 28 -> 29.
- **Logic:** Parallel edits karne se 15X/15Y ke fixes se conflict hota. Isliye existing tree verify kiya, nayi regression nahi joDi.

## 1. Audit script ke 6 FAIL — sab false positive nikle
- **Issue:** `phase_smart_session_audit.py` 6 FAIL dikha raha tha.
- **Fix:** Patterns ko current code se match kiya (checks 67/67 pass ab):
  - Device credential fallback: ab `DEVICE_CREDENTIAL` constant + localized "Use device PIN" string (L.s) check hota hai.
  - Key B store: key naam `biometric_credential_v2` hai, aur password `cipher.doFinal(bytes)` se encrypt hokar jaata hai (plaintext nahi).
  - Root startup: `runCatching { withTimeoutOrNull(4_000L) { restoreSession() } }` (Fix.md 4.1).
  - Logging check: `activityLog.record` ("...Log.record") aur comments me aaya "password" shabd ab match nahi hota.
  - Brace balance: string/char literals hata kar ginti (Csv.kt, ImportParser.kt, BackupUseCases.kt sab balanced).
- **Logic:** Har FAIL ko pehle asli code me hand-check kiya; koi asli bug nahi mila, isliye app code nahi chhua.

## 2. Static checks (is exact tree par)
| Check | Result |
|---|---|
| bracket_check | 0 issues |
| phase_smart_session_audit | 67/67 |
| phase15m_regression | 10/10 + 8/8 |
| all_fixes_regression | 68/68 |
| XML (EN `values`, HI `values-b+hi`, manifest, res/**) | 0 invalid |
| Strings | EN 866 / HI 866, 0 duplicates, 0 HI-only, 0 undefined `R.string`/`@string`/`L.s` refs, placeholders equal |
| `import pro.babasitaram.vault.R` missing | 0 |
| Duplicate imports | 0 |
| symbol_check (unresolved capitalised symbols) | residuals hand-checked: stdlib/Java aliases, top-level vals, wildcard imports, text in strings |
| Unit-test constructor arity | 0 real mismatches (hits are all-default `VaultSettings()` / `ExportOptions()`) |

## 3. Fix.md ke baaki items — honest status
- **5.2 Size optimisation:** app ke andar ka vault ab compress hota hai (section 5). Export/backup `.Vault` abhi bhi pehle jaisa hai jab tak extension update na ho.
- **3.6 Lottie:** NAHI hua. Logo + Compose pulse animation hai; Lottie ke liye library + animation file chahiye.
- **1.1 extension-side "sirf website padho" filter:** extension code is ZIP me nahi hai. App export/backup me app data filter nahi kiya (shared .Vault se data lose hota).
- **3.7 poore app ka typography/spacing sweep:** sirf Backup screen aur splash par hua.

## 4. Pending / unverified
- Compile nahi hua (sandbox me Gradle/Android SDK nahi). Push -> build -> `gradle testDebugUnitTest` chalana baaki.
- Device-only: SAF backup (10 baar backup = 1 file), theme flash, launch speed, Entry PIN autofill (OEM), PIN flows, Hindi text ki native-speaker reading, app icon ka padding.
- Biometric `setUserAuthenticationRequired` hardening is tree me Key B par already hai (audit check pass); migration/device test baaki.

## 5. Size optimisation (Fix.md 5.2) — Issue -> Fix -> Logic
- **Issue:** Vault ka payload bada tha (har entry ke saare default fields JSON me jaate the); 1000+ entries par file MB me, har save par poora blob encrypt + write.
- **Fix:** Naya `core/crypto/VaultPlaintext.kt`. Payload encrypt se PEHLE gzip hota hai: `"BSRZ1:" + Base64(gzip(UTF-8 JSON))`. 16 KB se chhota payload plain JSON hi rehta hai. `VaultBlobStore.write` pack karta hai; `V3PayloadParser.parse` unpack karta hai (isliye blob, restore snapshot, import, backup read-back, sab dono form padhte hain).
- **Logic:** Encryption/KDF/schema nahi badla. Marker na ho to purani plain JSON jaisa hi padha jata hai, isliye purane vaults, backups aur extension files bina badlav khulte hain. Unpack me 64 MB cap (zip-bomb guard) aur kharab data par `InvalidFormat`. Neeche ki hadd: naya blob purane app build me nahi khulega (downgrade unsupported).
- **Export/backup `.Vault` jaan-boojh kar abhi compress NAHI:** `VaultPlaintext.COMPRESS_EXPORT = false`. Extension jab `BSRZ1:` samajhne lage (base64 decode -> gunzip -> JSON.parse), tab ise `true` karo; app dono form already padhta hai.
- **Extension ke liye spec:** plaintext `BSRZ1:` se shuru ho to baaki hissa base64 decode karke gunzip karo (browser: `DecompressionStream('gzip')` ya pako), phir JSON.parse. Warna pehle jaisa.
- **Tests (chalaye nahi gaye):** `VaultPlaintextTest` (small plain, large round-trip, damaged payload, parser, blob store round-trip, export flag false).

## 6. Ab bhi pending
- Lottie (library + asset), poore app ka typography sweep, extension-side changes (aap extension doge to app ke hisaab se karunga: `type` filter + `BSRZ1:` reader), aur sab device tests.

## 7. Extension update list
Extension me jo badlav chahiye unki poori list `docs/EXTENSION_UPDATE.md` me hai (E1-E10, rollout order, acceptance checks, ZIP milne par checklist).

## Sudhaar (Phase 16) — upar ke purane bayan
- **3.6 Lottie:** upar "NAHI hua" likha hai, par is tree me ab hai (`lottie-compose`, `res/raw/bsr_loading.json`, StartupSplash).
- **1.3 Auto-import:** `AutoBackupManager.autoImportIfVaultEmpty()` is tree me hai.
- Extension ki poori list aur status table: `docs/EXTENSION_UPDATE.md` (E1-E14). Fix.md ka live status: `docs/FIX_MD_STATUS.md`.
