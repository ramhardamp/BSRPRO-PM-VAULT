# BSRPRO Vault feature audit (source inventory through 0.2.8 preview)

## Evidence boundary
This is a source-level inventory of the supplied project tree, not a claim that every screen/flow has passed device QA. Release history from 0.1.0–0.2.3 is not fully represented by per-version changelog records in this checkout; where historical attribution is unavailable, features are listed as present in the current source rather than assigned a guessed introduction version.

## User-visible features
- Setup/unlock and master password; biometric unlock toggle; password change and vault reset.
- Credential list, search/filter/sort, entry detail/editor, folders/categories, notes and custom fields.
- Password generator, strength utility, TOTP field/code support.
- Android Autofill service setup, inline suggestion preference, diagnostics, pending-save support.
- Theme and app icon color; auto-lock and clipboard-clear preferences; screenshot guard and root-state detection utilities.
- Import/export: encrypted V3, CSV/JSON and provider-oriented CSV formats; duplicate review before additive import.
- Daily auto-backup controls, back-up-now action, backup discovery code. 0.2.8 preview adds an explicit folder-restore confirmation/password UI.

## Backend / infrastructure
- V3 encryption/decryption and payload parser; PBKDF2/key/session handling, rate limiting, biometric credential storage.
- Encrypted file blob store with temporary and backup generations, repository/Room metadata, DataStore preferences.
- Backup scheduling/writes, MediaStore discovery on Android 10+, legacy path lookup on Android 8–9.
- Autofill matching/parser/dataset service, pending save notification and diagnostics data.
- TOTP and password generation/search/strength utilities.
- Restore transaction class with current-vault authentication via blob read, V3 parse, canonical SHA-256 read-back comparison, snapshot/marker, rollback attempt. Startup app-kill recovery is not implemented in this preview.

## Known gaps vs common Bitwarden / 1Password capabilities
- No passkey storage/use or passkey autofill workflow.
- No end-to-end secure item sharing/emergency access or trusted-contact recovery workflow.
- No audited cross-device sync/account ecosystem; current data path is local/offline-first.
- No polished local security-health dashboard for weak/reused/old passwords or actionable remediation.
- No verified breach-monitoring integration/coverage claim; source inventory alone is insufficient to claim parity with commercial breach alerts.
- No mature organization/collection sharing, access policies, admin controls, or family vault sharing.
- No travel mode, masked email/alias integration, or robust recovery kit workflow.
- Restore app-kill recovery and Room/in-memory synchronization remain follow-up work; restore integration/tests need device/CI validation.

## Next five priorities (implementation order proposal)
1. Finish restore recovery journal, startup recovery, repository/Room sync, and fault-injection tests.
2. Local vault health report: weak/reused/aged credentials with direct navigation and no secret upload.
3. Improve autofill reliability/coverage with supported-field matrix, save/update review UX, and regression instrumentation.
4. Passkey roadmap prototype and threat model before enabling storage/autofill.
5. Secure sharing/recovery design review (recipient binding, expiry, revocation, replay controls) before any server feature.
