# Fix.md — live status (Phase 16, versionCode 30)

Format: Issue -> Fix -> Logic. NOT compiled, NOT device-tested (sandbox me Gradle/Android SDK nahi).
Is file ko har phase me update karna hai; extension ka kaam `docs/EXTENSION_UPDATE.md` me alag hai.

| Fix.md | Issue | Status | Fix / Logic |
|---|---|---|---|
| 1.1 | App vs website data mix | App + extension (v5.42.0) DONE; browser test baaki | `type` = app/website (purana khali `type` derive hota hai, overwrite nahi); export me "App logins" option. Extension: E2/E12/E13 |
| 1.2 | App Login category | DONE | "App Login" filter + list me Saved/Used dates |
| 1.3 | Zero-click backup/restore | DONE (device test baaki) | Auto-export pehle se; ab auto-import: khali vault par unlock ke baad merge, ek baar, sirf merge |
| 2.1 | Single share ka blank page | DONE | Auth ke baad seedha OS share sheet |
| 2.2 | Share list me search | DONE | Real-time search field |
| 3.1 | Notes list me content | DONE | Sirf title |
| 3.2 | 3-dot menu | DONE (pehle se) | DropdownMenu, naya page nahi |
| 3.3 | New Entry confusion | DONE (pehle se) | Chooser me alag icon/colour/hint |
| 3.4 | Backup screen | DONE | 3 tabs, chhote labels + info icon |
| 3.5 | Bin buttons | DONE | Empty Bin red + confirm dialog |
| 3.6 | Loading branding | DONE | Lottie ring + logo |
| 3.7 | Typography/spacing | DONE (code), device review baaki | Type.kt scale + off-grid card padding (18/14dp) -> 16dp. Har screen ka device-par review baaki |
| 4.1 | Startup loop | DONE | Session restore par 4s timeout |
| 4.2 | Restore warning/empty state | DONE | Confirm dialog + "No backup found" empty state |
| 5.1 | Save speed | DONE | JSON encode background thread par; bulk ops ek write me |
| 5.2 | Size | App + extension reader DONE; export flag baaki | Internal vault gzip (`BSRZ1:`); `.Vault` export tab compress hoga jab extension E1 release ho (`COMPRESS_EXPORT = true`) |
| 5.3 | Zero regression | Static checks pass | Regression scripts pass; device test baaki |
| 6 | Docs + Hinglish | DONE | Reports + docs Issue -> Fix -> Logic, Hinglish |

## Baaki (sirf device / extension par nirbhar)
1. Gradle build + `testDebugUnitTest`.
2. Device: auto-import, Lottie splash, direct share, Realme/Redmi master-password share, Vault tab, 300+ entries.
3. Extension v5.42.0 ko Chrome me load karke test; phir `COMPRESS_EXPORT = true`.
