# Feature roadmap (status should be confirmed against a device build)

## Current product areas represented in source
- Encrypted local vault, unlock/session lock, biometric integration
- Native Android autofill and web autofill support
- Password generation and strength indicators
- TOTP fields, folders/tags/categories, search/filter/sort
- Import/export, encrypted V3 backup, automatic backup controls
- Settings and restore flow (restore recovery remains incomplete)

## Next priorities
1. Restore journal recovery after process death, with durable transaction phases and safe startup reconciliation.
2. Repository/Room/in-memory consistency after restore and fault-injection tests.
3. Vault health dashboard: weak, reused, old passwords and explainable score.
4. Autofill save/update reliability, long-lived save prompt, theme parity.
5. Import same-screen progress, counts, duplicate/error summary, and completion actions.

## Later roadmap
- UI polish, onboarding, Hindi/English localization, travel mode
- Secure sharing, emergency access, encrypted attachments, rotation reminders
- Passkey/FIDO2 investigation, optional cloud sync, family sharing, widgets, quick settings tile, browser-extension bridge

Feature names above are roadmap candidates, not claims of completed or industry-parity behavior. Compare only after feature-by-feature device validation against current Bitwarden and 1Password releases.
