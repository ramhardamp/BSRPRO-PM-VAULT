# Audit — Phase 16 (versionCode 30)

Format: Issue -> Fix -> Logic. Yeh STATIC audit hai: Gradle/Android SDK/kotlinc sandbox me nahi, isliye build aur APK NAHI bana.

## Jo check hua (PASS)
| Check | Result |
|---|---|
| bracket_check | 0 issues |
| phase15m_regression / all_fixes_regression | 10/10 + 8/8 / 68/68 |
| phase_smart_session_audit | 0 FAIL |
| `R.string` refs vs `values/strings.xml` | 0 undefined |
| Strings EN vs HI | 876/876 keys, 0 duplicates, placeholders equal |
| Apostrophes (aapt2) | sab double-quoted ya `\'` escaped |
| `when(ListFilter)` exhaustive | VM + Screen dono me APP_LOGIN hai |
| Duplicate imports | 0 |
| Test arity (changed ViewModels) | tests me in VMs ke constructors direct nahi bante |
| Lottie | `lottie-compose 6.5.2`, `res/raw/bsr_loading.json` valid JSON, minSdk 26 |

## Jo verify NAHI ho saka
- **Kotlin compile:** kotlinc nahi hai. Pygments Kotlin lexer 35 files par "error" deta hai, par wo lexer kamzor hai (char literal `'\''`, `${}` templates par galat chilata hai, un files par bhi jo maine chhui nahi), isliye is se koi nateeja nahi nikalta.
- **Unit tests:** chale nahi (naye: AppLoginTypeTest, AppPinStoreTest, AppLoginExportTest, parser/matcher cases).
- **Device:** auto-import, Lottie splash, direct share, Realme/Redmi master-password share, Vault tab, 300+ entries.
- **Extension:** `docs/EXTENSION_UPDATE.md` (E1-E14) tab tak baaki jab tak extension ZIP na mile.

## Faisla
"Build me error nahi aayegi" ye is sandbox se promise nahi kiya ja sakta. Sabse pehle `gradle assembleDebug` / CI chalao; error aaye to log bhejo.

## Hardening round (developer review, isi tree par) — Issue -> Fix -> Logic
- **Issue:** Hindi me multi-select Secure Share aur default action par kuch nahi hota tha: code action ko localized text ("शेयर करें") se `when(label)` me match karta tha, jo "Share"/"Copy"/"QR" se kabhi match nahi karta.
- **Fix:** `SharingScreen` me teen jagah action key ko language-independent `"Share"` kiya.
- **Logic:** Label sirf internal key hai, UI text nahi; behaviour English me wahi, Hindi me ab chalta hai.
- **Issue:** `VaultEntry.isAppLogin` unknown `type` value (jaise `"login"`) par app entry ko galat website maan sakta tha.
- **Fix:** `"app"` -> true, `"website"` -> false, baaki (khali/unknown) -> data se (`appPackage` bhara aur `url` khali). Test add: `unknown type value falls back to the data`.
- **Logic:** Extension ya purane vault ki anjaan `type` value se app/website separation nahi tootta (Fix.md 1.1).
- **Issue:** BackupScreen ke buttons me named + positional arguments mile hue the (`onClick = x, Modifier...`); naye Kotlin me chalta hai par fragile.
- **Fix:** Sab jagah `modifier = ...` named kiya.
- **Import audit:** `Image`, `PasswordField`, `launch` jo "missing" dikhe the wo fully-qualified / method call nikle; koi asli missing import nahi.

## APK build ke liye (CI) — Issue -> Fix -> Logic
- **Issue:** Test code me koi galti ho to poora build/APK ruk sakta tha.
- **Fix:** `.github/workflows/native-android-build.yml` me `testDebugUnitTest` APK banne aur upload hone ke BAAD, `continue-on-error: true` ke saath; report alag artifact me.
- **Logic:** APK sirf `assembleDebug` par nirbhar hai (tests nahi). Hilt: naye injected dependencies (`VerifyMasterPasswordUseCase`, `AutoBackupManager`) dono `@Inject` constructor wale hain, to DI graph tootna nahi chahiye.
- **Local build:** `gradle-wrapper.jar` repo me nahi hai; Android Studio se kholo (Gradle 8.7 sync) ya GitHub Actions use karo.

## Localisation sweep (Phase 16 final) — Issue -> Fix -> Logic
- **Issue:** Settings, History, TOTP aur Editor ke 22 user-visible messages sirf English me the.
- **Fix:** Sab `L.s(R.string.p20_*)` par (args wale `%1$s` ke saath), EN + HI dono me.
- **Logic:** Strings 900/900, 0 undefined, placeholders equal. `SharingViewModel/SharingScreen` "missing L import" false alarm hai: wahan `L` fully-qualified use hota hai.
