# BsrProVault — Phase 16G Final Handoff

## Current status
- **Phase:** 16G
- **Step:** A
- **Final consolidation:** Batch 8
- **Final source:** Batch 7 source, consolidated without application-logic changes
- **versionCode:** **30**
- **versionName:** **1.0.0**
- **Regression:** **68/68 source-level checks passed**
- **Strings:** **EN 1089 / HI 1089 — exact parity**
- **V3PayloadParser SHA-256:** `177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d`
- **Build/CI:** not run in Batch 8 by request

## Version reconciliation
Historical Phase 16 documentation records the transition from versionCode 29 to 30. The current source of truth is `app/build.gradle.kts`, which contains:

```kotlin
versionCode = 30
versionName = "1.0.0"
```

No versionName change was necessary for this consolidation.

## Build instructions
Batch 8 intentionally does **not** build the application. For a later local build, from this project root:

```bash
./gradlew assembleDebug
```

Windows:

```bat
gradlew.bat assembleDebug
```

Release/signing should use the project's configured release/signing process and should be verified separately. This final handoff does not claim a compile, APK, emulator, device, or runtime PASS.

## Consolidated contents
- Current Phase 16G Step A source tree
- `reports/` with Batch 1–7 audit reports
- `previous-batches/` containing the delivered Batch 1–7 ZIP archives (including the corrected Batch 4 Redo archive)
- Existing project documentation and audit tooling

## Protected-data rule
Batch 8 makes no application logic changes. Crypto, model, security, data, and domain source trees are copied unchanged from the Batch 7 final source. V3 hash is re-verified above.
