# Phase 16E — 8 issue patch (based on Phase 16D)

Status: source patched; CI/device build remains required in the user environment because this authoring environment has no Gradle wrapper/executable or Android emulator.

## Fixed in source
1. Biometric-less devices: combined BIOMETRIC_WEAK + DEVICE_CREDENTIAL prompt; crypto path bypassed on devices without a usable weak biometric; Key B accepts weak biometric/device credential for the 24-hour authentication window.
2. Entry PIN autofill: numeric password input + maxLength 4–6 classified as PIN; dedicated PIN-only Dataset is emitted when a matching entry has an Entry PIN.
3. Bottom Vault tab: pops to Vault root then navigates with launchSingleTop and restoreState=false.
4. Unified App PIN: existing secure store is the single source for Sharing + Hidden Vault; legacy hidden PIN is migrated on first successful verification and removed on save.
5. PIN click: Security → App PIN remains a real clickable ActionRow; dialog now explicitly shows Set App PIN / Change App PIN and the corresponding action.
6. PIN change: master-password verification gates save/change/remove; PIN is validated as 4–6 digits.
7. Performance: render page reduced to 50, search debounce 300ms, filtering/sorting off main thread, derivedStateOf for row building, Room category/recordType indices retained, VaultEntry marked @Immutable.
8. Polish: logo added to EmptyState/About, explicit round adaptive launcher resource, existing four icon aliases retained, notification uses a dedicated monochrome BSRPRO vector.

## Honest pending
- Real Realme/Redmi hardware autofill behavior cannot be certified here; must be tested with actual AssistStructure/autofill framework.
- Android/Gradle compile, signed APK, install, process-death, device-credential, and 300+ entry performance tests must run in CI/device lab.
- Icon visual correctness still needs launcher screenshots on OEM launchers.
