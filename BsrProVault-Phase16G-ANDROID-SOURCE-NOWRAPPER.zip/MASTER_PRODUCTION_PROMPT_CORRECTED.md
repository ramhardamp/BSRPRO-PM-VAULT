# BsrProVault Phase16G — Corrected Master Production Build & 3-Clean Compiler Prompt

Use this prompt with the Phase16G Android ZIP.

## Mission
Perform a non-destructive, compiler-verified production audit. Preserve existing Phase16 functionality, security, migrations, golden vectors, and UI contracts. Never blindly replace whole source files. Generate/verify the official Gradle Wrapper for the detected toolchain, repair genuine issues, and require three consecutive complete real build passes before producing the final archive.

## 1. Detect the actual project
Extract the ZIP, locate the root containing `settings.gradle.kts`, root `build.gradle.kts`, and `app/`. Read `gradle/libs.versions.toml`, `app/build.gradle.kts`, and `gradle/wrapper/gradle-wrapper.properties` before patching anything. Determine AGP, Kotlin, KSP, Java/JVM target, SDKs, and Gradle dynamically. Do not invent versions.

For this current Phase16G tree, the audited values are AGP 8.5.2, Kotlin 2.0.20, KSP 2.0.20-1.0.25, Java/JVM 17, SDK 35, and Gradle 8.7.

## 2. NO-WRAPPER remediation
If wrapper files are missing, install/use the detected Gradle version and run `gradle wrapper --gradle-version <DETECTED_VERSION>`. Require:
- `gradlew`
- `gradlew.bat`
- `gradle/wrapper/gradle-wrapper.jar`
- `gradle/wrapper/gradle-wrapper.properties`
- executable `gradlew`
- `./gradlew --version` succeeds and matches the detected version
- wrapper JAR is non-zero and, when the version is known, checksum verified

## 3. Surgical patches only
Patch existing implementations in place. Do not create duplicate replacement classes.

Important actual architecture constraints:
- Preserve the repository's existing `FileVaultBlobStore` implementation and signatures; locate it by class definition rather than assuming a filename. Add hardening only if the existing implementation lacks it.
- Preserve the existing `VaultClipboardManager`; retain clipboard listener/debounce/sensitive-clip behavior and patch only missing safety.
- Preserve `VaultCrypto` and the existing V3 format/golden vectors.
- `V3PayloadParser` in this project parses the decoded V3 payload. Do NOT force a different binary 46/47-byte wire format into it. Audit the actual binary encrypted-container parser in `VaultCrypto` against existing tests instead.
- Preserve existing Room/serialization/migration code and specialized UI composables.

## 4. Known regression contracts
Search the whole project, not only the last failing file, for:
- malformed Compose lambda nesting such as `AppScreenState ... { padding -> }` when the lambda accepts no argument
- `androidx.compose.foundation.lazy.item` imports
- composable calls (`stringResource`, `MaterialTheme`, `LocalContext`, etc.) inside ordinary callbacks or non-composable `remember` lambdas
- untyped heterogeneous `buildList {}` where multiple sealed/interface row types are inserted
- six-input heterogeneous `combine(...)` inference traps
- missing `toArgb` import when `Color.toArgb()` is used
- exact badge boundaries `[0, 1, 999, 1000, 3780]`
- hardcoded `999+`

## 5. Genuine 3-clean-loop
`CLEAN_STREAK = 0` initially.

One clean pass MUST run, in order:
1. source/static audits
2. `./gradlew compileDebugKotlin --no-daemon --stacktrace`
3. `./gradlew compileReleaseKotlin --no-daemon --stacktrace`
4. `./gradlew testDebugUnitTest --no-daemon --stacktrace`
5. `./gradlew assembleDebug --no-daemon --stacktrace`
6. `./gradlew assembleRelease --no-daemon --stacktrace`
7. APK existence, manifest, ZIP integrity, and debug APK signature verification

Any genuine error, warning treated as blocking, test failure, resource failure, broken symbol, security regression, or data-loss risk:
- diagnose the actual root cause
- apply the smallest safe patch
- set `CLEAN_STREAK = 0`
- rerun the entire pass from step 1

Only after three consecutive complete clean passes is the source eligible for final archive creation.

## 6. GitHub Actions
Create/update a workflow that:
- dynamically detects the project JDK and Gradle versions
- installs the detected Android SDK needed by the project
- generates/verifies the official wrapper if missing
- performs the complete 3-clean loop
- runs API 35 emulator smoke tests after the three clean passes
- uploads Debug APK, Release APK, smoke logs, and final source archive

## 7. Final archive
Only after the real GitHub 3-clean loop and smoke test succeed:
- remove `.gradle`, `build`, `.idea`, `.pytest_cache`, and `__pycache__`
- ensure the archive root directly contains `gradlew`, `gradlew.bat`, wrapper JAR/properties, `settings.gradle.kts`, root `build.gradle.kts`, `gradle/libs.versions.toml`, and `app/`
- create `BsrProVault_Phase16G_Production_Master_Ready.zip`
- validate the ZIP with `unzip -t`

Never call the archive “compiler-verified” unless the actual Kotlin/KSP/AAPT/Gradle build has succeeded in a real Android build environment.
