# Phase 15W — static verification pass on Phase15V-patched (NOT compiled, NOT device-tested)

Base: BsrProVault-Phase15V-patched.zip (workspace `phase15s_work`). Changes in this pass: `app/build.gradle.kts` versionCode 26 -> 27; unit-test constructor calls repaired (see below);
new `tools/symbol_check.py`; this report. No app (src/main) Kotlin/XML was edited, so the app code from the previous round is untouched.

## Static checks run (all on this exact tree)
| Check | Result |
|---|---|
| tools/bracket_check.py | 0 delimiter issues |
| Duplicate imports (static_audit.py) | none |
| XML well-formed, every res/**/*.xml + manifest (EN `values`, HI `values-b+hi`) | 0 invalid |
| Duplicate string keys (EN, HI) | 0 / 0 |
| Hindi keys missing from English | 0 |
| `R.string.*` / `@string/*` references with no definition | 0 |
| Files using `R.*` without `import pro.babasitaram.vault.R` | 0 |
| `R.drawable/mipmap` refs with no resource | only `android.R.drawable.ic_lock_lock` (platform resource, fine) |
| `launchCatching` helper: defined, imported everywhere it is used, rethrows CancellationException | OK |
| Common Compose / coroutine / lifecycle imports (Icon, IconButton, remember, mutableStateOf, LaunchedEffect, Modifier, dp, stringResource, hiltViewModel, viewModelScope, launch, withContext, Dispatchers, stateIn, combine, collectAsStateWithLifecycle) | 0 missing |
| tools/symbol_check.py (new: unresolved capitalised symbols per file) | residuals reviewed by hand: all stdlib/Java aliases, inherited nested classes (PrintDocumentAdapter callbacks), top-level vals, or text inside strings |
| tools/phase15m_regression.py | 10/10 + 8/8 |
| tools/all_fixes_regression.py | 68/68 |

## Audit "FAIL" lines that are false positives (checked by hand)
- phase_smart_session_audit brace balance, ImportParser.kt and BackupUseCases.kt: raw `{`/`}` counts differ only because of
  brace characters inside string/char literals; with literals stripped both files balance (96/96 and 35/35).
- phase_smart_session_audit "sensitive debug logging" (5 lines): these are `activityLog.record("...", "<fixed label>")`
  calls with constant text, no password or secret value is logged.

## Pending / not verified (honest disclosure)
- Not compiled: no Gradle/Android SDK/adb in this sandbox. Compile risk points: the large SAF/MediaStore code in
  AutoBackupManager.kt, the Room activity-log classes (ActivityLog*), and the cached-theme startup path.
- Unit tests are still NOT run or compiled by CI (`assembleDebug` only). Constructor calls in UseCasesTest,
  SettingsAndBackupUseCasesTest, SettingsDataStoreTest and SettingsDataStorePhase7Test were stale and are now repaired
  with relaxed mockk mocks (BiometricSessionKeyStore, AutoBackupManager, Context). Not executed: after pushing, run
  `gradle testDebugUnitTest` once; assertion-level failures are possible even though the signatures now match.
- Device-only behaviours: SAF provider behaviour, 10-backup single-file check, theme flash, launch time, OEM autofill,
  large-vault scrolling, biometric migration.
- Backup duplicates, likely root cause: on Android 10+ an install cannot see a BSRPRO.Vault created by an earlier install,
  so MediaStore renames the new file to "BSRPRO (n).Vault". Choosing the BSRPRO_Backups folder once through the in-app
  folder picker lets the app overwrite the real file and remove the numbered copies.
- Backup size 343 KB -> 1.57 MB: probably data growth (Mobiles badge showed 999+ after contact import), not appended data.
  Verify on device: the entry count must rise with the size.
- Biometric hardening (setUserAuthenticationRequired) was deliberately not applied: the shared wrap key also protects the
  lockout counter and PIN stores.

## Decisions recorded
- versionCode 27 (above 26). Entry PIN (per-login) and App PIN (sharing + hidden vault) stay separate.
