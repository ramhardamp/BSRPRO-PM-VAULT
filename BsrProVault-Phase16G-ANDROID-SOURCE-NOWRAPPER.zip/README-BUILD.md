# BSRPRO Vault — Phase16G Production Build Gate

This repository contains the Phase16G native Android source with the latest compiler-driven fixes and a CI workflow that performs a real 3-clean build gate.

## Detected toolchain

- AGP: 8.5.2
- Kotlin: 2.0.20
- KSP: 2.0.20-1.0.25
- Java/JVM target: 17
- compileSdk/targetSdk: 35
- minSdk: 26
- Gradle: 8.7 (from the retained wrapper properties and audited against the project configuration)

## Important architecture notes

- The existing encrypted-vault V3 implementation is preserved. The project uses `VaultCrypto` for the encrypted binary container and `V3PayloadParser` for the decoded V3 payload; do not replace the latter with a different binary wire-format parser.
- Existing `FileVaultBlobStore` and `VaultClipboardManager` implementations are preserved by class/signature rather than replaced with generic template files.
- Source patches are surgical. Existing Phase16 methods, data migrations, security hooks, golden vectors, and UI contracts are not blindly overwritten.
- Count badges use exact numeric values; `999+` is not a hardcoded cap.

## GitHub build gate

The workflow dynamically detects Java/Gradle versions, generates and verifies the official Gradle Wrapper when the NO-WRAPPER source is checked out, then executes **three complete clean passes**. Each pass runs static/source audits, Kotlin + KSP Debug/Release compilation, unit tests, Debug/Release APK assembly, and APK output verification. A failed pass ends the workflow; the clean streak is not allowed to continue through a failure.

After three clean passes, API 35 emulator smoke testing runs. Only then does GitHub create and upload `BsrProVault_Phase16G_Production_Master_Ready.zip` containing the generated wrapper files.

## Current local verification limit

This sandbox does not contain the Android SDK or a usable Gradle 8.7 installation, so a genuine Android Gradle/KSP/AAPT build has not been claimed locally. The source-level and regression audits can be run here; the authoritative compiler gate is the GitHub workflow above.
