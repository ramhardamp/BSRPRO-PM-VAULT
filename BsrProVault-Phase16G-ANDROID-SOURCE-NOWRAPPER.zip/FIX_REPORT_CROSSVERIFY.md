# Cross-verify fixes (this ZIP)

Real bugs found and fixed (6 bugs, 22 files):
1. R.string.selection_bulk_share_message was undefined (SharingScreen.kt:236) -> added to values/strings.xml and values-b+hi/strings.xml.
2. Missing import AppDimens: VaultListScreen.kt, VaultNavHost.kt.
3. Missing import androidx.compose.ui.res.stringResource: ContactsImportScreen.kt.
4. Missing import androidx.compose.runtime.remember: SharingScreen.kt.
5. Missing import androidx.lifecycle.viewModelScope in 15 ViewModels (History, HiddenVault, TotpDetail, TotpManager, Root, Notes, VaultList, EntryDetail, Files, Settings, VaultHealth, Bin, Mobiles, ActivityLog, Sharing).
6. EntryEditorScreen.kt:254 - folder name was passed as Text(modifier) instead of as stringResource format arg.

The reported "invalid unicode escape" error did NOT reproduce: both strings.xml compile cleanly with aapt2 2.19; no \u in either file.

NOT verified: real Gradle/Kotlin compile (no Android SDK here), aapt2 link, unit-test compile.
V3 format, crypto and backup code were not touched.
