# BsrProVault Phase16G Step A — Batch 4 Redo (Option A)

## Scope
In-place migration of the first five Batch 4 screens. Existing Hilt ViewModels, repository/use-case wiring, navigation signatures and protected V3/data/security code were preserved. The five thin adapter directories from the rejected Batch 4 were removed.

## Migrated screens
| Screen | File | Added | Removed | Changed-line delta |
|---|---|---:|---:|---:|
| SetupScreen | `app/src/main/java/pro/babasitaram/vault/presentation/setup/SetupScreen.kt` | 64 | 146 | 210 |\n| LockScreen | `app/src/main/java/pro/babasitaram/vault/presentation/lock/LockScreen.kt` | 58 | 122 | 180 |\n| VaultListScreen | `app/src/main/java/pro/babasitaram/vault/presentation/vault/VaultListScreen.kt` | 99 | 385 | 484 |\n| EntryDetailScreen | `app/src/main/java/pro/babasitaram/vault/presentation/vault/EntryDetailScreen.kt` | 90 | 153 | 243 |\n| EntryEditorScreen | `app/src/main/java/pro/babasitaram/vault/presentation/editor/EntryEditorScreen.kt` | 88 | 217 | 305 |\n
## UI/token migration
- Setup §2.1: 120dp logo token, 24sp headline token, two AppPasswordField controls, 56dp primary AppButton, restore AppCard.
- Lock §2.2: 100dp logo token, AppPasswordField, biometric action, recovery text action, version footer.
- Vault §2.3: AppSearchBar, type tabs `[All][Passwords][AppLogin][Cards][Identities]`, strength tabs `[All][Strong][Weak][Starred]`, category chips, 40dp AppIconCircle rows, copy/3-dot actions, FAB.
- Entry Detail §2.4: header AppCard, category icon, field AppCopyField cards, Copy/Edit/Share/Delete action row.
- Entry Editor: AppTextField/AppPasswordField form, URL/notes/category dropdown, save AppButton.
- No new typography size was introduced. Typography remains the Section 1.2 system.
- Added named dimension tokens for existing helper geometry only: `Zero`, `TotpRingSize`, `SmallFieldIcon`, `AppPickerIcon`, `AppPickerMaxHeight`.
- No raw `.dp`, `.sp`, or `Color(...)` in the five migrated screen files.

## Strings
- EN: 947
- HI: 947
- Delta from Batch 3/4 baseline: +3
- Exact EN/HI string-name parity: PASS
- Added: `p17_version_footer`, `entry_bank`, `entry_details`

## Regression / audit
- Source regression: **68/68 PASS**
- Bracket check: **0 issues**
- 10-clean-loop: **10/10 PASS**
- R.string references in migrated screens: all resolved
- First-five adapter directories: removed

## Protected data/security
- `V3PayloadParser.kt` SHA-256: `177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d`
- Protected crypto/model/security/data/domain changed files: **0**
- Build / CI / APK / device testing: **NOT RUN**

## Important audit scope note
The 68/68 suite is source-level FIX1–FIX9 regression validation, not Android compilation or runtime validation.
