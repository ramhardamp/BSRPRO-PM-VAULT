# Phase 16C — UI polish audit (Fix.md 3.7 ke daayre me)

Format: Issue -> Fix -> Logic. NOT compiled, NOT device-tested (sandbox me Gradle/Android SDK nahi).

| # | Issue | Fix | Logic |
|---|---|---|---|
| U1 | Light theme me primary button par white text ka contrast 2.7:1 (WCAG AA = 4.5:1) | `AccentPurpleLight = #6D4AE8` light primary + `onPrimary = White` (Color.kt, Theme.kt) | White vs #6D4AE8 = 5.5:1. Dark theme ka brand purple #A78BFA wahi rakha (black text 7.7:1) |
| U2 | Android 15 (targetSdk 35) me edge-to-edge forced hai, `adjustResize` window resize nahi karta -> keyboard Setup/Lock/Editor ke fields dhak deta tha | `MainActivity`: content ko `Box(Modifier.fillMaxSize().imePadding())` me wrap kiya | imePadding insets consume karta hai, isliye andar ke Scaffold double padding nahi lagate. Purane Android jaisa hi behaviour |
| U3 | Keyboard ka Done/Enter kuch nahi karta tha (Lock, Setup) | `PasswordField` me `imeAction` + `onImeAction` (defaults ke saath, purane callers unchanged). Lock: Done = Unlock. Setup: password -> Next, confirm -> Done = Create | `onImeAction == null` ho to Compose ka default behaviour |
| U4 | LockScreen scroll nahi hoti thi (chhoti screen / bada font / keyboard par buttons kat-te) | `verticalScroll(rememberScrollState())` | Content kam ho to center me rehta hai, zyada ho to scroll |
| U5 | Setup screen: "Restore from Backup?" sabse upar, vault banane ka form neeche; 6 hardcoded English strings; ek message sirf Hindi me hardcoded | Order: Password -> Confirm -> Create -> Restore file -> Restore folder -> Backup folder card. Saari strings `strings.xml` (en + hi) me | Primary flow pehle, secondary neeche (Bitwarden/1Password pattern). en/hi dono 906 strings, parity OK |
| U6 | Avatar initial hamesha white: amber/mint par contrast ~2:1 | `readableOn(bg)` white/black me se zyada contrast wala chunta hai; size `AppDimens.AvatarSize` | WCAG luminance formula |
| U7 | EmptyState ka title/message left-aligned, icon center me | `TextAlign.Center` | Visual alignment |
| U8 | Off-grid values (6/10/14/18dp) | 8 / 8 / 16 / `AppDimens.SmallIconSize` (20dp) — 11 jagah | 4/8dp grid, Fix.md 3.7 ke mutabik |

## Baaki (device par dekhna hai)
1. Light theme me har screen par primary colour ka naya shade.
2. Keyboard + bottom bar behaviour (bottom bar keyboard ke upar aayegi, purane Android jaisa).
3. Hindi font scale + chhoti screen par Setup/Lock.
4. Gradle build + `testDebugUnitTest` abhi bhi pending.
