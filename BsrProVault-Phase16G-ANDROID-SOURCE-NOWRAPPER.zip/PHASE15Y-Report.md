# Phase 15Y — remaining English UI text -> EN/HI string resources (NOT compiled, NOT device-tested)

Base: BsrProVault-Phase15W (versionCode unchanged). Only UI text handling was touched; V3 format, crypto, backup logic untouched.

## What changed
- 226 hardcoded English UI literals in 28 files (Settings, Autofill popup/auth, Hidden Vault, Sharing, Backup, Contacts import,
  TOTP detail, Entry detail/editor, Lock, Setup, History, Bin, Notes/Mobile/TOTP editor messages) -> string resources.
  143 uses of stringResource(...) in Composables, 83 uses of L.s(...) in ViewModels / Activities / callbacks.
- New helper core/util/L.kt: localised strings for code without Compose context (follows the in-app language chosen in
  LocaleHelper; installed from BsrApplication.onCreate; LocaleHelper.save() resets its cache).
- 163 new keys (prefix p18_) in values/strings.xml and values-b+hi/strings.xml. EN 866 / HI 866, no duplicates, placeholders equal.
- 3 plural-style strings were rewritten by hand ("duplicate(s)" instead of if/else suffix).
- Deliberately left in English: autofill-diagnostics clipboard text, "CVV"/"GitHub"/"TOTP" style technical names,
  one fragment ("No saved login for this ...") that is concatenated with dynamic text.

## Static checks run (all on this tree)
aapt2 compile of res: OK | kotlinc 2.0.21 parse: 0 syntax errors | R.string/@string refs undefined: 0 | R import missing: 0
Compose/Icon/coroutine/lifecycle imports missing: 0 | format-argument count vs placeholders (904 calls): 0 mismatches
constructor-call check (454 calls): 0 | bracket_check: 0 | stringResource in non-composable context introduced by this change: 0

## NOT verified
No Gradle/Android SDK here: not compiled, unit tests not run, nothing tested on a device.
Hindi text was written by hand in one pass; a native-speaker read is recommended.
Still open from Phase15X: backup size optimisation (5.2) and the extension-side "website only" filter (not in this ZIP).
