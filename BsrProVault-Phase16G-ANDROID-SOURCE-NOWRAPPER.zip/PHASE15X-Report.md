# Phase 15X — 8 Pending Issues Fix (NOT compiled, NOT device-tested)

Base: BsrProVault-Phase15W-patched.zip. versionCode 27 -> 28.
Format: Issue -> Fix -> Logic (Fix.md style). Static checks only: bracket_check 0 issues, phase15m 10/10 + 8/8, all_fixes 68/68.
Gradle / Android SDK sandbox me nahi hai, isliye compile aur unit tests run NAHI hue. Pehle `gradle testDebugUnitTest` chalao.

## 1. Biometric-less phone (Realme/Redmi)
- **Issue:** Fingerprint/face/App PIN ke bina Secure Share par sirf "enable biometric" message aata tha, aage nahi badh sakte the.
- **Fix:** SharingScreen me master-password dialog add hua. PIN dialog me "Use master password" button bhi hai.
- **Logic:** Biometric -> App PIN -> master password (VerifyMasterPasswordUseCase, rate-limited). Files: SharingScreen.kt, SharingViewModel.kt.

## 2. Entry PIN autofill
- **Issue:** maxLength unset hone par PIN field detect nahi hota tha; PIN-only logins fill nahi hote the.
- **Fix:** AutofillParser: unset limit ko allow kiya, "PIN code"/zip/address aur 8+ digit numeric password ko PIN nahi maana. AutofillValues: PIN box me 4-6 digit password fallback, PASSWORD box me appPin fallback.
- **Logic:** `type`, Package Name vs URL matching ko chhua nahi gaya. Files: AutofillParser.kt, AutofillMatcher.kt. Tests: 3 naye cases.

## 3. Bottom nav Vault click
- **Issue:** restoreState purani detail/edit screen wapas la deta tha.
- **Fix:** Vault tab aur drawer ka Vault `popBackStack(Routes.LIST)` se seedha list par jaate hain.
- **Logic:** Baaki tabs me saveState/restoreState hata diya (inclusive=false popUpTo + launchSingleTop). File: VaultNavHost.kt.

## 4. Do PIN systems -> ek App PIN
- **Issue:** Sharing PIN aur Hidden-vault PIN alag stores the.
- **Fix:** Dono ab key `sensitive_action_pin_v1` use karte hain. Purana `hidden_vault_pin_v1` pehli sahi entry par migrate hota hai.
- **Logic:** Entry PIN (har login ka appPin) alag hi hai, as approved. Files: SecureStores.kt, DataModule.kt.

## 5. PIN set hone ke baad click nahi hota
- **Issue:** (a) Settings ki "Entry PINs" row ka onClick khali tha. (b) Sharing me pendingEntryIds recreate par kho jaate the.
- **Fix:** (a) Info dialog. (b) ids rememberSaveable string me, aur khali selection par message.
- **Logic:** Files: SettingsScreen.kt, SharingScreen.kt.

## 6. PIN change master password se
- **Issue:** PIN bina master password ke set/change/remove ho jata tha.
- **Fix:** Settings "App PIN" aur Hidden vault, dono jagah set/change/remove ke liye master password zaroori.
- **Logic:** Sab ek hi VerifyMasterPasswordUseCase se jaate hain (wahi lockout rules). Files: SettingsViewModel.kt, SettingsScreen.kt, HiddenVaultViewModel.kt, HiddenVaultScreen.kt.

## 7. Performance (300+ entries)
- **Issue:** Bulk delete/favorite har entry par poora vault re-encrypt karte the; filter+sort 3 baar chalta tha; search regex har keystroke par compile hota tha.
- **Fix:** `softDeleteAll` aur `upsertAll` se ek hi write. computedVisible ek baar compute (stateIn). Regex ek baar compile.
- **Logic:** Encryption/schema same hai, backward compatible. Files: VaultRepository(.Impl).kt, VaultListViewModel.kt, EntrySearch.kt.

## 8. App icon / logo (general polish + icon consistency)
- **Issue:** Launcher round icon declare nahi tha; Vault top bar par branding nahi thi.
- **Fix:** `android:roundIcon` add, Vault top bar me brand_logo.
- **Logic:** Sirf yehi kiya. Foreground PNG ka padding/size abhi ek jaisa verify nahi hua, device par dekhna hoga.

## Fix.md round (8 issues ke baad) — Issue -> Fix -> Logic
- **1.1 type field:** Issue: app/website data mix. Fix: `EditorForm.toEntry` ab login par `type` = "app" ya "website" set karta hai (purani non-empty value kabhi overwrite nahi). `VaultEntry.isAppLogin` purane (empty type) vaults ke liye derive karta hai. Logic: schema field pehle se tha, naya column nahi. **Extension side par "sirf website padho" filter extension code me lagega — wo is zip me nahi hai.** Export/backup me app data filter NAHI kiya (extension ke saath .Vault shared hai, filter se data lose hota).
- **1.2 App Login:** "App Login" quick filter chip + list row par "Saved / Used" dates.
- **1.3 Auto backup:** pehle se bana tha (AutoBackupManager); is round me badla nahi.
- **2.1 Direct share:** single item par intermediate page nahi; auth (biometric / App PIN / master password) ke baad seedha OS share sheet (Username, Password, URL/App, PIN). Auth gate maine rakha hai kyunki plain-text password share ho raha hai; hatana ho to bolo.
- **2.2 Share search:** Sharing list me real-time search field.
- **3.1 Notes:** list me sirf title.
- **3.2 3-dot menu:** Vault/Notes/Mobiles me pehle se DropdownMenu hai; badla nahi.
- **3.3 New Entry:** chooser me alag icon/color/hint pehle se hai; badla nahi.
- **3.4 Backup screen:** 3 tabs (Auto-Backup, Restore / Import, Export / Share), chhote labels + info icon. Duplicate "Import" nahi.
- **3.5 Bin:** "Empty Bin" red + icon, confirm dialog pehle se tha. "Restore all" primary.
- **3.6 Splash:** logo + Compose pulse animation. **Lottie nahi lagaya** (library + animation file ka network/asset chahiye tha); chahiye to bolo.
- **3.7 Typography/spacing:** sirf Backup screen aur splash par. Poore app ka sweep nahi hua.
- **4.1 Startup loop:** session restore par 4s timeout; stuck hone par Locked/Setup screen aati hai.
- **4.2 Restore warning:** "No backup found" ab empty state + "Create First Backup" button; restore pehle se confirm dialog se hota hai, scary text hata diya.
- **5.1 Save speed:** vault JSON encode ab Main thread par nahi (Default dispatcher). Pehle viewModelScope (Main) par chalta tha.
- **5.2 Size optimisation: NAHI kiya.** Encrypt se pehle compression ya naya format backward compatibility aur extension interop tod sakta hai (Fix.md 5.3). Alag, tested migration chahiye.
- **5.3:** schema change nahi, sab backward compatible.

## Developer-judgement round (quality, bina naya feature joDe)
- **Hindi:** Backup tabs/labels, empty state, Share search aur "App Login" filter ab string resources me hain (EN + HI, 703/703 keys, koi duplicate nahi).
- **Tests:** `AppLoginTypeTest` (type tagging, legacy vault, existing type overwrite nahi) aur `AppPinStoreTest` (legacy hidden PIN migration, clear) add hue. Chalaye nahi gaye (compile nahi hua).
- **Jaan-boojh kar nahi chhua:** poore app ka spacing/typography sweep, encryption payload format, Lottie.

## Final Fix.md pass — Issue -> Fix -> Logic
- **1.3 Auto Import (pehle sirf export tha):** Issue: login ke baad backup apne aap nahi padha jata tha. Fix: `AutoBackupManager.autoImportIfVaultEmpty()`, `SaveRouterViewModel` se unlock par chalta hai. Logic: sirf tab jab vault + Bin khali ho aur koi backup pending na ho; sirf merge (replace nahi); ek hi baar; alag password wali file chhod di jati hai (manual Restore se hogi). Isse delete kiya hua data wapas nahi aata.
- **1.1 Export me app logins:** `ExportOptions.includeAppLogins` + Export dialog me checkbox. Default ON, taaki .Vault extension ke saath pehle jaisa rahe. Extension me "sirf website padho" rule extension code me lagega, wo is zip me nahi hai.
- **3.6 Lottie:** `lottie-compose 6.5.2` + `res/raw/bsr_loading.json` (ring) logo ke aas-paas. Composition load na ho to sirf logo dikhta hai.
- **3.7 Typography:** `Type.kt` me fixed scale (bold headings, 16/14/12 body). Spacing grid ka poore app me sweep device dekhe bina nahi kiya.
- **3.2:** Vault, Notes, Mobiles, Files, TOTP, sab jagah DropdownMenu hai; koi naya page nahi khulta.
- **5.2 Size: abhi bhi NAHI.** `VaultJson.encodeDefaults = true` har entry me khali fields likhta hai (isse size badhta hai), lekin .Vault container extension ke saath shared hai aur compression ya fields hatane se extension kaise padhega, ye is zip se verify nahi ho sakta. Pehle extension ke parser par check karna hoga.
- **Tests:** `AppLoginExportTest` add hua. Chalaya nahi gaya.

## Risk points (compile)
SettingsViewModel, HiddenVaultViewModel, SharingViewModel, VaultListViewModel ke constructors badle hain. Naye Compose dialogs (AppPinDialog, master dialog) pehli baar compile honge.
