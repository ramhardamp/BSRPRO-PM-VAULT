# Phase 16A backup/import incident patch

## Changes in this patch
- Added metadata-only `BSRPROBackup` diagnostics at SAF document read/write and import preparation/decrypt/parse/preview boundaries. Logs include byte/character size, URI scheme/authority, marker class, parser result type, entry/folder counts, and exception class; they do not log passwords or record contents.
- Added direct recognition and parsing for raw `BSRZ1:` compressed payloads. Previously `ImportParser.detectKind()` classified any non-JSON, non-base64/vCard text as CSV, so a BSRZ1 payload could enter the CSV path and fail rather than decompress/parse.
- Added unit tests for BSRZ1 detection, including BOM/whitespace prefix.
- Existing automatic backup writer already uses canonical `BSRPRO.Vault`, transactional staging/readback validation, and guarded cleanup of managed numbered/recovery copies. This patch does not broaden deletion scope.

## Root-cause limits / follow-up
- No device-produced failing backup artifact or Logcat trace was attached, so decrypt/key mismatch and provider-specific URI behavior cannot be proven from the report alone.
- The manual Save-As flow and automatic fixed-folder backup are separate paths. Android SAF's create-document picker may choose a duplicate filename; reliable overwrite requires the configured folder tree URI and provider operations. This patch does not silently replace a user-picked document or delete arbitrary numbered files.
- Startup cleanup remains validation-gated: canonical backup must be readable/decryptable before managed duplicate cleanup. Do not delete numbered copies while canonical validation fails.

## Validation
- Source-level review only. Gradle wrapper/system Gradle is not available in this runtime, so Android compilation, JUnit, emulator, and device tests were not run.
- Device retest should capture filtered `BSRPROBackup` logs. Confirm the reported file is encrypted V3 JSON, legacy base64 device blob, or raw BSRZ1 payload; then use counts and failure stage to select a definitive data-preserving fix.
