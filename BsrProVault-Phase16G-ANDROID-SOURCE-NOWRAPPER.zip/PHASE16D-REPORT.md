# Phase 16D — Backup / Setup / Autofill / Share / Backup-UI (from Phase 16C device testing)

Status: STATIC-VERIFIED ONLY (no compiler/device in the authoring environment). Needs CI build + device test.

## Done
1. **Recovery files (Issue 1) — root cause + fix** (`AutoBackupManager.kt`)
   - Cause: `cleanupSafTree` deliberately keeps files that do not open with the active password (e.g. an old vault's backup) but then
     counted them in its "remaining" check and threw -> every backup failed AFTER publishing -> `pending` retry -> the old canonical file was
     renamed to a new visible `BSRPRO-Recovery-*.Vault` again, every retry.
   - Fix: (a) no visible Recovery name any more: the old canonical file is held as hidden `.bsrpro-old-<uuid>.vault` and disposed right after
     the new file is published (same password -> deleted; other password/corrupt -> kept as visible `BSRPRO-Other-<time>.Vault`, never destroyed);
     (b) cleanup no longer throws for intentionally preserved files; stale undecryptable `.pending` staging files (>10 min) are removed;
     (c) a verified+published backup is not reported as failed if only the tidy-up fails (retried at next unlock);
     (d) disposal runs OUTSIDE the rollback try-block so a cancellation can never delete the live canonical file.
   - Existing leftovers: Recovery files that open with the current password are deleted at next unlock/backup. One that does NOT open
     (e.g. the 1 Oct file from another vault) is kept on purpose (data safety) -> delete it manually.
2. **Setup (Issues 2, 3, 7)**: one "Restore from Backup" button (auto-finds chosen folder / Downloads/BSRPRO_Backups, else opens the file picker),
   centred 120dp logo, centred 24sp bold heading, "— या —" divider, Backup-folder card (status + Change), Autofill card. LockScreen: same logo/heading.
3. **Autofill (Issue 4)**: one-time "Enable Autofill?" dialog after first unlock (Skip remembered) -> system picker with BSRPRO preselected;
   Setup card with [Enable Autofill]; Settings already shows ACTIVE / OFF (existing row).
4. **Share (Issue 5)**: single-entry Share opens a small chooser (no screen): Secure Link (existing encrypted flow) / Text (warning -> Android share sheet
   with Username/Password/URL). Notes/cards/TOTP go straight to the secure flow.
5. **Backup screen (Issue 6)**: tabs removed; one page: Backup Status -> Restore -> Import/Export. Import opens a format dialog (CSV / JSON-.Vault / vCard / Contacts);
   Export opens the existing selective + format + encrypt dialog.
6. Strings: 37 new keys EN+HI (`p16c_*`). 943 EN = 943 HI.

## Known trade-offs / not done (ROADMAP)
- "Share as Text" does not re-authenticate (same exposure as Copy). Consider PIN/biometric before plain share.
- Backup Status card shows name/time/location but NOT size / entry count (not available in state yet).
- Dedicated "Export encrypted" button was folded into Export Data -> ".Vault (encrypted backup)".
- Settings screen has no BackupFolderCard yet (Backup screen + Setup have it).
- Earlier-reported items still open: Issue 1/2/3 of the previous list (biometric-less 24h session, entry-PIN autofill, bottom-nav Vault tap),
  unified App PIN (4-6), PIN click/change-with-master-password, list performance (pagination/debounce/indices), icon polish.
