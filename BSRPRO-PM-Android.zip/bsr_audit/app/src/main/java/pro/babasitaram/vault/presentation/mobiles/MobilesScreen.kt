// file: app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesScreen.kt
@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package pro.babasitaram.vault.presentation.mobiles

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.Avatar
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.components.SelectionBottomBar
import pro.babasitaram.vault.presentation.components.SelectionTopBar
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens

@Composable
fun MobilesScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onOpen: (String) -> Unit = {},
    onShareSelected: (List<String>) -> Unit = { ids -> ids.forEach(onShare) },
    onImportContacts: () -> Unit = {},
    vm: MobilesViewModel = hiltViewModel()
) {
    val entries by vm.visibleEntries.collectAsStateWithLifecycle()
    val favoritesOnly by vm.favoritesOnly.collectAsStateWithLifecycle()
    val selectedIds by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode by vm.selectionMode.collectAsStateWithLifecycle()
    var confirmBulkDelete by remember { mutableStateOf(false) }

    BackHandler {
        if (selectionMode) vm.exitSelection() else onBack()
    }
    CollectMessages(vm.messages)

    val allSelected = entries.isNotEmpty() && selectedIds.containsAll(entries.map { it.id })

    Scaffold(
        topBar = {
            if (selectionMode) {
                SelectionTopBar(
                    selectedCount = selectedIds.size,
                    allSelected = allSelected,
                    onExit = vm::exitSelection,
                    onToggleSelectAll = vm::toggleSelectAll
                )
            } else {
                androidx.compose.foundation.layout.Column {
                    TopAppBar(
                        title = {
                            Text(
                                stringResource(R.string.p15_mobiles),
                                style = MaterialTheme.typography.titleLarge
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = onBack) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = stringResource(R.string.p15_back)
                                )
                            }
                        },
                        actions = {
                            TextButton(onClick = onImportContacts) {
                                Text(stringResource(R.string.mobiles_import_contacts))
                            }
                        }
                    )
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = !favoritesOnly,
                            onClick = { if (favoritesOnly) vm.toggleFavoritesOnly() },
                            label = { Text(stringResource(R.string.p15_all)) }
                        )
                        androidx.compose.foundation.layout.Spacer(Modifier.size(8.dp))
                        FilterChip(
                            selected = favoritesOnly,
                            onClick = { if (!favoritesOnly) vm.toggleFavoritesOnly() },
                            label = { Text(stringResource(R.string.p15_starred)) },
                            leadingIcon = { Icon(Icons.Default.Star, contentDescription = null) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (!selectionMode) {
                ExtendedFloatingActionButton(
                    onClick = onAdd,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text(stringResource(R.string.mobiles_add_entry)) }
                )
            }
        },
        bottomBar = {
            if (selectionMode) {
                SelectionBottomBar(
                    selectedCount = selectedIds.size,
                    onDelete = { confirmBulkDelete = true },
                    onShare = { onShareSelected(selectedIds.toList()) },
                    onFavorite = vm::favoriteSelected
                )
            }
        }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(
                stringResource(R.string.p15_no_mobile_entries),
                stringResource(R.string.mobiles_empty_message),
                Modifier.padding(padding).fillMaxWidth()
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(horizontal = AppDimens.ScreenHorizontal),
                verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)
            ) {
                items(entries, key = { it.id }, contentType = { "mobile" }) { entry ->
                    MobileItem(
                        entry = entry,
                        selectionMode = selectionMode,
                        selected = entry.id in selectedIds,
                        onClick = {
                            if (selectionMode) vm.toggleSelection(entry.id)
                            else onOpen(entry.id)
                        },
                        onLongClick = { vm.beginSelection(entry.id) },
                        onToggleFavorite = { vm.toggleFavorite(entry.id) },
                        onCopy = { vm.copy(entry.mobile.ifBlank { entry.phone }) },
                    )
                }
            }
        }
    }

    if (confirmBulkDelete && selectedIds.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { confirmBulkDelete = false },
            title = { Text(stringResource(R.string.selection_delete_title)) },
            text = { Text(stringResource(R.string.selection_delete_text, selectedIds.size)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmBulkDelete = false
                        vm.deleteSelected()
                    }
                ) { Text(stringResource(R.string.p15_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmBulkDelete = false }) {
                    Text(stringResource(R.string.p15_cancel))
                }
            }
        )
    }
}

@Composable
private fun MobileItem(
    entry: VaultEntry,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit
) {
    val number = entry.mobile.ifBlank { entry.phone }
    val operator = remember(entry.customFields) {
        entry.customFields.firstOrNull { it.k == OPERATOR_FIELD }?.v.orEmpty()
    }
    val subtitle = remember(number, operator) {
        listOf(number, operator).filter { it.isNotBlank() }.joinToString(" · ")
    }

    Card(
        Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
    ) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selectionMode) {
                Checkbox(checked = selected, onCheckedChange = { onClick() })
            }
            Avatar(entry.title.ifBlank { number })
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        entry.title.ifBlank { stringResource(R.string.mobiles_entry) },
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f)
                    )
                    if (entry.starred) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = stringResource(R.string.vault_starred),
                            modifier = Modifier.size(AppDimens.SmallIconSize),
                            tint = MaterialTheme.colorScheme.secondary
                        )
                    }
                }
                Text(subtitle)
            }
            if (!selectionMode) {
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        Icons.Default.Star,
                        contentDescription = stringResource(
                            if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite
                        ),
                        tint = if (entry.starred) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onCopy) {
                    Icon(
                        Icons.Default.ContentCopy,
                        contentDescription = stringResource(R.string.mobiles_copy_number)
                    )
                }
            } else if (selected) {
                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(AppDimens.IconSize))
            }
        }
    }
}
