# Feature audit — BSRPRO Vault 1.0.0 vs master spec

Legend: DONE = present in code (not re-verified on a device) · THIS BUILD = changed/added in this iteration · GAP = not implemented.
Nothing here was compiled or run in the authoring sandbox.

| Area | Status | Notes |
|---|---|---|
| Bottom nav (Vault/TOTP/Health/Settings, filled/outlined) | THIS BUILD | Material3 `NavigationBar` default height (80dp); the 64dp "tall bar" is not forced |
| Side drawer 280dp, grouped, Lock Now, badges | THIS BUILD | Bin/Sharing/Emergency/etc. badges were already wired |
| Backup folder -> auto restore (Setup + Settings) | THIS BUILD | see CHANGELOG_1.0.0.md |
| Auto-import safety (armed flag, no permanent one-shot) | THIS BUILD | |
| Don't delete a backup with a different password | THIS BUILD | kept as BSRPRO-Recovery-*.Vault |
| Support Developer: UPI copy + GPay/PhonePe/Paytm | THIS BUILD | |
| GitHub issues/repo URLs | THIS BUILD | `ramhardamp/babasitaram-pro` |
| TOTP Manager screen, Vault Health, Notes, Files, Mobiles, Bin, Emergency, Sharing, About, Help, Activity log | DONE | existing screens; layouts not pixel-compared to the spec wireframes |
| AES-256-GCM / PBKDF2 600k, V3 backup, fixed `BSRPRO.Vault` | DONE | unchanged |
| FLAG_SECURE (MainActivity, share, autofill auth) | DONE | |
| Save prompt lasts 30 s | DONE | `PendingSaveStore.TTL_MS` |
| Rate limiting, clipboard auto-clear, root detection, HIBP checker | DONE | classes present |
| Custom fonts (Inter / Manrope / JetBrains Mono) | GAP | font files not bundled (no network in sandbox) |
| Dynamic color (Material You) | GAP | not wired in `Theme.kt` |
| Swipe actions, pull-to-refresh, loading skeletons, haptics | GAP | not found in code |
| "Importing X of Y" on the same page | GAP | export has progress; import does not |
| Autofill native-app fill / popup theming / save-button bugs (spec bugs 1,2,4) | NOT RE-TESTED | need on-device test; no code changed in this build |
| New unit tests for the restore flow | GAP | existing tests untouched; none added for new ViewModel logic |
