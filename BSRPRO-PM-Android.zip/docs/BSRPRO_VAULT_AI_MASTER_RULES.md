# BSRPRO Vault — Master AI Development Rules

**Project:** BSRPRO Vault
**Application Type:** Native Password Manager
**Role of AI:** Senior Developer + Security Engineer + QA Engineer + Performance Engineer + UI/UX Engineer
**Primary Rule:** पहले समझो → फिर जांचो → फिर fix करो → उसी समय verify करो → document करो → तभी आगे बढ़ो।

---

# 1. ABSOLUTE SOURCE OF TRUTH

`Fix.md` इस project का primary functional source of truth है।

इसके अलावा:

`BSRPRO_VAULT_AI_MASTER_RULES.md`

इस document में project के permanent development rules, security rules, workflow, change-control और historical record रहेगा।

### हर task शुरू करने से पहले:

1. `Fix.md` पढ़ो।
2. यह Master Rules document पढ़ो।
3. पिछले fixes/history पढ़ो।
4. Current code को समझो।
5. User द्वारा बताई गई exact समस्या identify करो।
6. तभी code touch करो।

**बिना context पढ़े सीधे code बदलना STRICTLY PROHIBITED है।**

---

# 2. ONE-DOCUMENT HISTORY RULE

हर build/fix की history इसी एक master document में maintain होगी।

अलग-अलग:

- Fix1.md
- Fix2.md
- Fix3.md
- FinalFix.md
- LatestFix.md

जैसी files बनाकर history को scatter मत करो।

हर completed change को इसी document के:

`CHANGE HISTORY`

section में append/update करो।

हर entry में:

- Build/version
- Date
- Reported problem
- Root cause
- Files changed
- Exact logic changed
- Why it was changed
- Test performed
- Result
- Regression risk
- Rollback information
- Backup/reference
- Final status

लिखना जरूरी है।

इससे अगर भविष्य में कोई bug वापस आए तो पहले देखो कि यह logic पहले कब बदला था और क्यों बदला था।

---

# 3. USER BUG = ONLY THAT FEATURE FIRST

जब user कहता है:

> "AutoFill में problem है"

तो सबसे पहले केवल AutoFill system को trace करो।

दूसरे unrelated features को modify मत करो।

### Required investigation:

`User Report → Feature Boundary → Relevant Files → Call Flow → Root Cause → Fix → Test`

उदाहरण:

AutoFill issue होने पर:

- AutoFill Service
- service lifecycle
- request handling
- credential matching
- biometric/PIN authentication
- autofill response
- browser/app detection
- background process
- timeout
- race condition
- service restart
- logs/errors

check करो।

Backup, UI, database या unrelated feature तभी touch करो जब actual root cause उससे directly जुड़ा हो।

---

# 4. NO RANDOM FIXING

किसी एक bug को fix करने के नाम पर:

- unrelated code refactor
- UI redesign
- database rewrite
- package change
- encryption change
- backup format change
- dependency replacement

मत करो।

अगर ऐसा change वास्तव में आवश्यक है तो पहले document करो:

**Why this change is required**

और फिर impact analysis करो।

---

# 5. ROOT CAUSE FIRST

हर bug के लिए केवल symptom fix स्वीकार नहीं है।

गलत:

> "AutoFill slow था इसलिए 2 second delay हटाया।"

सही:

> Request lifecycle में duplicate initialization + unnecessary authentication wait मिला → duplicate initialization हटाया → authentication flow optimized किया → lifecycle/restart tests किए।

हर fix में:

**Symptom → Root Cause → Correct Fix → Verification**

होना चाहिए।

---

# 6. STOP CONDITION

अगर user द्वारा बताई गई समस्या का कारण code में स्पष्ट नहीं है:

**Guess करके code मत बदलो।**

पहले:

- relevant files inspect करो
- call flow trace करो
- logs/errors check करो
- dependency/API behavior verify करो
- existing implementation समझो

अगर फिर भी required behavior अस्पष्ट है और कोई safe assumption संभव नहीं है, user से clarification मांगो।

लेकिन केवल इसलिए clarification मत मांगो क्योंकि investigation करने में मेहनत लगती है।

---

# 7. CHANGE BEFORE/AFTER RULE

हर code modification से पहले identify करो:

### BEFORE

Current behavior क्या है?

### AFTER

Expected behavior क्या होना चाहिए?

### CHANGE

कौन-सी exact logic बदलेगी?

### RISK

इस change से कौन-कौन से existing features प्रभावित हो सकते हैं?

फिर implementation करो।

---

# 8. IMMEDIATE VERIFICATION RULE

सबसे महत्वपूर्ण rule:

**एक change करके उसे बिना verify किए अगले change पर मत जाओ।**

हर meaningful code change के तुरंत बाद:

1. Compile/type/syntax check
2. Relevant static checks
3. Relevant runtime test
4. Error/log check
5. Regression check

करो।

अगर error मिला:

**STOP → FIX → VERIFY AGAIN**

फिर आगे बढ़ो।

इससे अंत में दोबारा पूरा audit करने की जरूरत कम होगी।

---

# 9. DEAD/OLD CODE RULE

अगर नया logic पुराने logic को replace करता है तो पुराना dead implementation:

- duplicate function
- unused class
- obsolete listener
- duplicate service
- unused import
- old fallback
- unreachable branch

सिर्फ इसलिए मत छोड़ो कि "शायद काम आएगा"।

लेकिन delete करने से पहले verify करो कि वह कहीं दूसरे feature द्वारा use नहीं हो रहा।

यदि uncertain हो तो पहले reference/search करके verify करो।

---

# 10. NO DOUBLE IMPLEMENTATION

एक feature के लिए दो competing implementations मत रखो।

उदाहरण:

अगर नया AutoFill authentication flow बनाया गया है और पुराना flow अब use नहीं होता, तो दोनों को parallel रखने से:

- race condition
- duplicate callback
- inconsistent state
- unpredictable behavior

हो सकता है।

एक authoritative implementation रखो।

---

# 11. DATA SAFETY — HIGHEST PRIORITY

Password manager में:

**DATA LOSS IS MORE SERIOUS THAN A UI BUG.**

किसी भी change से:

- passwords
- usernames
- notes
- credentials
- encryption keys
- backup files
- history
- settings
- user database

delete/corrupt/overwrite नहीं होने चाहिए।

Database schema बदलने से पहले migration plan आवश्यक है।

---

# 12. BACKUP SAFETY

Backup system में:

### कभी भी:

- existing valid backup को failed backup से overwrite मत करो।
- incomplete backup को valid backup मत मानो।
- corrupt backup को silently replace मत करो।
- failed restore के बाद backup modify मत करो।

### Preferred flow:

`Create Temporary Backup → Validate → Encrypt → Verify → Atomic Replace`

अगर किसी step में failure हो:

`Keep Previous Valid Backup`

---

# 13. RESTORE SAFETY

Restore से पहले:

1. Backup exists?
2. File readable?
3. Format valid?
4. Version supported?
5. Encryption valid?
6. Master Password/key valid?
7. Data integrity valid?

तभी restore करो।

Failure पर original user database सुरक्षित रहना चाहिए।

---

# 14. AUTOMATIC BACKUP RULE

Automatic backup:

- background में चले
- UI freeze न करे
- repeated prompts न दे
- unnecessary duplicate backups न बनाए
- selected folder/permission का सम्मान करे
- failed backup पर old valid backup सुरक्षित रखे

Backup operation interrupt हो जाए तो recovery mechanism होना चाहिए।

---

# 15. AUTOMATIC RESTORE / REINSTALL

Reinstall recovery में:

1. Backup location detect करो।
2. Valid backup detect करो।
3. Backup metadata/version verify करो।
4. Master Password/key से decrypt करने की कोशिश करो।
5. Password गलत हो तो backup को touch मत करो।
6. Clear error/status दो।
7. Valid होने पर safe restore करो।

Possible errors:

- No backup found
- Folder unavailable
- Permission denied
- Wrong Master Password
- Decryption failed
- Corrupt backup
- Unsupported backup version
- Integrity check failed

---

# 16. SECURITY RULES

Password Manager में security को convenience के लिए कमजोर मत करो।

Never:

- plaintext passwords logs में डालो
- master password store करो
- encryption key hardcode करो
- secrets source code में रखो
- sensitive data unnecessarily clipboard में रखो
- insecure random generator use करो
- authentication bypass करो
- biometric result को केवल UI state मानकर trust करो

Encryption/key handling existing architecture के साथ compatible और secure रहनी चाहिए।

---

# 17. AUTOFILL RULES

AutoFill को:

- fast
- reliable
- deterministic
- lifecycle-safe

रखो।

Check:

- service binding
- initialization
- duplicate requests
- request cancellation
- authentication
- biometric
- PIN fallback
- process death
- force stop
- app restart
- device restart
- browser restart
- timeout
- credential matching
- multiple accounts
- wrong website/app matching
- repeated refill

Unnecessary sleep/delay/polling हटाओ।

लेकिन security authentication को केवल speed के लिए bypass मत करो।

---

# 18. AUTHENTICATION RULE

Authentication state को properly manage करो।

Possible states clearly defined हों:

`Unauthenticated → Authenticating → Authenticated → Locked → Expired`

Race conditions रोकें।

Biometric failure, cancellation, timeout और fallback correctly handle हों।

---

# 19. PERFORMANCE RULE

UI thread को heavy काम के लिए block मत करो।

Database, encryption, backup, compression, migration आदि उचित background mechanism में चलें।

लेकिन "background" का मतलब uncontrolled thread creation नहीं है।

Use project-appropriate:

- Coroutines
- WorkManager
- structured concurrency
- lifecycle-aware operations

जहाँ applicable हो।

---

# 20. LANGUAGE / TECHNOLOGY RULE

पहले project की actual technology identify करो।

उदाहरण:

- Kotlin/Java → Android
- JavaScript/TypeScript → Extension/Web/PWA
- Flutter/Dart → Flutter
- React Native → JS/TS + native bridge

**Project की existing technology को बिना कारण दूसरी language/framework में migrate मत करो।**

अगर code Kotlin में है तो Kotlin standards follow करो।

अगर JavaScript/TypeScript है तो उसी ecosystem के standards follow करो।

अगर नया code existing architecture में जोड़ना है तो उसी architecture/pattern को follow करो।

---

# 21. LANGUAGE UPDATE RULE

अगर काम के दौरान newer API/library/language feature उपलब्ध मिले:

पहले check करो:

- project compatibility
- min SDK
- target SDK
- browser compatibility
- existing dependencies
- migration risk
- security benefit
- performance benefit

केवल "नया है" इसलिए upgrade मत करो।

यदि upgrade जरूरी है तो अलग change के रूप में document करो और regression test करो।

---

# 22. BUILD & DEPENDENCY RULE

कोई dependency जोड़ने से पहले:

- क्या इसकी वास्तव में जरूरत है?
- क्या existing dependency से काम हो सकता है?
- security reputation?
- maintenance?
- package size?
- compatibility?
- license?

check करो।

Unnecessary dependency prohibited है।

---

# 23. ERROR HANDLING

हर important operation में meaningful error handling हो।

Silent failure नहीं।

लेकिन user को internal stack trace या sensitive information मत दिखाओ।

Developer logs में भी secrets नहीं होने चाहिए।

---

# 24. LOGGING RULE

Production code में:

- password
- master password
- encryption key
- token
- backup contents
- personal credential data

log नहीं होना चाहिए।

Debug logging केवल जरूरत होने पर और safe form में।

Final production build में unnecessary debug logs हटाओ।

---

# 25. TESTING RULE

हर feature के लिए minimum:

### Normal case

काम करता है?

### Failure case

गलत input पर सुरक्षित रहता है?

### Restart case

restart के बाद काम करता है?

### Recovery case

failure के बाद वापस काम करता है?

### Regression case

दूसरा feature नहीं टूटा?

### Security case

कोई bypass/data exposure तो नहीं?

---

# 26. LARGE DATA TEST

Password manager को केवल 5 passwords से test मत करो।

जहाँ applicable हो:

- hundreds of credentials
- large history
- large backup
- duplicate sites
- multiple accounts
- repeated AutoFill requests

के साथ test करो।

---

# 27. USER-REPORTED BUG WORKFLOW

जब user बोले:

> "इस feature में problem है"

AI का exact workflow:

### STEP 1

User की complaint को एक exact issue statement में बदलो।

### STEP 2

Feature boundary तय करो।

### STEP 3

उस feature से जुड़े files/functions/classes खोजो।

### STEP 4

Call flow trace करो।

### STEP 5

Logs/errors inspect करो।

### STEP 6

Historical CHANGE HISTORY check करो।

### STEP 7

देखो यह logic पहले क्यों बदला गया था।

### STEP 8

Root cause identify करो।

### STEP 9

Minimal safe fix बनाओ।

### STEP 10

Code change करो।

### STEP 11

तुरंत compile/static/runtime verification करो।

### STEP 12

Related regression tests करो।

### STEP 13

PASS होने पर ही next task करो।

### STEP 14

इस change को उसी Master Document में record करो।

---

# 28. DO NOT FIX A DIFFERENT FEATURE

अगर user ने AutoFill कहा है और investigation में Backup का unrelated bug दिख गया:

पहले AutoFill पूरा करो।

Backup issue को अलग "Discovered Issue" में record करो।

बिना permission unrelated feature बदलना नहीं है, जब तक वह AutoFill root cause न हो।

---

# 29. SECURITY-SENSITIVE AREA RULE

इन areas में extra caution:

- Master Password
- Encryption
- Key derivation
- Biometric
- PIN
- AutoFill authentication
- Backup encryption
- Database migration
- Credential storage

इनमें cosmetic या experimental changes नहीं।

पहले existing implementation समझो।

---

# 30. ROLLBACK RULE

हर risky change के लिए पता होना चाहिए:

**अगर नया code fail हुआ तो previous working implementation पर कैसे लौटेंगे?**

Git history, previous build या backup reference उपलब्ध रखें।

लेकिन production में पुराने insecure/dead code को blindly restore मत करो।

---

# 31. GIT / VERSION CONTROL

हर meaningful stable milestone को version/commit से identify करो।

Commit message meaningful हो:

`fix: autofill biometric timeout`

या

`fix: atomic encrypted backup restore`

ऐसा नहीं:

`update`
`changes`
`final`
`new`

---

# 32. BUILD HISTORY

हर final build को identify करो:

`Version / Build Number / Date / Commit`

और Master Document में record करो।

उदाहरण:

| Build | Change                 | Result |
| ----- | ---------------------- | ------ |
| 1.0.1 | AutoFill lifecycle fix | PASS   |
| 1.0.2 | Backup atomic write    | PASS   |
| 1.0.3 | Biometric timeout fix  | PASS   |

---

# 33. CHANGE HISTORY FORMAT

हर change के लिए:

```text
## CHANGE ENTRY

Build:
Date:

Reported Problem:

Affected Feature:

Root Cause:

Files Changed:

Functions/Classes Changed:

Previous Logic:

New Logic:

Why This Fix Is Safe:

Security Impact:

Data Impact:

Performance Impact:

Tests Performed:

Regression Tests:

Result:

Rollback Reference:

Status:
PASS / PARTIAL / FAILED

```

---

# 34. FAILED CHANGE RULE

अगर change fail हो:

उसको छुपाना नहीं है।

Document करो:

- क्या किया
- क्यों fail हुआ
- क्या वापस rollback किया
- नया approach क्या होगा

Failed attempt को history से delete मत करो।

यह future developer को वही गलती दोहराने से बचाएगा।

---

# 35. DISCOVERED BUG RULE

काम करते समय कोई दूसरा bug मिले:

उसे तुरंत fix करना आवश्यक नहीं है।

पहले:

`DISCOVERED ISSUES`

में record करो।

अगर वह current issue का root cause है → fix करो।

अगर unrelated है → user approval/appropriate task मिलने तक untouched रखो।

---

# 36. SMALL AI / LOW-CAPABILITY AI RULE

अगर कोई AI project को पूरी तरह समझने में सक्षम नहीं है:

उसे sensitive/core architecture बदलने की अनुमति नहीं है।

वह:

- documentation पढ़ सकता है
- issue identify कर सकता है
- analysis दे सकता है
- safe minor changes कर सकता है

लेकिन बिना complete context के:

- encryption
- database schema
- backup format
- authentication
- AutoFill security
- migration

नहीं बदले।

---

# 37. SENIOR AI / ADVANCED DEVELOPER RULE

यदि capable Senior AI/Developer available है:

वह केवल requested bug fix तक सीमित नहीं रहेगा बल्कि:

- root cause
- architecture
- security
- performance
- regression
- maintainability

भी evaluate करेगा।

लेकिन फिर भी **scope creep नहीं करेगा**।

---

# 38. NO FAKE COMPLETION

AI कभी यह न कहे:

> "Fixed"

जब तक actual verification न हुई हो।

Status केवल:

`VERIFIED PASS`

तभी दें जब test evidence available हो।

अगर test नहीं चल पाया:

`NOT VERIFIED`

लिखें।

---

# 39. CLOUD / TIME / RESOURCE LIMIT RULE

अगर available execution/cloud/tool time या context limit के कारण पूरा task complete करना संभव नहीं है:

काम silently अधूरा छोड़कर final मत कहो।

पहले बताओ:

- क्या complete हुआ
- क्या बाकी है
- कहाँ limitation आई
- कितना काम realistically बाकी है
- कौन-सा part सुरक्षित है
- कौन-सा part touch नहीं किया गया

अगर current environment में build/ZIP संभव नहीं है तो स्पष्ट बताओ।

**Never pretend that ZIP/build was created or tested when it was not.**

---

# 40A. FINAL ZIP NAMING RULE

Final ZIP का filename हमेशा इसी fixed base name से शुरू और समाप्त होगा:

`BSRPRO PM Android.<SEQUENTIAL_NUMBER>.zip`

उदाहरण:

- `BSRPRO PM Android.1.zip`
- `BSRPRO PM Android.2.zip`
- `BSRPRO PM Android.3.zip`
- `BSRPRO PM Android.4.zip`

### Mandatory rules

1. हर नया final ZIP पिछले final ZIP से sequential number में **+1** होगा।
2. Base name हमेशा exactly **`BSRPRO PM Android`** रहेगा।
3. Number के बाद `.zip` के अलावा कोई दूसरा suffix/prefix नहीं होगा।
4. `final`, `fixed`, `polished`, `updated`, `cl-updated`, date, time, build name, commit hash या कोई अन्य पहचान filename में नहीं जोड़ी जाएगी।
5. यदि ZIP के अंदर build/version/commit पहचान चाहिए तो वह Master Document/CHANGE HISTORY में दर्ज होगी, filename में नहीं।
6. ZIP बनाने से पहले अगला sequential number history और उपलब्ध final ZIPs से verify करना आवश्यक है।
7. किसी पुराने ZIP को overwrite नहीं करना है; नया milestone नया sequential number लेगा।
8. ZIP बनने के बाद उसी exact filename से archive extraction/integrity verification करना होगा।

**Golden filename format:** `BSRPRO PM Android.1.zip → BSRPRO PM Android.2.zip → BSRPRO PM Android.3.zip → ...`

---

# 40. FINAL ZIP RULE

Final ZIP तभी बनाओ जब:

- requested fixes complete हों
- build succeeds
- relevant tests pass हों
- no critical security issue हो
- no known data-loss risk हो
- no unresolved compile error हो
- required files मौजूद हों
- ZIP contents verify किए गए हों

ZIP बनाने के बाद ZIP को खोलकर verify करो कि files वास्तव में मौजूद हैं।

---

# 41. FINAL POLISH

Final release से पहले:

- TODO
- FIXME
- placeholder
- dead code
- duplicate implementation
- debug logs
- unused imports
- unused dependency
- broken reference
- unnecessary permission
- obsolete migration
- stale comments

check करो।

लेकिन किसी potentially-used code को केवल "unused दिख रहा है" के आधार पर delete मत करो।

---

# 42. ZERO REGRESSION POLICY

Existing working functionality को preserve करना है।

हर fix के बाद पूछो:

> "क्या इस change से कोई existing feature टूट सकता है?"

अगर हाँ:

- test करो
- guard करो
- migration दो
- rollback तैयार रखो

---

# 43. USER DATA FIRST

Priority हमेशा:

**User Data Safety > Security > Correctness > Reliability > Performance > UI Polish**

लेकिन security को data safety के खिलाफ sacrifice नहीं करना है।

---

# 44. FINAL AUDIT

Final build से पहले पूरा project audit करो:

### Core

[ ] Master Password
[ ] Encryption
[ ] Credential storage
[ ] Add/Edit/Delete
[ ] Search
[ ] History

### AutoFill

[ ] Fast AutoFill
[ ] Authentication
[ ] Biometric
[ ] PIN fallback
[ ] Service restart
[ ] Process death
[ ] Correct matching

### Backup

[ ] Automatic backup
[ ] Manual backup
[ ] Encryption
[ ] Atomic write
[ ] Automatic restore
[ ] Reinstall recovery
[ ] Wrong password
[ ] Corrupt backup
[ ] Version migration

### Security

[ ] No plaintext secrets
[ ] Secure key handling
[ ] Secure authentication
[ ] Clipboard protection
[ ] Session locking
[ ] No sensitive logs

### Reliability

[ ] Crash checks
[ ] ANR checks
[ ] Race conditions
[ ] Large database
[ ] Restart/recovery
[ ] Permission failure

### Code

[ ] No TODO
[ ] No placeholder
[ ] No duplicate logic
[ ] No unnecessary dependency
[ ] No dead code
[ ] No debug code

### Release

[ ] Build PASS
[ ] Runtime PASS
[ ] Regression PASS
[ ] Security PASS
[ ] ZIP verified
[ ] CHANGE HISTORY updated

---

# 45. FINAL RESPONSE FORMAT TO USER

हर completed task के बाद concise report:

```text
TASK:
क्या fix किया गया।

ROOT CAUSE:
असल समस्या क्या थी।

CHANGED:
कौन-सी files/logic बदली।

VERIFICATION:
क्या-क्या test हुआ।

RESULT:
PASS / PARTIAL / FAILED

DATA SAFETY:
No data loss / Risk identified

SECURITY:
PASS / Issue

REGRESSION:
PASS / Issue

BUILD:
Build number/version

HISTORY:
Master document में entry update की गई।

```

---

# 46. GOLDEN RULE

## THINK BEFORE CODE.

## READ BEFORE CHANGE.

## TRACE BEFORE FIX.

## FIX ONLY THE ACTUAL PROBLEM.

## VERIFY IMMEDIATELY AFTER EVERY CHANGE.

## NEVER SACRIFICE USER DATA OR SECURITY.

## NEVER CLAIM PASS WITHOUT TESTING.

## DOCUMENT EVERY IMPORTANT CHANGE IN ONE MASTER HISTORY.

## NEVER MAKE THE USER EXPLAIN THE SAME PROJECT CONTEXT AGAIN.

---

# PROJECT OPERATING PRINCIPLE

इस project को ऐसे maintain करो जैसे यह production में लाखों users का real password manager हो।

हर future developer/AI को इस document को देखकर समझ आना चाहिए:

- project क्या है
- कौन-सी technology है
- कौन-सा feature कैसे काम करता है
- कौन-सी समस्या पहले आई थी
- उसका root cause क्या था
- कौन-सा code बदला गया
- क्यों बदला गया
- कौन-सा solution fail हुआ
- कौन-सा solution काम किया
- कौन-सा backup/build safe है
- किसी पुराने bug के वापस आने पर कहाँ से investigation शुरू करनी है

**इस document का उद्देश्य AI को अधिक code लिखवाना नहीं, बल्कि AI को गलत code लिखने से रोकना है।**

यदि कोई instruction इस document से conflict करे, तो पहले conflict identify करो और user से clarification लो।

**BSRPRO Vault को हमेशा Safe → Correct → Tested → Documented → Production Ready अवस्था में आगे बढ़ाओ।**
---

# 48. CHANGE HISTORY — UNIFIED AUTOFILL AUTHORITY

## CHANGE ENTRY

Build:
BSRPRO PM Android Twelve (source milestone; APK build not verified in this environment)

Date:
2026-10-06

Reported Problem:
Autofill authentication behaved like a separate session with its own timer, while the vault had additional session/background timing. This could cause an Autofill unlock prompt even though the vault was already authenticated and made the authentication model harder to reason about.

Affected Feature:
Android Autofill authentication/session handling.

Root Cause:
`AutofillSessionGate` owned an independent elapsed-time expiry window (`autofillSessionSeconds`) in addition to `SessionKeyStore`, which already owns the actual decrypted vault session and its expiry.

Files Changed:
- `app/src/main/java/pro/babasitaram/vault/autofill/AutofillSessionGate.kt`
- `app/src/main/java/pro/babasitaram/vault/autofill/AutofillAuthActivity.kt`
- `app/src/main/java/pro/babasitaram/vault/autofill/VaultAutofillService.kt`
- `app/src/main/java/pro/babasitaram/vault/core/model/VaultSettings.kt`
- `app/src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt`
- `app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt`
- `docs/FIX_MD_STATUS.md`

Functions/Classes Changed:
- `AutofillSessionGate.isValid/touch/clear`
- Autofill service/auth activity session checks
- Settings presentation for the separate Autofill duration

Previous Logic:
Autofill had a separate short-lived gate whose expiry was controlled by `autofillSessionSeconds`. The gate could expire while the vault session was still valid, causing another Autofill authentication flow.

New Logic:
`SessionKeyStore` is the single authoritative authentication/session state. `AutofillSessionGate` is now only a compatibility facade and does not own an expiry clock. Autofill `touch()` no longer extends a second timer. The separate Autofill unlock-duration control is removed from the Settings UI; its persisted field remains only for backward-compatible migration.

Why This Fix Is Safe:
No vault database, credential records, encryption format, backup format, restore format, or master-password data is changed. The change removes a competing in-memory Autofill timer rather than changing stored vault data.

Security Impact:
Improves consistency by preventing a second Autofill-only authentication state from diverging from the real vault session. Autofill still requires a valid authenticated vault session before sensitive datasets are returned.

Data Impact:
No data migration. No credential/database/backup changes.

Performance Impact:
Removes an independent Autofill timer and its lifecycle/broadcast bookkeeping. Autofill uses the existing vault session validity check.

Tests Performed:
- Source inspection of Autofill service, authentication activity, session store, auto-lock controller, settings, and restore flow.
- Static reference search after edits.
- Web verification against current Android Autofill documentation for authenticated datasets and inline fallback behavior.
- Android/Gradle compilation: NOT VERIFIED in this environment because Android SDK/Gradle executable is unavailable.
- Device runtime Autofill test: NOT VERIFIED.

Regression Tests:
NOT RUN — requires Android build/device execution.

Result:
PARTIAL — source change applied; build/runtime evidence unavailable in this environment.

Rollback Reference:
Previous source package: BSRPRO-PM-Android.11.zip. The entire working tree was copied before editing.

Status:
PARTIAL


# PERMANENT APP-LOGIN BACKUP/RESTORE SAFETY RULE

Native Android app-login credentials are a protected data boundary. Backup/import/restore code MUST NOT silently remove or downgrade an existing app login. Unless the user explicitly deletes the credential, preserve its `appPackage`, `appName`, `loginUri`, `appPin`, `isPrimaryAppLogin`, and existing password when an incoming backup omits those fields or omits the record. Incoming non-empty credential changes remain authoritative. This rule must be checked before any future backup, restore, import, migration, or Autofill-related code change.
