# BSRPRO Vault 1.0.0 — Backup-restore fix + navigation/support alignment

Format: Issue -> Fix -> Logic. **Not compiled in the authoring sandbox** (no Android SDK / Maven access);
real compile + unit tests run on GitHub Actions (`native-android-build.yml`).

## 1. Issue: backup folder selected, same master password, but nothing is restored
Root causes found in code:
1. **Setup screen** — the "Backup folder" button only saved the URI (`onBackupFolderSelected`). `create()` then built an
   *empty* vault; the backup sitting in the folder was never looked at.
2. **Settings > Backup** — `setBackupFolder` only showed "Existing backup files were not changed". No scan, no restore.
3. **`autoImportIfVaultEmpty`** used a permanent one-shot flag (`auto_import_done_v1`). After ONE attempt (wrong password,
   transient provider error, ...) auto-restore was disabled forever, even after choosing a new folder.
4. **Data-loss risk**: when the first backup was written into a folder that already held a BSRPRO.Vault from another
   password, the old file was renamed and then *deleted* after the new one verified.

**Fix**
- `SetupViewModel.create()` now looks for a backup first (chosen folder, then default locations). If the typed master
  password opens it, the vault is **restored automatically**. If it does not, a dialog explains the mismatch and offers:
  enter the backup's own password / "Create new vault" (backup file untouched) / Cancel.
- Choosing a folder in Setup scans it immediately; if a master password is already typed it restores right away.
- Settings > Backup folder pick: empty vault + backup opens with current password -> restored automatically;
  vault has data -> merge **review** (duplicates skipped by default); different password -> asks for it, then review.
- Auto-import is now *armed* only for a freshly created empty vault (not a permanent flag) and disarmed on success,
  on a different-password backup, or once the vault has data.
- The previous backup is deleted after publishing a new one **only if it opens with the current password**; otherwise it is
  kept as `BSRPRO-Recovery-*.Vault`.

**Logic**: master password == backup password is the common case, so we try it silently first and only ask when it fails.
Nothing destructive happens without the user choosing it, and an existing backup is never overwritten by an empty vault.

## 2. Navigation per spec
Bottom bar: Vault / TOTP / Health / Settings (filled/outlined icon states). Generator and Mobiles stay in the drawer.
Drawer: 280dp, scrollable, grouped (main / settings-help-support-about / "Lock Vault Now"), spec labels, badges kept.
`DrawerCountsViewModel.lockNow()` uses the same `LockVaultUseCase` as the Vault screen.

## 3. Support Developer / links
Copy-UPI button, Google Pay / PhonePe / Paytm deep links with `upi://` fallback, developer card, "where every coffee goes".
GitHub links now point to `ramhardamp/babasitaram-pro`.

## Not changed (deliberately)
V3 backup format, crypto, Room schema, `BSRPRO.Vault` fixed filename, `versionCode` (see README note).

## 4. Issue: successful backup import/restore could make native app-login credentials disappear

**Root cause / risk:** V3 payload parsing itself preserves `appPackage`, `appName`, `loginUri`, `appPin`, and password fields, but the restore/import boundary had no permanent invariant protecting an existing native app login when an incoming backup omitted the record or omitted app-specific fields. A restore could therefore leave the vault valid while forcing the user to save app logins again for Autofill.

**Fix**
- Added one authoritative `AppLoginRestorePolicy` for backup/import/restore boundaries.
- MERGE and REPLACE imports now protect active native app-login records.
- V3 transactional restore now carries forward active app logins and recovers missing app-specific fields from the current vault.
- Incoming non-empty password/credential changes remain authoritative; only missing fields are recovered.
- No V3 crypto format, encryption key, Room schema, or password storage format was changed.
- Added regression tests for missing app fields, omitted app-login records, incoming password updates, and REPLACE import.

**Permanent rule:** native app-login credentials are protected data and must not be silently removed/downgraded by future backup/import/restore/migration changes. Explicit user deletion is required to remove them.

**Verification:** source/static inspection and regression test source added. Android compile/device execution remains NOT VERIFIED in this sandbox because Android SDK/Gradle runner is unavailable.

## 5. Issue: Android Autofill request repeatedly cancelled / response timed out

**Evidence from device log supplied by user:** the service connected and parsed `pkg=com.jio.jpp1` with one username and one password field, but every request was cancelled before a response; the log showed `build timeout — request deadline guard` and `5 reply — empty`.

**Root cause:** `VaultAutofillService.onFillRequest()` was performing a process-death persisted-session restore inside the Android FillRequest deadline. That restore can require Keystore/KDF work and was guarded at 3.5 seconds, while the outer response guard was 4.25 seconds. Android cancelled the request before the unlock dataset could be returned. This is a lifecycle/deadline error, not a credential-matching failure.

**Fix**
- Removed slow persisted-session restoration from `onFillRequest()`.
- Locked requests now return the authentication dataset immediately; biometric/device-PIN/master-password work happens only after the user selects the BSRPRO suggestion in `AutofillAuthActivity`.
- Removed the FillRequest timeout/polling workaround and restore mutex from the service.
- Kept the existing exact package/domain matcher and real `AutofillId` propagation.
- Inline/keyboard presentation remains attached to the same response and authentication dataset.

**Expected flow:** `onFillRequest → parse → session check → immediate locked/unlocked response → user authentication only when required → authenticated dataset → Android fills the original AutofillIds`.

## 6. Issue: two independent lock timers caused confusing early/duplicate locking

**Root cause:** the app had an absolute `vaultSessionSeconds` plus a separate `backgroundGraceSeconds` policy. The background lifecycle started another timer and persisted background timestamps, so the Settings screen exposed two values that could disagree.

**Fix**
- `SessionKeyStore` is now the only authoritative vault timeout.
- `AutoLockController` no longer starts a background timer; backgrounding only records process-death recovery metadata.
- Persisted-session restore uses the same absolute `expiresAtWallMs`; background duration is no longer a second expiry condition.
- Settings now exposes one `Vault auto-lock` control with 5m/15m/30m/1h/4h/12h/24h/Manual Lock Only.
- The legacy background timeout remains stored only as a compatibility mirror and is not an independent lock policy.
- Changing the vault timeout updates the currently authenticated session immediately and refreshes the persisted biometric session expiry when available.

**Expected behavior:** if the vault is set to 15 minutes, closing/backgrounding and reopening after 1–14 minutes does not create a second lock. At/after the 15-minute expiry, the vault locks. A process death can still require biometric/master-password authentication when no safe persisted biometric credential is available.

## 7. UI consistency pass

- Setup/login branding now centers the BSRPRO logo with the same 88dp primary authentication logo size used by the lock screen.
- Startup splash keeps the branded loading animation and uses a consistent 72dp centered logo.
- Autofill password/choice/error dialogs now use the BSRPRO logo in their titles for consistent authentication branding.
- No vault data, encryption format, backup format, or credential records were changed by the UI work.

**Verification status:** source/static verification completed. Android compile, unit-test execution, and device runtime verification remain **NOT VERIFIED** in this sandbox because the Android SDK/Gradle executable is unavailable. The supplied Autofill log is consistent with the removed slow-restore-in-request root cause, but the runtime fix must still be confirmed on the device.

## 7. Issue: Bin screen had conflicting bulk actions and no safe selection workflow

**Evidence:** user screenshot showed both `Restore all` and `Empty Bin` as large global actions, while each row only exposed Restore. There was no selection model for restoring/deleting a chosen subset, and permanent deletion was effectively all-or-nothing from the screen.

**Root cause:** Bin UI was built around repository-wide `restoreAll()` / `emptyTrash()` operations instead of a selection-aware workflow. The repository already had efficient bulk encrypted writes for trash operations, but no selected-ID restore/permanent-delete APIs.

**Fix**
- Added `restoreSelected(ids)` and `permanentlyDelete(ids)` to the repository contract and implementation; both perform one encrypted persistence/publish operation for the selected records.
- Replaced the large `Restore all` / `Empty Bin` buttons with a compact selection toolbar.
- Added a header checkbox for Select all / clear all.
- Added per-entry checkboxes.
- Added selected-count feedback.
- Added `Restore` and `Delete` actions that operate only on the selected IDs.
- Added a per-entry permanent-delete icon for one-at-a-time deletion.
- Permanent deletion always requires confirmation; restore does not destroy data.
- The 30-day automatic cleanup remains a background retention rule and is unchanged.
- No vault encryption format, backup format, credential data model, or existing restore semantics were changed.

**Expected workflow:**
`Bin → select one/many → Restore` or `Bin → select one/many → Delete → confirmation`.
`Select all` applies only to currently visible Bin records; there is no hidden destructive global delete action.

**Regression tests added:** selected restore affects only selected trashed entries; selected permanent delete affects only selected trashed entries.

**Verification:** existing source regression suite 78/78 PASS; item-action audit PASS; production polish source gate PASS. Android compile and device UI/runtime verification remain NOT VERIFIED because this sandbox has no Android SDK/Gradle executable.
