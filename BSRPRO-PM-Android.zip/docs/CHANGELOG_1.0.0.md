# BSRPRO Vault 1.0.0 — Backup-restore fix + navigation/support alignment

Format: Issue -> Fix -> Logic. **Not compiled in the authoring sandbox** (no Android SDK / Maven access);
real compile + unit tests run on GitHub Actions (`native-android-build.yml`).

## 1. Issue: backup folder selected, same master password, but nothing is restored
Root causes found in code:
1. **Setup screen** — the "Backup folder" button only saved the URI (`onBackupFolderSelected`). `create()` then built an
   *empty* vault; the backup sitting in the folder was never looked at.
2. **Settings > Backup** — `setBackupFolder` only showed "Existing backup files were not changed". No scan, no restore.
3. **`autoImportIfVaultEmpty`** used a permanent one-shot flag (`auto_import_done_v1`). After ONE attempt (wrong password,
   transient provider error, ...) auto-restore was disabled forever, even after choosing a new folder.
4. **Data-loss risk**: when the first backup was written into a folder that already held a BSRPRO.Vault from another
   password, the old file was renamed and then *deleted* after the new one verified.

**Fix**
- `SetupViewModel.create()` now looks for a backup first (chosen folder, then default locations). If the typed master
  password opens it, the vault is **restored automatically**. If it does not, a dialog explains the mismatch and offers:
  enter the backup's own password / "Create new vault" (backup file untouched) / Cancel.
- Choosing a folder in Setup scans it immediately; if a master password is already typed it restores right away.
- Settings > Backup folder pick: empty vault + backup opens with current password -> restored automatically;
  vault has data -> merge **review** (duplicates skipped by default); different password -> asks for it, then review.
- Auto-import is now *armed* only for a freshly created empty vault (not a permanent flag) and disarmed on success,
  on a different-password backup, or once the vault has data.
- The previous backup is deleted after publishing a new one **only if it opens with the current password**; otherwise it is
  kept as `BSRPRO-Recovery-*.Vault`.

**Logic**: master password == backup password is the common case, so we try it silently first and only ask when it fails.
Nothing destructive happens without the user choosing it, and an existing backup is never overwritten by an empty vault.

## 2. Navigation per spec
Bottom bar: Vault / TOTP / Health / Settings (filled/outlined icon states). Generator and Mobiles stay in the drawer.
Drawer: 280dp, scrollable, grouped (main / settings-help-support-about / "Lock Vault Now"), spec labels, badges kept.
`DrawerCountsViewModel.lockNow()` uses the same `LockVaultUseCase` as the Vault screen.

## 3. Support Developer / links
Copy-UPI button, Google Pay / PhonePe / Paytm deep links with `upi://` fallback, developer card, "where every coffee goes".
GitHub links now point to `ramhardamp/babasitaram-pro`.

## Not changed (deliberately)
V3 backup format, crypto, Room schema, `BSRPRO.Vault` fixed filename, `versionCode` (see README note).
