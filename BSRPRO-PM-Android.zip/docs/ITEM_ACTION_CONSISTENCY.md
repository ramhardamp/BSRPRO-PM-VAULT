# Global item-action interaction policy

## Decision

All **row-level overflow/three-dot action menus** are removed from the app. A user now taps the item itself to open a dedicated, full-screen detail view. Item-specific actions live on that detail page.

This policy is applied to:

- Vault login entries
- Notes
- TOTP entries
- Mobile entries
- File entries

The remaining controls in list rows are only direct, high-frequency actions that are stable in the row (for example favorite and copy where appropriate). They are not a transient popup.

## Why this design

Android's Material 3 `DropdownMenu` is a temporary surface positioned relative to its anchor. Because it is displayed separately from normal layout and does not consume list space, an anchored menu is inherently fragile when used as a row action inside a scrolling list unless its lifecycle/anchor behavior is carefully managed. See Android's official menu documentation.

Google Password Manager's Android flow similarly starts from selecting a password and then opens a password detail screen for show/edit/delete actions.

Community feedback around Bitwarden also repeatedly identifies quick copy/view/edit actions hidden behind row-level three-dot menus as less efficient, particularly on constrained screens.

## UX contract

1. **Main list**: tap the item -> full detail page.
2. **No row-level three-dot**: no floating action menu can drift while the list scrolls.
3. **Detail page**: show all relevant fields, with copy/show-hide/action buttons.
4. **Back behavior**: system back and visible back arrow return to the same list.
5. **Delete**: confirmation happens on the detail page; successful deletion returns to the list.
6. **Long-press selection**: where bulk selection exists (mobile/vault), long press remains selection behavior and never opens an action popup.
7. **Page-level menus**: transient menus may still exist for non-item controls such as sorting or form field selection; these are not row-level item actions.

## Current implementation map

- `VaultListScreen.kt`: no row overflow; global overflow removed; drawer/settings provide global actions.
- `NotesScreen.kt`: note row opens `EntryDetailScreen`.
- `MobilesScreen.kt`: mobile row opens `EntryDetailScreen`; long press remains selection.
- `TotpManagerScreen.kt`: TOTP row opens existing `TotpDetailScreen`.
- `FilesScreen.kt`: file row opens `FileDetailScreen`.
- `EntryDetailScreen.kt`: editor route is selected from the entry type so notes/mobile/TOTP keep their specialized editors.

## Data-safety boundary

These UI changes do not alter backup payloads, vault serialization, import/export formats, or autofill session storage. They only change navigation and presentation of item actions.
