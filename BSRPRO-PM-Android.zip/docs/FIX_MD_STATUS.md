# Fix.md — live status (Phase 16D)

Format: Issue -> Fix -> Logic. NOT compiled, NOT device-tested (sandbox me Gradle/Android SDK nahi).
Is file ko har phase me update karna hai; extension ka kaam `docs/EXTENSION_UPDATE.md` me alag hai.

| Fix.md | Issue | Status | Fix / Logic |
|---|---|---|---|
| 1.1 | App vs website data mix | App + extension (v5.42.0) DONE; browser test baaki | `type` = app/website (purana khali `type` derive hota hai, overwrite nahi); export me "App logins" option. Extension: E2/E12/E13 |
| 1.2 | App Login category | DONE | "App Login" filter + list me Saved/Used dates |
| 1.3 | Zero-click backup/restore | DONE (16E fix, device test baaki) | Auto-import ab chuna hua backup folder scan karta hai (pehle sirf Downloads/MediaStore). Khali vault ka backup maujooda file overwrite nahi karta (data-loss guard) |
| 1.4 | Backup/import app-login credential loss | SOURCE APPLIED, build/device test baaki | Central `AppLoginRestorePolicy` protects active native app logins during MERGE/REPLACE import and V3 restore: missing app target/PIN/password fields are recovered, and app-login records absent from incoming backup are carried forward. Explicit user deletion remains the removal path. |
| 2.1 | Single share ka blank page | DONE (16D: Vault/Notes/Mobiles se bhi) | Auth ke baad seedha OS share sheet; beech ka Sharing page nahi |
| 2.2 | Share list me search | DONE | Real-time search field |
| 3.1 | Notes list me content | DONE | Sirf title |
| 3.2 | 3-dot menu | DONE (pehle se) | DropdownMenu, naya page nahi |
| 3.3 | New Entry confusion | DONE (pehle se) | Chooser me alag icon/colour/hint |
| 3.4 | Backup screen | DONE (16D) | 3 tabs; Settings rows sahi tab/picker par; export me 1 button = 1 format; import me alag file-type filters |
| 3.5 | Bin buttons | DONE | Empty Bin red + confirm dialog |
| 3.6 | Loading branding | DONE | Lottie ring + logo |
| 3.7 | Typography/spacing/contrast | DONE (code, 16C), device review baaki | Type.kt scale, 4/8dp grid, light-theme contrast 5.5:1, imePadding, IME actions |
| 4.1 | Startup loop | DONE | Session restore par 4s timeout |
| 4.2 | Restore warning/empty state | DONE (16E) | Confirm dialog + "No backup found" empty state; import preview me file khali ho to "0 entries" message + Import button disabled |
| 5.1 | Save speed | DONE | JSON encode background thread par; bulk ops ek write me |
| 5.2 | Size | App + extension reader DONE; export flag baaki | Internal vault gzip (`BSRZ1:`); `.Vault` export tab compress hoga jab extension E1 release ho (`COMPRESS_EXPORT = true`) |
| 5.3 | Zero regression | Static checks pass | Regression scripts pass; device test baaki |
| 7.1 | Duplicate `BSRPRO-Recovery-*.Vault` files | DONE (16D), device test baaki | SAF delete `DocumentsContract.deleteDocument`; publish ke baad purani file turant delete |
| 7.2 | Setup par backup folder / folder se restore | DONE (16B, 16E), device test baaki | SAF tree picker; exact `BSRPRO.Vault` PEHLI priority, na mile to folder/sub-folder ki baaki `.Vault` files (header check ke saath). Backup screen ka Restore bhi ab isi folder ko dekhta hai |
| 7.3 | Show suggestions default | DONE (16D) | `autofillInline = true` (key `autofill_inline_v2`) |
| 6 | Docs + Hinglish | DONE | Docs Issue -> Fix -> Logic, Hinglish; history `docs/CHANGELOG_PHASE16.md` me |
| 8.1 | Autofill baar-baar unlock (Phase 17) | DONE (source), device test baaki | Gate ab vault unlock/lock se sync; gate expire par vault lock nahi; vault unlocked ho to sirf biometric re-verify (KDF nahi); process-kill ke baad service me silent restore. Fix.md me ye point alag se nahi tha, user ke kehne par add hua |
| 8.2 | Autofill security hardening (Phase 17) | DONE (source), device test baaki | Related-site ka password dataset me nahi, confirm ke baad; hidden/1px field me fill nahi; release me logcat band; diagnostics me exception message nahi |
| 8.3 | Autofill speed (Phase 17) | DONE (source) | Regex cache, DataStore warm-up, ek waqt me ek restore (Mutex), 3.5s timeout |
| 8.4 | Session expiry + matching consistency (Phase 17d) | DONE (source), device test baaki | Restore se session ki umar nahi badhti; auth activity aur service ek jaisi settings se match karte hain |
| 8.5 | Unified Autofill authentication authority (Phase 18) | SOURCE APPLIED, build/device test baaki | AutofillSessionGate no longer owns a second expiry timer; Autofill follows SessionKeyStore; separate Autofill unlock-duration setting removed from Settings UI; persisted legacy value retained for migration compatibility |

## Baaki (sirf device / extension par nirbhar)
1. Gradle build + `testDebugUnitTest`.
2. Device: auto-import, Lottie splash, direct share, Realme/Redmi master-password share, Vault tab, 300+ entries, backup folder me sirf ek `BSRPRO.Vault`.
3. Extension v5.42.0 ko Chrome me load karke test; phir `COMPRESS_EXPORT = true`.
