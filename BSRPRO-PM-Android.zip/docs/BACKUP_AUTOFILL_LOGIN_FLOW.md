# BSRPRO Login, Backup-Folder Auto-Import, and Autofill Flow

## 1. Login / first-run screen

The first-run screen is the single entry point for recovery from an existing backup.
Only **Backup Folder** is exposed there. The standalone file-import button and the second
"Restore from backup folder" button have been removed from this screen.

### Backup-folder selection

1. The user taps **Choose backup folder**.
2. Android's Storage Access Framework (`OpenDocumentTree`) returns a folder URI.
3. The app persists read/write permission for that tree URI in `VaultSettings.backupFolderUri`.
4. The app scans **that exact folder** (and its supported subfolders) using `BackupFolderFinder`.
5. `BSRPRO.Vault` is preferred; otherwise the newest valid `.Vault` candidate is considered.
6. Only files up to the backup-size limit and matching the BSRPRO V3 container header are considered.
7. The real backup file is never deleted or renamed during this login/setup scan.
8. A private in-memory copy is kept as `pendingBackup` for the restore attempt.

### Create-vault / automatic restore

When the user enters the master password and taps **Create vault**:

- If a backup was found in the selected folder, the app first tries the entered password against that backup.
- If it opens successfully, the backup is restored directly and the vault becomes available with those records.
- If the selected backup uses a different password, the app asks for the backup's own password.
- Choosing **Create new vault** after a password mismatch does not modify the backup file.
- If no backup was found in the selected folder, a normal empty vault can be created.
- The setup flow no longer silently searches Downloads or another remembered backup location.

## 2. General backup discovery rule

`AutoBackupManager.findRestorableBackup()` now treats `VaultSettings.backupFolderUri` as authoritative.
When a folder is explicitly selected:

- a usable backup in that folder is returned;
- no usable backup returns `null`;
- permission/provider errors return `null` rather than falling through to another location.

Only when **no folder has ever been selected** does the legacy/default backup discovery path run.
This prevents restoring a different vault by accident.

## 3. Automatic backup write flow

Changes to vault data request an automatic backup through `AutoBackupManager.requestBackup()`.
The request is persisted first in private preferences so process death cannot silently lose the request.
Rapid changes are coalesced for 2.5 seconds before one encrypted V3 backup is written.

The write path is transactional:

1. Build encrypted V3 payload from the unlocked session.
2. Write to a staging file/document.
3. Decrypt/verify the staged payload with the current session password.
4. Publish `BSRPRO.Vault` only after verification.
5. Preserve the previous backup until the new one is safely published.
6. Remove superseded managed duplicates only after verification.
7. Update the last-success timestamp and activity log.

An empty vault is never allowed to overwrite an existing backup.

## 4. Auto-import after a fresh empty vault

After a fresh vault is created, `armAutoImport()` sets a private one-shot armed flag.
On the next unlock, `autoImportIfVaultEmpty()` runs only when:

- the vault is still empty, including the Bin check;
- the auto-import flag is armed;
- a restorable backup is available under the selected-folder rules.

The imported payload is merged with `upsertAll`; it does not replace live records.
After success, the armed flag is cleared and the real backup file remains untouched.

## 5. Autofill service flow

### Normal request

`VaultAutofillService.onFillRequest()`:

1. Parses the current `AssistStructure` with `AutofillParser`.
2. Ignores BSRPRO's own UI and non-fillable requests.
3. Rejects plain HTTP pages.
4. Reads settings, including excluded packages and inline suggestions.
5. Reuses the authenticated `SessionKeyStore` plus `AutofillSessionGate` when valid.
6. If the process was recreated, the service may silently restore the session only when the configured biometric/quick-autofill policy allows it.
7. If still locked, Android receives a placeholder dataset whose authentication opens `AutofillAuthActivity`.
8. If unlocked, matching entries are built into datasets.
9. Related-site matches remain authenticated; their secrets are released only after confirmation.

### Authentication hand-off

`AutofillAuthActivity` receives the exact `AutofillId`s and field types from the service.
After biometric/device-credential/master-password authentication it builds the final dataset from
those same IDs and returns it with `AutofillManager.EXTRA_AUTHENTICATION_RESULT`.

The auth activity now treats this as a **one-shot result**. Once the result is set, it finishes immediately;
it does not need to stay visible while Android performs the actual autofill. Reusable authentication state
lives in `SessionKeyStore` and `AutofillSessionGate`, not in the UI activity.

### What happens if the screen is manually closed

Closing the authentication UI **before successful authentication** cancels that particular autofill request.
That is required for safe user-consent handling. The app must not persist a master password just to keep filling
without authentication after a process kill.

Once authentication has succeeded, the activity can finish immediately; Android's autofill framework owns the
returned dataset. If the app process is later killed, the provider can only restore silently when the configured
secure biometric session mechanism permits it; otherwise another authentication is required.

## 6. Data-loss protections

- Existing backup files are read, not deleted, by login/setup import.
- A backup made with another password is preserved for manual recovery.
- Empty-vault backup overwrites are blocked.
- Backup publication is staged and verified before replacement.
- Selected-folder restore does not fall back to an unrelated backup location.
