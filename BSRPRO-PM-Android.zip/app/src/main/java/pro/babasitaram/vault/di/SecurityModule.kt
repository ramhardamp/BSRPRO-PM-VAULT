package pro.babasitaram.vault.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import pro.babasitaram.vault.core.security.PwnedPasswordChecker

@Module
@InstallIn(SingletonComponent::class)
object SecurityModule {
    @Provides @Singleton
    fun providePwnedPasswordChecker(): PwnedPasswordChecker = PwnedPasswordChecker()
}
