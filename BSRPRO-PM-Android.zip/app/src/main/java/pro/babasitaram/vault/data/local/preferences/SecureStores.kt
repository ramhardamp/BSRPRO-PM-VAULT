package pro.babasitaram.vault.data.local.preferences

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import java.nio.ByteBuffer
import java.util.Base64
import kotlinx.coroutines.flow.first
import pro.babasitaram.vault.core.crypto.MasterKeyManager
import pro.babasitaram.vault.core.security.LockoutState
import pro.babasitaram.vault.core.security.LockoutStore

/** Lockout counter, wrapped with the Keystore key so it can't be edited as plain text. */
class EncryptedLockoutStore(
    private val store: DataStore<Preferences>,
    private val keys: MasterKeyManager
) : LockoutStore {
    private val key = stringPreferencesKey("lockout_v1")

    override suspend fun load(): LockoutState {
        val raw = store.data.first()[key] ?: return LockoutState()
        return try {
            val text = String(keys.unwrapKey(Base64.getDecoder().decode(raw)), Charsets.UTF_8)
            val parts = text.split("|")
            LockoutState(parts[0].toInt(), parts[1].toLong())
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            LockoutState()
        }
    }

    override suspend fun save(state: LockoutState) {
        val wrapped = keys.wrapKey("${state.failedAttempts}|${state.lockedUntilMs}".toByteArray(Charsets.UTF_8))
        store.edit { it[key] = Base64.getEncoder().encodeToString(wrapped) }
    }
}

/** Master password wrapped by the Keystore key; used only for the biometric "quick unlock" path. */
interface BiometricCredentialStore {
    suspend fun exists(): Boolean
    suspend fun save(password: CharArray)
    suspend fun load(): CharArray?
    suspend fun clear()
}

class WrappedBiometricCredentialStore(
    private val store: DataStore<Preferences>,
    private val keys: MasterKeyManager
) : BiometricCredentialStore {
    private val key = stringPreferencesKey("biometric_credential_v1")

    override suspend fun exists(): Boolean = store.data.first()[key] != null

    override suspend fun save(password: CharArray) {
        val bytes = Charsets.UTF_8.encode(java.nio.CharBuffer.wrap(password)).let { b ->
            ByteArray(b.remaining()).also { b.get(it) }
        }
        try {
            val wrapped = keys.wrapKey(bytes)
            store.edit { it[key] = Base64.getEncoder().encodeToString(wrapped) }
        } finally {
            bytes.fill(0)
        }
    }

    override suspend fun load(): CharArray? {
        val raw = store.data.first()[key] ?: return null
        return try {
            val bytes = keys.unwrapKey(Base64.getDecoder().decode(raw))
            val chars = Charsets.UTF_8.decode(ByteBuffer.wrap(bytes))
            val out = CharArray(chars.remaining())
            chars.get(out)
            bytes.fill(0)
            out
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun clear() {
        store.edit { it.remove(key) }
    }
}

/** A short PIN used to authorize sensitive local actions such as secure sharing when biometric auth is unavailable. */
interface SensitiveActionPinStore {
    suspend fun isConfigured(): Boolean
    suspend fun save(pin: CharArray)
    suspend fun verify(pin: CharArray): Boolean
    suspend fun clear()
}

class EncryptedSensitiveActionPinStore(
    private val store: DataStore<Preferences>,
    private val keys: MasterKeyManager,
    keyName: String = "sensitive_action_pin_v1",
    legacyKeyNames: List<String> = emptyList()
) : SensitiveActionPinStore {
    private val key = stringPreferencesKey(keyName)
    private val legacyKeys = legacyKeyNames.map { stringPreferencesKey(it) }

    override suspend fun isConfigured(): Boolean {
        val prefs = store.data.first()
        return prefs[key] != null || legacyKeys.any { prefs[it] != null }
    }

    override suspend fun save(pin: CharArray) {
        require(pin.size in 4..6 && pin.all { it.isDigit() }) { "PIN must contain 4-6 digits" }
        val wrapped = keys.wrapKey(pin.concatToString().toByteArray(Charsets.UTF_8))
        store.edit { prefs ->
            prefs[key] = Base64.getEncoder().encodeToString(wrapped)
            legacyKeys.forEach { prefs.remove(it) }
        }
    }

    override suspend fun verify(pin: CharArray): Boolean {
        if (pin.size !in 4..6 || !pin.all { it.isDigit() }) return false
        val prefs = store.data.first()
        val primary = prefs[key]
        if (primary != null) return matches(primary, pin)
        // Older builds kept a separate hidden-vault PIN. Accept it once and move it to the unified PIN.
        for (legacy in legacyKeys) {
            val raw = prefs[legacy] ?: continue
            if (matches(raw, pin)) {
                save(pin)
                return true
            }
        }
        return false
    }

    private suspend fun matches(raw: String, pin: CharArray): Boolean {
        return try {
            val bytes = keys.unwrapKey(Base64.getDecoder().decode(raw))
            try {
                MessageDigestCompat.constantTimeEquals(
                    bytes,
                    pin.concatToString().toByteArray(Charsets.UTF_8)
                )
            } finally {
                bytes.fill(0)
            }
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (_: Exception) {
            false
        }
    }

    override suspend fun clear() {
        store.edit { prefs ->
            prefs.remove(key)
            legacyKeys.forEach { prefs.remove(it) }
        }
    }
}

private object MessageDigestCompat {
    fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean =
        java.security.MessageDigest.isEqual(a, b)
}
