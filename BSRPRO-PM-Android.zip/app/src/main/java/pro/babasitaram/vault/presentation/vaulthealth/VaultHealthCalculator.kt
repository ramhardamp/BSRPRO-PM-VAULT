package pro.babasitaram.vault.presentation.vaulthealth

import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.UrlUtils

data class HealthAnalysis(
    val total: Int,
    val weakPasswords: List<VaultEntry>,
    val reusedPasswords: List<VaultEntry>,
    val duplicateLogins: List<VaultEntry>,
    val missingUsernames: List<VaultEntry>,
    val oldPasswords: List<VaultEntry>,
    val uniqueIssueCount: Int,
    val score: Int
)

object VaultHealthCalculator {
    fun calculate(values: List<VaultEntry>, now: Long): HealthAnalysis {
        val entries = values.filter { it.deletedAt == 0L }
        val ageCutoff = now - 90L * 24L * 60L * 60L * 1000L
        val passwordGroups = entries.asSequence().filter { it.password.isNotBlank() }.groupBy { it.password }
        val reused = passwordGroups.values.filter { it.size > 1 }.flatten().distinctBy { it.id }
        val loginGroups = entries.mapNotNull { entry ->
            val domain = UrlUtils.domainOf(entry.url)
            if (entry.username.isBlank() || domain.isBlank()) null else entry to "${domain.lowercase()}|${entry.username.lowercase()}"
        }.groupBy({ it.second }, { it.first })
        val duplicate = loginGroups.values.filter { it.size > 1 }.flatten().distinctBy { it.id }
        val weak = entries.filter { it.password.isNotBlank() && PasswordStrength.score(it.password) <= 2 }.distinctBy { it.id }
        val old = entries.filter { it.password.isNotBlank() && it.updatedAt > 0L && it.updatedAt < ageCutoff && it.recordType.equals("login", true) }.distinctBy { it.id }
        val missing = entries.filter { it.username.isBlank() && it.recordType.equals("login", true) }.distinctBy { it.id }
        val unique = (weak.asSequence() + reused.asSequence() + duplicate.asSequence() + old.asSequence() + missing.asSequence()).map { it.id }.toSet().size
        val penalty = minOf(40, weak.size * 8) + minOf(30, reused.size * 6) + minOf(15, duplicate.size * 3) + minOf(10, old.size * 2) + minOf(5, missing.size)
        return HealthAnalysis(entries.size, weak, reused, duplicate, missing, old, unique, (100 - penalty).coerceIn(0, 100))
    }
}
