package pro.babasitaram.vault.presentation.navigation

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.outlined.Lock as OutlinedLock
import androidx.compose.material.icons.outlined.Pin as OutlinedPin
import androidx.compose.material.icons.outlined.Settings as OutlinedSettings
import androidx.compose.material3.HorizontalDivider
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import pro.babasitaram.vault.R
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.ContactEmergency
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Folder
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Key
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.DisposableEffect
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.navigation.NavType
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.backup.BackupScreen
import pro.babasitaram.vault.presentation.activitylog.ActivityLogScreen
import pro.babasitaram.vault.presentation.bin.BinScreen
import pro.babasitaram.vault.presentation.editor.EntryEditorScreen
import pro.babasitaram.vault.presentation.emergency.EmergencyScreen
import pro.babasitaram.vault.presentation.files.FilesScreen
import pro.babasitaram.vault.presentation.files.FileDetailScreen
import pro.babasitaram.vault.presentation.generator.GeneratorScreen
import pro.babasitaram.vault.presentation.help.HelpScreen
import pro.babasitaram.vault.presentation.history.HistoryScreen
import pro.babasitaram.vault.presentation.mobiles.MobilesScreen
import pro.babasitaram.vault.presentation.mobiles.MobileEditorScreen
import pro.babasitaram.vault.presentation.notes.NotesScreen
import pro.babasitaram.vault.presentation.notes.NoteEditorScreen
import pro.babasitaram.vault.presentation.settings.SettingsScreen
import pro.babasitaram.vault.presentation.sharing.SharingScreen
import pro.babasitaram.vault.presentation.supportdeveloper.SupportDeveloperScreen
import pro.babasitaram.vault.presentation.totpmanager.TotpManagerScreen
import pro.babasitaram.vault.presentation.totpmanager.TotpDetailScreen
import pro.babasitaram.vault.presentation.totpmanager.TotpEditorScreen
import pro.babasitaram.vault.presentation.vault.EntryDetailScreen
import pro.babasitaram.vault.presentation.vault.VaultListScreen
import pro.babasitaram.vault.presentation.vaulthealth.VaultHealthScreen
import androidx.compose.ui.res.stringResource

object Routes {
    const val LIST = "list"
    const val DETAIL = "detail/{id}"
    const val EDIT = "edit?id={id}&type={type}"
    const val TYPE_CHOOSER = "entry-type"
    const val NOTE_EDIT = "note-edit?id={id}"
    const val MOBILE_EDIT = "mobile-edit?id={id}"
    const val TOTP_DETAIL = "totp-detail/{id}"
    const val TOTP_EDIT = "totp-edit?id={id}"
    const val GENERATOR = "generator"
    const val SETTINGS = "settings"
    const val BACKUP = "backup"
    const val TOTP = "totp"
    const val HEALTH = "health"
    const val BIN = "bin"
    const val NOTES = "notes"
    const val FILES = "files"
    const val FILE_DETAIL = "files-detail/{id}"
    const val MOBILES = "mobiles"
    const val HISTORY = "history"
    const val HELP = "help"
    const val SHARING = "sharing"
    const val SUPPORT = "support"
    const val EMERGENCY = "emergency"
    const val ACTIVITY_LOG = "activity-log"
    const val ABOUT = "about"
    const val CONTACTS_IMPORT = "contacts-import"
    const val HIDDEN = "hidden-vault"

    fun detail(id: String) = "detail/${Uri.encode(id)}"
    fun edit(id: String? = null, type: String? = null): String {
        val q = buildList {
            if (id != null) add("id=${Uri.encode(id)}")
            if (type != null) add("type=${Uri.encode(type)}")
        }
        return if (q.isEmpty()) "edit" else "edit?" + q.joinToString("&")
    }
    fun noteEdit(id: String? = null) = if (id == null) "note-edit" else "note-edit?id=${Uri.encode(id)}"
    fun totpDetail(id: String) = "totp-detail/${Uri.encode(id)}"
    fun totpEdit(id: String? = null) = if (id == null) "totp-edit" else "totp-edit?id=${Uri.encode(id)}"
    fun mobileEdit(id: String? = null) = if (id == null) "mobile-edit" else "mobile-edit?id=${Uri.encode(id)}"
    fun fileDetail(id: String) = "files-detail/${Uri.encode(id)}"
}

private data class DrawerDestination(
    val route: String,
    @androidx.annotation.StringRes val label: Int,
    val icon: @Composable () -> Unit
)

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun VaultNavHost() {
    val nav = rememberNavController()
    val saveRouter: SaveRouterViewModel = hiltViewModel()
    val drawerCountsVm: DrawerCountsViewModel = hiltViewModel()
    val counts by drawerCountsVm.counts.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val current by nav.currentBackStackEntryAsState()
    val route = current?.destination?.route ?: Routes.LIST

    DisposableEffect(nav) {
        onDispose {
            runCatching { nav.popBackStack(Routes.LIST, inclusive = true) }
        }
    }

    LifecycleResumeEffect(Unit) {
        saveRouter.nextRoute()?.let { pendingRoute -> nav.navigate(pendingRoute) }
        onPauseOrDispose { }
    }

    // Spec: 4 tabs - Vault / TOTP / Health / Settings (Generator + Mobiles live in the side drawer).
    val bottomItems = remember {
        listOf(
            Routes.LIST to R.string.nav_vault,
            Routes.TOTP to R.string.nav_totp,
            Routes.HEALTH to R.string.nav_health,
            Routes.SETTINGS to R.string.nav_settings
        )
    }

    // Drawer order follows the spec; three groups are separated by dividers.
    val drawerMain = remember {
        listOf(
            DrawerDestination(Routes.LIST, R.string.drawer_vault) {
                androidx.compose.foundation.Image(
                    painter = painterResource(R.drawable.brand_logo),
                    contentDescription = null,
                    modifier = Modifier.width(32.dp).height(32.dp).clip(MaterialTheme.shapes.small),
                    contentScale = ContentScale.Crop
                )
            },
            DrawerDestination(Routes.TOTP, R.string.drawer_totp) { Icon(Icons.Default.Pin, null) },
            DrawerDestination(Routes.HEALTH, R.string.drawer_health) { Icon(Icons.Default.FavoriteBorder, null) },
            DrawerDestination(Routes.GENERATOR, R.string.drawer_generator) { Icon(Icons.Default.Casino, null) },
            DrawerDestination(Routes.NOTES, R.string.drawer_notes) { Icon(Icons.Default.Note, null) },
            DrawerDestination(Routes.ACTIVITY_LOG, R.string.drawer_activity) { Icon(Icons.Default.History, null) },
            DrawerDestination(Routes.FILES, R.string.drawer_files) { Icon(Icons.Default.Folder, null) },
            DrawerDestination(Routes.MOBILES, R.string.drawer_mobiles) { Icon(Icons.Default.PhoneAndroid, null) },
            DrawerDestination(Routes.BACKUP, R.string.drawer_backup) { Icon(Icons.Default.SwapVert, null) },
            DrawerDestination(Routes.BIN, R.string.drawer_bin) { Icon(Icons.Default.DeleteOutline, null) },
            DrawerDestination(Routes.EMERGENCY, R.string.drawer_emergency) { Icon(Icons.Default.ContactEmergency, null) },
            DrawerDestination(Routes.SHARING, R.string.drawer_sharing) { Icon(Icons.Default.Share, null) },
            DrawerDestination(Routes.HIDDEN, R.string.hidden_vault) { Icon(Icons.Default.VisibilityOff, null) }
        )
    }
    val drawerSecondary = remember {
        listOf(
            DrawerDestination(Routes.SETTINGS, R.string.drawer_settings) { Icon(Icons.Default.Settings, null) },
            DrawerDestination(Routes.HELP, R.string.drawer_help) { Icon(Icons.Default.HelpOutline, null) },
            DrawerDestination(Routes.SUPPORT, R.string.drawer_support) { Icon(Icons.Default.LocalCafe, null) },
            DrawerDestination(Routes.ABOUT, R.string.drawer_about) { Icon(Icons.Default.Info, null) }
        )
    }

    BackHandler(enabled = route != Routes.LIST || drawerState.isOpen) {
        if (drawerState.isOpen) scope.launch { drawerState.close() } else nav.popBackStack()
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = true,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.width(280.dp)) {
                // Stable drawer: all destinations stay visible without vertical scrolling.
                androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.foundation.Image(
                            painter = painterResource(R.drawable.brand_logo),
                            contentDescription = null,
                            modifier = Modifier.width(38.dp).height(38.dp).clip(MaterialTheme.shapes.small),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(Modifier.width(10.dp))
                        androidx.compose.foundation.layout.Column {
                            Text(
                                stringResource(R.string.app_name),
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                "PRO \u00b7 v${pro.babasitaram.vault.BuildConfig.VERSION_NAME}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
                    val onDrawerItem: (DrawerDestination) -> Unit = { destination ->
                        scope.launch { drawerState.close() }
                        if (destination.route == Routes.LIST) {
                            if (!nav.popBackStack(Routes.LIST, inclusive = false)) {
                                nav.navigate(Routes.LIST) { launchSingleTop = true }
                            }
                        } else {
                            nav.navigate(destination.route) { launchSingleTop = true }
                        }
                    }
                    drawerMain.forEach { destination ->
                        NavigationDrawerItem(
                            icon = destination.icon,
                            label = { Text(androidx.compose.ui.res.stringResource(destination.label)) },
                            badge = {
                                drawerBadgeText(counts.forRoute(destination.route))?.let { badge ->
                                    Text(badge, style = MaterialTheme.typography.labelMedium)
                                }
                            },
                            selected = route == destination.route,
                            onClick = { onDrawerItem(destination) },
                            modifier = Modifier.padding(horizontal = AppDimens.ScreenHorizontal).height(43.dp)
                        )
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                    drawerSecondary.forEach { destination ->
                        NavigationDrawerItem(
                            icon = destination.icon,
                            label = { Text(androidx.compose.ui.res.stringResource(destination.label)) },
                            selected = route == destination.route,
                            onClick = { onDrawerItem(destination) },
                            modifier = Modifier.padding(horizontal = AppDimens.ScreenHorizontal).height(43.dp)
                        )
                    }
                    HorizontalDivider(Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Lock, null) },
                        label = { Text(stringResource(R.string.drawer_lock_now)) },
                        selected = false,
                        onClick = {
                            scope.launch { drawerState.close() }
                            drawerCountsVm.lockNow()
                        },
                        modifier = Modifier.padding(horizontal = AppDimens.ScreenHorizontal, vertical = 2.dp).height(43.dp)
                    )
                }
            }
        }
    ) {
        Scaffold(
            bottomBar = {
                NavigationBar {
                    bottomItems.forEach { (destination, label) ->
                        NavigationBarItem(
                            selected = route == destination,
                            onClick = {
                                if (destination == Routes.LIST) {
                                    // Always land on the Vault list itself (not a restored detail/edit screen).
                                    val popped = nav.popBackStack(Routes.LIST, inclusive = false)
                                    if (!popped) {
                                        nav.navigate(Routes.LIST) {
                                            popUpTo(nav.graph.findStartDestination().id) { inclusive = false }
                                            launchSingleTop = true
                                        }
                                    }
                                } else {
                                    nav.navigate(destination) {
                                        popUpTo(nav.graph.findStartDestination().id) { inclusive = false }
                                        launchSingleTop = true
                                    }
                                }
                            },
                            icon = {
                                val active = route == destination
                                when (destination) {
                                    Routes.LIST -> Icon(if (active) Icons.Default.LockOpen else Icons.Outlined.OutlinedLock, contentDescription = null)
                                    Routes.TOTP -> Icon(if (active) Icons.Default.Pin else Icons.Outlined.OutlinedPin, contentDescription = null)
                                    Routes.HEALTH -> Icon(if (active) Icons.Default.Favorite else Icons.Default.FavoriteBorder, contentDescription = null)
                                    Routes.SETTINGS -> Icon(if (active) Icons.Default.Settings else Icons.Outlined.OutlinedSettings, contentDescription = null)
                                    else -> Icon(Icons.Default.Lock, contentDescription = null)
                                }
                            },
                            label = { Text(androidx.compose.ui.res.stringResource(label)) }
                        )
                    }
                }
            },
            floatingActionButton = {
                if (route == Routes.LIST) {
                    androidx.compose.material3.FloatingActionButton(
                        onClick = { nav.navigate(Routes.TYPE_CHOOSER) }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_add_entry))
                    }
                }
            }
        ) { innerPadding ->
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                NavHost(
                    navController = nav,
                    startDestination = Routes.LIST
                ) {
                    composable(Routes.LIST) {
                        VaultListScreen(
                            onOpen = { entryId -> nav.navigate(Routes.detail(entryId)) },
                            onOpenDrawer = { scope.launch { drawerState.open() } },
                            onShare = { id -> nav.navigate("${Routes.SHARING}?id=${Uri.encode(id)}") },
                            onShareSelected = { ids ->
                                val encoded = Uri.encode(ids.joinToString(","))
                                nav.navigate("${Routes.SHARING}?ids=$encoded")
                            }
                        )
                    }
                    composable(
                        route = Routes.DETAIL,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) {
                        EntryDetailScreen(
                            onBack = { nav.popBackStack() },
                            onEdit = { entry ->
                                when {
                                    entry.isNote || entry.recordType.equals("note", true) -> nav.navigate(Routes.noteEdit(entry.id))
                                    entry.recordType.equals("mobile", true) -> nav.navigate(Routes.mobileEdit(entry.id))
                                    entry.recordType.equals("totp", true) -> nav.navigate(Routes.totpEdit(entry.id))
                                    else -> nav.navigate(Routes.edit(entry.id))
                                }
                            },
                            onShare = { entryId -> nav.navigate("${Routes.SHARING}?id=${Uri.encode(entryId)}") }
                        )
                    }
                    composable(
                        route = Routes.EDIT,
                        arguments = listOf(
                            navArgument("id") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            },
                            navArgument("type") {
                                type = NavType.StringType
                                nullable = true
                                defaultValue = null
                            }
                        )
                    ) {
                        EntryEditorScreen(onDone = { nav.popBackStack() })
                    }
                    composable(
                        route = Routes.NOTE_EDIT,
                        arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
                    ) { NoteEditorScreen(onDone = { nav.popBackStack() }) }
                    composable(
                        route = Routes.MOBILE_EDIT,
                        arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
                    ) { MobileEditorScreen(onDone = { nav.popBackStack() }) }
                    composable(Routes.GENERATOR) { GeneratorScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.SETTINGS) {
                        SettingsScreen(
                            onBack = { nav.popBackStack() },
                            onOpenBackup = { nav.navigate(Routes.BACKUP) },
                            onOpenBackupTarget = { target ->
                                if (target == pro.babasitaram.vault.presentation.backup.BackupTarget.CONTACTS) nav.navigate(Routes.CONTACTS_IMPORT)
                                else { pro.babasitaram.vault.presentation.backup.BackupDeepLink.set(target); nav.navigate(Routes.BACKUP) }
                            },
                            onOpenActivityLog = { nav.navigate(Routes.ACTIVITY_LOG) },
                            onOpenHidden = { nav.navigate(Routes.HIDDEN) }
                        )
                    }
                    composable(Routes.BACKUP) { BackupScreen(onBack = { nav.popBackStack() }, onImportContacts = { nav.navigate(Routes.CONTACTS_IMPORT) }) }
                    composable(Routes.HIDDEN) { pro.babasitaram.vault.presentation.hidden.HiddenVaultScreen(onBack = { nav.popBackStack() }, onOpenEntry = { id -> nav.navigate(Routes.detail(id)) }) }
                    composable(Routes.CONTACTS_IMPORT) { pro.babasitaram.vault.presentation.contacts.ContactsImportScreen(onBack = { nav.popBackStack() }) }
                    composable(
                        route = Routes.TOTP_DETAIL,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) { TotpDetailScreen(onBack = { nav.popBackStack() }, onEdit = { id -> nav.navigate(Routes.totpEdit(id)) }) }
                    composable(
                        route = Routes.TOTP_EDIT,
                        arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null })
                    ) { TotpEditorScreen(onDone = { nav.popBackStack() }) }
                    composable(Routes.TOTP) { TotpManagerScreen(onBack = { nav.popBackStack() }, onAdd = { nav.navigate(Routes.totpEdit()) }, onOpen = { id -> nav.navigate(Routes.totpDetail(id)) }) }
                    composable(Routes.HEALTH) { VaultHealthScreen(onBack = { nav.popBackStack() }, onOpenEntry = { id -> nav.navigate(Routes.detail(id)) }) }
                    composable(Routes.BIN) { BinScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.NOTES) { NotesScreen(onBack = { nav.popBackStack() }, onAdd = { nav.navigate(Routes.noteEdit()) }, onOpen = { id -> nav.navigate(Routes.detail(id)) }) }
                    composable(Routes.FILES) { FilesScreen(onBack = { nav.popBackStack() }, onOpen = { id -> nav.navigate(Routes.fileDetail(id)) }) }
                    composable(
                        Routes.FILE_DETAIL,
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) { FileDetailScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.MOBILES) { MobilesScreen(onBack = { nav.popBackStack() }, onImportContacts = { nav.navigate(Routes.CONTACTS_IMPORT) }, onAdd = { nav.navigate(Routes.mobileEdit()) }, onOpen = { id -> nav.navigate(Routes.detail(id)) }, onShareSelected = { ids ->
                        val encoded = Uri.encode(ids.joinToString(","))
                        nav.navigate("${Routes.SHARING}?ids=$encoded")
                    }) }
                    composable(Routes.HISTORY) { HistoryScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.HELP) { HelpScreen(onBack = { nav.popBackStack() }) }
                    composable(
                        "${Routes.SHARING}?id={id}&ids={ids}",
                        arguments = listOf(
                            navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null },
                            navArgument("ids") { type = NavType.StringType; nullable = true; defaultValue = null }
                        )
                    ) { backStackEntry ->
                        val ids = backStackEntry.arguments?.getString("ids")
                            ?.split(',')
                            ?.filter { it.isNotBlank() }
                            .orEmpty()
                        SharingScreen(onBack = { nav.popBackStack() }, initialEntryIds = ids)
                    }
                    composable(Routes.TYPE_CHOOSER) {
                        pro.babasitaram.vault.presentation.editor.EntryTypeChooserScreen(
                            onBack = { nav.popBackStack() },
                            onPick = { picked ->
                                val target = when (picked) {
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.PASSWORD -> Routes.edit(type = "login")
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.CARD -> Routes.edit(type = "card")
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.IDENTITY -> Routes.edit(type = "identity")
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.APP_LOGIN -> Routes.edit(type = "app")
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.NOTE -> Routes.noteEdit()
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.TOTP -> Routes.totpEdit()
                                    pro.babasitaram.vault.presentation.editor.NewEntryType.MOBILE -> Routes.mobileEdit()
                                }
                                nav.navigate(target) { popUpTo(Routes.TYPE_CHOOSER) { inclusive = true } }
                            }
                        )
                    }
                    composable(Routes.ABOUT) { pro.babasitaram.vault.presentation.about.AboutScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.SUPPORT) { SupportDeveloperScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.EMERGENCY) { EmergencyScreen(onBack = { nav.popBackStack() }) }
                    composable(Routes.ACTIVITY_LOG) { ActivityLogScreen(onBack = { nav.popBackStack() }) }
                }
            }
        }
    }
}
