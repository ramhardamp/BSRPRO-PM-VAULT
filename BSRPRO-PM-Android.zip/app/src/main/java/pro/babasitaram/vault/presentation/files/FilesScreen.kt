@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.files

import pro.babasitaram.vault.R

import android.net.Uri
import androidx.compose.ui.res.stringResource
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens

@Composable
fun FilesScreen(onBack: () -> Unit = {}, onOpen: (String) -> Unit = {}, vm: FilesViewModel = hiltViewModel()) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let(vm::importFile) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.p15_files), style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { picker.launch(arrayOf(context.getString(pro.babasitaram.vault.R.string.p17_loc_119))) }, icon = { Icon(Icons.Default.Add, null) }, text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_120)) }) }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(
                stringResource(R.string.p15_no_files),
                stringResource(R.string.files_empty_message),
                Modifier.padding(padding).fillMaxWidth(),
                actionLabel = stringResource(R.string.files_upload),
                onAction = { picker.launch(arrayOf("*/*")) }
            )
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(AppDimens.ScreenHorizontal), verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)) {
                items(
                    items = entries,
                    key = { entry: VaultEntry -> entry.id },
                    contentType = { _: VaultEntry -> "item" }
                ) { entry -> FileItem(entry, context, onOpen = { onOpen(entry.id) }) }
            }
        }
    }
}

@Composable
private fun FileItem(
    entry: VaultEntry,
    context: android.content.Context,
    onOpen: () -> Unit
) {
    val primaryUriField = entry.customFields.firstOrNull {
        it.k.equals("file_uri", true) || it.k.startsWith("attachment_uri_", true)
    }
    val suffix = primaryUriField?.k?.removePrefix("attachment_uri_")
    val name = entry.fileField("file_name").orEmpty().ifBlank {
        entry.customFields.firstOrNull { it.k.equals("attachment_name_$suffix", true) }?.v.orEmpty()
    }.ifBlank { entry.title }
    val mime = entry.fileField("mime_type").orEmpty().ifBlank {
        entry.customFields.firstOrNull { it.k.equals("attachment_mime_$suffix", true) }?.v.orEmpty()
    }.ifBlank { "application/octet-stream" }
    val size = entry.fileField("file_size")?.toLongOrNull() ?: primaryUriField?.let {
        context.contentResolver.query(
            Uri.parse(it.v),
            arrayOf(OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && !c.isNull(i)) c.getLong(i) else 0L
            } else 0L
        }
    } ?: 0L

    Card(Modifier.fillMaxWidth().clickable(onClick = onOpen)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(name.ifBlank { "File" }, style = MaterialTheme.typography.titleMedium)
            Text(mime, style = MaterialTheme.typography.bodySmall)
            Text(formatSize(size), style = MaterialTheme.typography.bodySmall)
        }
    }
}


private fun formatSize(size: Long): String = when {
    size <= 0L -> "0 B"
    size < 1024L -> "$size B"
    size < 1024L * 1024L -> "%.1f KB".format(size / 1024f)
    size < 1024L * 1024L * 1024L -> "%.1f MB".format(size / (1024f * 1024f))
    else -> "%.1f GB".format(size / (1024f * 1024f * 1024f))
}
