package pro.babasitaram.vault.data.repository

import pro.babasitaram.vault.core.security.LockoutState
import pro.babasitaram.vault.core.security.RateLimiter
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.data.local.preferences.BiometricCredentialStore
import pro.babasitaram.vault.domain.repository.AuthRepository

class AuthRepositoryImpl(
    private val blobStore: VaultBlobStore,
    private val rateLimiter: RateLimiter,
    private val credentials: BiometricCredentialStore
) : AuthRepository {
    override suspend fun vaultExists() = blobStore.exists()
    override suspend fun lockoutState() = rateLimiter.state()
    override fun remainingAttempts(state: LockoutState) = rateLimiter.remainingAttempts(state)
    override suspend fun checkAllowed() = rateLimiter.check()
    override suspend fun recordFailure() = rateLimiter.recordFailure()
    override suspend fun recordSuccess() = rateLimiter.recordSuccess()
    override suspend fun hasBiometricCredential() = credentials.exists()
    override suspend fun saveBiometricCredential(password: CharArray) = credentials.save(password)
    override suspend fun loadBiometricCredential() = credentials.load()
    override suspend fun clearBiometricCredential() = credentials.clear()
}
