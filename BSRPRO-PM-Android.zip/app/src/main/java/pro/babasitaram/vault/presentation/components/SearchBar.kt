package pro.babasitaram.vault.presentation.components
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.R
@Composable fun SearchBar(value: String, onValueChange: (String)->Unit, modifier: Modifier = Modifier) { OutlinedTextField(value,onValueChange,modifier=modifier,placeholder={Text(stringResource(R.string.search_vault))},singleLine=true,shape=RoundedCornerShape(50)) }
