package pro.babasitaram.vault.presentation.navigation

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.launch
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.autofill.PendingSaveStore
import pro.babasitaram.vault.autofill.SaveNotifier
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.presentation.util.launchCatching
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

/** Decides where a login captured by the autofill save flow should go: new entry, update, or nowhere. */
@HiltViewModel
class SaveRouterViewModel @Inject constructor(
    private val store: PendingSaveStore,
    private val repository: VaultRepository,
    private val settings: SettingsRepository,
    private val autoBackup: AutoBackupManager,
    @ApplicationContext private val context: Context
) : ViewModel() {

    init {
        // created each time the vault is unlocked: keep the daily job scheduled and catch up a missed backup
        launchCatching {
            val imported = autoBackup.autoImportIfVaultEmpty()
            if (imported > 0) Toast.makeText(context, L.s(R.string.p18_save_router_restored_records_from_your_backup, imported), Toast.LENGTH_LONG).show()
            val hadPending = autoBackup.hasPendingBackup()
            if (settings.current().autoBackupEnabled) autoBackup.schedule()
            val completed = autoBackup.runPendingOrDue()
            if (hadPending) {
                val message = if (completed) "Pending backup completed" else "Pending backup will retry; keep your vault data intact"
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Returns a route to open the editor, or null when nothing is pending / nothing changed. */
    fun nextRoute(): String? {
        val p = store.peek() ?: return null
        SaveNotifier.cancel(context)
        val dup = repository.findDuplicate(p.toCandidate())
        if (dup != null && dup.password == p.password && dup.appPin == p.appPin) {
            store.clear()          // already saved with this exact password
            return null
        }
        store.attach(dup?.id)
        return if (dup != null) Routes.edit(dup.id) else Routes.edit()
    }
}
