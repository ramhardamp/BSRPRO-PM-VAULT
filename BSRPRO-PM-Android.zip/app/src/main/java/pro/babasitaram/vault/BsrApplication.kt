package pro.babasitaram.vault

import android.app.Application
import pro.babasitaram.vault.core.model.ThemeMode
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject
import pro.babasitaram.vault.autofill.AutofillSessionGate
import pro.babasitaram.vault.core.security.AppIconApplier
import pro.babasitaram.vault.core.security.AutoLockController
import timber.log.Timber

@HiltAndroidApp
class BsrApplication : Application() {

    @Inject
    lateinit var autoLock: AutoLockController

    @Inject
    lateinit var iconApplier: AppIconApplier

    // Eager init: gate vault unlock/lock ko app start se hi observe kare (autofill ke pehle request ka intezaar na kare)
    @Inject
    lateinit var autofillGate: AutofillSessionGate

    override fun onCreate() {
        super.onCreate()
        pro.babasitaram.vault.core.util.L.init(this)
        // Fast synchronous snapshot only; DataStore remains canonical.
        val cachedName = getSharedPreferences("bsrpro_prefs", MODE_PRIVATE)
            .getString("cached_theme", ThemeMode.DARK.name)
        AppThemeCache.update(
            ThemeMode.values().firstOrNull { it.name == cachedName } ?: ThemeMode.DARK
        )
        // Debug-only logging. A redacting release tree is added in Phase 10.
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())
        pro.babasitaram.vault.autofill.AutofillDiagnostics.logcatEnabled = BuildConfig.DEBUG

        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) = autoLock.onForegrounded()
            override fun onStop(owner: LifecycleOwner) {
                autoLock.onBackgrounded()
                iconApplier.applyWhenBackgrounded()
            }
        })
    }
}
