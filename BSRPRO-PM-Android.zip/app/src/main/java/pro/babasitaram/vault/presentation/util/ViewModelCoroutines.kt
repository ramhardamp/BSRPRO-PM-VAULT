// file: app/src/main/java/pro/babasitaram/vault/presentation/util/ViewModelCoroutines.kt
package pro.babasitaram.vault.presentation.util

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import timber.log.Timber

/**
 * Runs a ViewModel coroutine with cancellation preserved and a non-fatal error boundary.
 * Sensitive payloads are deliberately never included in logs.
 */
fun ViewModel.launchCatching(block: suspend CoroutineScope.() -> Unit): Job = viewModelScope.launch {
    try {
        block()
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (error: Throwable) {
        Timber.w(error, "%s coroutine failed", this@launchCatching::class.java.simpleName)
    }
}
