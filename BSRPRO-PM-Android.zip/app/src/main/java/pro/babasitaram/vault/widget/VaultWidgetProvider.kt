package pro.babasitaram.vault.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import pro.babasitaram.vault.MainActivity
import pro.babasitaram.vault.R
import dagger.hilt.EntryPoint
import dagger.hilt.InstallIn
import dagger.hilt.android.EntryPointAccessors
import dagger.hilt.components.SingletonComponent
import pro.babasitaram.vault.core.crypto.SessionKeyStore

class VaultWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        val entryPoint = EntryPointAccessors.fromApplication(
            context.applicationContext,
            WidgetEntryPoint::class.java
        )
        val unlocked = entryPoint.session().isUnlocked.value

        val intent = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
        val pi = PendingIntent.getActivity(
            context,
            1301,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        ids.forEach { id ->
            val views = RemoteViews(context.packageName, R.layout.widget_vault).apply {
                setTextViewText(R.id.widget_title, "BSRPRO Vault")
                setTextViewText(R.id.widget_status, if (unlocked) "Vault unlocked" else "Vault locked")
                setOnClickPendingIntent(R.id.widget_root, pi)
            }
            manager.updateAppWidget(id, views)
        }
    }

    companion object {
        fun requestUpdate(context: Context) {
            val intent = Intent(context, VaultWidgetProvider::class.java).apply { action = AppWidgetManager.ACTION_APPWIDGET_UPDATE }
            context.sendBroadcast(intent)
        }
    }
}


@EntryPoint
@InstallIn(SingletonComponent::class)
interface WidgetEntryPoint {
    fun session(): SessionKeyStore
}
