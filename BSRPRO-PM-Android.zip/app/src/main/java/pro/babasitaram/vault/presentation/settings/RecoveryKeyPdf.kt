package pro.babasitaram.vault.presentation.settings

import android.content.Context
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor

object RecoveryKeyPdf {
    fun write(context: Context, uri: Uri, key: String) {
        val document = PdfDocument()
        try {
            val page = document.startPage(
                PdfDocument.PageInfo.Builder(612, 792, 1).create()
            )
            val canvas = page.canvas
            val title = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 24f
                isFakeBoldText = true
            }
            val body = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = 16f
            }
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_recovery_title), 48f, 72f, title)
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_keep_private), 48f, 120f, body)
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_reset_password), 48f, 148f, body)
            canvas.drawText(key.chunked(4).joinToString(" "), 48f, 220f, title)
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_generated_by), 48f, 700f, body)
            document.finishPage(page)
            context.contentResolver.openOutputStream(uri, "w")?.use { output ->
                document.writeTo(output)
            } ?: throw java.io.IOException("Could not open PDF destination")
        } finally {
            document.close()
        }
    }
}


class RecoveryKeyPrintAdapter(private val context: Context, private val key: String) : PrintDocumentAdapter() {
    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: android.os.Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        callback.onLayoutFinished(
            PrintDocumentInfo.Builder("BSRPRO-Recovery-Key.pdf")
                .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                .setPageCount(1)
                .build(),
            true
        )
    }

    override fun onWrite(
        pages: Array<out android.print.PageRange>,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal,
        callback: WriteResultCallback
    ) {
        if (cancellationSignal.isCanceled) {
            callback.onWriteCancelled()
            return
        }
        try {
            val document = PdfDocument()
            val page = document.startPage(PdfDocument.PageInfo.Builder(612, 792, 1).create())
            val canvas = page.canvas
            val title = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 24f; isFakeBoldText = true }
            val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 16f }
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_recovery_title), 48f, 72f, title)
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_keep_private), 48f, 120f, body)
            canvas.drawText(context.getString(pro.babasitaram.vault.R.string.p17_pdf_reset_password), 48f, 148f, body)
            canvas.drawText(key.chunked(4).joinToString(" "), 48f, 220f, title)
            document.finishPage(page)
            ParcelFileDescriptor.AutoCloseOutputStream(destination).use { output ->
                document.writeTo(output)
            }
            document.close()
            callback.onWriteFinished(arrayOf(android.print.PageRange.ALL_PAGES))
        } catch (e: Exception) {
            callback.onWriteFailed(e.message)
        }
    }
}

fun printRecoveryKey(context: Context, key: String) {
    val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
    printManager.print(
        "BSRPRO Recovery Key",
        RecoveryKeyPrintAdapter(context, key),
        PrintAttributes.Builder().build()
    )
}
