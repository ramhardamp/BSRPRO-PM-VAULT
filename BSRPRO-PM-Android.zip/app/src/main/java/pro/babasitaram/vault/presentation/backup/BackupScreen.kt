package pro.babasitaram.vault.presentation.backup

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.layout.size
import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import androidx.compose.ui.semantics.Role
import androidx.compose.material3.RadioButton
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.selectable
import pro.babasitaram.vault.presentation.components.PasswordField
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.CardDefaults
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import java.util.Locale
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.data.transfer.ExportKind
import pro.babasitaram.vault.data.transfer.ExportOptions
import pro.babasitaram.vault.data.transfer.ImportMode
import pro.babasitaram.vault.data.transfer.MapField
import pro.babasitaram.vault.core.util.L

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupScreen(onBack: () -> Unit, onImportContacts: () -> Unit = {}, vm: BackupViewModel = hiltViewModel()) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    LaunchedEffect(state.backupFolderUri) {
        if (state.backupFolderUri.isNotBlank()) vm.refreshBackupFile()
    }
    var saveMime by remember { mutableStateOf("application/octet-stream") }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> vm.onImportFile(uri) }
    val exportTarget = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? -> vm.onExportTarget(uri) }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }.onSuccess { vm.setBackupFolder(uri) }
                .onFailure { android.widget.Toast.makeText(context, context.getString(pro.babasitaram.vault.R.string.p17_folder_access_failed), android.widget.Toast.LENGTH_LONG).show() }
        }
    }

    LaunchedEffect(vm) {
        vm.events.collect { e ->
            when (e) {
                is BackupEvent.Message -> android.widget.Toast.makeText(context, e.text, android.widget.Toast.LENGTH_LONG).show()
                is BackupEvent.SaveFile -> { saveMime = e.mime; exportTarget.launch(e.fileName) }
            }
        }
    }

    // Settings se aaye deep-links ko preserve rakho, lekin har flow ka result isi main screen par render hota hai.
    val initialTarget = remember { BackupDeepLink.take() }
    var deepLinkHandled by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (deepLinkHandled) return@LaunchedEffect
        deepLinkHandled = true
        when (initialTarget) {
            BackupTarget.PICK_VAULT -> importPicker.launch(PICK_VAULT_TYPES)
            BackupTarget.PICK_CSV -> { vm.requestMappedImport(); importPicker.launch(PICK_CSV_TYPES) }
            BackupTarget.RESTORE -> vm.startFolderRestore()
            BackupTarget.EXPORT -> vm.openExportOptionsFor(ExportKind.VAULT)
            else -> Unit
        }
    }

    val review = state.importing as? ImportStage.Review
    val mapStage = state.importing as? ImportStage.MapFields
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (review != null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_review_import) else if (mapStage != null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_map_columns) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_import_title)) },
                navigationIcon = {
                    IconButton(onClick = { if (review != null || mapStage != null) vm.cancelImport() else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037))
                    }
                },
                actions = {
                    IconButton(onClick = vm::backupNow, enabled = !state.busy && restoreStageSafe(state)) {
                        Icon(Icons.Default.CloudUpload, contentDescription = stringResource(R.string.p18_backup_create))
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            if (state.busy && state.restoreStage == RestoreStage.Idle) CircularProgressIndicator(Modifier.padding(16.dp).align(Alignment.CenterHorizontally))
            when {
                review != null -> ReviewPane(review, vm)
                mapStage != null -> MapPane(mapStage, vm)
                else -> MainPane(
                    state, vm,
                    // Har import option ka apna file-type filter: .Vault (sab files), CSV (sirf csv/text), JSON (sirf json/text)
                    onPick = { importPicker.launch(PICK_VAULT_TYPES) },
                    onPickMapped = { vm.requestMappedImport(); importPicker.launch(PICK_CSV_TYPES) },
                    onPickJson = { importPicker.launch(PICK_JSON_TYPES) },
                    onContacts = onImportContacts,
                    onChooseBackupFolder = { backupFolderPicker.launch(null) }
                )
            }
        }
    }

    state.exportOptions?.let { o ->
        ExportOptionsDialog(o, onChange = vm::updateExportOptions, onContinue = vm::continueExport, onCancel = vm::dismissExportOptions)
    }
    state.exportProgress?.let { p ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_038)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (p.total > 0) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export_progress, p.done, p.total) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_preparing_export))
                    if (p.total > 0 && p.done < p.total) LinearProgressIndicator(progress = { p.done / p.total.toFloat() }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    if (p.total > 0 && p.done >= p.total) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_039), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelRunningExport) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    state.exportAsk?.takeIf { state.exportProgress == null }?.let { format ->
        val plain = state.activeExport?.isPlainText ?: format.plaintext
        PasswordDialog(
            title = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export_title, state.activeExport?.kind?.label ?: format.label),
            message = if (plain) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_plain_export_warning)
            else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_encrypted_export_prompt),
            confirmLabel = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export),
            error = state.exportError,
            busy = state.busy,
            onConfirm = vm::confirmExport,
            onCancel = vm::cancelExport
        )
    }
    state.smartBackupPassword?.let { smart ->
        AlertDialog(
            onDismissRequest = vm::dismissSmartBackupPassword,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_040)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_041))
                    OutlinedTextField(
                        value = smart,
                        onValueChange = {},
                        readOnly = true,
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(
                        onClick = {
                            vm.copySecret(smart, "Backup password")
                        }
                    ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_042)) }
                }
            },
            confirmButton = { TextButton(onClick = vm::dismissSmartBackupPassword) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_043)) } }
        )
    }

    if (state.restoreAsk) {
        BackupRestorePasswordDialog(
            busy = state.busy,
            error = state.restoreError,
            onConfirm = vm::confirmFolderRestore,
            onCancel = vm::cancelFolderRestore
        )
    }

    (state.importing as? ImportStage.NeedsBackupPassword)?.let { s ->
        PasswordDialog(
            title = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_041),
            message = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_password_message),
            confirmLabel = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_047),
            error = s.error,
            busy = state.busy,
            onConfirm = vm::submitBackupPassword,
            onCancel = vm::cancelImport
        )
    }
}

private fun restoreStageSafe(state: BackupUiState): Boolean = state.restoreStage == RestoreStage.Idle

// .Vault ka koi standard MIME nahi hota, isliye sab files dikhate hain
private val PICK_VAULT_TYPES = arrayOf("*/*")
private val PICK_CSV_TYPES = arrayOf("text/csv", "text/comma-separated-values", "application/csv", "application/vnd.ms-excel", "text/plain", "application/octet-stream")
private val PICK_JSON_TYPES = arrayOf("application/json", "text/plain", "application/octet-stream")

private enum class BackupTab(@androidx.annotation.StringRes val label: Int) { AUTO(R.string.bk_tab_auto), RESTORE(R.string.bk_tab_restore), EXPORT(R.string.bk_tab_export) }

/** Card with a bold title, a small info icon that reveals the long explanation, and the content below. */
@Composable
private fun InfoCard(title: String, info: String, content: @Composable () -> Unit) {
    var showInfo by rememberSaveable(title) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { showInfo = !showInfo }) { Icon(Icons.Default.Info, contentDescription = stringResource(R.string.bk_info)) }
            }
            if (showInfo) Text(info, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
private fun MainPane(
    state: BackupUiState,
    vm: BackupViewModel,
    onPick: () -> Unit,
    onPickMapped: () -> Unit,
    onPickJson: () -> Unit,
    onContacts: () -> Unit,
    onChooseBackupFolder: () -> Unit
) {
    val restoreStage = state.restoreStage
    val hasSelectedFolder = state.backupFolderUri.isNotBlank()
    val folderName = state.backupFolderLabel.ifBlank { stringResource(R.string.bk_choose_folder) }
    val fileName = state.backupFileName.ifBlank { "BSRPRO.Vault" }
    val restoring = restoreStage == RestoreStage.Restoring
    val finished = restoreStage is RestoreStage.Complete
    var showMore by rememberSaveable { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        BackupSurfaceCard(
            icon = Icons.Default.Folder,
            title = stringResource(R.string.p18_backup_selected_folder),
            value = folderName,
            supporting = if (hasSelectedFolder) stringResource(R.string.p18_backup_folder_selected) else stringResource(R.string.p18_backup_folder_choose_hint),
            onClick = onChooseBackupFolder
        )

        if (state.backupFileAvailable) {
            BackupSurfaceCard(
                icon = Icons.Default.InsertDriveFile,
                title = stringResource(R.string.p18_backup_file),
                value = fileName,
                supporting = buildString {
                    if (state.backupFileSizeBytes > 0) append(formatBytes(state.backupFileSizeBytes))
                    if (state.backupRecordCount > 0) {
                        if (isNotEmpty()) append("  •  ")
                        append(state.backupRecordCount)
                        append(" ")
                        append(stringResource(R.string.p18_backup_records))
                    }
                }.ifBlank { stringResource(R.string.p18_backup_file_ready) },
                onClick = vm::startFolderRestore
            )
        } else {
            BackupEmptyFileCard()
        }

        when (restoreStage) {
            RestoreStage.Restoring -> BackupProgressCard()
            is RestoreStage.Complete -> BackupSuccessCard(count = restoreStage.count, onDone = vm::dismissRestoreResult)
            is RestoreStage.Error -> BackupErrorCard(
                message = restoreStage.message,
                onRetry = vm::startFolderRestore,
                onDismiss = vm::dismissRestoreResult
            )
            RestoreStage.Idle -> Unit
        }

        if (!restoring && !finished && restoreStage !is RestoreStage.Error) {
            Button(
                onClick = vm::startFolderRestore,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = !state.busy && state.backupFileAvailable,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.CloudUpload, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
                Text(stringResource(R.string.p18_backup_restore_from_backup))
            }
        }

        if (restoreStage == RestoreStage.Idle) {
            Text(
                stringResource(R.string.p18_backup_available_options),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(top = 4.dp)
            )

            BackupActionRow(
                icon = { Icon(Icons.Default.CloudUpload, contentDescription = null) },
                title = stringResource(R.string.p18_backup_create),
                subtitle = stringResource(R.string.p18_backup_create_hint),
                enabled = !state.busy,
                onClick = vm::backupNow
            )
            BackupActionRow(
                icon = { Icon(Icons.Default.Security, contentDescription = null) },
                title = stringResource(R.string.p18_backup_file_import),
                subtitle = stringResource(R.string.p18_backup_file_import_hint),
                enabled = !state.busy,
                onClick = onPick
            )

            TextButton(
                onClick = { showMore = !showMore },
                enabled = !state.busy,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) { Text(if (showMore) stringResource(R.string.p18_backup_less_options) else stringResource(R.string.p18_backup_more_options)) }

            if (showMore) {
                Text(
                    stringResource(R.string.p18_backup_import_section),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(top = 2.dp)
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.InsertDriveFile, contentDescription = null) },
                    title = stringResource(R.string.p18_backup_more_import_formats),
                    subtitle = stringResource(R.string.p18_backup_file_import_hint),
                    enabled = !state.busy,
                    onClick = onPickMapped
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.InsertDriveFile, contentDescription = null) },
                    title = stringResource(R.string.bk_import_json),
                    subtitle = stringResource(R.string.p18_backup_json_hint),
                    enabled = !state.busy,
                    onClick = onPickJson
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.Folder, contentDescription = null) },
                    title = stringResource(R.string.bk_import_contacts),
                    subtitle = stringResource(R.string.p18_backup_contacts_hint),
                    enabled = !state.busy,
                    onClick = onContacts
                )

                Text(
                    stringResource(R.string.p18_backup_export_section),
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(top = 4.dp)
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.CloudUpload, contentDescription = null) },
                    title = stringResource(R.string.bk_export_vault),
                    subtitle = stringResource(R.string.p18_backup_export_vault_hint),
                    enabled = !state.busy,
                    onClick = { vm.openExportOptionsFor(ExportKind.VAULT) }
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.CloudUpload, contentDescription = null) },
                    title = stringResource(R.string.bk_export_csv),
                    subtitle = stringResource(R.string.p18_backup_export_csv_hint),
                    enabled = !state.busy,
                    onClick = { vm.openExportOptionsFor(ExportKind.CSV) }
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.CloudUpload, contentDescription = null) },
                    title = stringResource(R.string.bk_export_json),
                    subtitle = stringResource(R.string.p18_backup_export_json_hint),
                    enabled = !state.busy,
                    onClick = { vm.openExportOptionsFor(ExportKind.JSON) }
                )
                BackupActionRow(
                    icon = { Icon(Icons.Default.Security, contentDescription = null) },
                    title = stringResource(R.string.bk_export_smart),
                    subtitle = stringResource(R.string.p18_backup_export_smart_hint),
                    enabled = !state.busy,
                    onClick = vm::startSmartEncryptedExport
                )
            }

            if (!hasSelectedFolder) {
                Text(
                    stringResource(R.string.p18_backup_choose_folder_first),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
            }
        }
    }
}

@Composable
private fun BackupSurfaceCard(
    icon: ImageVector,
    title: String,
    value: String,
    supporting: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.titleSmall)
                Text(supporting, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BackupEmptyFileCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier.size(50.dp).background(MaterialTheme.colorScheme.surface, RoundedCornerShape(15.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.InsertDriveFile, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(stringResource(R.string.p18_backup_file), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(stringResource(R.string.p18_backup_no_file), style = MaterialTheme.typography.titleSmall)
                Text(stringResource(R.string.p18_backup_no_file_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun BackupActionRow(
    icon: @Composable () -> Unit,
    title: String,
    subtitle: String,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 11.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier.size(38.dp).background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { icon() }
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun BackupProgressCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(modifier = Modifier.size(48.dp), strokeWidth = 4.dp)
            }
            Text(stringResource(R.string.p18_backup_restoring), style = MaterialTheme.typography.titleMedium, modifier = Modifier.align(Alignment.CenterHorizontally))
            Text(stringResource(R.string.p18_backup_restoring_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.align(Alignment.CenterHorizontally))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun BackupSuccessCard(count: Int, onDone: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF9F2))
    ) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                modifier = Modifier.size(56.dp).background(Color(0xFFC9F3DE), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF0A9D67), modifier = Modifier.size(32.dp)) }
            Text(stringResource(R.string.p18_backup_restore_done), style = MaterialTheme.typography.titleMedium)
            Text(stringResource(R.string.p18_backup_restore_done_hint, count), style = MaterialTheme.typography.bodySmall, color = Color(0xFF27664E), textAlign = TextAlign.Center)
            Button(onClick = onDone, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(14.dp)) { Text(stringResource(R.string.p18_backup_ok)) }
        }
    }
}

@Composable
private fun BackupErrorCard(message: String, onRetry: () -> Unit, onDismiss: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f))
    ) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(stringResource(R.string.p18_backup_restore_failed), style = MaterialTheme.typography.titleMedium)
            Text(message, style = MaterialTheme.typography.bodySmall)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text(stringResource(R.string.p15_close)) }
                Button(onClick = onRetry, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text(stringResource(R.string.p18_backup_retry)) }
            }
        }
    }
}

private fun formatBytes(size: Long): String = when {
    size >= 1024L * 1024L -> String.format(Locale.getDefault(), "%.1f MB", size / 1024f / 1024f)
    size >= 1024L -> String.format(Locale.getDefault(), "%.0f KB", size / 1024f)
    else -> "$size B"
}

@Composable
private fun BackupRestorePasswordDialog(
    busy: Boolean,
    error: String?,
    onConfirm: (String) -> Unit,
    onCancel: () -> Unit
) {
    var password by rememberSaveable { mutableStateOf("") }
    Dialog(
        onDismissRequest = { if (!busy) onCancel() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Box(
                        modifier = Modifier.size(46.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary) }
                }
                Text(stringResource(R.string.p18_backup_restore_title), style = MaterialTheme.typography.titleLarge, modifier = Modifier.align(Alignment.CenterHorizontally))
                Text(stringResource(R.string.p18_backup_restore_password_hint), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                PasswordField(
                    value = password,
                    onValueChange = { password = it },
                    label = stringResource(R.string.p18_backup_master_password),
                    enabled = !busy
                )
                if (!error.isNullOrBlank()) {
                    Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onCancel, enabled = !busy, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text(stringResource(R.string.p15_cancel))
                    }
                    Button(onClick = { val p = password; password = ""; onConfirm(p) }, enabled = password.isNotEmpty() && !busy, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp) else Text(stringResource(R.string.p18_backup_restore_start))
                    }
                }
            }
        }
    }
}

@Composable
private fun ReviewPane(review: ImportStage.Review, vm: BackupViewModel) {
    val p = review.preview
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(p.format.label, style = MaterialTheme.typography.titleSmall)
            Text(
                stringResource(R.string.p18_backup_preview_counts, p.newCount, p.duplicateCount) +
                    if (p.skippedRows > 0) L.s(R.string.p18_backup_row_s_skipped, p.skippedRows) else "",
                style = MaterialTheme.typography.bodyMedium
            )
            if (p.items.isEmpty()) {
                // Fix.md 4.2 empty state: "0" ka matlab saaf dikhao (file khali hai), chup-chaap 0 import mat karo.
                Text(
                    stringResource(R.string.bk_import_file_empty),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ImportMode.values().forEach { m ->
                    FilterChip(
                        selected = review.mode == m,
                        onClick = { vm.setImportMode(m) },
                        label = { Text(if (m == ImportMode.MERGE) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_merge) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_replace)) }
                    )
                }
            }
            Text(
                if (review.mode == ImportMode.MERGE) stringResource(R.string.p18_backup_merge_your_current_entries_stay)
                else stringResource(R.string.p18_backup_replace_every_current_entry_moves),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (p.duplicateCount > 0 && review.mode == ImportMode.MERGE) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.SKIP) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_062)) }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.REPLACE) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_063)) }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.KEEP_BOTH) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_064)) }
                }
                Row(Modifier.clickable { vm.setApplyToAll(!review.applyToAll) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = review.applyToAll, onCheckedChange = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_065), modifier = Modifier.padding(start = 8.dp), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(p.items, key = { index, _ -> index }) { index, item ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Text(item.entry.title, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        listOf(item.entry.username.ifEmpty { item.entry.mobile }, item.entry.url).filter { it.isNotEmpty() }.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (item.duplicateOf != null && review.mode == ImportMode.MERGE) {
                        val action = review.actions[index] ?: DuplicateAction.SKIP
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_066), style = MaterialTheme.typography.labelSmall)
                        Column(Modifier.selectableGroup()) {
                            DuplicateAction.values().forEach { a ->
                                Row(
                                    Modifier.fillMaxWidth().selectable(
                                        selected = action == a,
                                        onClick = { vm.setAction(index, a) },
                                        role = Role.RadioButton
                                    ).padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = action == a, onClick = null)
                                    Text(
                                        when (a) { DuplicateAction.SKIP -> "Skip"; DuplicateAction.REPLACE -> "Replace existing"; DuplicateAction.KEEP_BOTH -> "Keep both" },
                                        modifier = Modifier.padding(start = 8.dp)
                                    )
                                }
                            }
                        }
                    } else {
                        Text(stringResource(R.string.p15_new), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                HorizontalDivider()
            }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text(stringResource(R.string.p15_cancel)) }
            Button(onClick = vm::askConfirmImport, Modifier.weight(1f), enabled = p.items.isNotEmpty()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056)) }
        }
    }
    if (review.confirm) {
        AlertDialog(
            onDismissRequest = vm::dismissConfirmImport,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_import_entries_count, p.items.size)) },
            text = {
                Text(
                    stringResource(R.string.p18_backup_entries_found, p.items.size, p.newCount, p.duplicateCount) +
                        if (review.mode == ImportMode.REPLACE) stringResource(R.string.p18_backup_all_current_entries_will_first) else ""
                )
            },
            confirmButton = { TextButton(onClick = vm::confirmImport) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056)) } },
            dismissButton = { TextButton(onClick = vm::dismissConfirmImport) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun MapPane(s: ImportStage.MapFields, vm: BackupViewModel) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Text(
                    stringResource(R.string.p18_backup_match_each_bsrpro_field_to),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            items(MapField.values().toList(), key = { it.name  }, contentType = { "item" }) { f -> ColumnPicker(f, s, vm) }
            item {
                Row(Modifier.clickable { vm.setSaveTemplate(!s.saveTemplate) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = s.saveTemplate, onCheckedChange = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_067), modifier = Modifier.padding(start = 8.dp))
                }
            }
            s.error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text(stringResource(R.string.p15_cancel)) }
            Button(onClick = vm::confirmMapping, Modifier.weight(1f)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_068)) }
        }
    }
}

@Composable
private fun ColumnPicker(f: MapField, s: ImportStage.MapFields, vm: BackupViewModel) {
    var open by remember { mutableStateOf(false) }
    val idx = s.mapping[f]
    val secret = f == MapField.PASSWORD || f == MapField.TOTP || f == MapField.APP_PIN
    Column {
        Text(f.label, style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth()) {
                Text(if (idx == null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_069) else s.headers.getOrElse(idx) { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, idx + 1) }.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, idx + 1) })
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_069)) }, onClick = { open = false; vm.setColumn(f, null) })
                s.headers.forEachIndexed { i, h ->
                    DropdownMenuItem(text = { Text(h.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, i + 1) }) }, onClick = { open = false; vm.setColumn(f, i) })
                }
            }
        }
        if (idx != null) {
            val value = s.sample.getOrNull(idx).orEmpty()
            if (value.isNotEmpty()) Text(
                "e.g. " + if (secret) "••••••" else value.take(40),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ExportOptionsDialog(
    o: ExportOptions,
    onChange: ((ExportOptions) -> ExportOptions) -> Unit,
    onContinue: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_070)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_071), style = MaterialTheme.typography.bodySmall)
                OptionCheck("Cards", o.includeCards) { v -> onChange { it.copy(includeCards = v) } }
                OptionCheck("Notes", o.includeNotes) { v -> onChange { it.copy(includeNotes = v) } }
                OptionCheck("Identities", o.includeIdentities) { v -> onChange { it.copy(includeIdentities = v) } }
                OptionCheck("App logins (apps, not websites)", o.includeAppLogins) { v -> onChange { it.copy(includeAppLogins = v) } }
                OptionCheck("Mobile numbers", o.includeMobiles) { v -> onChange { it.copy(includeMobiles = v) } }
                OptionCheck("TOTP secrets", o.includeTotp) { v -> onChange { it.copy(includeTotp = v) } }
                OptionCheck("Attachments (references)", o.includeAttachments) { v -> onChange { it.copy(includeAttachments = v) } }
                Text(stringResource(R.string.bk_export_format_label, o.kind.label), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                if (o.kind == ExportKind.CSV) {
                    OptionCheck("Encrypt CSV with my master password", o.encrypt) { v -> onChange { it.copy(encrypt = v) } }
                }
                Text(
                    when {
                        o.kind == ExportKind.VAULT -> "Encrypted with your master password. The BSRPRO extension can open it."
                        o.kind == ExportKind.CSV && o.encrypt -> "Saved as .csv.Vault. Only BSRPRO can open it (Import from file)."
                        else -> "This file will NOT be encrypted. Anyone who gets it can read your passwords."
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (o.isPlainText) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = onContinue) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_073)) } },
        dismissButton = { TextButton(onClick = onCancel) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun OptionCheck(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = null)
        Text(label, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
internal fun PasswordDialog(
    title: String,
    message: String,
    confirmLabel: String,
    error: String?,
    busy: Boolean,
    onConfirm: (String) -> Unit,
    onCancel: () -> Unit
) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(message, style = MaterialTheme.typography.bodyMedium)
                PasswordField(value = pw, onValueChange = { pw = it }, label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_074), enabled = !busy)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(pw); pw = "" }, enabled = pw.isNotEmpty() && !busy) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}
