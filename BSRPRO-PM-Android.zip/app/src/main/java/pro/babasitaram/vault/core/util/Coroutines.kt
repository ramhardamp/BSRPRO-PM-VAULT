package pro.babasitaram.vault.core.util

import kotlin.coroutines.cancellation.CancellationException

/**
 * Like runCatching, but never swallows coroutine cancellation. Plain runCatching around suspend calls turns a
 * cancelled coroutine into an ordinary failure, so the caller keeps running after its scope is gone.
 */
inline fun <T> runCatchingCancellable(block: () -> T): Result<T> =
    try {
        Result.success(block())
    } catch (ce: CancellationException) {
        throw ce
    } catch (t: Throwable) {
        Result.failure(t)
    }
