@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.sharing

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.lifecycle.lifecycleScope
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.SecureShareManager
import pro.babasitaram.vault.domain.repository.VaultRepository

@AndroidEntryPoint
class SecureShareActivity : ComponentActivity() {
    @javax.inject.Inject lateinit var repository: VaultRepository
    @javax.inject.Inject lateinit var autoBackup: pro.babasitaram.vault.data.backup.AutoBackupManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pro.babasitaram.vault.core.security.ScreenshotGuard.enable(this)

        val envelope = SecureShareManager.parse(intent?.data?.fragment)
        var loaded by mutableStateOf(envelope != null && !envelope.passwordProtected)
        var result by mutableStateOf<VaultEntry?>(null)
        var error by mutableStateOf<String?>(null)
        var password by mutableStateOf("")
        var imported by mutableStateOf(false)

        if (envelope == null) {
            loaded = true
            error = getString(R.string.p17_secure_share_invalid)
        } else if (!isWithinExpiry(envelope.expiry)) {
            loaded = true
            error = getString(R.string.p17_secure_share_expired)
        } else if (!envelope.passwordProtected) {
            lifecycleScope.launch {
                val decoded = decode(envelope, envelope.secret.orEmpty())
                result = decoded
                loaded = true
                if (decoded == null) error = getString(R.string.p17_secure_share_decrypt_failed)
            }
        }

        setContent {
            pro.babasitaram.vault.presentation.theme.VaultTheme {
                Column(
                    Modifier.fillMaxSize().padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(stringResource(R.string.p17_share_secure_title), style = MaterialTheme.typography.headlineSmall)

                    if (!loaded) {
                        if (envelope?.passwordProtected == true) {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(stringResource(R.string.p17_share_password_protected_link))
                                    Text(stringResource(R.string.p17_share_password_separate))
                                    OutlinedTextField(
                                        value = password,
                                        onValueChange = { password = it },
                                        label = { Text(stringResource(R.string.p17_share_password)) },
                                        visualTransformation = PasswordVisualTransformation(),
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Button(
                                        enabled = password.isNotEmpty(),
                                        onClick = {
                                            lifecycleScope.launch {
                                                val decoded = decode(envelope, password)
                                                if (decoded == null) {
                                                    error = getString(R.string.p17_secure_share_password_failed)
                                                } else {
                                                    result = decoded
                                                    loaded = true
                                                    password = ""
                                                }
                                            }
                                        },
                                        modifier = Modifier.fillMaxWidth()
                                    ) { Text(stringResource(R.string.p17_decrypt)) }
                                }
                            }
                        } else {
                            Text(stringResource(R.string.p17_decrypting_share))
                        }
                    }

                    error?.let {
                        Text(it, color = MaterialTheme.colorScheme.error)
                    }

                    result?.let { shared ->
                        Card(Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(shared.title.ifBlank { getString(R.string.p17_untitled) }, style = MaterialTheme.typography.titleMedium)
                                if (shared.username.isNotBlank()) Text(shared.username)
                                if (shared.url.isNotBlank()) Text(shared.url)
                                Text(stringResource(R.string.p17_password_protected_import))
                            }
                        }

                        Button(
                            onClick = {
                                lifecycleScope.launch {
                                    repository.upsert(shared)
                                    autoBackup.requestBackup()
                                    imported = true
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !imported
                        ) {
                            Text(stringResource(if (imported) R.string.p17_imported else R.string.p17_import_into_vault))
                        }
                    }

                    TextButton(onClick = ::finish, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.p15_close))
                    }
                }
            }
        }
    }

    private suspend fun decode(
        envelope: SecureShareManager.Envelope,
        secret: String
    ): VaultEntry? {
        if (secret.isBlank()) return null
        val views = getSharedPreferences("secure_share", MODE_PRIVATE)
        val used = views.getInt("views:${envelope.fingerprint}", 0)
        if (envelope.maxViews > 0 && used >= envelope.maxViews) return null

        return try {
            val entry = withContext(Dispatchers.Default) {
                SecureShareManager.decryptEnvelope(envelope, secret)
            }
            if (envelope.maxViews > 0) {
                views.edit()
                    .putInt("views:${envelope.fingerprint}", used + 1)
                    .apply()
            }
            entry
        } catch (_: Exception) {
            null
        }
    }

    private fun isWithinExpiry(expiry: Long): Boolean =
        System.currentTimeMillis() <= expiry
}
