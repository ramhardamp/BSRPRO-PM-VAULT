package pro.babasitaram.vault.core.util

import pro.babasitaram.vault.core.model.VaultEntry

/**
 * "Hidden vault" is a normal entry carrying the tag [TAG]. Tags are an existing V3 field, so the backup
 * format is unchanged and the BSRPRO extension still reads these entries. They are only kept out of the
 * Vault list / drawer count; opening them needs the separate Hidden-vault PIN.
 */
object HiddenVault {
    const val TAG = "hidden-vault"

    fun isHidden(tags: List<String>): Boolean = tags.any { it.equals(TAG, ignoreCase = true) }

    /** Adds or removes [TAG] in a comma separated tags string (as used by the editor form). */
    fun withHidden(tags: String, hidden: Boolean): String {
        val parts = tags.split(',').map { it.trim() }.filter { it.isNotEmpty() && !it.equals(TAG, ignoreCase = true) }
        return (if (hidden) parts + TAG else parts).joinToString(", ")
    }

    fun isHiddenText(tags: String): Boolean = isHidden(tags.split(',').map { it.trim() })
}

val VaultEntry.isHiddenVault: Boolean get() = HiddenVault.isHidden(tags)
