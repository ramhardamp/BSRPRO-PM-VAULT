package pro.babasitaram.vault.core.constants

/** Single source of truth for every external link / contact shown in About, Help and Support. */
object AppLinks {
    const val WEBSITE = "https://ramhardamp.github.io/babasitaram-pro/"
    const val EMAIL = "babasitarampro@gmail.com"
    const val GITHUB = "https://github.com/ramhardamp/babasitaram-pro"
    const val GITHUB_ISSUES = "https://github.com/ramhardamp/babasitaram-pro/issues"
    const val GITHUB_LICENSE = "https://github.com/ramhardamp/babasitaram-pro/blob/main/LICENSE"
    const val CHANGELOG = "https://github.com/ramhardamp/babasitaram-pro/releases"
    const val PRIVACY = "https://ramhardamp.github.io/babasitaram-pro/privacy.html"
    const val UPI_ID = "Totalpay@upi"
    const val DEVELOPER = "VIKRAM SINGH RAJPUT"
}
