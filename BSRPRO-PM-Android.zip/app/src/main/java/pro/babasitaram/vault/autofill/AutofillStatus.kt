package pro.babasitaram.vault.autofill

import android.content.Context
import android.content.Intent
import android.content.ComponentName
import android.net.Uri
import android.provider.Settings

/** Android Autofill status and the guided system hand-off used by the wallet. */
object AutofillStatus {
    /** True only when BSRPRO itself is the selected Android Autofill provider. */
    fun isEnabled(context: Context): Boolean {
        val configured = runCatching {
            Settings.Secure.getString(context.contentResolver, "autofill_service")
        }.getOrNull().orEmpty()
        val expected = ComponentName(context, VaultAutofillService::class.java).flattenToString()
        return configured == expected
    }

    fun enableIntent(context: Context): Intent =
        Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:${context.packageName}"))

    fun fallbackIntent(): Intent = Intent(Settings.ACTION_SETTINGS)
}
