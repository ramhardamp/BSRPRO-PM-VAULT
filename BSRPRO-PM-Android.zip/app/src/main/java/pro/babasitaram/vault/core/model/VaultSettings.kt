package pro.babasitaram.vault.core.model

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Launcher icon colour. [aliasName] is the <activity-alias> in the manifest (relative to the app namespace). */
enum class AppIconColor(val aliasName: String, val label: String) {
    PURPLE("IconPurple", "Purple"),
    TEAL("IconTeal", "Teal"),
    ORANGE("IconOrange", "Orange"),
    BLUE("IconBlue", "Blue")
}

data class VaultSettings(
    val theme: ThemeMode = ThemeMode.DARK,
    /** Legacy background timeout retained for backward-compatible settings migration. */
    val autoLockSeconds: Int = 1800,
    /** Seconds until the clipboard is wiped. 0 = never. */
    val clipboardClearSeconds: Int = 30,
    val biometricEnabled: Boolean = false,
    val lockOnBackground: Boolean = true,
    /** Absolute vault-session lifetime. -1 = Manual Lock Only. */
    val vaultSessionSeconds: Int = 24 * 60 * 60,
    /** Grace period while the app process is backgrounded. */
    val backgroundGraceSeconds: Int = 30 * 60,
    /** Reuse a valid authenticated session for Android Autofill instead of prompting every request. */
    val quickAutofillEnabled: Boolean = true,
    /** Seconds an authenticated Autofill window remains reusable. Default: 5 minutes. -2 = until screen lock. */
    val autofillSessionSeconds: Int = 5 * 60,
    /** Sensitive actions may request fresh authentication even while the normal session is active. */
    val sensitiveActionReauth: Boolean = true,
    val generatorDefaultLength: Int = 16,
    val generatorKeyword: String = "",
    val travelMode: Boolean = false,
    /** Keyboard ke upar autofill suggestions: default ON (Android 11+ par keyboard support kare to). */
    val autofillInline: Boolean = true,
    val autofillRegexEnabled: Boolean = true,
    val autofillExcludedPackages: List<String> = emptyList(),
    val generatorExcludeSimilar: Boolean = false,
    val blockWeakPasswords: Boolean = true,
    val appIcon: AppIconColor = AppIconColor.PURPLE,
    val autoBackupEnabled: Boolean = false,
    val lastAutoBackupAt: Long = 0L,
    /** Persisted SAF tree URI for user-selected automatic backup destination. */
    val backupFolderUri: String = "",
    val emergencyEncryptedMaster: String = "",
    val emergencyRequestTime: Long = 0L,
    val emergencyActive: Boolean = false,
    val emergencyContactName: String = "",
    val emergencyContactPhone: String = "",
    /** Recovery master encrypted with the 24-character recovery key. */
    val recoveryEncryptedMaster: String = "",
    /** Recovery key encrypted with the current master password, so a normal password change can preserve the same printed key. */
    val recoveryEncryptedKey: String = "",
    val recoveryCreatedAt: Long = 0L,
    val fontScalePercent: Int = 90,
    val hideSensitiveContentInRecents: Boolean = true,
    /** false (default) = FLAG_SECURE on, screenshots / screen recording blocked. */
    val allowScreenshots: Boolean = false,
    val autofillSavePrompts: Boolean = true,
    val generatorLower: Boolean = true,
    val generatorUpper: Boolean = true,
    val generatorDigits: Boolean = true,
    val generatorSymbols: Boolean = true,
    val showCategoryChips: Boolean = true,
    /** Wrong master-password attempts before a lockout (3-20). */
    val lockoutMaxAttempts: Int = 5,
    /** Lockout length in seconds (10-3600). */
    val lockoutSeconds: Int = 30
) {
    companion object {
        const val AUTO_LOCK_NEVER = -1
        /** Autofill remains authenticated until Android reports the screen turning off. */
        const val AUTOFILL_UNTIL_SCREEN_LOCK = -2
    }
}
