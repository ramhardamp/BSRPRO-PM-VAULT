package pro.babasitaram.vault.autofill

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * In-memory trace of the last autofill requests, shown in Settings → Autofill → Diagnostics.
 * Stores ONLY structural facts (package, domain, counts, outcome) — never usernames, passwords or field values.
 *
 * Phase 17c: ab sirf kaccha log nahi — [explain] seedha batata hai ki password KYON nahi aaya (Hinglish),
 * aur [summaryLines] har request ki ek chhoti line deti hai.
 */
object AutofillDiagnostics {
    const val TAG = "BSRPROAutofill"
    private const val MAX = 40

    /** Ek log entry. [line] purane format jaisi hi hai ("HH:mm:ss  stage — detail"). */
    data class Event(val time: String, val stage: String, val detail: String = "") {
        fun line(): String = "$time  $stage${if (detail.isNotEmpty()) " — $detail" else ""}"
    }

    /** [short] = ek chhoti line ke liye, [reason] = poora karan + kya karein. */
    data class Outcome(val short: String, val reason: String)

    private val events = ArrayDeque<Event>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    /** Security: logcat me domain/package sirf debug build me jaayein. BsrApplication isse BuildConfig.DEBUG par set karta hai. */
    @Volatile var logcatEnabled: Boolean = false

    @Synchronized
    fun record(stage: String, detail: String = "") {
        if (events.size >= MAX) events.removeFirst()
        events.addLast(Event(fmt.format(Date()), stage, detail))
        // logcat: adb logcat -s BSRPROAutofill   (structure only — never usernames, passwords or values)
        if (!logcatEnabled) return
        try {
            android.util.Log.d(TAG, "$stage${if (detail.isNotEmpty()) " | $detail" else ""}")
        } catch (e: Throwable) {
            // plain JVM unit tests have no android.util.Log
        }
    }

    @Synchronized
    fun snapshot(): List<String> = events.map { it.line() }.asReversed()

    @Synchronized
    fun clear() = events.clear()

    /** Password kyon nahi aaya — seedha karan (Hinglish). [serviceEnabled] = BSRPRO selected Android autofill service hai ya nahi. */
    @Synchronized
    fun explain(serviceEnabled: Boolean): String = diagnose(events.toList(), serviceEnabled)

    /** Har request ki ek chhoti line, sabse nayi pehle (max [max]). */
    @Synchronized
    fun summaryLines(max: Int = 6): List<String> = summarize(events.toList(), max)

    @Synchronized
    fun report(serviceEnabled: Boolean? = null): String {
        val list = events.toList()
        val head = if (serviceEnabled == null) "" else "KARAN: ${diagnose(list, serviceEnabled)}\n\n"
        if (list.isEmpty()) return head + "No autofill requests received yet."
        val short = summarize(list, 6).joinToString("\n")
        return head + short + "\n\n--- detail ---\n" + list.asReversed().joinToString("\n") { it.line() }
    }

    // ───────────────────────── pure logic (JVM-testable) ─────────────────────────

    internal fun diagnose(list: List<Event>, serviceEnabled: Boolean): String {
        if (!serviceEnabled) {
            return "BSRPRO abhi Android ka selected Autofill service nahi hai, isliye password nahi aa rahe. " +
                "Phone Settings → Passwords & accounts → Autofill service me BSRPRO chuno."
        }
        val last = requests(list).lastOrNull()
            ?: return "Service ON hai par Android ne abhi tak koi request nahi bheji. Kisi login field par tap karo. " +
                "Phir bhi khali ho to us app/browser me autofill band hai (Chrome: Settings → Autofill services → " +
                "\"Autofill using another service\" ON karo)."
        return outcome(last).reason
    }

    internal fun summarize(list: List<Event>, max: Int): List<String> =
        requests(list).takeLast(max).asReversed().map { g ->
            val target = target(g)
            "${g.first().time}  $target → ${outcome(g).short}"
        }

    /** Log ko request-groups me todta hai ("1 onFillRequest called" se shuru). */
    private fun requests(list: List<Event>): List<List<Event>> {
        val out = ArrayList<MutableList<Event>>()
        for (e in list) {
            if (e.stage.startsWith("1 onFillRequest")) out.add(mutableListOf(e))
            else out.lastOrNull()?.add(e)
        }
        return out
    }

    private fun find(g: List<Event>, prefix: String): Event? = g.lastOrNull { it.stage.startsWith(prefix) }

    private fun target(g: List<Event>): String {
        val d = find(g, "2 parsed")?.detail.orEmpty()
        val domain = Regex("domain=(\\S+)").find(d)?.groupValues?.get(1)?.takeIf { it != "-" }
        val pkg = Regex("pkg=(\\S+)").find(d)?.groupValues?.get(1)
        return domain ?: pkg?.substringAfterLast('.') ?: "?"
    }

    internal fun outcome(g: List<Event>): Outcome {
        val parsed = find(g, "2 parsed")?.detail.orEmpty()
        val skipped = find(g, "2 skipped")?.detail
        val pkg = Regex("pkg=(\\S+)").find(parsed)?.groupValues?.get(1) ?: "is app"

        if (find(g, "2 parse FAILED") != null) {
            return Outcome("screen padh nahi payi", "Screen ka structure padhte waqt error aaya, isliye kuch nahi bhara. Dobara try karo; baar-baar ho to app update/restart karo.")
        }
        if (find(g, "2 no structure") != null) {
            return Outcome("screen data nahi mila", "Android ne screen ka data hi nahi diya (kuch apps/screens autofill ko block karte hain), isliye bharne ko kuch nahi.")
        }
        when {
            skipped == "own app" ->
                return Outcome("BSRPRO ki apni screen", "BSRPRO apni hi screen par kabhi autofill nahi karta.")
            skipped == "plain http page" ->
                return Outcome("http page, skip", "Ye page HTTPS nahi (http) hai. Suraksha ke liye bina HTTPS wale page par password nahi bharte.")
            skipped == "no fillable fields" -> return Outcome(
                "koi login field nahi",
                "Android ko is screen ($pkg) par koi username/password/PIN/OTP field mili hi nahi (sab 0). " +
                    "Matlab ye login screen nahi hai, ya ye app apni fields ko autofill ke liye mark nahi karta. " +
                    "Login wali screen par field tap karke dobara try karo."
            )
        }
        find(g, "3 skipped")?.let {
            return if (it.detail.contains("travel", true))
                Outcome("travel mode ON", "Travel mode chalu hai, isliye autofill band hai. Settings me travel mode OFF karo.")
            else Outcome("skip: ${it.detail}", "Autofill is request par skip hua: ${it.detail}.")
        }
        if (find(g, "3 no vault") != null) {
            return Outcome("vault nahi bana", "Is phone par abhi BSRPRO ka vault nahi hai. App kholkar vault banao ya backup restore karo.")
        }
        find(g, "4 build FAILED")?.let {
            return Outcome("build error", "Suggestion banate waqt error aaya (${it.detail}). Dobara try karo; baar-baar ho to is log ko copy karke bhejo.")
        }
        if (find(g, "4 offering unlock entry") != null) {
            return Outcome("vault locked, Unlock row", "Vault locked hai ya autofill ki window khatam ho gayi, isliye password nahi bhare. \"Unlock BSRPRO Vault\" row par tap karke unlock karo.")
        }
        find(g, "4 matches")?.let { m ->
            val n = m.detail.substringBefore(' ').toIntOrNull()
            val forWhat = m.detail.substringAfter("for ", "is site/app")
            if (n == 0) return Outcome("0 saved login", "$forWhat ke liye vault me koi saved login match nahi hua. Entry me sahi site URL ya app package link karo (App Login ke liye package name).")
            val built = find(g, "4 datasets")?.detail?.substringBefore(' ')?.toIntOrNull()
            return when {
                built == 0 -> Outcome("entry khali", "Entry mili ($n) par is screen ke fields ke liye username/password khali hain, isliye kuch nahi bhara.")
                built != null -> Outcome("$built suggestion bheje", "$built suggestion Android ko bhej diye gaye. Na dikhe to keyboard suggestions / dropdown setting check karo.")
                else -> Outcome("$n match", "$n login mile, par suggestion abhi bane nahi.")
            }
        }
        if (find(g, "cancelled") != null) {
            return Outcome("system ne cancel kiya", "Android ne request beech me cancel kar di (screen badal gayi ya der ho gayi). Field par dobara tap karo.")
        }
        return Outcome("jawab atka", "Request aayi par abhi tak jawab nahi bana. Thodi der baad field par dobara tap karo.")
    }
}
