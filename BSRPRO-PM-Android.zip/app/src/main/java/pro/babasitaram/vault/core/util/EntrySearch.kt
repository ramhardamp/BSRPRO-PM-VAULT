package pro.babasitaram.vault.core.util

import pro.babasitaram.vault.core.model.VaultEntry

/** Substring search over all text fields, with a trigram-similarity fallback for typos ("gogle" → Google). */
object EntrySearch {
    private const val FUZZY_THRESHOLD = 0.4

    fun filter(entries: List<VaultEntry>, query: String): List<VaultEntry> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return entries
        return entries
            .map { it to score(it, q) }
            .filter { it.second > 0.0 }
            .sortedWith(compareByDescending<Pair<VaultEntry, Double>> { it.second }.thenBy { it.first.title.lowercase() })
            .map { it.first }
    }

    private fun score(e: VaultEntry, q: String): Double {
        val domain = UrlUtils.domainOf(e.url)
        val strong = listOf(e.title, e.username, domain, e.appName)
        val weak = listOf(e.url, e.notes, e.email, e.fullName, e.folder, e.category) + e.tags
        if (strong.any { it.lowercase().contains(q) }) return 3.0
        if (weak.any { it.lowercase().contains(q) }) return 2.0
        if (q.length >= 3) {
            val tokens = (strong.flatMap { tokens(it) } + domain.split('.')).filter { it.length >= 3 }
            val best = tokens.maxOfOrNull { similarity(q, it) } ?: 0.0
            if (best >= FUZZY_THRESHOLD) return best
        }
        return 0.0
    }

    private val NON_ALNUM = Regex("[^a-z0-9]+")

    private fun tokens(s: String) = s.lowercase().split(NON_ALNUM).filter { it.isNotEmpty() }

    private fun trigrams(s: String): Set<String> {
        val t = "  ${s.lowercase()} "
        return (0..t.length - 3).map { t.substring(it, it + 3) }.toSet()
    }

    internal fun similarity(a: String, b: String): Double {
        val ta = trigrams(a)
        val tb = trigrams(b)
        val inter = ta.intersect(tb).size
        val union = ta.size + tb.size - inter
        return if (union == 0) 0.0 else inter.toDouble() / union
    }
}
