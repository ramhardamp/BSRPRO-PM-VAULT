package pro.babasitaram.vault.core.security

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import org.json.JSONArray
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import pro.babasitaram.vault.data.local.db.ActivityLogDao
import pro.babasitaram.vault.data.local.db.ActivityLogEntity

/** Durable local audit trail. Never pass passwords, OTPs, secret values, URLs or raw share tokens. */
@Singleton
class ActivityLogStore @Inject constructor(
    private val dao: ActivityLogDao,
    @ApplicationContext context: Context
) {
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val legacyPrefs = context.getSharedPreferences("bsrpro_activity_log", Context.MODE_PRIVATE)

    init {
        ioScope.launch {
            if (!legacyPrefs.getBoolean("room_migrated_v1", false)) {
                val legacy = runCatching { JSONArray(legacyPrefs.getString("events", "[]")) }.getOrDefault(JSONArray())
                val rows = buildList {
                    for (i in 0 until legacy.length()) {
                        val item = legacy.optJSONObject(i) ?: continue
                        val action = item.optString("action", "Activity").take(80)
                        add(ActivityLogEntity(timestamp = item.optLong("at", System.currentTimeMillis()), action = action,
                            details = item.optString("detail", "").take(160), category = categoryFor(action)))
                    }
                }
                if (rows.isNotEmpty()) dao.insertAll(rows)
                legacyPrefs.edit().putBoolean("room_migrated_v1", true).commit()
            }
        }
    }

    fun record(action: String, detail: String = "") {
        val safeAction = action.trim().take(80).ifBlank { "Activity" }
        val safeDetail = detail.replace(Regex("https?://\\S+", RegexOption.IGNORE_CASE), "[redacted-url]")
            .take(160)
        ioScope.launch {
            runCatching {
                dao.insert(ActivityLogEntity(
                    timestamp = System.currentTimeMillis(),
                    action = safeAction,
                    details = safeDetail,
                    category = categoryFor(safeAction)
                ))
            }
        }
    }

    fun observe(limit: Int = 500): Flow<List<ActivityLogItem>> =
        dao.observeLatest(limit.coerceIn(1, 2_000)).map { rows ->
            rows.map { ActivityLogItem(it.id, it.timestamp, it.action, it.details, it.category) }
        }

    suspend fun clear() = dao.clear()

    data class ActivityLogItem(
        val id: Long,
        val timestamp: Long,
        val action: String,
        val detail: String,
        val category: String
    )

    private fun categoryFor(action: String): String {
        val a = action.lowercase()
        return when {
            listOf("unlock", "lock", "login", "password", "biometric", "pin", "emergency", "share", "security").any(a::contains) -> "Security"
            listOf("setting", "theme", "language", "preference").any(a::contains) -> "Settings"
            else -> "Data"
        }
    }
}
