@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.activitylog

import pro.babasitaram.vault.R

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date
import pro.babasitaram.vault.core.security.ActivityLogStore

@Composable
fun ActivityLogScreen(onBack: () -> Unit, vm: ActivityLogViewModel = hiltViewModel()) {
    BackHandler { onBack() }
    val items by vm.items.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("All") }
    var clock by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(60_000); clock = System.currentTimeMillis() } }
    val visible = remember(items, filter) { if (filter == "All") items else items.filter { it.category == filter } }
    val filterOptions = listOf(
        "All" to R.string.p15_all,
        "Security" to R.string.p15_security,
        "Data" to R.string.activity_log_data,
        "Settings" to R.string.p15_settings
    )

    Scaffold(topBar = {
        TopAppBar(title = { Text(stringResource(R.string.activity_log_title), style = MaterialTheme.typography.titleLarge) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p15_back)) } },
            actions = { if (items.isNotEmpty()) TextButton(onClick = { confirmClear = true }) { Text(stringResource(R.string.activity_log_clear)) } })
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                filterOptions.forEach { (key, labelRes) ->
                    FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(stringResource(labelRes)) })
                }
            }
            if (visible.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
                    Text(if (items.isEmpty()) stringResource(R.string.activity_log_empty) else stringResource(R.string.activity_log_empty_filter), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.activity_log_disclaimer))
                }
            } else LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible, key = { it.id  }, contentType = { "item" }) { item -> ActivityRow(item, clock) }
            }
        }
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false },
        title = { Text(stringResource(R.string.activity_log_clear_title)) },
        text = { Text(stringResource(R.string.activity_log_clear_text)) },
        confirmButton = { Button(onClick = { confirmClear = false; vm.clear() }) { Text(stringResource(R.string.activity_log_clear)) } },
        dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(stringResource(R.string.p15_cancel)) } })
}

@Composable
private fun ActivityRow(item: ActivityLogStore.ActivityLogItem, now: Long) {
    val icon = when (item.category) { "Security" -> Icons.Default.Security; "Settings" -> Icons.Default.Settings; else -> Icons.Default.Storage }
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, contentDescription = stringResource(when (item.category) { "Security" -> R.string.p15_security; "Settings" -> R.string.p15_settings; else -> R.string.activity_log_data }), tint = MaterialTheme.colorScheme.primary)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(item.action, style = MaterialTheme.typography.titleSmall)
                if (item.detail.isNotBlank()) Text(item.detail, style = MaterialTheme.typography.bodyMedium)
                Text(
                    "${relativeTime(
                        now - item.timestamp,
                        stringResource(R.string.activity_log_just_now),
                        stringResource(R.string.activity_log_minutes),
                        stringResource(R.string.activity_log_hours),
                        stringResource(R.string.activity_log_days)
                    )} · ${DateFormat.getDateTimeInstance().format(Date(item.timestamp))}",
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

private fun relativeTime(deltaMs: Long, justNow: String, minutes: String, hours: String, days: String): String {
    val seconds = (deltaMs.coerceAtLeast(0) / 1_000)
    return when {
        seconds < 60 -> justNow
        seconds < 3_600 -> "${seconds / 60} $minutes"
        seconds < 86_400 -> "${seconds / 3_600} $hours"
        else -> "${seconds / 86_400} $days"
    }
}
