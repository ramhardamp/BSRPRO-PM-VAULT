package pro.babasitaram.vault.core.security

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import pro.babasitaram.vault.R
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

sealed interface AuthResult {
    data class Success(val cryptoObject: BiometricPrompt.CryptoObject? = null) : AuthResult

    /** A single rejected attempt (e.g. wrong finger). The prompt stays open; more results may follow. */
    data object Failed : AuthResult
    data class Error(val code: Int, val message: String) : AuthResult
    data object Cancelled : AuthResult
    /** Negative button used OR biometric sensor unusable (no hardware/not enrolled/lockout): caller must launch the system device-credential prompt. */
    data object FallbackRequested : AuthResult
}

enum class BiometricAvailability {
    Available, NoHardware, HardwareUnavailable, NotEnrolled, SecurityUpdateRequired, Unsupported
}

interface BiometricAuthenticator {
    fun availability(): BiometricAvailability

    /** BIOMETRIC_STRONG or DEVICE_CREDENTIAL. Collect from the main thread. */
    fun authenticate(activity: FragmentActivity, title: String, subtitle: String? = null): Flow<AuthResult>

    /**
     * Crypto-bound variant (BIOMETRIC_STRONG only, so a negative button is required).
     * [cipher] must already be initialised with a Keystore key that requires user authentication.
     */
    fun authenticateWithCipher(
        activity: FragmentActivity,
        cipher: Cipher,
        title: String,
        negativeButtonText: String,
        subtitle: String? = null
    ): Flow<AuthResult>
}

/**
 * Error codes meaning "the biometric sensor cannot be used right now" (no sensor, sensor busy/unavailable,
 * nothing enrolled, or temporary/permanent biometric lockout). None of these mean the user cannot
 * authenticate: Android's own device credential (PIN/Pattern/Password) is still valid, so the caller
 * must continue with the system device-credential prompt instead of failing or showing the master password.
 */
internal fun isBiometricSensorUnusable(code: Int): Boolean = when (code) {
    BiometricPrompt.ERROR_HW_NOT_PRESENT,
    BiometricPrompt.ERROR_HW_UNAVAILABLE,
    BiometricPrompt.ERROR_NO_BIOMETRICS,
    BiometricPrompt.ERROR_LOCKOUT,
    BiometricPrompt.ERROR_LOCKOUT_PERMANENT -> true
    else -> false
}

internal fun mapAuthError(code: Int, message: String): AuthResult = when {
    code == BiometricPrompt.ERROR_USER_CANCELED ||
        code == BiometricPrompt.ERROR_CANCELED -> AuthResult.Cancelled
    code == BiometricPrompt.ERROR_NEGATIVE_BUTTON -> AuthResult.FallbackRequested
    // Root-cause fix: the crypto-bound prompt is BIOMETRIC_STRONG only. On a device with no usable
    // biometric it fails with one of these codes; route to the device-credential flow.
    isBiometricSensorUnusable(code) -> AuthResult.FallbackRequested
    else -> AuthResult.Error(code, message)
}

/**
 * AndroidX Biometric reports BIOMETRIC_STRONG|DEVICE_CREDENTIAL as UNSUPPORTED on API 28-29 even when the device
 * has a PIN/Pattern/Password. In exactly that case the system lock-screen confirmation
 * (KeyguardManager.createConfirmDeviceCredentialIntent) is used instead; the app still never sees the credential.
 */
internal fun needsLegacyCredentialPrompt(sdk: Int, combinedResult: Int, deviceSecure: Boolean): Boolean =
    sdk < Build.VERSION_CODES.R && combinedResult == BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED && deviceSecure

/** Pure adapter from the callback API to a Flow; [start] creates+launches the prompt, [cancel] dismisses it. */
internal fun <P> authCallbackFlow(
    start: (BiometricPrompt.AuthenticationCallback) -> P,
    cancel: (P) -> Unit
): Flow<AuthResult> = callbackFlow {
    val finished = AtomicBoolean(false)
    val callback = object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            finished.set(true)
            trySend(AuthResult.Success(result.cryptoObject))
            close()
        }

        override fun onAuthenticationFailed() {
            trySend(AuthResult.Failed)
        }

        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            finished.set(true)
            trySend(mapAuthError(errorCode, errString.toString()))
            close()
        }
    }
    val prompt = start(callback)
    awaitClose { if (!finished.get()) cancel(prompt) }
}

class AndroidBiometricAuthenticator(private val context: Context) : BiometricAuthenticator {

    private fun combinedResult(): Int = BiometricManager.from(context).canAuthenticate(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)

    private fun deviceSecure(): Boolean =
        (context.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager)?.isDeviceSecure == true

    private fun legacyCredentialMode(): Boolean =
        needsLegacyCredentialPrompt(Build.VERSION.SDK_INT, combinedResult(), deviceSecure())

    override fun availability(): BiometricAvailability =
        if (legacyCredentialMode()) BiometricAvailability.Available
        else when (combinedResult()) {
            BiometricManager.BIOMETRIC_SUCCESS -> BiometricAvailability.Available
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricAvailability.NoHardware
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> BiometricAvailability.HardwareUnavailable
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricAvailability.NotEnrolled
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> BiometricAvailability.SecurityUpdateRequired
            else -> BiometricAvailability.Unsupported
        }

    override fun authenticate(activity: FragmentActivity, title: String, subtitle: String?): Flow<AuthResult> {
        if (legacyCredentialMode()) return legacyAuthenticate(activity, title, subtitle)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .apply { subtitle?.let { setSubtitle(it) } }
            .setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL)
            .build()
        return authCallbackFlow(
            start = { cb ->
                BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), cb).also { it.authenticate(info) }
            },
            cancel = { it.cancelAuthentication() }
        ).flowOn(Dispatchers.Main.immediate)
    }

    /** API 28-29: strong biometric (if enrolled) with a "use device PIN" button, otherwise the system lock screen. */
    private fun legacyAuthenticate(activity: FragmentActivity, title: String, subtitle: String?): Flow<AuthResult> = flow {
        val strongBiometric =
            BiometricManager.from(context).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
        if (strongBiometric) {
            var useCredential = false
            strongBiometricWithNegativeButton(activity, title, subtitle).collect { result ->
                if (result == AuthResult.FallbackRequested) useCredential = true else emit(result)
            }
            if (!useCredential) return@flow
        }
        emitAll(confirmDeviceCredential(activity, title, subtitle))
    }

    private fun strongBiometricWithNegativeButton(activity: FragmentActivity, title: String, subtitle: String?): Flow<AuthResult> {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .apply { subtitle?.let { setSubtitle(it) } }
            .setNegativeButtonText(context.getString(R.string.p18_common_use_device_pin))
            .setAllowedAuthenticators(BIOMETRIC_STRONG)
            .build()
        return authCallbackFlow(
            start = { cb ->
                BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), cb).also { it.authenticate(info) }
            },
            cancel = { it.cancelAuthentication() }
        ).flowOn(Dispatchers.Main.immediate)
    }

    /**
     * Android's own lock-screen confirmation. RESULT_OK means the system verified the user; the actual unlock is
     * still gated by Keystore Key B (time-bound), so a spoofed result could not decrypt anything.
     */
    private fun confirmDeviceCredential(activity: FragmentActivity, title: String, subtitle: String?): Flow<AuthResult> = callbackFlow {
        val keyguard = activity.getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
        val intent: Intent? = keyguard?.createConfirmDeviceCredentialIntent(title, subtitle)
        var launcher: ActivityResultLauncher<Intent>? = null
        if (intent == null) {
            trySend(AuthResult.Error(BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL, "Set a screen lock (PIN, pattern or password) on this device"))
            close()
        } else {
            val registered = activity.activityResultRegistry.register(
                "bsrpro_device_credential_${UUID.randomUUID()}",
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                trySend(if (result.resultCode == Activity.RESULT_OK) AuthResult.Success(null) else AuthResult.Cancelled)
                close()
            }
            launcher = registered
            registered.launch(intent)
        }
        awaitClose { launcher?.unregister() }
    }.flowOn(Dispatchers.Main.immediate)

    override fun authenticateWithCipher(
        activity: FragmentActivity,
        cipher: Cipher,
        title: String,
        negativeButtonText: String,
        subtitle: String?
    ): Flow<AuthResult> {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .apply { subtitle?.let { setSubtitle(it) } }
            .setNegativeButtonText(negativeButtonText)
            .setAllowedAuthenticators(BIOMETRIC_STRONG)
            .build()
        return authCallbackFlow(
            start = { cb ->
                BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), cb)
                    .also { it.authenticate(info, BiometricPrompt.CryptoObject(cipher)) }
            },
            cancel = { it.cancelAuthentication() }
        ).flowOn(Dispatchers.Main.immediate)
    }
}
