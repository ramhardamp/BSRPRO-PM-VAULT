package pro.babasitaram.vault.presentation.backup

import android.net.Uri
import android.content.Context
import android.provider.DocumentsContract
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.security.SmartBackupPassword
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.data.backup.UriIo
import pro.babasitaram.vault.data.transfer.CsvMapping
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.ExportFilter
import pro.babasitaram.vault.data.transfer.ExportKind
import pro.babasitaram.vault.data.transfer.ExportOptions
import pro.babasitaram.vault.data.transfer.ExportProgress
import pro.babasitaram.vault.data.transfer.ImportMappingStore
import pro.babasitaram.vault.data.transfer.ImportMode
import pro.babasitaram.vault.data.transfer.MapField
import kotlinx.coroutines.Job
import pro.babasitaram.vault.data.transfer.EntryExporter
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.data.transfer.ImportParser
import pro.babasitaram.vault.data.transfer.SourceKind
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import pro.babasitaram.vault.domain.usecase.CommitImportUseCase
import pro.babasitaram.vault.domain.usecase.ImportPreview
import pro.babasitaram.vault.domain.usecase.PrepareImportUseCase
import pro.babasitaram.vault.domain.usecase.RestoreVaultTransactionUseCase
import pro.babasitaram.vault.domain.usecase.VerifyMasterPasswordUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage
import androidx.compose.foundation.lazy.*
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

sealed interface ImportStage {
    data object Idle : ImportStage
    data class NeedsBackupPassword(val text: String, val error: String? = null) : ImportStage
    data class Review(
        val preview: ImportPreview,
        val actions: Map<Int, DuplicateAction>,
        val mode: ImportMode = ImportMode.MERGE,
        val applyToAll: Boolean = false,
        val confirm: Boolean = false
    ) : ImportStage
    /** CSV column → vault field mapping (auto-detected, user can override). */
    data class MapFields(
        val text: String,
        val headers: List<String>,
        val sample: List<String>,
        val mapping: Map<MapField, Int>,
        val saveTemplate: Boolean = true,
        val error: String? = null
    ) : ImportStage
}

sealed interface RestoreStage {
    data object Idle : RestoreStage
    data object Restoring : RestoreStage
    data class Complete(val count: Int) : RestoreStage
    data class Error(val message: String) : RestoreStage
}

@Stable
data class BackupUiState(
    val busy: Boolean = false,
    val exportAsk: ExportFormat? = null,
    val exportError: String? = null,
    val importing: ImportStage = ImportStage.Idle,
    val autoBackupEnabled: Boolean = false,
    val lastAutoBackupAt: Long = 0L,
    val backupFolderUri: String = "",
    val backupFolderLabel: String = "",
    val backupFileAvailable: Boolean = false,
    val backupFileName: String = "BSRPRO.Vault",
    val backupFileSizeBytes: Long = 0L,
    val backupRecordCount: Int = 0,
    val restoreAsk: Boolean = false,
    val restoreError: String? = null,
    val restoreStage: RestoreStage = RestoreStage.Idle,
    val smartBackupPassword: String? = null,
    val smartBackupExport: Boolean = false,
    /** Non-null while the "Export options" dialog is open. */
    val exportOptions: ExportOptions? = null,
    /** Options chosen in the dialog, kept while the password dialog is open. */
    val activeExport: ExportOptions? = null,
    val exportProgress: ExportProgress? = null,
    /** Restore was tapped but Downloads/BSRPRO_Backups has no usable backup: the screen shows an empty state. */
    val noBackupFound: Boolean = false
)

sealed interface BackupEvent {
    data class Message(val text: String) : BackupEvent
    data class SaveFile(val fileName: String, val mime: String) : BackupEvent
}

@HiltViewModel
class BackupViewModel @Inject constructor(
    @dagger.hilt.android.qualifiers.ApplicationContext private val context: Context,
    private val verify: VerifyMasterPasswordUseCase,
    private val buildExport: BuildExportUseCase,
    private val prepare: PrepareImportUseCase,
    private val commit: CommitImportUseCase,
    private val io: UriIo,
    private val settings: SettingsRepository,
    private val autoBackup: AutoBackupManager,
    private val activityLog: ActivityLogStore,
    private val restoreTransaction: RestoreVaultTransactionUseCase,
    private val clipboard: pro.babasitaram.vault.presentation.util.ClipboardActions,
    private val mappingStore: ImportMappingStore,
    private val repository: pro.babasitaram.vault.domain.repository.VaultRepository
) : ViewModel() {

    /** Copies a secret through the vault clipboard manager (sensitive flag + auto-clear). */
    fun copySecret(text: String, label: String) {
        launchCatching { clipboard.copy(text, label) }
    }

    private val _state = MutableStateFlow(BackupUiState())
    val state: StateFlow<BackupUiState> = _state.asStateFlow()
    private val _events = Channel<BackupEvent>(Channel.BUFFERED)
    val events: Flow<BackupEvent> = _events.receiveAsFlow()

    /** Export text waiting for the user to pick where to save it. Dropped after writing / cancelling. */
    private var pendingExport: String? = null
    private var pendingRestoreFile: java.io.File? = null

    init {
        launchCatching {
            settings.settings.collect { s ->
                val label = resolveFolderLabel(s.backupFolderUri)
                _state.update { it.copy(
                    autoBackupEnabled = s.autoBackupEnabled,
                    lastAutoBackupAt = s.lastAutoBackupAt,
                    backupFolderUri = s.backupFolderUri,
                    backupFolderLabel = label
                ) }
            }
        }
    }

    private fun resolveFolderLabel(uriString: String): String {
        if (uriString.isBlank()) return "बैकअप फ़ोल्डर चुनें"
        return try {
            val uri = Uri.parse(uriString)
            context.contentResolver.query(
                uri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) c.getString(0).orEmpty().ifBlank { "चयनित फ़ोल्डर" } else "चयनित फ़ोल्डर"
            } ?: "चयनित फ़ोल्डर"
        } catch (_: Exception) {
            "चयनित फ़ोल्डर"
        }
    }

    fun dismissRestoreResult() = _state.update { it.copy(restoreStage = RestoreStage.Idle, restoreError = null) }

    /** Refreshes the selected-folder backup summary without modifying any backup file. */
    fun refreshBackupFile() {
        val selected = _state.value.backupFolderUri
        if (selected.isBlank()) return
        launchCatching {
            val probe = runCatching { autoBackup.probeFolderBackup() }.getOrNull()
            if (probe == null) {
                _state.update { it.copy(backupFileAvailable = false, backupFileSizeBytes = 0L, backupRecordCount = 0) }
            } else {
                _state.update { it.copy(backupFileAvailable = true, backupFileName = "BSRPRO.Vault", backupFileSizeBytes = probe.sizeBytes, backupRecordCount = probe.recordCount) }
            }
        }
    }

    // ───────────────────────── export ─────────────────────────

    fun startExport(format: ExportFormat) = _state.update {
        it.copy(exportAsk = format, exportError = null, smartBackupExport = false, smartBackupPassword = null)
    }

    fun openExportOptions() = _state.update { it.copy(exportOptions = ExportOptions(), exportError = null) }

    /** Export tab ka har button apna format pehle se chun kar kholta hai (pehle sab ek hi dialog + radio me khulta tha). */
    fun openExportOptionsFor(kind: ExportKind) = _state.update { it.copy(exportOptions = ExportOptions(kind = kind), exportError = null) }

    fun updateExportOptions(transform: (ExportOptions) -> ExportOptions) =
        _state.update { s -> s.exportOptions?.let { s.copy(exportOptions = transform(it)) } ?: s }

    fun dismissExportOptions() = _state.update { it.copy(exportOptions = null) }

    /** Options accepted: ask for the master password next. */
    fun continueExport() {
        val o = _state.value.exportOptions ?: return
        _state.update {
            it.copy(exportOptions = null, activeExport = o, exportAsk = o.legacyFormat, exportError = null,
                smartBackupExport = false, smartBackupPassword = null)
        }
    }

    fun cancelRunningExport() {
        exportJob?.cancel()
        exportJob = null
        pendingExport = null
        _state.update { it.copy(busy = false, exportProgress = null, activeExport = null, exportAsk = null) }
    }

    private var exportJob: Job? = null

    fun startSmartEncryptedExport() = _state.update {
        it.copy(exportAsk = ExportFormat.V3, exportError = null, smartBackupExport = true, smartBackupPassword = null)
    }

    fun dismissSmartBackupPassword() = _state.update { it.copy(smartBackupPassword = null) }

    fun cancelExport() {
        pendingExport = null
        _state.update { it.copy(exportAsk = null, exportError = null, activeExport = null) }
    }

    /** Every export re-asks for the master password; the encrypted backup is encrypted with it. */
    fun confirmExport(password: String) {
        val format = _state.value.exportAsk ?: return
        val options = _state.value.activeExport
        val pw = password.toCharArray()
        exportJob = launchCatching {
            _state.update { it.copy(busy = true, exportError = null) }
            try {
                val v = verify(pw)
                if (v is VaultResult.Failure) {
                    _state.update { it.copy(busy = false, exportError = v.error.toUserMessage()) }
                    return@launchCatching
                }
                val r = if (options != null && !_state.value.smartBackupExport) {
                    _state.update { it.copy(exportProgress = ExportProgress(0, 0, "Preparing")) }
                    buildExport.withOptions(options) { done, total ->
                        _state.update { it.copy(exportProgress = ExportProgress(done, total, "Preparing")) }
                    }
                } else if (_state.value.smartBackupExport && format == ExportFormat.V3) {
                    val smart = SmartBackupPassword.generate()
                    val chars = smart.toCharArray()
                    try {
                        when (val built = buildExport.encryptedV3WithPassword(chars)) {
                            is VaultResult.Success -> {
                                _state.update { it.copy(smartBackupPassword = smart) }
                                built
                            }
                            else -> built
                        }
                    } finally {
                        chars.fill('\u0000')
                    }
                } else {
                    buildExport(format)
                }
                when (r) {
                    is VaultResult.Success -> {
                        pendingExport = r.value
                        activityLog.record("Export", if (_state.value.smartBackupExport) "Encrypted backup with generated password" else (options?.kind?.label ?: format.label))
                        _state.update { it.copy(busy = false, exportAsk = null, exportProgress = null, activeExport = null) }
                        val date = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                        if (options != null && !_state.value.smartBackupExport) {
                            _events.send(BackupEvent.SaveFile(ExportFilter.fileName(options, date), ExportFilter.mime(options)))
                        } else {
                            _events.send(BackupEvent.SaveFile(EntryExporter.fileName(format, date), format.mime))
                        }
                    }
                    is VaultResult.Failure -> _state.update { it.copy(busy = false, exportProgress = null, exportError = r.error.toUserMessage()) }
                    VaultResult.Loading -> Unit
                }
            } finally {
                pw.fill('\u0000')
            }
        }
    }

    fun onExportTarget(uri: Uri?) {
        val text = pendingExport
        pendingExport = null
        if (uri == null || text == null) return
        launchCatching {
            _state.update { it.copy(busy = true) }
            try {
                io.writeText(uri, text)
                activityLog.record("Export completed", "File export written successfully")
                if (text.contains("BSRPRO", ignoreCase = true)) activityLog.record("Backup created", "Encrypted backup file saved")
                _events.send(BackupEvent.Message("Export saved"))
            } catch (e: VaultError) {
                _events.send(BackupEvent.Message(e.toUserMessage()))
            } finally {
                _state.update { it.copy(busy = false) }
            }
        }
    }

    // ───────────────────────── import ─────────────────────────

    /** Set by the "Import CSV with column mapping" button so the next picked file opens the mapping screen. */
    private var forceMapping = false

    fun requestMappedImport() { forceMapping = true }

    fun onImportFile(uri: Uri?) {
        val wantMap = forceMapping
        forceMapping = false
        if (uri == null) return
        launchCatching {
            _state.update { it.copy(busy = true) }
            try {
                val text = io.readText(uri)
                val kind = ImportParser.detectKind(text)
                when {
                    kind == SourceKind.V3_BACKUP || kind == SourceKind.DEVICE_BACKUP ->
                        _state.update { it.copy(busy = false, importing = ImportStage.NeedsBackupPassword(text)) }
                    kind == SourceKind.CSV && (wantMap || !hasPasswordColumn(text)) && !ImportParser.looksLikeContactsCsv(text) ->
                        openMapping(text)
                    else -> runPrepare(text, null)
                }
            } catch (e: VaultError) {
                _state.update { it.copy(busy = false) }
                _events.send(BackupEvent.Message(e.toUserMessage()))
            }
        }
    }

    private fun hasPasswordColumn(text: String): Boolean =
        CsvMapping.headers(text).any { h -> val l = h.lowercase(); l.contains("password") || l == "pass" || l == "pwd" }

    private fun openMapping(text: String) {
        val headers = CsvMapping.headers(text)
        if (headers.isEmpty()) {
            _state.update { it.copy(busy = false) }
            launchCatching { _events.send(BackupEvent.Message("The file is empty or unreadable.")) }
            return
        }
        val mapping = mappingStore.load(headers) ?: CsvMapping.autoDetect(headers)
        _state.update { it.copy(busy = false, importing = ImportStage.MapFields(text, headers, CsvMapping.sampleRow(text), mapping)) }
    }

    fun setColumn(field: MapField, column: Int?) = _state.update {
        val s = it.importing
        if (s is ImportStage.MapFields) {
            val next = if (column == null) s.mapping - field else s.mapping + (field to column)
            it.copy(importing = s.copy(mapping = next, error = null))
        } else it
    }

    fun setSaveTemplate(v: Boolean) = _state.update {
        val s = it.importing
        if (s is ImportStage.MapFields) it.copy(importing = s.copy(saveTemplate = v)) else it
    }

    fun confirmMapping() {
        val s = _state.value.importing as? ImportStage.MapFields ?: return
        launchCatching {
            _state.update { it.copy(busy = true) }
            try {
                val parsed = CsvMapping.parse(s.text, s.mapping)
                if (s.saveTemplate) mappingStore.save(s.headers, s.mapping)
                val plan = pro.babasitaram.vault.data.transfer.DuplicateDetector.plan(parsed.entries, repository.entries.value)
                val preview = ImportPreview(parsed.format, plan, emptyList(), parsed.skippedRows)
                val defaults = plan.withIndex().filter { it.value.duplicateOf != null }.associate { it.index to DuplicateAction.SKIP }
                _state.update { it.copy(busy = false, importing = ImportStage.Review(preview, defaults)) }
            } catch (e: VaultError) {
                _state.update { it.copy(busy = false, importing = s.copy(error = e.toUserMessage())) }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                _state.update { it.copy(busy = false, importing = s.copy(error = L.s(R.string.p18_backup_could_not_read_this_file))) }
            }
        }
    }

    fun submitBackupPassword(password: String) {
        val stage = _state.value.importing as? ImportStage.NeedsBackupPassword ?: return
        val pw = password.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true) }
            try {
                runPrepare(stage.text, pw)
            } finally {
                pw.fill('\u0000')
            }
        }
    }

    private suspend fun runPrepare(text: String, backupPassword: CharArray?) {
        when (val r = prepare(text, backupPassword)) {
            is VaultResult.Success -> {
                val defaults = r.value.items.withIndex().filter { it.value.duplicateOf != null }.associate { it.index to DuplicateAction.SKIP }
                _state.update { it.copy(busy = false, importing = ImportStage.Review(r.value, defaults)) }
            }
            is VaultResult.Failure -> {
                val msg = r.error.toUserMessage()
                val stage = _state.value.importing
                if (stage is ImportStage.NeedsBackupPassword || backupPassword != null) {
                    _state.update { it.copy(busy = false, importing = ImportStage.NeedsBackupPassword(text, msg)) }
                } else {
                    _state.update { it.copy(busy = false, importing = ImportStage.Idle) }
                    _events.send(BackupEvent.Message(msg))
                }
            }
            VaultResult.Loading -> Unit
        }
    }

    fun setAction(index: Int, action: DuplicateAction) = updateReview { r ->
        if (r.applyToAll) {
            r.copy(actions = r.preview.items.withIndex().filter { it.value.duplicateOf != null }.associate { it.index to action })
        } else r.copy(actions = r.actions + (index to action))
    }

    fun setApplyToAll(v: Boolean) = updateReview { it.copy(applyToAll = v) }

    fun setImportMode(mode: ImportMode) = updateReview { it.copy(mode = mode) }

    fun askConfirmImport() = updateReview { it.copy(confirm = true) }

    fun dismissConfirmImport() = updateReview { it.copy(confirm = false) }

    fun setAllDuplicates(action: DuplicateAction) = updateReview { r ->
        r.copy(actions = r.preview.items.withIndex().filter { it.value.duplicateOf != null }.associate { it.index to action })
    }

    private fun updateReview(f: (ImportStage.Review) -> ImportStage.Review) = _state.update {
        val s = it.importing
        if (s is ImportStage.Review) it.copy(importing = f(s)) else it
    }

    fun cancelImport() = _state.update { it.copy(importing = ImportStage.Idle, busy = false) }

    fun confirmImport() {
        val s = _state.value.importing as? ImportStage.Review ?: return
        updateReview { it.copy(confirm = false) }
        launchCatching {
            _state.update { it.copy(busy = true) }
            when (val r = commit(s.preview, s.actions, mode = s.mode)) {
                is VaultResult.Success -> {
                    activityLog.record("Import completed", "${r.value} records imported")
                    _state.update { it.copy(busy = false, importing = ImportStage.Idle) }
                    _events.send(BackupEvent.Message("Imported ${r.value} ${if (r.value == 1) "entry" else "entries"}"))
                }
                is VaultResult.Failure -> {
                    _state.update { it.copy(busy = false) }
                    _events.send(BackupEvent.Message(r.error.toUserMessage()))
                }
                VaultResult.Loading -> Unit
            }
        }
    }


    /** Start the explicit destructive restore flow from the app-managed backup location. */
    fun startFolderRestore() {
        // Scan selected backup folder off the main thread. The password prompt is shown only after
        // a real backup is found; actual restore progress is rendered on the main Backup screen.
        launchCatching {
            _state.update { it.copy(busy = true, restoreStage = RestoreStage.Idle, noBackupFound = false) }
            val file = try {
                autoBackup.findRestorableBackup()
            } finally {
                _state.update { it.copy(busy = false) }
            }
            if (file == null || !file.isFile || file.length() <= 0L) {
                _state.update { it.copy(noBackupFound = true, backupFileAvailable = false, backupRecordCount = 0) }
                return@launchCatching
            }
            pendingRestoreFile?.delete()
            pendingRestoreFile = file
            _state.update { it.copy(
                restoreAsk = true,
                restoreError = null,
                restoreStage = RestoreStage.Idle,
                backupFileAvailable = true,
                backupFileName = "BSRPRO.Vault",
                backupFileSizeBytes = file.length()
            ) }
        }
    }

    fun dismissNoBackup() = _state.update { it.copy(noBackupFound = false) }

    fun cancelFolderRestore() {
        pendingRestoreFile?.delete()
        pendingRestoreFile = null
        _state.update { it.copy(restoreAsk = false, restoreError = null, restoreStage = RestoreStage.Idle) }
    }

    fun confirmFolderRestore(password: String) {
        val file = pendingRestoreFile ?: return
        val pw = password.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, restoreAsk = false, restoreError = null, restoreStage = RestoreStage.Restoring) }
            try {
                val backupText = withContext(kotlinx.coroutines.Dispatchers.IO) {
                    require(file.isFile && file.length() in 1..(25L * 1024L * 1024L)) { "Backup is missing, empty, or too large" }
                    file.readText(Charsets.UTF_8)
                }
                when (val result = restoreTransaction(backupText, pw)) {
                    is VaultResult.Success -> {
                        _state.update { it.copy(
                            busy = false,
                            restoreAsk = false,
                            restoreError = null,
                            restoreStage = RestoreStage.Complete(result.value),
                            backupRecordCount = result.value
                        ) }
                        activityLog.record("Restore backup", "${result.value} entries restored")
                        pendingRestoreFile?.delete(); pendingRestoreFile = null
                    }
                    is VaultResult.Failure -> {
                        val message = result.error.toUserMessage()
                        _state.update { it.copy(
                            busy = false,
                            restoreAsk = false,
                            restoreError = message,
                            restoreStage = RestoreStage.Error(message)
                        ) }
                    }
                    VaultResult.Loading -> _state.update { it.copy(busy = true, restoreAsk = false, restoreStage = RestoreStage.Restoring) }
                }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                val message = e.message ?: L.s(R.string.p18_backup_could_not_read_backup)
                _state.update { it.copy(busy = false, restoreAsk = false, restoreError = message, restoreStage = RestoreStage.Error(message)) }
            } finally { pw.fill('\u0000') }
        }
    }

    // ───────────────────────── auto-backup ─────────────────────────

    /**
     * Folder chosen in Backup settings. Previously only the URI was saved ("Existing backup files were not changed"),
     * so a backup already sitting in that folder was never offered for restore. Now the folder is scanned:
     *  - empty vault + backup opens with the current master password  -> restored automatically,
     *  - vault has data + backup opens                                -> merge review (duplicates skipped by default),
     *  - backup uses a different password                             -> asks for that password, then review.
     * The backup file itself is never modified here.
     */
    fun setBackupFolder(uri: Uri) {
        launchCatching {
            settings.update { it.copy(backupFolderUri = uri.toString(), autoBackupEnabled = true) }
            autoBackup.schedule()
            _state.update { it.copy(
                busy = true,
                backupFolderLabel = resolveFolderLabel(uri.toString()),
                backupFileAvailable = false,
                backupFileSizeBytes = 0L,
                backupRecordCount = 0,
                restoreStage = RestoreStage.Idle
            ) }
            val probe = try {
                autoBackup.probeFolderBackup()
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (e: Exception) {
                null
            } finally {
                _state.update { it.copy(busy = false) }
            }
            if (probe == null) {
                _state.update { it.copy(backupFileAvailable = false, backupFileSizeBytes = 0L, backupRecordCount = 0) }
                _events.send(BackupEvent.Message(L.s(R.string.bk_folder_saved_no_backup)))
                return@launchCatching
            }
            _state.update { it.copy(backupFileAvailable = true, backupFileName = "BSRPRO.Vault", backupFileSizeBytes = probe.sizeBytes, backupRecordCount = probe.recordCount) }
            val vaultIsEmpty = repository.entries.value.isEmpty() && repository.trashedEntries.value.isEmpty()
            when {
                probe.opensWithCurrentPassword && vaultIsEmpty -> {
                    autoBackup.armAutoImport()
                    val n = autoBackup.autoImportIfVaultEmpty()
                    val msg = if (n > 0) L.s(R.string.p18_save_router_restored_records_from_your_backup, n) else L.s(R.string.bk_folder_saved_no_backup)
                    if (n > 0) activityLog.record("Restore backup", "$n records restored from the selected backup folder")
                    _events.send(BackupEvent.Message(msg))
                }
                probe.opensWithCurrentPassword -> {
                    _state.update { it.copy(busy = true) }
                    autoBackup.withSessionPassword { pw -> runPrepare(probe.text, pw) }
                    val review = _state.value.importing as? ImportStage.Review
                    if (review != null && review.preview.newCount == 0) {
                        // Same data as the vault already has (e.g. the folder holds this vault's own backup).
                        _state.update { it.copy(importing = ImportStage.Idle, busy = false) }
                        _events.send(BackupEvent.Message(L.s(R.string.bk_folder_backup_already_synced)))
                    } else {
                        _events.send(BackupEvent.Message(L.s(R.string.bk_folder_backup_review)))
                    }
                }
                else -> {
                    _state.update { it.copy(importing = ImportStage.NeedsBackupPassword(probe.text)) }
                    _events.send(BackupEvent.Message(L.s(R.string.bk_folder_backup_other_password)))
                }
            }
        }
    }

    fun setAutoBackup(enabled: Boolean) {
        launchCatching {
            settings.update { it.copy(autoBackupEnabled = enabled) }
            if (enabled) {
                autoBackup.schedule()
                when (val r = autoBackup.backupNow()) {
                    is VaultResult.Success -> _events.send(BackupEvent.Message("Backup saved to ${r.value}"))
                    is VaultResult.Failure -> _events.send(BackupEvent.Message("Auto-backup is on, but the first backup failed"))
                    VaultResult.Loading -> Unit
                }
            } else autoBackup.cancel()
        }
    }

    fun backupNow() {
        launchCatching {
            _state.update { it.copy(busy = true) }
            val msg = when (val r = autoBackup.backupNow()) {
                is VaultResult.Success -> "Backup saved to ${r.value}"
                is VaultResult.Failure -> r.error.toUserMessage()
                VaultResult.Loading -> ""
            }
            _state.update { it.copy(busy = false) }
            if (msg.isNotEmpty()) _events.send(BackupEvent.Message(msg))
        }
    }
}
