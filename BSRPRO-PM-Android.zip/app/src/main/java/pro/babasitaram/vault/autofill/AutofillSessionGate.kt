package pro.babasitaram.vault.autofill

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import dagger.hilt.android.qualifiers.ApplicationContext
import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.di.ApplicationScope
import pro.babasitaram.vault.domain.repository.SettingsRepository
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Short-lived authentication window used only by Android Autofill.
 * It never stores credentials; the vault session remains the source of decrypted data.
 * Screen-off immediately invalidates the Autofill window.
 *
 * Fix (smooth autofill): pehle ye window sirf autofill ke andar khulti thi, isliye app me master password /
 * biometric se unlock karne ke baad bhi autofill dobara "Unlock" maangta tha. Ab jaise hi vault unlock hota hai
 * (koi bhi raasta: app unlock, autofill unlock, process-death restore) window khul jaati hai; vault lock hote hi band.
 */
@Singleton
class AutofillSessionGate @Inject constructor(
    @ApplicationContext private val context: Context,
    private val session: SessionKeyStore,
    private val settings: SettingsRepository,
    @ApplicationScope private val scope: CoroutineScope,
) {
    @Volatile private var expiresAtElapsedMs: Long = 0L
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> clear()
                // Phone ko user ne device PIN/fingerprint se unlock kiya = user maujood hai (Google PM jaisa).
                // Vault session abhi valid ho to window dobara khol do, taaki har screen-lock ke baad dubara unlock na maange.
                // "Until screen locks" mode me ye nahi hota (uska matlab hi screen-lock par band rehna hai).
                Intent.ACTION_USER_PRESENT -> scope.launch {
                    val seconds = settings.current().autofillSessionSeconds
                    if (seconds != VaultSettings.AUTOFILL_UNTIL_SCREEN_LOCK && session.hasValidSession()) touch(seconds)
                }
            }
        }
    }

    init {
        // System broadcasts hain; NOT_EXPORTED = doosre apps fake SCREEN_OFF/USER_PRESENT bhej kar gate nahi chhed sakte
        androidx.core.content.ContextCompat.registerReceiver(
            context,
            receiver,
            IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_USER_PRESENT)
            },
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )
        // Vault ki unlock state ke saath sync: unlock -> window open, lock -> window band.
        scope.launch {
            session.isUnlocked.collectLatest { unlocked ->
                if (unlocked) {
                    // Vault unlock hua (kisi bhi raaste se) -> autofill window khol do
                    touch(settings.current().autofillSessionSeconds)
                } else {
                    clear()
                }
            }
        }
    }

    fun isValid(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Boolean {
        val expiry = expiresAtElapsedMs
        return expiry > nowElapsedMs
    }

    fun touch(seconds: Int = 5 * 60, nowElapsedMs: Long = SystemClock.elapsedRealtime()) {
        expiresAtElapsedMs = if (seconds == VaultSettings.AUTOFILL_UNTIL_SCREEN_LOCK) {
            Long.MAX_VALUE
        } else {
            nowElapsedMs + seconds.coerceIn(60, 30 * 60) * 1000L
        }
    }

    fun clear() {
        expiresAtElapsedMs = 0L
    }
}

