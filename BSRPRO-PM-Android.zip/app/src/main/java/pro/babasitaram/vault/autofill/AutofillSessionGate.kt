package pro.babasitaram.vault.autofill

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import pro.babasitaram.vault.core.crypto.SessionKeyStore

/**
 * Compatibility facade for Autofill callers.
 *
 * Autofill no longer owns a second authentication timer. The vault's SessionKeyStore is the single authoritative authentication/session state.
 * This class intentionally has no independent expiry clock.
 */
@Singleton
class AutofillSessionGate @Inject constructor(
    @ApplicationContext private val context: Context,
    private val session: SessionKeyStore,
) {
    fun isValid(nowElapsedMs: Long = android.os.SystemClock.elapsedRealtime()): Boolean =
        session.hasValidSession(nowElapsedMs)

    /** Refreshing Autofill must never extend the vault session. */
    fun touch(seconds: Int = 0, nowElapsedMs: Long = android.os.SystemClock.elapsedRealtime()) {
        // Intentionally no-op: the vault session owner controls the expiry.
        // Keep the API for source compatibility with existing Autofill call sites.
    }

    fun clear() {
        // Intentionally no-op: only LockVaultUseCase may lock the vault/session.
    }
}
