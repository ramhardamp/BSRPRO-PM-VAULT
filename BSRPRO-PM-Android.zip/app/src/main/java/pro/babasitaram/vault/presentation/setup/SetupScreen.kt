@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.setup

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Card
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.Alignment
import androidx.activity.result.contract.ActivityResultContracts.CreateDocument
import pro.babasitaram.vault.presentation.settings.RecoveryKeyPdf
import pro.babasitaram.vault.presentation.settings.printRecoveryKey
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.presentation.components.PasswordField
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import pro.babasitaram.vault.core.util.L

@Composable
fun SetupScreen(vm: SetupViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var backupPassword by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val recoveryPdf = rememberLauncherForActivityResult(CreateDocument("application/pdf")) { uri ->
        val key = state.recoveryKey
        if (uri != null && key != null) {
            runCatching { RecoveryKeyPdf.write(context, uri, key) }
                .onFailure {
                    android.widget.Toast.makeText(context, context.getString(pro.babasitaram.vault.R.string.p17_recovery_save_failed), android.widget.Toast.LENGTH_LONG).show()
                }
        }
    }

    val backupTreePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }.onSuccess { vm.onBackupFolderSelected(uri, password) }
            .onFailure { android.widget.Toast.makeText(context, context.getString(R.string.setup_folder_permission_denied), android.widget.Toast.LENGTH_LONG).show() }
    }
    Scaffold { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            androidx.compose.foundation.layout.Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(pro.babasitaram.vault.R.drawable.brand_logo),
                    contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_brand_accessibility),
                    modifier = Modifier.size(88.dp)
                )
            }
            Text(
                androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_148),
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.fillMaxWidth()
            )
            Text(
                stringResource(R.string.p18_setup_your_master_password_encrypts_everyt),
                style = MaterialTheme.typography.bodyMedium
            )
            // Login/setup ka single backup entry-point: user sirf backup folder choose karta hai.
            // Isi folder ki BSRPRO.Vault file ko Create vault ke time auto-restore kiya jata hai.
            PasswordField(
                password, { password = it }, stringResource(R.string.p17_loc_074),
                showStrength = true, enabled = !state.busy,
                imeAction = androidx.compose.ui.text.input.ImeAction.Next
            )
            PasswordField(
                confirm, { confirm = it }, stringResource(R.string.p18_setup_confirm_master_password),
                enabled = !state.busy,
                // Keyboard Done = Create vault
                onImeAction = { if (!state.busy && password.isNotEmpty()) vm.create(password, confirm) }
            )
            Text(
                L.s(R.string.p18_setup_minimum_characters_with_upper_lower, PasswordStrength.MIN_MASTER_LENGTH),
                style = MaterialTheme.typography.labelSmall
            )
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            Button(
                onClick = { vm.create(password, confirm) },
                enabled = !state.busy && password.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (state.busy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) else Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_149))
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.setup_backup_folder_title), style = MaterialTheme.typography.titleMedium)
                    Text(
                        stringResource(if (state.backupFolderUri.isBlank()) R.string.setup_backup_folder_suggested else R.string.setup_backup_folder_saved),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (state.backupFound) {
                        Text(
                            stringResource(R.string.setup_backup_found_hint),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    OutlinedButton(onClick = { backupTreePicker.launch(null) }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(if (state.backupFolderUri.isBlank()) R.string.bk_choose_folder else R.string.bk_change_folder))
                    }
                }
            }
        }
    }

    state.recoveryKey?.let { key ->
        AlertDialog(
            onDismissRequest = { vm.dismissRecoveryKey() },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_151), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_152))
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                key.chunked(4).joinToString(" "),
                                modifier = Modifier.weight(1f),
                                style = MaterialTheme.typography.titleMedium
                            )
                            IconButton(
                                onClick = {
                                    vm.copySecret(key, "Recovery key")
                                }
                            ) { Icon(Icons.Default.ContentCopy, "Copy recovery key") }
                        }
                    }
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_153), color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = {
                TextButton(onClick = { recoveryPdf.launch(context.getString(pro.babasitaram.vault.R.string.p17_loc_018)) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_019)) }
            },
            dismissButton = {
                TextButton(onClick = { printRecoveryKey(context, key) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_020)) }
            }
        )
    }

    if (state.awaitingBackupPassword) {
        AlertDialog(
            onDismissRequest = { vm.cancelRestore(); backupPassword = "" },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_154), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (state.backupMismatch) stringResource(R.string.setup_backup_password_mismatch)
                        else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_155)
                    )
                    PasswordField(backupPassword, { backupPassword = it }, stringResource(R.string.p17_loc_154))
                    state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = { vm.restore(backupPassword); backupPassword = "" },
                    enabled = backupPassword.isNotEmpty() && !state.busy
                ) { Text(stringResource(R.string.p15_restore)) }
            },
            dismissButton = {
                Row {
                    if (state.backupMismatch) {
                        TextButton(
                            onClick = { vm.createWithoutRestore(password, confirm); backupPassword = "" },
                            enabled = !state.busy && password.isNotEmpty()
                        ) { Text(stringResource(R.string.setup_create_new_anyway)) }
                    }
                    TextButton(onClick = { vm.cancelRestore(); backupPassword = "" }) { Text(stringResource(R.string.p15_cancel)) }
                }
            }
        )
    }
}
