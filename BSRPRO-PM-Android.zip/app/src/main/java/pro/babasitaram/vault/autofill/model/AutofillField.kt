package pro.babasitaram.vault.autofill.model

import android.view.autofill.AutofillId

enum class AutofillFieldType { USERNAME, PASSWORD, PIN, NEW_PASSWORD, OTP }

/** One classified input of the screen being filled. [value] is only populated for save requests. */
data class AutofillField(
    val id: AutofillId,
    val type: AutofillFieldType,
    val focused: Boolean = false,
    val value: String? = null
)

/**
 * Framework-free description of a single view. Classification works on this type
 * (not on AssistStructure.ViewNode) so it can be unit-tested on the JVM.
 */
data class FieldHints(
    val autofillHints: List<String> = emptyList(),
    val idEntry: String? = null,
    val hint: String? = null,
    val inputType: Int = 0,
    val htmlType: String? = null,
    val htmlName: String? = null,
    val htmlId: String? = null,
    val htmlAutocomplete: String? = null,
    val htmlPlaceholder: String? = null,
    val maxLength: Int = -1
)

/** Result of parsing an AssistStructure. */
data class ParsedStructure(
    val packageName: String,
    val webDomain: String?,
    val webScheme: String?,
    val fields: List<AutofillField>
) {
    val usernameFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.USERNAME }
    val passwordFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.PASSWORD || it.type == AutofillFieldType.NEW_PASSWORD }
    val pinFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.PIN }
    val secretFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.PASSWORD || it.type == AutofillFieldType.PIN || it.type == AutofillFieldType.NEW_PASSWORD }
    val otpFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.OTP }

    /** Fields that can receive an existing credential (new-password fields never do). */
    val fillableFields: List<AutofillField>
        get() = fields.filter { it.type != AutofillFieldType.NEW_PASSWORD }

    val isFillable: Boolean get() = fillableFields.isNotEmpty()
    val isOtpOnly: Boolean get() = otpFields.isNotEmpty() && fields.all { it.type == AutofillFieldType.OTP }
}
