package pro.babasitaram.vault.presentation.theme

import androidx.compose.ui.graphics.Color

/**
 * BSRPRO brand palette. Keep brand identity here; screens should consume
 * MaterialTheme.colorScheme roles instead of inventing local brand colors.
 *
 * Purple = core BSRPRO identity. Gold = premium/security accent.
 * Status colors (success/warning/error) remain semantic and are not replaced
 * by brand colors.
 */
val BrandPrimaryLight = Color(0xFF5B2FB8)
val BrandPrimaryDark = Color(0xFFC5A6FF)

val BrandPrimaryContainerLight = Color(0xFFEDE3FF)
val BrandPrimaryContainerDark = Color(0xFF432A66)

val BrandSecondaryLight = Color(0xFF6C5A80)
val BrandSecondaryDark = Color(0xFFD4BEE2)
val BrandSecondaryContainerLight = Color(0xFFE9DDF2)
val BrandSecondaryContainerDark = Color(0xFF4D3958)

val BrandGoldLight = Color(0xFFD99A21)
val BrandGoldDark = Color(0xFFF2C45F)
val BrandGoldContainerLight = Color(0xFFFCE8B5)
val BrandGoldContainerDark = Color(0xFF5A4516)

val LightBackground = Color(0xFFFAF8FF)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEEE8F2)
val LightOnBackground = Color(0xFF211A2B)
val LightOnSurface = Color(0xFF211A2B)
val LightOnSurfaceVariant = Color(0xFF655D70)
val LightOutline = Color(0xFF807788)
val LightOutlineVariant = Color(0xFFD8CFDF)

val DarkBackground = Color(0xFF100D18)
val DarkSurface = Color(0xFF181321)
val DarkSurfaceVariant = Color(0xFF292330)
val DarkOnBackground = Color(0xFFF5EFFC)
val DarkOnSurface = Color(0xFFF5EFFC)
val DarkOnSurfaceVariant = Color(0xFFC8BECE)
val DarkOutline = Color(0xFF958B9D)
val DarkOutlineVariant = Color(0xFF413747)

val LightInverseSurface = Color(0xFF352F3C)
val LightInverseOnSurface = Color(0xFFF8F0FF)
val DarkInverseSurface = Color(0xFFF5EFFC)
val DarkInverseOnSurface = Color(0xFF352F3C)

val BrandOnPrimaryLight = Color(0xFFFFFFFF)
val BrandOnPrimaryDark = Color(0xFF1C1328)
val BrandOnPrimaryContainerLight = Color(0xFF24152F)
val BrandOnPrimaryContainerDark = Color(0xFFF0DFFF)

val BrandOnSecondaryLight = Color(0xFFFFFFFF)
val BrandOnSecondaryDark = Color(0xFF34213F)
val BrandOnSecondaryContainerLight = Color(0xFF24152F)
val BrandOnSecondaryContainerDark = Color(0xFFEFDDFB)

val BrandOnGoldLight = Color(0xFF2A1B05)
val BrandOnGoldDark = Color(0xFF2A1B05)
val BrandOnGoldContainerLight = Color(0xFF3A2700)
val BrandOnGoldContainerDark = Color(0xFFFFE9A9)
