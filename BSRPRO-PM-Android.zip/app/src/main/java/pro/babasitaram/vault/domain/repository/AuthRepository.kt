package pro.babasitaram.vault.domain.repository

import pro.babasitaram.vault.core.security.LockoutState

interface AuthRepository {
    suspend fun vaultExists(): Boolean
    suspend fun lockoutState(): LockoutState
    fun remainingAttempts(state: LockoutState): Int

    /** Throws VaultError.RateLimited while locked out. */
    suspend fun checkAllowed()
    suspend fun recordFailure(): LockoutState
    suspend fun recordSuccess()

    suspend fun hasBiometricCredential(): Boolean
    suspend fun saveBiometricCredential(password: CharArray)
    suspend fun loadBiometricCredential(): CharArray?
    suspend fun clearBiometricCredential()
}
