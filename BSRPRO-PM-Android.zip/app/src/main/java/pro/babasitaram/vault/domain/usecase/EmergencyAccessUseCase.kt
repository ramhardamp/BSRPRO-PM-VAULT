package pro.babasitaram.vault.domain.usecase

import java.security.SecureRandom
import javax.inject.Inject
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching

/** Local 72-hour emergency recovery matching the extension's offline threat model.
 * The master password is stored only as ciphertext; the 24-character emergency key is never persisted.
 */
class EmergencyAccessUseCase @Inject constructor(
    private val settings: SettingsRepository,
    private val session: SessionKeyStore,
    private val unlockVault: UnlockVaultUseCase
) {
    data class Status(
        val configured: Boolean,
        val requestTime: Long,
        val active: Boolean
    ) {
        val unlockAt: Long get() = requestTime + WAIT_MS
        val pending: Boolean get() = requestTime > 0L
        val ready: Boolean get() = pending && System.currentTimeMillis() >= unlockAt
    }

    suspend fun status(): Status {
        val s = settings.current()
        return Status(
            configured = s.emergencyEncryptedMaster.isNotBlank(),
            requestTime = s.emergencyRequestTime,
            active = s.emergencyActive
        )
    }

    suspend fun setup(): VaultResult<String> = vaultCatching {
        val key = generateKey()
        val encoded = key.toCharArray()
        try {
            val ciphertext = session.withPassword { master ->
                val masterText = String(master)
                VaultCrypto.encrypt(masterText, encoded)
            }
            settings.update {
                it.copy(
                    emergencyEncryptedMaster = ciphertext,
                    emergencyRequestTime = 0L,
                    emergencyActive = false
                )
            }
            key
        } finally {
            encoded.fill('\u0000')
        }
    }

    suspend fun request(key: String): VaultResult<Long> = vaultCatching {
        val clean = validateKey(key)
        val current = settings.current()
        if (current.emergencyEncryptedMaster.isBlank()) {
            throw VaultError.Validation("Emergency access is not configured")
        }
        val chars = clean.toCharArray()
        try {
            VaultCrypto.decrypt(current.emergencyEncryptedMaster, chars)
        } finally {
            chars.fill('\u0000')
        }
        val now = System.currentTimeMillis()
        settings.update {
            it.copy(emergencyRequestTime = now, emergencyActive = false)
        }
        now + WAIT_MS
    }

    suspend fun unlock(key: String): VaultResult<Unit> = vaultCatching {
        val clean = validateKey(key)
        val current = settings.current()
        if (current.emergencyEncryptedMaster.isBlank() || current.emergencyRequestTime <= 0L) {
            throw VaultError.Validation("No pending emergency request")
        }
        val unlockAt = current.emergencyRequestTime + WAIT_MS
        if (System.currentTimeMillis() < unlockAt) {
            throw VaultError.Validation("Emergency unlock is not ready yet")
        }
        val chars = clean.toCharArray()
        val master = try {
            VaultCrypto.decrypt(current.emergencyEncryptedMaster, chars).toCharArray()
        } finally {
            chars.fill('\u0000')
        }
        try {
            when (val result = unlockVault(master)) {
                is VaultResult.Success -> {
                    settings.update { it.copy(emergencyActive = true) }
                }
                is VaultResult.Failure -> throw result.error
                VaultResult.Loading -> throw VaultError.Validation("Vault unlock still in progress")
            }
        } finally {
            master.fill('\u0000')
        }
    }

    suspend fun cancel(): VaultResult<Unit> = vaultCatching {
        requireUnlocked()
        settings.update { it.copy(emergencyRequestTime = 0L, emergencyActive = false) }
    }

    suspend fun revoke(): VaultResult<Unit> = vaultCatching {
        requireUnlocked()
        settings.update {
            it.copy(
                emergencyEncryptedMaster = "",
                emergencyRequestTime = 0L,
                emergencyActive = false
            )
        }
    }

    private fun requireUnlocked() {
        if (!session.isUnlocked.value) throw VaultError.VaultLocked
    }

    private fun validateKey(value: String): String {
        val clean = value.filter { it.isLetterOrDigit() }.uppercase()
        if (clean.length != KEY_LENGTH) {
            throw VaultError.Validation("Emergency key must be 24 characters")
        }
        return clean
    }

    private fun generateKey(): String {
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val random = SecureRandom()
        return buildString(KEY_LENGTH) {
            repeat(KEY_LENGTH) { append(alphabet[random.nextInt(alphabet.length)]) }
        }
    }

    companion object {
        const val KEY_LENGTH = 24
        const val WAIT_MS = 72L * 60L * 60L * 1000L
    }
}
