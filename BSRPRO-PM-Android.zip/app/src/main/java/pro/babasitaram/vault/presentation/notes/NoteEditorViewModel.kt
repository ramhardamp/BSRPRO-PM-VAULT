package pro.babasitaram.vault.presentation.notes

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.Folder
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

 @Stable
data class NoteEditorState(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val category: String = "other",
    val folders: List<Folder> = emptyList(),
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: String? = null,
    val existing: VaultEntry? = null
)

@HiltViewModel
class NoteEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase
) : ViewModel() {
    private val id = savedStateHandle.get<String>("id").orEmpty()
    private val existing = id.takeIf { it.isNotBlank() }?.let(repository::entry)
    private val _state = MutableStateFlow(
        NoteEditorState(
            id = existing?.id.orEmpty(),
            title = existing?.title.orEmpty(),
            content = existing?.notes.orEmpty(),
            category = existing?.category ?: "other",
            folders = repository.folders.value,
            existing = existing
        )
    )
    val state: StateFlow<NoteEditorState> = _state.asStateFlow()

    fun setTitle(value: String) = _state.update { it.copy(title = value, error = null) }
    fun setContent(value: String) = _state.update { it.copy(content = value, error = null) }
    fun setCategory(value: String) = _state.update { it.copy(category = value, error = null) }

    fun insertToken(token: String) = _state.update { state ->
        val value = state.content
        val replacement = when (token) {
            "- " -> if (value.isBlank()) "- " else value + "\n- "
            "## " -> if (value.isBlank()) "## " else value + "\n## "
            else -> value + token
        }
        state.copy(content = replacement, error = null)
    }

    fun save() {
        val s = _state.value
        if (s.title.isBlank()) {
            _state.update { it.copy(error = L.s(R.string.p18_note_editor_enter_a_title)) }
            return
        }
        if (s.content.isBlank()) {
            _state.update { it.copy(error = L.s(R.string.p18_note_editor_enter_note_content)) }
            return
        }
        launchCatching {
            _state.update { it.copy(saving = true, error = null) }
            val entry = (s.existing ?: VaultEntry()).copy(
                title = s.title.trim(),
                notes = s.content,
                category = s.category,
                recordType = "note",
                isNote = true,
                url = "",
                username = "",
                password = "",
                totp = ""
            )
            when (val result = saveEntry(entry, s.existing)) {
                is VaultResult.Success -> _state.update { it.copy(saving = false, saved = true) }
                is VaultResult.Failure -> _state.update { it.copy(saving = false, error = result.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }
}
