package pro.babasitaram.vault.core.model

import kotlinx.serialization.Serializable

@Serializable
data class Folder(
    val id: String = "",
    val name: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L
)
