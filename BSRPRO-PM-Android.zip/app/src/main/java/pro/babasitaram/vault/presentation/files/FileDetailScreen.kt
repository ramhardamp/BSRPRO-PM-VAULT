@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.files

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.lifecycle.HiltViewModel
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import javax.inject.Inject
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.L
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.launchCatching
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow

@HiltViewModel
class FileDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    repository: VaultRepository,
    private val deleteEntry: DeleteEntryUseCase
) : ViewModel() {
    val id: String = savedStateHandle.get<String>("id").orEmpty()
    val entry: StateFlow<VaultEntry?> = repository.entries
        .map { list -> list.firstOrNull { it.id == id && it.deletedAt == 0L } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), repository.entry(id))
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun delete(onDone: () -> Unit) {
        launchCatching {
            when (val result = deleteEntry(id)) {
                is VaultResult.Success -> { _messages.send(L.s(pro.babasitaram.vault.R.string.p20_moved_to_bin)); onDone() }
                is VaultResult.Failure -> _messages.send(result.error.message ?: L.s(pro.babasitaram.vault.R.string.p20_could_not_delete))
                VaultResult.Loading -> Unit
            }
        }
    }
}

@Composable
fun FileDetailScreen(
    onBack: () -> Unit,
    vm: FileDetailViewModel = hiltViewModel()
) {
    val entry by vm.entry.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    LaunchedEffect(entry == null) { if (entry == null) onBack() }
    if (entry == null) return
    val e = entry!!
    val primaryUriField = e.customFields.firstOrNull {
        it.k.equals("file_uri", true) || it.k.startsWith("attachment_uri_", true)
    }
    val uri = primaryUriField?.v?.let(Uri::parse)
    val suffix = primaryUriField?.k?.removePrefix("attachment_uri_")
    val name = e.fileField("file_name").orEmpty().ifBlank {
        e.customFields.firstOrNull { it.k.equals("attachment_name_$suffix", true) }?.v.orEmpty()
    }.ifBlank { e.title }.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.file_detail_default_name) }
    val mime = e.fileField("mime_type").orEmpty().ifBlank {
        e.customFields.firstOrNull { it.k.equals("attachment_mime_$suffix", true) }?.v.orEmpty()
    }.ifBlank { "application/octet-stream" }
    val size = e.fileField("file_size")?.toLongOrNull() ?: querySize(context, uri)
    val sizeUnavailable = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.file_detail_size_unavailable)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(name, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } },
                actions = {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("File name", style = MaterialTheme.typography.labelMedium)
            Text(name, style = androidx.compose.material3.MaterialTheme.typography.bodyLarge)
            Text("Type", style = MaterialTheme.typography.labelMedium)
            Text(mime)
            Text("Size", style = MaterialTheme.typography.labelMedium)
            Text(formatSize(size, sizeUnavailable))
            Button(
                onClick = { openFile(context, uri, mime) },
                enabled = uri != null,
                modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.FolderOpen, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_068)) }
            Button(
                onClick = { shareFile(context, uri, mime) },
                enabled = uri != null,
                modifier = Modifier.fillMaxWidth()
            ) { Icon(Icons.Default.Download, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_123)) }
            TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033))
            }
        }
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_124)) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_125)) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.delete(onBack) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p15_cancel)) } }
        )
    }
}

private fun querySize(context: Context, uri: Uri?): Long {
    if (uri == null) return 0L
    return runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && !c.isNull(i)) c.getLong(i) else 0L
            } else 0L
        } ?: 0L
    }.getOrDefault(0L)
}

private fun openFile(context: Context, uri: Uri?, mime: String) {
    if (uri == null) return
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }
}

private fun shareFile(context: Context, uri: Uri?, mime: String) {
    if (uri == null) return
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }, "Export file"))
}

private fun formatSize(size: Long, sizeUnavailable: String): String = when {
    size <= 0 -> sizeUnavailable
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> "%.1f KB".format(size / 1024f)
    size < 1024 * 1024 * 1024 -> "%.1f MB".format(size / (1024f * 1024f))
    else -> "%.1f GB".format(size / (1024f * 1024f * 1024f))
}
