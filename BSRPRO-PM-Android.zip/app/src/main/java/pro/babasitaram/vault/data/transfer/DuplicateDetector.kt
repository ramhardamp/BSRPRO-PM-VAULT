package pro.babasitaram.vault.data.transfer

import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils

data class ImportItem(val entry: VaultEntry, val duplicateOf: VaultEntry?)

enum class DuplicateAction { SKIP, REPLACE, KEEP_BOTH }

enum class ImportMode { MERGE, REPLACE }

/**
 * Target-aware duplicate identity shared with the browser extension:
 * canonical ID first, then Website/App targets + username. Password is never
 * part of identity because it can legitimately change during an update.
 */
object DuplicateDetector {
    fun find(item: VaultEntry, existing: List<VaultEntry>): VaultEntry? = existing.firstOrNull { e ->
        if (item.isNote || e.isNote) {
            return@firstOrNull item.isNote && e.isNote &&
                e.title.trim().equals(item.title.trim(), ignoreCase = true) &&
                e.notes == item.notes
        }

        if (item.id.isNotBlank() && e.id.isNotBlank() && item.id == e.id) return@firstOrNull true

        val sameUser = e.username.trim().equals(item.username.trim(), ignoreCase = true)
        if (!sameUser) return@firstOrNull false

        val itemWebsite = UrlUtils.domainOf(item.url)
        val existingWebsite = UrlUtils.domainOf(e.url)
        val sameWebsite = itemWebsite.isNotBlank() && existingWebsite.isNotBlank() &&
            itemWebsite.equals(existingWebsite, ignoreCase = true)

        val itemPkg = item.appPackage.trim().lowercase()
        val existingPkg = e.appPackage.trim().lowercase()
        val sameApp = itemPkg.isNotBlank() && existingPkg.isNotBlank() && itemPkg == existingPkg

        // Linked Website + App: both targets identify the same credential.
        if (sameWebsite && sameApp) return@firstOrNull true
        // Website-only identity. Do not let an App Login match a website record.
        if (sameWebsite && itemPkg.isBlank() && existingPkg.isBlank()) return@firstOrNull true
        // App-only identity. Package is mandatory; it is never treated as a URL.
        if (sameApp && itemWebsite.isBlank() && existingWebsite.isBlank()) return@firstOrNull true

        false
    }

    fun plan(candidates: List<VaultEntry>, existing: List<VaultEntry>): List<ImportItem> =
        candidates.map { ImportItem(it, find(it, existing)) }
}
