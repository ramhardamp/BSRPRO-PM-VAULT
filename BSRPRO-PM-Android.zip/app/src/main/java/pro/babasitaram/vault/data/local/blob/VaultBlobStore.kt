package pro.babasitaram.vault.data.local.blob

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.security.MessageDigest
import javax.crypto.spec.SecretKeySpec
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.DerivedVaultKey
import pro.babasitaram.vault.core.crypto.Pbkdf2
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.constants.VaultConstants
import pro.babasitaram.vault.core.crypto.VaultPlaintext
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultJson
import pro.babasitaram.vault.core.model.VaultPayload
import pro.babasitaram.vault.core.util.VaultError

interface VaultBlobStore {
    suspend fun exists(): Boolean
    suspend fun read(password: CharArray): VaultData
    suspend fun write(data: VaultData, password: CharArray)
    suspend fun readRaw(): String?
    suspend fun writeRaw(blob: String)
    suspend fun deleteAll()

    /** Remove the .bak / .bak2 copies (they are still encrypted with the *previous* password after a password change). */
    suspend fun deleteBackups()

    /** Forget the cached derived key (call on lock). */
    fun invalidateKeyCache()

    /**
     * Serialises the cached derived key as salt || key || SHA-256(salt || password) so it can be wrapped by the
     * Android Keystore and reused by a later quick (biometric/device-credential) unlock. Null when nothing is
     * cached for [password]. Default no-op keeps fakes source-compatible.
     */
    fun exportKeyBlob(password: CharArray): ByteArray? = null

    /** Restores the cache from [exportKeyBlob] output. True only if the blob is well-formed and bound to [password]. */
    fun primeKeyFromBlob(password: CharArray, blob: ByteArray): Boolean = false
}

/**
 * vault.blob = base64(salt16 || iv12 || AES-256-GCM(payload JSON)) — the extension's legacy vault format.
 * Writes are atomic (tmp + fsync + rename) and the previous two versions are kept as .bak / .bak2.
 */
fun interface VaultWriteHooks {
    fun before(step: Step)

    enum class Step { TEMP_WRITE, BACKUP_ROTATE, ATOMIC_MOVE, FALLBACK_MOVE }
}

object NoopVaultWriteHooks : VaultWriteHooks {
    override fun before(step: VaultWriteHooks.Step) = Unit
}

class FileVaultBlobStore(
    private val dir: File,
    private val dispatcher: CoroutineDispatcher,
    private val writeHooks: VaultWriteHooks = NoopVaultWriteHooks
) : VaultBlobStore {

    private val main = File(dir, "vault.blob")
    private val tmp = File(dir, "vault.blob.tmp")
    private val bak1 = File(dir, "vault.blob.bak")
    private val bak2 = File(dir, "vault.blob.bak2")
    private val mutex = Mutex()

    private class KeyCache(val fingerprint: ByteArray, val dk: DerivedVaultKey)

    private companion object {
        const val KEY_BYTES = 32
        const val FINGERPRINT_BYTES = 32
    }

    @Volatile
    private var cache: KeyCache? = null

    override suspend fun exists(): Boolean = withContext(dispatcher) { main.exists() || bak1.exists() }

    override suspend fun read(password: CharArray): VaultData = mutex.withLock {
        var formatError: VaultError? = null
        var result: VaultData? = null
        for (file in listOf(main, bak1, bak2)) {
            if (result != null) break
            if (!withContext(dispatcher) { file.exists() }) continue
            try {
                result = readFile(file, password)
            } catch (e: VaultError.InvalidFormat) {
                // corrupted file: try the previous version. A wrong password is NOT retried on backups.
                formatError = e
            }
        }
        result ?: throw (formatError ?: VaultError.VaultNotFound)
    }

    private suspend fun readFile(file: File, password: CharArray): VaultData {
        val text = ioCall { file.readText(Charsets.UTF_8) }.trim()
        // Fast path: a derived key for exactly this password + this file's salt is already cached (primed from the
        // Keystore after a quick unlock). Any mismatch or tag failure falls through to the normal PBKDF2 path.
        val cached = cache
        if (cached != null && MessageDigest.isEqual(cached.fingerprint, fingerprint(password, cached.dk.salt))) {
            VaultCrypto.decryptWithDerivedKey(text, cached.dk)?.let { return toVaultData(it) }
        }
        val (plain, dk) = VaultCrypto.decryptWithKeyInfo(text, password)
        cache = KeyCache(fingerprint(password, dk.salt), dk)
        return toVaultData(plain)
    }

    override suspend fun write(data: VaultData, password: CharArray) = mutex.withLock {
        val dk = obtainKey(password)
        val json = withContext(kotlinx.coroutines.Dispatchers.Default) {
            // compress before encrypting (smaller file, faster atomic write); plain JSON for small vaults
            VaultPlaintext.pack(
                VaultJson.encodeToString(VaultPayload.serializer(), VaultPayload(entries = data.entries, folders = data.folders))
            )
        }
        val blob = VaultCrypto.encryptWithKey(json, dk)
        atomicWrite(blob)
    }

    private suspend fun obtainKey(password: CharArray): DerivedVaultKey {
        val c = cache
        if (c != null && MessageDigest.isEqual(c.fingerprint, fingerprint(password, c.dk.salt))) return c.dk
        val fresh = VaultCrypto.deriveNewVaultKey(password)
        cache = KeyCache(fingerprint(password, fresh.salt), fresh)
        return fresh
    }

    override fun exportKeyBlob(password: CharArray): ByteArray? {
        val c = cache ?: return null
        val fp = fingerprint(password, c.dk.salt)
        if (!MessageDigest.isEqual(c.fingerprint, fp)) return null
        val raw = c.dk.key.encoded ?: return null
        return try { c.dk.salt + raw + fp } finally { raw.fill(0) }
    }

    override fun primeKeyFromBlob(password: CharArray, blob: ByteArray): Boolean {
        val saltN = VaultConstants.SALT_BYTES
        if (blob.size != saltN + KEY_BYTES + FINGERPRINT_BYTES) return false
        val salt = blob.copyOfRange(0, saltN)
        val keyBytes = blob.copyOfRange(saltN, saltN + KEY_BYTES)
        val fp = blob.copyOfRange(saltN + KEY_BYTES, blob.size)
        try {
            // The blob must be bound to this very password; otherwise it is ignored.
            if (!MessageDigest.isEqual(fp, fingerprint(password, salt))) return false
            cache = KeyCache(fp, DerivedVaultKey(salt, SecretKeySpec(keyBytes, "AES")))
            return true
        } finally {
            keyBytes.fill(0)
        }
    }

    private fun fingerprint(password: CharArray, salt: ByteArray): ByteArray {
        val bytes = Pbkdf2.utf8Bytes(password)
        try {
            return MessageDigest.getInstance("SHA-256").apply { update(salt); update(bytes) }.digest()
        } finally {
            bytes.fill(0)
        }
    }

    private suspend fun atomicWrite(blob: String): Unit = ioCall {
        dir.mkdirs()
        writeHooks.before(VaultWriteHooks.Step.TEMP_WRITE)
        FileOutputStream(tmp).use { out ->
            out.write(blob.toByteArray(Charsets.UTF_8))
            out.flush()
            out.fd.sync()
        }
        if (main.exists()) {
            writeHooks.before(VaultWriteHooks.Step.BACKUP_ROTATE)
            if (bak1.exists()) bak1.copyTo(bak2, overwrite = true)
            main.copyTo(bak1, overwrite = true)
        }
        try {
            writeHooks.before(VaultWriteHooks.Step.ATOMIC_MOVE)
            Files.move(tmp.toPath(), main.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            Unit
        } catch (e: AtomicMoveNotSupportedException) {
            writeHooks.before(VaultWriteHooks.Step.FALLBACK_MOVE)
            if (!tmp.renameTo(main)) throw IOException("rename failed")
            Unit
        }
        Unit
    }

    override suspend fun readRaw(): String? = mutex.withLock {
        ioCall { if (main.exists()) main.readText(Charsets.UTF_8).trim() else null }
    }

    override suspend fun writeRaw(blob: String) = mutex.withLock { atomicWrite(blob) }

    override suspend fun deleteAll() = mutex.withLock {
        cache = null
        ioCall { listOf(main, tmp, bak1, bak2).forEach { it.delete() } }
        Unit
    }

    override suspend fun deleteBackups() = mutex.withLock {
        ioCall { listOf(bak1, bak2).forEach { it.delete() } }
        Unit
    }

    override fun invalidateKeyCache() {
        cache = null
    }

    private fun toVaultData(plaintext: String): VaultData {
        val r = V3PayloadParser.parse(plaintext)
        return VaultData(r.entries, r.folders)
    }

    private suspend fun <T> ioCall(block: () -> T): T = withContext(dispatcher) {
        try {
            block()
        } catch (e: IOException) {
            throw VaultError.IOError(e)
        }
    }
}
