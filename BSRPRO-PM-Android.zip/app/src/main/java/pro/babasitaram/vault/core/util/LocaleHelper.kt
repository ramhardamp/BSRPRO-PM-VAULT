package pro.babasitaram.vault.core.util

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/**
 * In-app language (English / हिन्दी). The choice lives in SharedPreferences because it must be read
 * synchronously in Activity.attachBaseContext, before DataStore / Compose exist.
 */
object LocaleHelper {
    private const val PREFS = "bsrpro_locale"
    private const val KEY = "language"
    const val SYSTEM = "system"
    const val ENGLISH = "en"
    const val HINDI = "hi"

    fun read(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, SYSTEM) ?: SYSTEM

    fun save(context: Context, code: String) {
        val safe = if (code == ENGLISH || code == HINDI) code else SYSTEM
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, safe).commit()
        L.onLanguageChanged()
    }

    /** Returns a context whose resources use the saved language (unchanged when "system"). */
    fun wrap(base: Context): Context {
        val code = read(base)
        if (code == SYSTEM) return base
        val locale = Locale.forLanguageTag(code)
        Locale.setDefault(locale)
        val config = Configuration(base.resources.configuration)
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
