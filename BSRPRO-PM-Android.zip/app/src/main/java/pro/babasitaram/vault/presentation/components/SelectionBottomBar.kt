// file: app/src/main/java/pro/babasitaram/vault/presentation/components/SelectionBottomBar.kt
package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import pro.babasitaram.vault.R

/** Shared selection-mode action bar used by Vault and Mobiles. */
@Composable
fun SelectionBottomBar(
    selectedCount: Int,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(modifier = modifier.fillMaxWidth().navigationBarsPadding(), tonalElevation = 4.dp) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(enabled = selectedCount > 0, onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = null)
                Spacer(Modifier.width(AppDimens.ItemSpacing))
                Text(stringResource(R.string.p15_delete))
            }
            TextButton(enabled = selectedCount > 0, onClick = onShare) {
                Icon(Icons.Default.Share, contentDescription = null)
                Spacer(Modifier.width(AppDimens.ItemSpacing))
                Text(stringResource(R.string.p15_share))
            }
            TextButton(enabled = selectedCount > 0, onClick = onFavorite) {
                Icon(Icons.Default.Star, contentDescription = null)
                Spacer(Modifier.width(AppDimens.ItemSpacing))
                Text(stringResource(R.string.selection_favorite))
            }
        }
    }
}
