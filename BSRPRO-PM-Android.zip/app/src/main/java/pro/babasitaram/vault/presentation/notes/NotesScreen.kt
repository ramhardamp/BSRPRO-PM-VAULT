@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.notes

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import java.text.DateFormat
import java.util.Date
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.components.AppDimens

@Composable
fun NotesScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onOpen: (String) -> Unit = {},
    vm: NotesViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_notes), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p15_back)) } }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, icon = { Icon(Icons.Default.Add, null) }, text = { Text(stringResource(R.string.notes_new_note)) })
        }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(stringResource(R.string.p15_no_notes), stringResource(R.string.notes_empty_message), Modifier.padding(padding).fillMaxWidth())
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(AppDimens.ScreenHorizontal), verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)) {
                items(entries, key = { it.id  }, contentType = { "item" }) { entry ->
                    NoteItem(entry, onOpen = { onOpen(entry.id) })
                }
            }
        }
    }
}

@Composable
private fun NoteItem(
    entry: VaultEntry,
    onOpen: () -> Unit
) {
    Card(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                entry.title.ifBlank { stringResource(R.string.p15_note) },
                style = MaterialTheme.typography.titleMedium
            )
            val noteDate = entry.updatedAt.takeIf { it > 0L } ?: entry.createdAt
            if (noteDate > 0L) {
                Text(
                    stringResource(
                        R.string.notes_date,
                        DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(noteDate))
                    ),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
