package pro.babasitaram.vault.data.transfer

import pro.babasitaram.vault.core.model.VaultEntry

/**
 * Data-safety invariant for native Android app logins.
 *
 * Backup/import/restore must never silently turn an existing app login into a website/ordinary
 * record or lose its app target/PIN/password. Incoming backup data wins for fields it actually
 * contains; existing app-login identity fields are retained when the incoming record is missing
 * them. Existing active app logins that are absent from an incoming backup are carried forward.
 * Explicit user deletion remains the only way to remove them.
 */
object AppLoginRestorePolicy {
    private fun sameIdentity(a: VaultEntry, b: VaultEntry): Boolean {
        if (!a.isMobileAppLinked || !b.isMobileAppLinked) return false
        val pkgA = a.appPackage.trim()
        val pkgB = b.appPackage.trim()
        if (pkgA.isBlank() || !pkgA.equals(pkgB, ignoreCase = true)) return false
        val userA = a.username.trim()
        val userB = b.username.trim()
        return userA.isNotBlank() && userA.equals(userB, ignoreCase = true)
    }

    private fun merge(existing: VaultEntry, incoming: VaultEntry): VaultEntry {
        val packageName = incoming.appPackage.ifBlank { existing.appPackage }
        val appOnly = packageName.isNotBlank() && incoming.url.isBlank()
        return incoming.copy(
            appPackage = packageName,
            appName = incoming.appName.ifBlank { existing.appName },
            loginUri = incoming.loginUri.ifBlank { existing.loginUri.ifBlank { "androidapp://$packageName" } },
            appPin = incoming.appPin.ifBlank { existing.appPin },
            password = incoming.password.ifBlank { existing.password },
            isPrimaryAppLogin = incoming.isPrimaryAppLogin || existing.isPrimaryAppLogin,
            type = if (appOnly && incoming.type.isBlank()) "app" else incoming.type
        )
    }

    /** Returns a new list; neither input list is mutated. */
    fun protect(existing: List<VaultEntry>, incoming: List<VaultEntry>): List<VaultEntry> {
        val result = incoming.toMutableList()
        existing.filter { it.deletedAt == 0L && it.isMobileAppLinked }.forEach { old ->
            val index = result.indexOfFirst { candidate ->
                (old.id.isNotBlank() && candidate.id == old.id) || sameIdentity(old, candidate)
            }
            if (index >= 0) {
                result[index] = merge(old, result[index])
            } else {
                result += old
            }
        }
        return result
    }
}
