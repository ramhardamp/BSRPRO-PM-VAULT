package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.domain.repository.SettingsRepository

/**
 * Restores a process-lost session only from the encrypted Key-B credential and session timestamps.
 * No boolean flag can make the vault appear unlocked after process death.
 */
class RestorePersistedSessionUseCase @Inject constructor(
    private val settings: SettingsRepository,
    private val persisted: BiometricSessionKeyStore,
    private val unlockVault: UnlockVaultUseCase,
    private val session: SessionKeyStore,
    private val lockVault: LockVaultUseCase
) {
    enum class Result { Restored, NotAvailable, RequiresAuthentication }

    suspend operator fun invoke(forAutofill: Boolean = false): Result = withContext(Dispatchers.Default) {
        val cfg = settings.current()
        if (!cfg.biometricEnabled) return@withContext Result.NotAvailable
        if (forAutofill && !cfg.quickAutofillEnabled) return@withContext Result.NotAvailable
        val metadata = persisted.readSessionMetadata() ?: return@withContext Result.NotAvailable
        val now = System.currentTimeMillis()
        if (now < metadata.issuedAtWallMs || now >= metadata.expiresAtWallMs) {
            persisted.clearSessionMetadata()
            return@withContext Result.NotAvailable
        }
        // Background duration is deliberately not a second lock policy. The single
        // authoritative expiry is metadata.expiresAtWallMs, which is the same vault-session
        // expiry used while the process is alive.
        when (val loaded = persisted.tryLoadCredentialSilently()) {
            is BiometricSessionKeyStore.SilentLoadResult.Password -> {
                val password = loaded.value
                try {
                    when (val r = unlockVault(password)) {
                        is pro.babasitaram.vault.core.util.VaultResult.Success -> {
                            // Security: unlockVault ne session ki umar naye sire se (24h) shuru kar di thi, jisse har process-restore
                            // par "absolute" limit khisakti rehti. Asli expiry/issued wapas lagao.
                            if (session.restore(password, metadata.expiresAtWallMs)) {
                                persisted.saveSessionMetadata(metadata.copy(backgroundedAtWallMs = 0L))
                                Result.Restored
                            } else {
                                lockVault("Session expired")
                                Result.NotAvailable
                            }
                        }
                        else -> {
                            persisted.clearSessionMetadata()
                            Result.NotAvailable
                        }
                    }
                } finally {
                    password.fill('\u0000')
                }
            }
            BiometricSessionKeyStore.SilentLoadResult.RequiresAuthentication -> Result.RequiresAuthentication
            BiometricSessionKeyStore.SilentLoadResult.Invalidated -> {
                persisted.clearSessionMetadata()
                persisted.clearSecureCredential()
                settings.update { it.copy(biometricEnabled = false) }
                Result.NotAvailable
            }
            BiometricSessionKeyStore.SilentLoadResult.Missing -> Result.NotAvailable
        }
    }
}
