package pro.babasitaram.vault.core.security

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import android.security.keystore.UserNotAuthenticatedException
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import javax.crypto.Cipher
import javax.crypto.SecretKey
import java.nio.ByteBuffer
import java.security.KeyStore
import java.util.Base64
import javax.inject.Inject
import javax.inject.Named
import javax.inject.Singleton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext

/**
 * BSRPRO Key B: a separate Android Keystore AES-256 key requiring recent user authentication.
 * Key A (bsrpro_master_wrap_key_v1) is never modified here.
 *
 * The store holds only encrypted session credentials and non-secret session timestamps.
 * Plaintext master passwords never enter DataStore, SharedPreferences or logs.
 */
@Singleton
class BiometricSessionKeyStore @Inject constructor(
    @Named("secure") private val store: DataStore<Preferences>
) {
    data class PreparedDecrypt(val cipher: Cipher, val ciphertext: ByteArray)

    sealed interface SilentLoadResult {
        data class Password(val value: CharArray) : SilentLoadResult
        data object Missing : SilentLoadResult
        data object RequiresAuthentication : SilentLoadResult
        data object Invalidated : SilentLoadResult
    }

    data class SessionMetadata(
        val issuedAtWallMs: Long,
        val expiresAtWallMs: Long,
        val backgroundedAtWallMs: Long
    )

    suspend fun hasSecureCredential(): Boolean = withContext(Dispatchers.IO) {
        store.data.first()[SECURE_CREDENTIAL] != null
    }

    suspend fun hasLegacyCredential(): Boolean = withContext(Dispatchers.IO) {
        store.data.first()[LEGACY_CREDENTIAL] != null
    }

    /** Creates an encryption cipher backed by Key B. The caller must authenticate before doFinal(). */
    suspend fun createEncryptCipher(): Cipher = withContext(Dispatchers.IO) {
        ensureKey().let { key ->
            Cipher.getInstance(TRANSFORMATION).apply { init(Cipher.ENCRYPT_MODE, key) }
        }
    }

    /** Prepares a decrypt cipher from the saved envelope. Authentication may still be required. */
    suspend fun prepareDecryptCipher(): PreparedDecrypt? = withContext(Dispatchers.IO) {
        val raw = store.data.first()[SECURE_CREDENTIAL] ?: return@withContext null
        val envelope = runCatching { Base64.getDecoder().decode(raw) }.getOrNull() ?: return@withContext null
        if (envelope.size <= IV_BYTES) return@withContext null
        val iv = envelope.copyOfRange(0, IV_BYTES)
        val ciphertext = envelope.copyOfRange(IV_BYTES, envelope.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(
            Cipher.DECRYPT_MODE,
            ensureKey(),
            javax.crypto.spec.GCMParameterSpec(TAG_BITS, iv)
        )
        PreparedDecrypt(cipher, ciphertext)
    }

    suspend fun decryptPrepared(prepared: PreparedDecrypt): CharArray = withContext(Dispatchers.IO) {
        val plain = try {
            prepared.cipher.doFinal(prepared.ciphertext)
        } catch (e: UserNotAuthenticatedException) {
            throw e
        }
        try {
            Charsets.UTF_8.decode(ByteBuffer.wrap(plain)).let { chars ->
                CharArray(chars.remaining()).also { chars.get(it) }
            }
        } finally {
            plain.fill(0)
        }
    }

    /** Best-effort no-prompt restore used after process death. */
    suspend fun tryLoadCredentialSilently(): SilentLoadResult = withContext(Dispatchers.IO) {
        try {
            val prepared = prepareDecryptCipher() ?: return@withContext SilentLoadResult.Missing
            SilentLoadResult.Password(decryptPrepared(prepared))
        } catch (_: UserNotAuthenticatedException) {
            SilentLoadResult.RequiresAuthentication
        } catch (_: KeyPermanentlyInvalidatedException) {
            clearSecureCredentialInternal()
            SilentLoadResult.Invalidated
        } catch (ce: kotlinx.coroutines.CancellationException) {
            throw ce
        } catch (_: Exception) {
            SilentLoadResult.Missing
        }
    }

    /** Saves a credential after BiometricPrompt has authenticated the cipher's Key B. */
    suspend fun saveCredentialAfterAuthentication(cipher: Cipher, password: CharArray) = withContext(Dispatchers.IO) {
        val bytes = password.concatToString().toByteArray(Charsets.UTF_8)
        try {
            val encrypted = cipher.doFinal(bytes)
            val envelope = cipher.iv + encrypted
            store.edit { it[SECURE_CREDENTIAL] = Base64.getEncoder().encodeToString(envelope) }
        } finally {
            bytes.fill(0)
        }
    }

    suspend fun clearSecureCredential() = withContext(Dispatchers.IO) { clearSecureCredentialInternal() }

    suspend fun clearLegacyCredential() = withContext(Dispatchers.IO) {
        store.edit { it.remove(LEGACY_CREDENTIAL) }
    }

    suspend fun clearAllCredentials() = withContext(Dispatchers.IO) {
        store.edit {
            it.remove(SECURE_CREDENTIAL)
            it.remove(LEGACY_CREDENTIAL)
            it.remove(SESSION_ISSUED)
            it.remove(SESSION_EXPIRES)
            it.remove(SESSION_BACKGROUND)
        }
        deleteKeyInternal()
    }

    suspend fun saveSessionMetadata(metadata: SessionMetadata) = withContext(Dispatchers.IO) {
        store.edit {
            it[SESSION_ISSUED] = metadata.issuedAtWallMs
            it[SESSION_EXPIRES] = metadata.expiresAtWallMs
            if (metadata.backgroundedAtWallMs > 0L) it[SESSION_BACKGROUND] = metadata.backgroundedAtWallMs
            else it.remove(SESSION_BACKGROUND)
        }
    }

    suspend fun readSessionMetadata(): SessionMetadata? = withContext(Dispatchers.IO) {
        val p = store.data.first()
        val issued = p[SESSION_ISSUED] ?: return@withContext null
        val expires = p[SESSION_EXPIRES] ?: return@withContext null
        SessionMetadata(issued, expires, p[SESSION_BACKGROUND] ?: 0L)
    }

    suspend fun markBackgrounded(atWallMs: Long) = withContext(Dispatchers.IO) {
        store.edit { it[SESSION_BACKGROUND] = atWallMs }
    }

    suspend fun clearBackgrounded() = withContext(Dispatchers.IO) {
        store.edit { it.remove(SESSION_BACKGROUND) }
    }

    suspend fun clearSessionMetadata() = withContext(Dispatchers.IO) {
        store.edit {
            it.remove(SESSION_ISSUED)
            it.remove(SESSION_EXPIRES)
            it.remove(SESSION_BACKGROUND)
        }
    }

    /**
     * Drops and recreates Key B after biometric enrollment/security changes. The old wrapped
     * credential becomes intentionally unusable and is removed; the user must re-enable biometric.
     */
    suspend fun resetForSecurityChange() = withContext(Dispatchers.IO) {
        clearSecureCredentialInternal()
        deleteKeyInternal()
    }

    private fun ensureKey(): SecretKey {
        val ks = keyStore()
        (ks.getKey(KEY_ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGeneratorCompat(ks)
        return generator.create()
    }

    private class KeyGeneratorCompat(private val keyStore: KeyStore) {
        fun create(): SecretKey {
            val generator = javax.crypto.KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
            val builder = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                builder.setUserAuthenticationParameters(
                    AUTH_WINDOW_SECONDS,
                    KeyProperties.AUTH_BIOMETRIC_STRONG or KeyProperties.AUTH_DEVICE_CREDENTIAL
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                @Suppress("DEPRECATION")
                builder.setUserAuthenticationValidityDurationSeconds(AUTH_WINDOW_SECONDS)
            }
            generator.init(builder.build())
            return generator.generateKey()
        }
    }

    private suspend fun clearSecureCredentialInternal() {
        store.edit { it.remove(SECURE_CREDENTIAL) }
    }

    private fun deleteKeyInternal() {
        runCatching {
            keyStore().deleteEntry(KEY_ALIAS)
        }
    }

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    private companion object {
        const val PROVIDER = "AndroidKeyStore"
        const val KEY_ALIAS = "bsrpro_biometric_session_key_v2"
        const val AUTH_WINDOW_SECONDS = 24 * 60 * 60
        const val IV_BYTES = 12
        const val TAG_BITS = 128
        val SECURE_CREDENTIAL = stringPreferencesKey("biometric_credential_v2")
        val LEGACY_CREDENTIAL = stringPreferencesKey("biometric_credential_v1")
        val SESSION_ISSUED = longPreferencesKey("session_issued_at_wall_v2")
        val SESSION_EXPIRES = longPreferencesKey("session_expires_at_wall_v2")
        val SESSION_BACKGROUND = longPreferencesKey("session_backgrounded_at_wall_v2")
        const val TRANSFORMATION = "AES/GCM/NoPadding"
    }
}
