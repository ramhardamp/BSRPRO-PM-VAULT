package pro.babasitaram.vault.data.backup

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract

/** Folder me mili ek file ka summary. [ref] sirf caller ke liye hai (document id). */
internal data class BackupCandidate(
    val name: String,
    val modified: Long,
    val size: Long,
    val ref: String = ""
)

/**
 * Pure (Android-free) rules: kaun si file backup ho sakti hai aur kis order me try karni hai.
 *
 * Fix.md 7.2: exact `BSRPRO.Vault` hamesha PEHLI priority hai. Sirf agar wo na mile / kharab ho,
 * tab folder ki baaki `.Vault` files (newest first) try hoti hain. Isse "folder me file hai par app
 * nahi dhundh raha" wali problem jaati hai (manual export `BSRPRO_Backup_<date>.Vault`, `(1)` duplicate, wagairah).
 */
internal object BackupCandidates {
    private const val MAX_BYTES = 25L * 1024L * 1024L
    private const val SNIFF_CHARS = 1024

    fun isCandidateName(name: String, finalName: String = AutoBackupManager.FINAL_NAME): Boolean {
        if (name.isBlank()) return false
        if (name.startsWith(".")) return false                       // staging / quarantine / hidden files
        if (name.equals(finalName, ignoreCase = true)) return true
        val lower = name.lowercase()
        if (lower.contains(".csv.") || lower.contains(".json.")) return false   // encrypted CSV/JSON export: vault payload nahi
        return lower.endsWith(".vault")
    }

    /** Candidate files ko try-order me lagata hai: exact naam, phir newest first. */
    fun order(items: List<BackupCandidate>, finalName: String = AutoBackupManager.FINAL_NAME): List<BackupCandidate> =
        items
            .filter { isCandidateName(it.name, finalName) && it.size != 0L && it.size <= MAX_BYTES }
            .sortedWith(
                compareByDescending<BackupCandidate> { it.name.equals(finalName, ignoreCase = true) }
                    .thenByDescending { it.modified }
                    .thenBy { it.name.lowercase() }
            )

    /** File ke shuru ke bytes dekhkar pakka karta hai ki ye BSRPRO V3 container hai (password nahi chahiye). */
    fun looksLikeV3Container(head: ByteArray): Boolean {
        val s = String(head, Charsets.UTF_8).trimStart('\uFEFF', ' ', '\n', '\r', '\t').take(SNIFF_CHARS)
        return s.startsWith("{") && s.contains("BSRPRO.Vault")
    }
}

/**
 * Fix.md 1.3 / 7.2: user ke chune hue backup folder (SAF tree) me backup dhundhta hai.
 *
 * - Folder + uske sub-folders (MAX_DEPTH tak) dekhta hai, kyunki user kabhi parent folder chun leta hai.
 * - Naam ke saath file ka header bhi check karta hai.
 * - Koi file delete/rename/write nahi karta (sirf padhta hai).
 */
class BackupFolderFinder(private val context: Context) {

    private data class Child(val id: String, val name: String, val isDir: Boolean, val modified: Long, val size: Long)

    /** Sabse sahi backup ka document Uri; kuch nahi mila to null. Folder padh na paye to IOException. */
    fun findBestBackup(treeUri: Uri): Uri? {
        val rootId = DocumentsContract.getTreeDocumentId(treeUri)
        val files = ArrayList<BackupCandidate>()
        var level = listOf(rootId)
        var scanned = 0
        for (depth in 0..MAX_DEPTH) {
            val next = ArrayList<String>()
            for (parentId in level) {
                for (child in children(treeUri, parentId)) {
                    if (scanned++ >= MAX_DOCS) break
                    if (child.isDir) next += child.id
                    else files += BackupCandidate(child.name, child.modified, child.size, child.id)
                }
            }
            if (next.isEmpty() || scanned >= MAX_DOCS) break
            level = next
        }
        for (candidate in BackupCandidates.order(files)) {
            val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, candidate.ref)
            val head = readHead(uri) ?: continue
            if (BackupCandidates.looksLikeV3Container(head)) return uri
        }
        return null
    }

    private fun children(treeUri: Uri, parentDocId: String): List<Child> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val out = ArrayList<Child>()
        context.contentResolver.query(
            uri,
            arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_SIZE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                out += Child(
                    id = id,
                    name = c.getString(1).orEmpty(),
                    isDir = c.getString(2) == DocumentsContract.Document.MIME_TYPE_DIR,
                    modified = if (c.isNull(3)) 0L else c.getLong(3),
                    size = if (c.isNull(4)) -1L else c.getLong(4)
                )
            }
        } ?: throw java.io.IOException("Cannot read selected folder")
        return out
    }

    private fun readHead(uri: Uri): ByteArray? = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val buf = ByteArray(HEAD_BYTES)
            var n = 0
            while (n < buf.size) {
                val r = input.read(buf, n, buf.size - n)
                if (r < 0) break
                n += r
            }
            buf.copyOf(n)
        }
    } catch (e: java.io.IOException) {
        null
    } catch (e: SecurityException) {
        null
    }

    private companion object {
        const val MAX_DEPTH = 2
        const val MAX_DOCS = 500
        const val HEAD_BYTES = 1024
    }
}
