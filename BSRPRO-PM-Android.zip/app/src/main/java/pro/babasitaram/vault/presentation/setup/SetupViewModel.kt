package pro.babasitaram.vault.presentation.setup

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.domain.usecase.CreateVaultUseCase
import pro.babasitaram.vault.domain.usecase.RestoreBackupUseCase
import pro.babasitaram.vault.domain.usecase.RecoveryKeyUseCase
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.presentation.util.toUserMessage

import androidx.compose.foundation.layout.*
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

@Stable
data class SetupUiState(
    val busy: Boolean = false,
    val error: String? = null,
    val awaitingBackupPassword: Boolean = false,
    val recoveryKey: String? = null,
    val backupFolderUri: String = "",
    /** A backup file was found in the chosen folder / default location. */
    val backupFound: Boolean = false,
    /** The found backup did not open with the typed master password: ask for the backup's own password. */
    val backupMismatch: Boolean = false
)

@HiltViewModel
class SetupViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val createVault: CreateVaultUseCase,
    private val restoreBackup: RestoreBackupUseCase,
    private val recoveryKey: RecoveryKeyUseCase,
    private val clipboard: pro.babasitaram.vault.presentation.util.ClipboardActions,
    private val activityLog: ActivityLogStore,
    private val settings: SettingsRepository,
    private val autoBackup: AutoBackupManager
) : ViewModel() {

    /** Copies a secret through the vault clipboard manager (sensitive flag + auto-clear). */
    fun copySecret(text: String, label: String) {
        launchCatching { clipboard.copy(text, label) }
    }

    private val _state = MutableStateFlow(SetupUiState())
    val state: StateFlow<SetupUiState> = _state.asStateFlow()

    private var pendingBackup: String? = null

    init {
        launchCatching {
            settings.settings.collect { cfg ->
                _state.update { it.copy(backupFolderUri = cfg.backupFolderUri) }
            }
        }
        // Reinstall-safe recovery: SAF grants and app DataStore state can disappear on uninstall,
        // but the app-managed Downloads/BSRPRO_Backups/BSRPRO.Vault remains discoverable.
        // Read the canonical settings snapshot first so a still-valid selected SAF folder remains
        // authoritative; only a genuinely blank destination uses default-folder discovery.
        launchCatching {
            if (settings.current().backupFolderUri.isBlank()) autoDetectDefaultBackup()
        }
    }

    private suspend fun autoDetectDefaultBackup() {
        if (pendingBackup != null || _state.value.backupFolderUri.isNotBlank()) return
        val file = autoBackup.findRestorableBackup() ?: return
        try {
            val text = withContext(Dispatchers.IO) {
                if (!file.isFile || file.length() !in 1..MAX_BACKUP_BYTES) ""
                else file.readText(Charsets.UTF_8).trim()
            }
            if (text.isNotEmpty()) {
                pendingBackup = text
                _state.update { it.copy(backupFound = true) }
            }
        } finally {
            runCatching { file.delete() }
        }
    }

    /**
     * Folder chosen in the "Backup folder" card. Previously this only stored the URI, so an existing
     * BSRPRO.Vault in that folder was never restored and an EMPTY vault got created next to it.
     * Now the folder is scanned right away; if a backup is there and a master password was already
     * typed, it is restored automatically with that password.
     */
    /**
     * The selected folder is authoritative during first-run setup. We never silently fall back to
     * Downloads/another remembered location, because that could restore the wrong vault.
     */
    fun onBackupFolderSelected(uri: Uri, typedPassword: String = "") {
        launchCatching {
            settings.update { it.copy(backupFolderUri = uri.toString(), autoBackupEnabled = true) }
            _state.update { it.copy(error = null, busy = true, backupFolderUri = uri.toString(), backupFound = false, backupMismatch = false) }
            val found = loadBackupFromSelectedFolder(uri)
            _state.update { it.copy(busy = false, backupFound = found, backupMismatch = false) }
            if (found && typedPassword.isNotEmpty()) attemptRestore(typedPassword, askOnFailure = true)
        }
    }

    /** Reads only the best backup from the exact folder the user just selected. */
    private suspend fun loadBackupFromSelectedFolder(treeUri: Uri): Boolean {
        val fileUri = withContext(Dispatchers.IO) {
            pro.babasitaram.vault.data.backup.BackupFolderFinder(context).findBestBackup(treeUri)
        } ?: return false
        return try {
            val text = withContext(Dispatchers.IO) {
                val bytes = context.contentResolver.openInputStream(fileUri)?.use { it.readBytes() }
                    ?: return@withContext ""
                require(bytes.size in 1..MAX_BACKUP_BYTES) { "Backup size is invalid" }
                String(bytes, Charsets.UTF_8).trim()
            }
            if (text.isEmpty()) false else {
                pendingBackup = text
                true
            }
        } finally {
            // The selected SAF document is the real backup. Nothing is deleted or modified here.
            // pendingBackup is an in-memory copy used only for the restore attempt.
        }
    }

    /**
     * Restores [pendingBackup] with [password]. The backup password becomes the master password (same as the
     * manual restore). Returns true when the vault was created from the backup.
     */
    private suspend fun attemptRestore(password: String, askOnFailure: Boolean): Boolean {
        val text = pendingBackup ?: return false
        val pw = password.toCharArray()
        try {
            _state.update { it.copy(busy = true, error = null) }
            return when (val r = restoreBackup(text, pw)) {
                is VaultResult.Success -> {
                    activityLog.record("Restore completed", "${r.value} records restored from the backup folder during setup")
                    pendingBackup = null
                    _state.update { it.copy(busy = false, awaitingBackupPassword = false, backupMismatch = false, backupFound = false) }
                    true
                }
                is VaultResult.Failure -> {
                    val wrongPassword = r.error is VaultError.InvalidMasterPassword
                    _state.update {
                        it.copy(
                            busy = false,
                            awaitingBackupPassword = askOnFailure,
                            backupMismatch = wrongPassword,
                            error = if (wrongPassword) null else r.error.toUserMessage()
                        )
                    }
                    false
                }
                VaultResult.Loading -> { _state.update { it.copy(busy = false) }; false }
            }
        } finally {
            pw.fill('\u0000')
        }
    }

    /**
     * Creates the vault. If a backup exists in the selected backup folder and the typed master password opens it,
     * the backup is restored automatically instead of creating an empty vault.
     * [skipBackupCheck] = user explicitly chose "create a new empty vault" (the existing backup file is kept).
     */
    fun create(password: String, confirm: String, skipBackupCheck: Boolean = false) {
        val pw = password.toCharArray()
        val cf = confirm.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            if (!skipBackupCheck && password.isNotEmpty() && pw.contentEquals(cf)) {
                if (pendingBackup == null) {
                    val selected = _state.value.backupFolderUri.trim()
                    val found = if (selected.isNotEmpty()) {
                        runCatching { loadBackupFromSelectedFolder(Uri.parse(selected)) }.getOrDefault(false)
                    } else {
                        runCatching { autoDetectDefaultBackup(); pendingBackup != null }.getOrDefault(false)
                    }
                    _state.update { it.copy(backupFound = found) }
                }
                if (pendingBackup != null) {
                    if (attemptRestore(password, askOnFailure = true)) {
                        pw.fill('\u0000'); cf.fill('\u0000')
                        return@launchCatching          // restored: RootViewModel switches to the vault screens
                    }
                    if (_state.value.awaitingBackupPassword || _state.value.error != null) {
                        pw.fill('\u0000'); cf.fill('\u0000')
                        return@launchCatching          // waiting for the backup's own password / showing an error
                    }
                }
            }
            val r = createVault(pw, cf)
            pw.fill('\u0000')
            cf.fill('\u0000')
            if (r is VaultResult.Success) {
                activityLog.record("Vault created", "Initial vault setup completed")
                if (!skipBackupCheck) autoBackup.armAutoImport()   // safety net: pick up a backup that appears later
                when (val recovery = recoveryKey.ensureCreated()) {
                    is VaultResult.Success -> _state.update { it.copy(busy = false, recoveryKey = recovery.value) }
                    is VaultResult.Failure -> _state.update { it.copy(busy = false, error = recovery.error.toUserMessage()) }
                    VaultResult.Loading -> Unit
                }
            } else {
                _state.update { it.copy(busy = false, error = (r as? VaultResult.Failure)?.error?.toUserMessage()) }
            }
            // On success the session unlocks and RootViewModel switches to the vault screens.
        }
    }

    fun dismissRecoveryKey() {
        _state.update { it.copy(recoveryKey = null) }
    }

    fun restore(backupPassword: String) {
        val text = pendingBackup ?: return
        val pw = backupPassword.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            val r = restoreBackup(text, pw)
            pw.fill('\u0000')
            if (r is VaultResult.Failure) {
                _state.update { it.copy(busy = false, error = r.error.toUserMessage(), awaitingBackupPassword = true, backupMismatch = false) }
            } else {
                activityLog.record("Restore completed", "Backup restored during setup")
                pendingBackup = null
                _state.update { it.copy(busy = false, awaitingBackupPassword = false) }
            }
        }
    }

    fun cancelRestore() {
        pendingBackup = null
        _state.update { it.copy(awaitingBackupPassword = false, backupMismatch = false, backupFound = false) }
    }

    /** Dialog action "Create new vault": ignores the found backup (file stays untouched) and creates an empty vault. */
    fun createWithoutRestore(password: String, confirm: String) {
        pendingBackup = null
        _state.update { it.copy(awaitingBackupPassword = false, backupMismatch = false, backupFound = false) }
        create(password, confirm, skipBackupCheck = true)
    }

    private companion object {
        const val MAX_BACKUP_BYTES = 50_000_000
    }
}
