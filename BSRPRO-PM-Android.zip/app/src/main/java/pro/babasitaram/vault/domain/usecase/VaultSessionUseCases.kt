package pro.babasitaram.vault.domain.usecase

import javax.inject.Inject
import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.StateFlow
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.crypto.V3PayloadParser
import pro.babasitaram.vault.core.crypto.VaultCrypto
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.VaultClipboardManager
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.util.vaultCatching
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.data.local.blob.VaultBlobStore
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.VaultRepository

class CreateVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository
) {
    suspend operator fun invoke(
        password: CharArray,
        confirm: CharArray,
        initial: VaultData = VaultData(),
        enforceStrength: Boolean = true
    ): VaultResult<Unit> = vaultCatching {
        if (auth.vaultExists()) throw VaultError.Validation("A vault already exists on this device")
        if (!password.contentEquals(confirm)) throw VaultError.Validation("Passwords do not match")
        if (enforceStrength && !PasswordStrength.isAcceptableMaster(java.nio.CharBuffer.wrap(password))) {
            throw VaultError.Validation("Use at least 12 characters with upper & lower case letters, digits or symbols")
        }
        if (password.isEmpty()) throw VaultError.Validation("Password must not be empty")
        blobStore.write(initial, password)
        session.unlock(password)
        repository.setData(initial)
        auth.recordSuccess()
    }
}

class UnlockVaultUseCase @Inject constructor(
    private val blobStore: VaultBlobStore,
    private val session: SessionKeyStore,
    private val repository: VaultRepository,
    private val auth: AuthRepository,
    private val settings: pro.babasitaram.vault.domain.repository.SettingsRepository,
    private val persistedSession: BiometricSessionKeyStore,
    @ApplicationContext private val context: Context
) {
    /**
     * The caller owns [password] and must wipe it afterwards.
     *
     * [quick] must be true ONLY right after a successful biometric / device-credential authentication (Key B is
     * then authorised). It lets the vault reuse the Keystore-wrapped derived key and skip the 600k-round PBKDF2;
     * the first quick unlock after enabling (or after a password/vault change) still derives once and stores it.
     */
    suspend operator fun invoke(password: CharArray, quick: Boolean = false): VaultResult<Unit> = vaultCatching {
        auth.checkAllowed()
        if (!auth.vaultExists()) throw VaultError.VaultNotFound
        val loadedKey: ByteArray? = if (quick) loadQuickKey(password) else null
        try {
            // Recover a pending in-place restore before any normal vault data is exposed.
            RecoveryJournal(context.filesDir).recover(blobStore, password)
            val data = try {
                blobStore.read(password)
            } catch (e: VaultError.InvalidMasterPassword) {
                auth.recordFailure()
                throw e
            }
            val cfg = settings.current()
            // Speed fix: publish entries BEFORE flipping the session to unlocked. RootViewModel navigates to the
            // vault the moment session.isUnlocked turns true; previously that happened first, so the vault screen
            // opened with an empty list and the passwords appeared only after setData() finished.
            repository.setData(data)
            session.unlock(password, cfg.vaultSessionSeconds)
            // Housekeeping runs after the vault is already visible (needs the unlocked session for its write).
            auth.recordSuccess()
            if (cfg.biometricEnabled && persistedSession.hasSecureCredential()) {
                persistedSession.saveSessionMetadata(
                    BiometricSessionKeyStore.SessionMetadata(
                        issuedAtWallMs = System.currentTimeMillis(),
                        expiresAtWallMs = session.sessionExpiresAtWallMs(),
                        backgroundedAtWallMs = 0L
                    )
                )
                if (quick) refreshQuickKey(password, loadedKey)
            }
            repository.cleanupExpiredTrash()
        } finally {
            loadedKey?.fill(0)
        }
    }

    /** Primes the blob store from the Keystore-wrapped derived key. Never fails the unlock; worst case = normal KDF. */
    private suspend fun loadQuickKey(password: CharArray): ByteArray? {
        val blob = persistedSession.loadDerivedKey() ?: return null
        return if (blobStore.primeKeyFromBlob(password, blob)) blob else { blob.fill(0); null }
    }

    /** Stores the derived key if it is missing or stale (different salt/key than the one we loaded). */
    private suspend fun refreshQuickKey(password: CharArray, loaded: ByteArray?) {
        val current = blobStore.exportKeyBlob(password) ?: return
        try {
            if (loaded == null || !current.contentEquals(loaded)) persistedSession.saveDerivedKey(current)
        } finally {
            current.fill(0)
        }
    }
}

class LockVaultUseCase @Inject constructor(
    private val session: SessionKeyStore,
    private val blobStore: VaultBlobStore,
    private val repository: VaultRepository,
    private val clipboard: VaultClipboardManager,
    private val persistedSession: BiometricSessionKeyStore,
    private val activityLog: ActivityLogStore? = null
) {
    suspend operator fun invoke(reason: String = "Manual") {
        activityLog?.record(if (reason.equals("Auto", true)) "Vault auto-locked" else "Vault locked", if (reason.equals("Auto", true)) "Automatic inactivity/background lock" else "Manual lock requested")
        session.lock()
        persistedSession.clearSessionMetadata()
        blobStore.invalidateKeyCache()
        clipboard.clearNow()
        repository.clear()
    }
}

/** Creates a fresh vault from a BSRPRO.Vault backup (V3 container). The backup password becomes the master password. */
class RestoreBackupUseCase @Inject constructor(private val createVault: CreateVaultUseCase) {
    suspend operator fun invoke(containerJson: String, backupPassword: CharArray): VaultResult<Int> {
        val data = try {
            val plain = VaultCrypto.decryptV3(containerJson, backupPassword)
            val parsed = V3PayloadParser.parse(plain)
            VaultData(parsed.entries, parsed.folders)
        } catch (e: VaultError) {
            return VaultResult.Failure(e)
        }
        return when (val r = createVault(backupPassword, backupPassword, data, enforceStrength = false)) {
            is VaultResult.Success -> VaultResult.Success(data.entries.count { !it.isFolderMarker })
            is VaultResult.Failure -> VaultResult.Failure(r.error)
            is VaultResult.Loading -> VaultResult.Loading
        }
    }
}

class GetEntriesUseCase @Inject constructor(private val repository: VaultRepository) {
    operator fun invoke(): StateFlow<List<VaultEntry>> = repository.entries
}

class DeleteEntryUseCase @Inject constructor(
    private val repository: VaultRepository,
    private val autoBackup: AutoBackupManager
) {
    suspend operator fun invoke(id: String): VaultResult<Unit> = vaultCatching {
        repository.softDelete(id)
        autoBackup.requestBackup()
    }
}

class SaveEntryUseCase @Inject constructor(
    private val repository: VaultRepository,
    private val autoBackup: AutoBackupManager,
    private val settings: pro.babasitaram.vault.domain.repository.SettingsRepository
) {
    /** [existing] is the stored version when editing (null for a new entry). */
    suspend operator fun invoke(
        entry: VaultEntry,
        existing: VaultEntry? = null,
        now: Long = System.currentTimeMillis()
    ): VaultResult<VaultEntry> = vaultCatching {
        val cfg = settings.current()
        if (cfg.blockWeakPasswords && entry.password.isNotBlank() && PasswordStrength.bucket(entry.password) == "weak") {
            throw VaultError.Validation("Weak password blocked. Turn off 'Block weak passwords' in Settings to save it anyway.")
        }
        var e = entry.copy(
            id = entry.id.ifBlank { pro.babasitaram.vault.core.util.IdGenerator.newId(now) },
            createdAt = existing?.createdAt?.takeIf { it > 0 } ?: now,
            updatedAt = now,
            strength = if (entry.password.isEmpty()) "" else PasswordStrength.bucket(entry.password)
        )
        if (existing != null) {
            val changedPassword = existing.password.isNotEmpty() && existing.password != e.password
            val history = if (changedPassword) {
                (listOf(pro.babasitaram.vault.core.model.PasswordHistoryItem(existing.password, now)) + existing.passwordHistory).take(20)
            } else existing.passwordHistory
            val changed = changedFields(existing, e)
            val edits = if (changed.isEmpty()) existing.editHistory else
                (listOf(pro.babasitaram.vault.core.model.EditHistoryItem(now, changed, "android")) + existing.editHistory).take(50)
            e = e.copy(passwordHistory = history, editHistory = edits)
        }
        repository.upsert(e)
        autoBackup.requestBackup()
        e
    }

    private fun changedFields(a: VaultEntry, b: VaultEntry): List<String> = buildList {
        if (a.title != b.title) add("title")
        if (a.url != b.url) add("url")
        if (a.username != b.username) add("username")
        if (a.password != b.password) add("password")
        if (a.appPin != b.appPin) add("appPin")
        if (a.notes != b.notes) add("notes")
        if (a.totp != b.totp) add("totp")
        if (a.category != b.category) add("category")
        if (a.tags != b.tags) add("tags")
    }
}
