package pro.babasitaram.vault.presentation.backup

/** Settings ki alag-alag rows ab Backup screen ke sahi tab / sahi action par seedha kholti hain (pehle sab ek hi page kholti thi). */
enum class BackupTarget { AUTO, RESTORE, EXPORT, PICK_VAULT, PICK_CSV, CONTACTS }

/** One-shot: Settings target set karti hai, BackupScreen use ek baar `take()` karke consume kar leti hai. */
object BackupDeepLink {
    @Volatile private var pending: BackupTarget? = null
    fun set(target: BackupTarget) { pending = target }
    fun take(): BackupTarget? = pending.also { pending = null }
}
