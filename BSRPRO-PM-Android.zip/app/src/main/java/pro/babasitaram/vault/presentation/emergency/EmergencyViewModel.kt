package pro.babasitaram.vault.presentation.emergency

import android.content.Context
import androidx.lifecycle.ViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.EmergencyAccessUseCase
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class EmergencyViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    private val emergency: EmergencyAccessUseCase,
    private val settings: SettingsRepository,
    private val activityLog: ActivityLogStore
) : ViewModel() {
    private val _status = MutableStateFlow<EmergencyAccessUseCase.Status?>(null)
    val status: StateFlow<EmergencyAccessUseCase.Status?> = _status.asStateFlow()
    private val _generatedKey = MutableStateFlow("")
    val generatedKey: StateFlow<String> = _generatedKey.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _contactName = MutableStateFlow("")
    val contactName: StateFlow<String> = _contactName.asStateFlow()
    private val _contactPhone = MutableStateFlow("")
    val contactPhone: StateFlow<String> = _contactPhone.asStateFlow()
    private val _now = MutableStateFlow(System.currentTimeMillis())
    val now: StateFlow<Long> = _now.asStateFlow()

    init { refresh() }

    fun refresh() {
        launchCatching {
            val s = settings.current()
            _contactName.value = s.emergencyContactName
            _contactPhone.value = s.emergencyContactPhone
            _status.value = emergency.status()
            _now.value = System.currentTimeMillis()
        }
    }

    fun setContactName(v: String) { _contactName.value = v }
    fun setContactPhone(v: String) { _contactPhone.value = v }
    fun saveContact() {
        launchCatching {
            settings.update { it.copy(emergencyContactName = _contactName.value.trim(), emergencyContactPhone = _contactPhone.value.trim()) }
            _message.value = context.getString(pro.babasitaram.vault.R.string.emergency_contact_saved)
        }
    }

    fun setup() {
        launchCatching {
            when (val result = emergency.setup()) {
                is VaultResult.Success -> {
                    _generatedKey.value = result.value
                    _message.value = context.getString(pro.babasitaram.vault.R.string.emergency_key_created)
                    activityLog.record("Emergency setup", "Emergency access configured")
                    _status.value = emergency.status()
                }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
        }
    }

    fun request(key: String) {
        launchCatching {
            when (val result = emergency.request(key)) {
                is VaultResult.Success -> { _message.value = context.getString(pro.babasitaram.vault.R.string.emergency_request_started); activityLog.record("Emergency request", "72-hour recovery timer started") }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun unlock(key: String) {
        launchCatching {
            when (val result = emergency.unlock(key)) {
                is VaultResult.Success -> { _message.value = context.getString(pro.babasitaram.vault.R.string.emergency_recovery_unlocked); activityLog.record("Emergency unlock", "Emergency recovery completed") }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun cancelRequest() {
        launchCatching {
            when (val result = emergency.cancel()) {
                is VaultResult.Success -> _message.value = context.getString(pro.babasitaram.vault.R.string.emergency_request_cancelled)
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun revoke() {
        launchCatching {
            when (val result = emergency.revoke()) {
                is VaultResult.Success -> { _message.value = context.getString(pro.babasitaram.vault.R.string.emergency_access_revoked); activityLog.record("Emergency access revoked", "Recovery access revoked") }
                is VaultResult.Failure -> _message.value = result.error.message
                VaultResult.Loading -> Unit
            }
            refresh()
        }
    }

    fun clearMessage() { _message.value = null }
}
