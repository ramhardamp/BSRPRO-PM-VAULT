package pro.babasitaram.vault.core.model

import kotlinx.serialization.Serializable

/** Everything stored in the encrypted vault blob. */
data class VaultData(
    val entries: List<VaultEntry> = emptyList(),
    val folders: List<Folder> = emptyList()
)

/** Plaintext layout inside the blob — identical to the extension's auto-backup payload. */
@Serializable
data class VaultPayload(
    val schema: String = "BSRPRO.Vault.Payload",
    val version: Int = 3,
    val entries: List<VaultEntry> = emptyList(),
    val folders: List<Folder> = emptyList()
)
