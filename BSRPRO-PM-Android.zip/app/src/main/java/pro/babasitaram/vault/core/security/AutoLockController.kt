package pro.babasitaram.vault.core.security

import android.os.SystemClock
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.di.ApplicationScope
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase

/**
 * Single vault-session authority for foreground and background.
 *
 * There used to be two competing timers: the absolute vault session and a separate
 * background grace timer. That made a 15-minute setting behave like a second, hidden
 * lock policy. The vault session is now the only timeout: leaving the app does not
 * restart or shorten it. The persisted biometric session uses the same expiry.
 */
@Singleton
class AutoLockController @Inject constructor(
    private val session: SessionKeyStore,
    private val persisted: BiometricSessionKeyStore,
    private val lockVault: LockVaultUseCase,
    @ApplicationScope private val scope: CoroutineScope
) {
    internal var clock: () -> Long = { SystemClock.elapsedRealtime() }
    private var sessionExpiryJob: Job? = null

    init {
        scope.launch {
            combine(session.isUnlocked, session.expiryVersion) { unlocked, _ -> unlocked }
                .collectLatest { unlocked ->
                sessionExpiryJob?.cancel()
                if (!unlocked) return@collectLatest
                val remaining = session.sessionRemainingMs(clock())
                if (remaining == Long.MAX_VALUE) return@collectLatest
                if (remaining <= 0L) {
                    lockVault("Auto")
                    return@collectLatest
                }
                sessionExpiryJob = launch {
                    delay(remaining)
                    if (!session.hasValidSession(clock())) lockVault("Session expired")
                }
            }
        }
    }

    /** Backgrounding only records process-death recovery metadata; it never starts a second timer. */
    fun onBackgrounded() {
        if (!session.isUnlocked.value || !session.hasValidSession(clock())) return
        scope.launch { persisted.markBackgrounded(System.currentTimeMillis()) }
    }

    /** Foregrounding never shortens the configured vault session. */
    fun onForegrounded() {
        if (!session.isUnlocked.value) return
        if (!session.hasValidSession(clock())) {
            scope.launch { lockVault("Session expired") }
            return
        }
        scope.launch { persisted.clearBackgrounded() }
    }
}
