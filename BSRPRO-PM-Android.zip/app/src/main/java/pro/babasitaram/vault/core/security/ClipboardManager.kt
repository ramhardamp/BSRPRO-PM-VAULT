package pro.babasitaram.vault.core.security

import android.content.ClipData
import android.content.Context
import android.os.Build
import android.os.PersistableBundle
import dagger.hilt.android.qualifiers.ApplicationContext
import java.security.MessageDigest
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import pro.babasitaram.vault.di.ApplicationScope

/**
 * Copies secrets to the clipboard flagged as sensitive and clears them automatically.
 * (Named VaultClipboardManager to avoid clashing with android.content.ClipboardManager.)
 */
@Singleton
class VaultClipboardManager @Inject constructor(
    @ApplicationContext private val context: Context,
    @ApplicationScope private val scope: CoroutineScope
) {
    private var clearJob: Job? = null

    private val system: android.content.ClipboardManager
        get() = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager

    @Synchronized
    fun copySensitive(text: String, clearAfterMs: Long = DEFAULT_CLEAR_MS, label: String = "vault") {
        clearJob?.cancel()
        val clip = ClipData.newPlainText(label, text)
        // Same key as ClipDescription.EXTRA_IS_SENSITIVE (API 33); harmless on older versions.
        clip.description.extras = PersistableBundle().apply { putBoolean(EXTRA_IS_SENSITIVE, true) }
        system.setPrimaryClip(clip)

        if (clearAfterMs > 0) {
            val fingerprint = sha256(text)
            clearJob = scope.launch {
                delay(clearAfterMs)
                clearIfUnchanged(fingerprint)
            }
        }
    }

    /** Immediately wipes the clipboard (called when the vault locks). */
    @Synchronized
    fun clearNow() {
        clearJob?.cancel()
        clearJob = null
        wipe()
    }

    private fun clearIfUnchanged(fingerprint: ByteArray) {
        // Since Android 10 a background app cannot read the clipboard (null/exception);
        // in that case we still clear, because clearing is always allowed and harmless.
        val current = runCatching { system.primaryClip?.getItemAt(0)?.text?.toString() }.getOrNull()
        if (!current.isNullOrEmpty() && !MessageDigest.isEqual(sha256(current), fingerprint)) return
        wipe()
    }

    private fun wipe() {
        runCatching { system.setPrimaryClip(ClipData.newPlainText("", "")) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) runCatching { system.clearPrimaryClip() }
    }

    private fun sha256(text: String): ByteArray = MessageDigest.getInstance("SHA-256").digest(text.toByteArray())

    companion object {
        const val DEFAULT_CLEAR_MS = 30_000L
        private const val EXTRA_IS_SENSITIVE = "android.content.extra.IS_SENSITIVE"
    }
}
