package pro.babasitaram.vault.data.backup

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/** Fix.md 1.3 / 7.2 (Phase 16E): picked folder me backup file ka selection. */
class BackupFolderFinderTest {

    private fun c(name: String, modified: Long, size: Long = 100L) = BackupCandidate(name, modified, size, name)

    @Test fun `exact BSRPRO Vault wins even when older`() {
        val ordered = BackupCandidates.order(
            listOf(c("BSRPRO_Backup_20261005_1200.Vault", 900), c("BSRPRO.Vault", 100))
        )
        assertEquals(listOf("BSRPRO.Vault", "BSRPRO_Backup_20261005_1200.Vault"), ordered.map { it.name })
    }

    @Test fun `exact name match ignores case`() {
        val ordered = BackupCandidates.order(listOf(c("bsrpro.vault", 1)))
        assertEquals(listOf("bsrpro.vault"), ordered.map { it.name })
    }

    @Test fun `without exact name other Vault files are tried newest first`() {
        val ordered = BackupCandidates.order(
            listOf(c("BSRPRO (1).Vault", 200), c("BSRPRO_Backup_20261005_1200.Vault", 500), c("old.Vault", 50))
        )
        assertEquals(
            listOf("BSRPRO_Backup_20261005_1200.Vault", "BSRPRO (1).Vault", "old.Vault"),
            ordered.map { it.name }
        )
    }

    @Test fun `non backup and hidden files are ignored`() {
        val ordered = BackupCandidates.order(
            listOf(
                c(".BSRPRO-1234.pending", 10),
                c(".bsrpro-old-1.vault", 10),
                c("BSRPRO_Vault_20261005.csv.Vault", 10),
                c("photo.jpg", 10),
                c("notes.txt", 10),
                c("BSRPRO.Vault", 10, size = 0L),
                c("BSRPRO-Recovery-1-abcd.Vault", 10)
            )
        )
        assertEquals(listOf("BSRPRO-Recovery-1-abcd.Vault"), ordered.map { it.name })
    }

    @Test fun `oversized file is ignored and unknown size is allowed`() {
        val ordered = BackupCandidates.order(
            listOf(c("big.Vault", 1, size = 26L * 1024L * 1024L), c("unknown.Vault", 1, size = -1L))
        )
        assertEquals(listOf("unknown.Vault"), ordered.map { it.name })
    }

    @Test fun `v3 container header is recognised`() {
        val head = """{"header":{"format":"BSRPRO.Vault","version":3},"ciphertext":"AAAA"}""".toByteArray()
        assertTrue(BackupCandidates.looksLikeV3Container(head))
        assertTrue(BackupCandidates.looksLikeV3Container(("\uFEFF\n  ").toByteArray() + head))
    }

    @Test fun `csv plain json and empty are not v3 containers`() {
        assertFalse(BackupCandidates.looksLikeV3Container("name,url,username,password\n".toByteArray()))
        assertFalse(BackupCandidates.looksLikeV3Container("""{"entries":[]}""".toByteArray()))
        assertFalse(BackupCandidates.looksLikeV3Container(ByteArray(0)))
    }
}
