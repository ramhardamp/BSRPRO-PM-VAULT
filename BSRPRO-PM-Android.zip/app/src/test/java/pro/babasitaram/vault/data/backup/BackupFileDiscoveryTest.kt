package pro.babasitaram.vault.data.backup

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import java.io.File
import java.nio.file.Path

class BackupFileDiscoveryTest {
    @TempDir lateinit var temp: Path

    @Test fun `backup exists returns matching file`() {
        val file = File(temp.toFile(), AutoBackupManager.FINAL_NAME).apply { writeText("v3") }
        assertEquals(file, BackupFileDiscovery.firstExisting(listOf(file)))
    }

    @Test fun `missing backup returns null`() {
        val missing = File(temp.toFile(), AutoBackupManager.FINAL_NAME)
        assertNull(BackupFileDiscovery.firstExisting(listOf(missing)))
    }

    @Test fun `multiple candidates selects first existing exact backup name`() {
        val wrong = File(temp.toFile(), "other.Vault").apply { writeText("wrong") }
        val missingDir = File(temp.toFile(), "missing")
        val absent = File(missingDir, AutoBackupManager.FINAL_NAME)
        val found = File(File(temp.toFile(), "present").apply { mkdirs() }, AutoBackupManager.FINAL_NAME).apply { writeText("right") }
        assertEquals(found, BackupFileDiscovery.firstExisting(listOf(wrong, absent, found)))
    }

    @Test fun `dated legacy file is not mistaken for the canonical backup`() {
        val dated = File(temp.toFile(), "vault_20261002.Vault").apply { writeText("legacy") }
        assertNull(BackupFileDiscovery.firstExisting(listOf(dated)))
    }

    @Test fun `permission denial returns null`() {
        assertNull(BackupFileDiscovery.safelyFind { throw SecurityException("permission denied") })
    }
}
