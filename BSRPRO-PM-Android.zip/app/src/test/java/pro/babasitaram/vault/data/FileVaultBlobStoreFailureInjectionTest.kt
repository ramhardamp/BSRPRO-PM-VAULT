package pro.babasitaram.vault.data

import java.io.File
import java.io.IOException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore
import pro.babasitaram.vault.data.local.blob.VaultWriteHooks

class FileVaultBlobStoreFailureInjectionTest {
    @TempDir
    lateinit var dir: File

    private val pw = "Master#Pass123456".toCharArray()
    private fun data(title: String) = VaultData(listOf(VaultEntry(id = "id", title = title)))

    @Test
    fun `temporary write failure leaves main vault unchanged`() = runTest {
        val healthy = FileVaultBlobStore(dir, Dispatchers.IO)
        healthy.write(data("old"), pw)
        val failing = FileVaultBlobStore(dir, Dispatchers.IO, VaultWriteHooks { step ->
            if (step == VaultWriteHooks.Step.TEMP_WRITE) throw IOException("injected temp write failure")
        })
        assertThrows<Exception> { failing.write(data("new"), pw) }
        assertEquals("old", healthy.read(pw).entries.single().title)
    }

    @Test
    fun `backup rotation failure leaves main vault unchanged`() = runTest {
        val healthy = FileVaultBlobStore(dir, Dispatchers.IO)
        healthy.write(data("old"), pw)
        val failing = FileVaultBlobStore(dir, Dispatchers.IO, VaultWriteHooks { step ->
            if (step == VaultWriteHooks.Step.BACKUP_ROTATE) throw IOException("injected backup failure")
        })
        assertThrows<Exception> { failing.write(data("new"), pw) }
        assertEquals("old", healthy.read(pw).entries.single().title)
    }

    @Test
    fun `atomic move failure with unsupported fallback still preserves main when fallback fails`() = runTest {
        val healthy = FileVaultBlobStore(dir, Dispatchers.IO)
        healthy.write(data("old"), pw)
        val failing = FileVaultBlobStore(dir, Dispatchers.IO, VaultWriteHooks { step ->
            when (step) {
                VaultWriteHooks.Step.ATOMIC_MOVE -> throw java.nio.file.AtomicMoveNotSupportedException("injected")
                VaultWriteHooks.Step.FALLBACK_MOVE -> throw IOException("injected fallback move failure")
                else -> Unit
            }
        })
        assertThrows<Exception> { failing.write(data("new"), pw) }
        assertEquals("old", healthy.read(pw).entries.single().title)
        assertTrue(File(dir, "vault.blob.tmp").exists())
    }

    @Test
    fun `first write failure without backups leaves no committed vault`() = runTest {
        val failing = FileVaultBlobStore(dir, Dispatchers.IO, VaultWriteHooks { step ->
            if (step == VaultWriteHooks.Step.TEMP_WRITE) throw IOException("injected first write failure")
        })
        assertThrows<Exception> { failing.write(data("first"), pw) }
        assertFalse(File(dir, "vault.blob").exists())
        assertFalse(File(dir, "vault.blob.bak").exists())
        assertFalse(File(dir, "vault.blob.bak2").exists())
    }
}
