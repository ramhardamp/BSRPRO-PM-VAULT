package pro.babasitaram.vault.security

import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import java.io.File

class UnifiedAutoLockPolicyStaticTest {
    private val controller = File("src/main/java/pro/babasitaram/vault/core/security/AutoLockController.kt").readText()
    private val restore = File("src/main/java/pro/babasitaram/vault/domain/usecase/RestorePersistedSessionUseCase.kt").readText()
    private val settings = File("src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt").readText()
    private val store = File("src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt").readText()

    @Test fun `background does not own a second timer`() {
        assertTrue(controller.contains("single vault-session authority"))
        assertTrue(controller.contains("persisted.markBackgrounded"))
        assertTrue(!controller.contains("backgroundJob"))
        assertTrue(!controller.contains("backgroundGraceSeconds.toTimeoutMs"))
    }

    @Test fun `persisted session uses absolute vault expiry only`() {
        assertTrue(restore.contains("metadata.expiresAtWallMs"))
        assertTrue(!restore.contains("now - bg >= cfg.backgroundGraceSeconds"))
    }

    @Test fun `settings expose one lock timer and mirror legacy field`() {
        assertTrue(settings.contains("ChoiceRow("Vault auto-lock""))
        assertTrue(!settings.contains("ChoiceRow("Background timeout""))
        assertTrue(store.contains("backgroundGraceSeconds = (this[VAULT_SESSION] ?: d.vaultSessionSeconds)"))
    }
}
