package pro.babasitaram.vault.presentation

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.core.model.PasswordHistoryItem
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.presentation.editor.EditorForm
import pro.babasitaram.vault.presentation.editor.toEntry
import pro.babasitaram.vault.presentation.editor.toForm
import pro.babasitaram.vault.presentation.editor.SAVE_CONFIRMATION_DURATION_MS
import pro.babasitaram.vault.presentation.editor.saveConfirmationLabel
import pro.babasitaram.vault.presentation.util.toUserMessage

class EditorMappingTest {
    @Test
    fun `form to entry trims, parses tags and drops empty custom fields`() {
        val e = EditorForm(
            title = "  Mail ", tags = "a, b ,, c", username = " bob ",
            customFields = listOf(CustomField("k", "v"), CustomField("", "ignored"))
        ).toEntry(null)
        assertEquals("Mail", e.title)
        assertEquals("bob", e.username)
        assertEquals(listOf("a", "b", "c"), e.tags)
        assertEquals(listOf(CustomField("k", "v")), e.customFields)
    }

    @Test
    fun `selected Android app name and package both survive save and edit mapping`() {
        val selected = EditorForm(title = "JioPOS Plus", appName = "JioPOS Plus", appPackage = "com.jio.jpp1")
        val saved = selected.toEntry(null)
        assertEquals("JioPOS Plus", saved.appName)
        assertEquals("com.jio.jpp1", saved.appPackage)
        val reopened = saved.toForm()
        assertEquals("JioPOS Plus", reopened.appName)
        assertEquals("com.jio.jpp1", reopened.appPackage)
    }

    @Test
    fun `editing keeps fields the form does not show`() {
        val base = VaultEntry(
            id = "1", title = "T", appPackage = "com.x", appName = "X", isPrimaryAppLogin = true,
            createdAt = 7, passwordHistory = listOf(PasswordHistoryItem("old", 1)), type = "legacy"
        )
        val back = base.toForm().copy(title = "T2").toEntry(base)
        assertEquals("T2", back.title)
        assertEquals("com.x", back.appPackage)
        assertTrue(back.isPrimaryAppLogin)
        assertEquals(7, back.createdAt)
        assertEquals(1, back.passwordHistory.size)
        assertEquals("legacy", back.type)
    }

    @Test
    fun `save confirmation is a dismissible thirty second status contract`() {
        assertEquals(30_000L, SAVE_CONFIRMATION_DURATION_MS)
        assertEquals("Saved to vault", saveConfirmationLabel(false))
        assertEquals("Updated", saveConfirmationLabel(true))
    }

    @Test
    fun `PIN is retained independently from website password`() {
        val entry = EditorForm(title = "Bank", password = "web-secret", appPin = "0123").toEntry(null)
        assertEquals("web-secret", entry.password)
        assertEquals("0123", entry.appPin)
        assertEquals("0123", entry.toForm().appPin)
    }

    @Test
    fun `note record type sets the note flag`() {
        assertTrue(EditorForm(recordType = "note", title = "n").toEntry(null).isNote)
        assertFalse(EditorForm(recordType = "login", title = "n").toEntry(null).isNote)
        assertEquals("note", VaultEntry(isNote = true).toForm().recordType)
    }

    @Test
    fun `user messages never leak internals`() {
        assertEquals("Incorrect password", VaultError.InvalidMasterPassword.toUserMessage())
        assertEquals("Too many attempts. Try again in 2s", VaultError.RateLimited(1_500).toUserMessage())
        assertEquals("Something went wrong. Please try again.", VaultError.CryptoFailure(RuntimeException("secret detail")).toUserMessage())
        assertEquals("Passwords do not match", VaultError.Validation("Passwords do not match").toUserMessage())
    }
}
