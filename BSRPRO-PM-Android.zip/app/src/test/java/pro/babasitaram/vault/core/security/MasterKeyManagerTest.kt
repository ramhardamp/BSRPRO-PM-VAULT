package pro.babasitaram.vault.core.security

import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertSame
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import pro.babasitaram.vault.core.crypto.KeyBackend
import pro.babasitaram.vault.core.crypto.KeystoreMasterKeyManager
import pro.babasitaram.vault.core.util.VaultError

/** JVM test with a software KeyBackend. Real AndroidKeyStore behaviour needs an instrumented test on a device. */
class MasterKeyManagerTest {

    private class MemoryBackend : KeyBackend {
        val keys = mutableMapOf<String, SecretKey>()
        var created = 0
        override fun get(alias: String) = keys[alias]
        override fun create(alias: String): SecretKey {
            created++
            return KeyGenerator.getInstance("AES").apply { init(256) }.generateKey().also { keys[alias] = it }
        }
    }

    private fun manager(b: KeyBackend) = KeystoreMasterKeyManager(b, Dispatchers.Unconfined)

    @Test
    fun `second call returns the same key and creates only once`() = runTest {
        val backend = MemoryBackend()
        val m = manager(backend)
        assertSame(m.generateOrRetrieveKey(), m.generateOrRetrieveKey())
        assertEquals(1, backend.created)
    }

    @Test
    fun `new manager reuses the stored key`() = runTest {
        val backend = MemoryBackend()
        val k1 = manager(backend).generateOrRetrieveKey()
        val k2 = manager(backend).generateOrRetrieveKey()
        assertSame(k1, k2)
        assertEquals(1, backend.created)
        assertEquals(KeystoreMasterKeyManager.ALIAS, backend.keys.keys.single())
    }

    @Test
    fun `wrap then unwrap round trips`() = runTest {
        val m = manager(MemoryBackend())
        val secret = ByteArray(32) { it.toByte() }
        assertArrayEquals(secret, m.unwrapKey(m.wrapKey(secret)))
    }

    @Test
    fun `wrapping twice gives different output`() = runTest {
        val m = manager(MemoryBackend())
        val s = ByteArray(16)
        assertNotEquals(m.wrapKey(s).toList(), m.wrapKey(s).toList())
    }

    @Test
    fun `another manager with the same backend can unwrap`() = runTest {
        val backend = MemoryBackend()
        val wrapped = manager(backend).wrapKey("data".toByteArray())
        assertArrayEquals("data".toByteArray(), manager(backend).unwrapKey(wrapped))
    }

    @Test
    fun `tampered wrapped key fails`() = runTest {
        val m = manager(MemoryBackend())
        val w = m.wrapKey("data".toByteArray())
        w[w.size - 1] = (w[w.size - 1].toInt() xor 1).toByte()
        assertThrows<VaultError.CryptoFailure> { m.unwrapKey(w) }
    }

    @Test
    fun `too short wrapped key is invalid format`() = runTest {
        assertThrows<VaultError.InvalidFormat> { manager(MemoryBackend()).unwrapKey(ByteArray(5)) }
    }
}
