package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class AutofillPresentationTest {
    @Test fun `light and dark suggestions use distinct readable palette tokens`() {
        val light = AutofillPalette.forNight(false)
        val dark = AutofillPalette.forNight(true)
        assertNotEquals(light.background, dark.background)
        assertNotEquals(light.primary, dark.primary)
        assertNotEquals(light.secondary, dark.secondary)
        assertTrue(light.background != light.primary)
        assertTrue(dark.background != dark.primary)
    }
}
