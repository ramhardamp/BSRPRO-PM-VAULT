package pro.babasitaram.vault.data.transfer

import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.model.VaultEntry

class LinkedLoginInteropTest {
    @Test fun `website and app with same credentials are one duplicate identity`() {
        val existing = VaultEntry(id="e1", title="HDFC", url="https://www.hdfcbank.com", username="u", password="old", appPackage="com.snapwork.hdfc", appName="HDFC Bank", loginUri="androidapp://com.snapwork.hdfc")
        val incoming = existing.copy(password="new")
        assertEquals("e1", DuplicateDetector.find(incoming, listOf(existing))?.id)
    }

    @Test fun `website and app are not merged when only one target exists`() {
        val website = VaultEntry(id="w", url="https://www.hdfcbank.com", username="u", password="p")
        val app = VaultEntry(id="a", url="", username="u", password="p", appPackage="com.snapwork.hdfc", appName="HDFC Bank", loginUri="androidapp://com.snapwork.hdfc")
        assertNull(DuplicateDetector.find(app, listOf(website)))
        assertNull(DuplicateDetector.find(website, listOf(app)))
    }

    @Test fun `app package is never treated as a website URL`() {
        val app = VaultEntry(id="a", url="", username="u", password="p", appPackage="com.example.app")
        val fakeWebsite = VaultEntry(id="w", url="https://com.example.app", username="u", password="p")
        assertNull(DuplicateDetector.find(app, listOf(fakeWebsite)))
    }
}
