package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import java.io.File

class AutofillDiagnosticsTest {
    @BeforeEach @AfterEach
    fun reset() = AutofillDiagnostics.clear()

    @Test
    fun `newest event comes first`() {
        AutofillDiagnostics.record("1 onFillRequest called")
        AutofillDiagnostics.record("2 parsed", "pkg=com.example")
        val s = AutofillDiagnostics.snapshot()
        assertEquals(2, s.size)
        assertTrue(s[0].contains("2 parsed — pkg=com.example"))
        assertTrue(s[1].contains("1 onFillRequest called"))
    }

    @Test
    fun `buffer is capped at 40 events`() {
        repeat(100) { AutofillDiagnostics.record("event $it") }
        val s = AutofillDiagnostics.snapshot()
        assertEquals(40, s.size)
        assertTrue(s.first().contains("event 99"))
        assertTrue(s.last().contains("event 60"))
    }

    @Test
    fun `report explains when empty and clear empties`() {
        assertTrue(AutofillDiagnostics.report().contains("No autofill requests"))
        AutofillDiagnostics.record("x")
        assertFalse(AutofillDiagnostics.report().contains("No autofill requests"))
        AutofillDiagnostics.clear()
        assertTrue(AutofillDiagnostics.snapshot().isEmpty())
    }
}

class AutofillDiagnosisTest {
    private fun ev(stage: String, detail: String = "") = AutofillDiagnostics.Event("11:14:35", stage, detail)

    /** Wahi log jo user ne bheja (KDE Connect screen par koi field nahi). */
    private val kde = listOf(
        ev("service connected"),
        ev("1 onFillRequest called"),
        ev("2 parsed", "pkg=org.kde.kdeconnect_tp domain=- scheme=- username=0 password=0 pin=0 otp=0"),
        ev("2 skipped", "no fillable fields")
    )

    @Test fun `no fillable fields explains the real reason`() {
        val r = AutofillDiagnostics.diagnose(kde, serviceEnabled = true)
        assertTrue(r.contains("org.kde.kdeconnect_tp"))
        assertTrue(r.contains("login field"))
    }

    @Test fun `summary is one short line per request`() {
        val s = AutofillDiagnostics.summarize(kde, 6)
        assertEquals(1, s.size)
        assertEquals("11:14:35  kdeconnect_tp → koi login field nahi", s[0])
    }

    @Test fun `service not selected is explained first`() {
        assertTrue(AutofillDiagnostics.diagnose(kde, serviceEnabled = false).contains("Autofill service"))
        assertTrue(AutofillDiagnostics.diagnose(emptyList(), serviceEnabled = false).contains("Autofill service"))
    }

    @Test fun `empty log with service on explains why nothing arrived`() {
        assertTrue(AutofillDiagnostics.diagnose(emptyList(), serviceEnabled = true).contains("koi request nahi"))
    }

    @Test fun `locked, no match, and built datasets each get their own reason`() {
        val head = listOf(ev("1 onFillRequest called"), ev("2 parsed", "pkg=com.x domain=shop.in scheme=https username=1 password=1 pin=0 otp=0"))
        assertTrue(AutofillDiagnostics.outcome(head + ev("4 offering unlock entry", "dataset authentication")).reason.contains("Unlock"))
        assertTrue(AutofillDiagnostics.outcome(head + ev("4 matches", "0 for shop.in")).reason.contains("shop.in"))
        assertEquals("2 suggestion bheje", AutofillDiagnostics.outcome(head + ev("4 matches", "2 for shop.in") + ev("4 datasets", "2 built, saveInfo=true")).short)
    }

    @Test fun `only the latest request decides the reason`() {
        val older = listOf(ev("1 onFillRequest called"), ev("2 skipped", "plain http page"))
        val newer = listOf(ev("1 onFillRequest called"), ev("2 parsed", "pkg=com.x domain=a.in scheme=https username=1 password=1 pin=0 otp=0"), ev("4 matches", "0 for a.in"))
        assertTrue(AutofillDiagnostics.diagnose(older + newer, true).contains("a.in"))
    }
}

/** Regression guards for the files that decide whether Android even talks to the service. */
class AutofillRegistrationTest {
    private val manifest = File("src/main/AndroidManifest.xml").readText()
    private val serviceXml = File("src/main/res/xml/autofill_service.xml").readText()

    @Test
    fun `service is declared with the bind permission, intent filter and metadata`() {
        val service = manifest.substringAfter("<service").substringBefore("</service>")
        assertTrue(service.contains("android.permission.BIND_AUTOFILL_SERVICE"))
        assertTrue(service.contains("android.service.autofill.AutofillService"))
        assertTrue(service.contains("android:name=\"android.autofill\""))
        assertTrue(service.contains("@xml/autofill_service"))
        assertTrue(service.contains("android:exported=\"true\""))
        assertTrue(service.contains("android:icon=\"@mipmap/ic_launcher\""))
        assertTrue(service.contains("android:label=\"@string/autofill_service_label\""))
    }

    @Test
    fun `popular browsers are registered for compatibility mode`() {
        listOf("com.android.chrome", "com.brave.browser", "com.microsoft.emmx", "org.mozilla.firefox", "com.sec.android.app.sbrowser")
            .forEach { assertTrue(serviceXml.contains("compatibility-package android:name=\"$it\""), it) }
        assertTrue(serviceXml.contains("android:maxLongVersionCode"))
    }
}


class AutofillIdPropagationStaticTest {
    private val parser = File("src/main/java/pro/babasitaram/vault/autofill/AutofillParser.kt").readText()
    private val factory = File("src/main/java/pro/babasitaram/vault/autofill/AutofillDatasetFactory.kt").readText()
    private val auth = File("src/main/java/pro/babasitaram/vault/autofill/AutofillAuthActivity.kt").readText()

    @Test
    fun `framework AutofillIds are captured and returned unchanged`() {
        assertTrue(parser.contains("val id = node.autofillId"))
        assertTrue(parser.contains("AutofillField(raw.id, type, raw.focused, raw.value)"))
        assertTrue(factory.contains("f.id, AutofillValue.forText(v)"))
        assertTrue(auth.contains("EXTRA_IDS, ArrayList<AutofillId>(parsed.fillableFields.map { it.id })"))
    }

    @Test
    fun `nothing-to-fill path records the concrete target`() {
        assertTrue(auth.contains("No saved login for this"))
        assertTrue(auth.contains("p.webDomain ?: p.packageName"))
    }

    @Test
    fun `authentication result is one-shot and activity can finish immediately`() {
        assertTrue(auth.contains("private var resultDelivered = false"))
        assertTrue(auth.contains("if (resultDelivered || isFinishing || isDestroyed) return"))
        assertTrue(auth.contains("EXTRA_AUTHENTICATION_RESULT"))
        assertTrue(auth.contains("All reusable state lives in SessionKeyStore/AutofillSessionGate"))
    }
}


class AutofillDeadlineStaticTest {
    private val service = File("src/main/java/pro/babasitaram/vault/autofill/VaultAutofillService.kt").readText()

    @Test fun `fill response has an outer deadline guard`() {
        assertTrue(service.contains("withTimeoutOrNull(BUILD_RESPONSE_TIMEOUT_MS)"))
        assertTrue(service.contains("const val BUILD_RESPONSE_TIMEOUT_MS = 4_250L"))
    }
}
