package pro.babasitaram.vault.core.security

import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.testing.FakeLockoutStore

class RateLimiterTest {
    private var now = 1_000_000L
    private val store = FakeLockoutStore()
    private val limiter = RateLimiter(store, clock = { now })

    @Test
    fun `four failures do not lock`() = runTest {
        repeat(4) { limiter.recordFailure() }
        limiter.check()
        assertEquals(1, limiter.remainingAttempts(limiter.state()))
    }

    @Test
    fun `fifth failure locks for 30 seconds`() = runTest {
        repeat(5) { limiter.recordFailure() }
        val e = assertThrows<VaultError.RateLimited> { limiter.check() }
        assertEquals(30_000L, e.retryAfterMs)
        assertEquals(0, limiter.remainingAttempts(limiter.state()))
    }

    @Test
    fun `lock expires`() = runTest {
        repeat(5) { limiter.recordFailure() }
        now += 30_001
        limiter.check()
        assertEquals(5, limiter.remainingAttempts(limiter.state()))
    }

    @Test
    fun `success resets the counter`() = runTest {
        repeat(4) { limiter.recordFailure() }
        limiter.recordSuccess()
        repeat(4) { limiter.recordFailure() }
        limiter.check()
    }

    @Test
    fun `state survives a new limiter instance (app restart)`() = runTest {
        repeat(5) { limiter.recordFailure() }
        val restarted = RateLimiter(store, clock = { now })
        assertThrows<VaultError.RateLimited> { restarted.check() }
    }
}
