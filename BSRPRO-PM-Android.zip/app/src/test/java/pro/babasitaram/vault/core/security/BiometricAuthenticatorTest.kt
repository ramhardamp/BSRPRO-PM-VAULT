package pro.babasitaram.vault.core.security

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import app.cash.turbine.test
import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class BiometricAuthenticatorTest {

    private suspend fun withCallback(
        block: suspend app.cash.turbine.ReceiveTurbine<AuthResult>.(BiometricPrompt.AuthenticationCallback) -> Unit
    ) {
        val captured = CompletableDeferred<BiometricPrompt.AuthenticationCallback>()
        authCallbackFlow<Unit>(start = { captured.complete(it) }, cancel = { }).test {
            block(captured.await())
        }
    }

    @Test
    fun `user dismissing the prompt yields Cancelled`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationError(BiometricPrompt.ERROR_USER_CANCELED, "dismissed")
            assertEquals(AuthResult.Cancelled, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `negative button requests device credential fallback`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationError(BiometricPrompt.ERROR_NEGATIVE_BUTTON, "cancel")
            assertEquals(AuthResult.FallbackRequested, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `biometric lockout falls back to device credential`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationError(BiometricPrompt.ERROR_LOCKOUT, "locked")
            assertEquals(AuthResult.FallbackRequested, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `no biometric hardware falls back to device credential instead of failing`() = runTest {
        listOf(
            BiometricPrompt.ERROR_HW_NOT_PRESENT,
            BiometricPrompt.ERROR_HW_UNAVAILABLE,
            BiometricPrompt.ERROR_NO_BIOMETRICS,
            BiometricPrompt.ERROR_LOCKOUT_PERMANENT
        ).forEach { code ->
            assertEquals(AuthResult.FallbackRequested, mapAuthError(code, "Biometric hardware unavailable"))
        }
    }

    @Test
    fun `no device credential configured stays a clear Error`() {
        val r = mapAuthError(BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL, "no lock")
        assertTrue(r is AuthResult.Error && r.code == BiometricPrompt.ERROR_NO_DEVICE_CREDENTIAL)
    }

    @Test
    fun `cancel stays Cancelled and never falls back`() {
        assertEquals(AuthResult.Cancelled, mapAuthError(BiometricPrompt.ERROR_CANCELED, "c"))
        assertEquals(AuthResult.Cancelled, mapAuthError(BiometricPrompt.ERROR_USER_CANCELED, "c"))
    }

    @Test
    fun `rejected attempt yields Failed and the flow stays open`() = runTest {
        withCallback { cb ->
            cb.onAuthenticationFailed()
            assertEquals(AuthResult.Failed, awaitItem())
            cb.onAuthenticationError(BiometricPrompt.ERROR_USER_CANCELED, "x")
            assertEquals(AuthResult.Cancelled, awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `success yields Success and completes`() = runTest {
        withCallback { cb ->
            val result = mockk<BiometricPrompt.AuthenticationResult> { every { cryptoObject } returns null }
            cb.onAuthenticationSucceeded(result)
            assertEquals(AuthResult.Success(null), awaitItem())
            awaitComplete()
        }
    }

    @Test
    fun `api 28-29 with a secure lock screen uses the system credential prompt`() {
        listOf(26, 27, 28, 29).forEach { sdk ->
            assertTrue(needsLegacyCredentialPrompt(sdk, BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED, deviceSecure = true))
        }
    }

    @Test
    fun `legacy credential prompt is not used when unnecessary or impossible`() {
        // API 30+ handles BIOMETRIC_STRONG|DEVICE_CREDENTIAL natively
        assertFalse(needsLegacyCredentialPrompt(30, BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED, deviceSecure = true))
        assertFalse(needsLegacyCredentialPrompt(34, BiometricManager.BIOMETRIC_SUCCESS, deviceSecure = true))
        // already supported by AndroidX on this device
        assertFalse(needsLegacyCredentialPrompt(28, BiometricManager.BIOMETRIC_SUCCESS, deviceSecure = true))
        // no PIN/Pattern/Password configured: nothing to confirm, Master Password remains the fallback
        assertFalse(needsLegacyCredentialPrompt(28, BiometricManager.BIOMETRIC_ERROR_UNSUPPORTED, deviceSecure = false))
    }
}
