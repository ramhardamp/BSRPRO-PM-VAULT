package pro.babasitaram.vault.data.transfer

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.model.VaultEntry

class AppLoginRestorePolicyTest {
    @Test
    fun `missing app fields are recovered from existing app login`() {
        val old = VaultEntry(
            id = "app-1", title = "Bank", username = "user", password = "old-password",
            appPackage = "com.example.bank", appName = "Bank", loginUri = "androidapp://com.example.bank",
            appPin = "1234", isPrimaryAppLogin = true
        )
        val incoming = old.copy(password = "", appPackage = "", appName = "", loginUri = "", appPin = "", isPrimaryAppLogin = false)

        val result = AppLoginRestorePolicy.protect(listOf(old), listOf(incoming)).single()

        assertEquals("old-password", result.password)
        assertEquals("com.example.bank", result.appPackage)
        assertEquals("Bank", result.appName)
        assertEquals("androidapp://com.example.bank", result.loginUri)
        assertEquals("1234", result.appPin)
        assertTrue(result.isPrimaryAppLogin)
    }

    @Test
    fun `existing app login absent from backup is retained`() {
        val old = VaultEntry(id = "app-1", title = "Bank", username = "user", password = "pw", appPackage = "com.example.bank")
        val incoming = VaultEntry(id = "web-1", title = "Website", url = "https://example.com", username = "user", password = "web")

        val result = AppLoginRestorePolicy.protect(listOf(old), listOf(incoming))

        assertEquals(2, result.size)
        assertTrue(result.any { it.id == "app-1" && it.appPackage == "com.example.bank" && it.password == "pw" })
    }

    @Test
    fun `incoming app password wins when present`() {
        val old = VaultEntry(id = "app-1", username = "user", password = "old", appPackage = "com.example.bank")
        val incoming = old.copy(password = "new")

        val result = AppLoginRestorePolicy.protect(listOf(old), listOf(incoming)).single()

        assertEquals("new", result.password)
        assertEquals("com.example.bank", result.appPackage)
    }
}
    @Test
    fun `linked website app login is also protected`() {
        val old = VaultEntry(id = "linked", url = "https://bank.example", username = "user", password = "pw", appPackage = "com.example.bank", appName = "Bank")
        val incoming = VaultEntry(id = "linked", url = "https://bank.example", username = "user", password = "new", appPackage = "", appName = "")

        val result = AppLoginRestorePolicy.protect(listOf(old), listOf(incoming)).single()

        assertEquals("new", result.password)
        assertEquals("com.example.bank", result.appPackage)
        assertEquals("Bank", result.appName)
    }

