package pro.babasitaram.vault.core.security

import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.domain.usecase.LockVaultUseCase
import pro.babasitaram.vault.testing.FakeSettings

@OptIn(ExperimentalCoroutinesApi::class)
class AutoLockControllerTest {
    private val lock = mockk<LockVaultUseCase>(relaxed = true)
    private val persisted = mockk<BiometricSessionKeyStore>(relaxed = true)

    private fun unlockedSession(seconds: Int = 60) = SessionKeyStore().also {
        it.unlock("Str0ng!Passw0rd".toCharArray(), seconds, nowElapsedMs = 0L, nowWallMs = 0L)
    }

    @Test
    fun `locks after the background grace period`() = runTest {
        val c = AutoLockController(FakeSettings(VaultSettings(backgroundGraceSeconds = 60)), unlockedSession(), persisted, lock, backgroundScope)
        c.onBackgrounded()
        advanceTimeBy(59_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
        advanceTimeBy(2_000); runCurrent()
        coVerify(exactly = 1) { lock.invoke() }
    }

    @Test
    fun `returning to the app in time cancels the lock`() = runTest {
        var t = 0L
        val c = AutoLockController(FakeSettings(VaultSettings(backgroundGraceSeconds = 60)), unlockedSession(), persisted, lock, backgroundScope)
        c.clock = { t }
        c.onBackgrounded()
        advanceTimeBy(30_000); runCurrent()
        t = 30_000
        c.onForegrounded()
        advanceTimeBy(120_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }

    @Test
    fun `returning after the timeout locks even if the timer never fired`() = runTest {
        var t = 0L
        val c = AutoLockController(FakeSettings(VaultSettings(backgroundGraceSeconds = 60)), unlockedSession(), persisted, lock, backgroundScope)
        c.clock = { t }
        c.onBackgrounded()
        t = 120_000          // process was frozen: virtual time did not advance, wall clock did
        c.onForegrounded()
        runCurrent()
        coVerify(exactly = 1) { lock.invoke() }
    }

    @Test
    fun `zero seconds locks immediately`() = runTest {
        val c = AutoLockController(FakeSettings(VaultSettings(backgroundGraceSeconds = 5)), unlockedSession(5), persisted, lock, backgroundScope)
        c.onBackgrounded()
        advanceTimeBy(6_000); runCurrent()
        coVerify(exactly = 1) { lock.invoke(any()) }
    }

    @Test
    fun `background timeout is independent of the absolute session lifetime`() = runTest {
        val c = AutoLockController(
            FakeSettings(VaultSettings(backgroundGraceSeconds = 60, vaultSessionSeconds = 24 * 60 * 60)),
            unlockedSession(24 * 60 * 60), persisted, lock, backgroundScope
        )
        c.onBackgrounded()
        advanceTimeBy(59_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke(any()) }
        advanceTimeBy(2_000); runCurrent()
        coVerify(exactly = 1) { lock.invoke(any()) }
    }

    @Test
    fun `absolute session expiry locks even without a background transition`() = runTest {
        val c = AutoLockController(
            FakeSettings(VaultSettings(backgroundGraceSeconds = 4 * 60 * 60, vaultSessionSeconds = 10)),
            unlockedSession(10), persisted, lock, backgroundScope
        )
        advanceTimeBy(11_000); runCurrent()
        coVerify(exactly = 1) { lock.invoke("Session expired") }
    }

    @Test
    fun `does nothing while already locked`() = runTest {
        val c = AutoLockController(FakeSettings(), SessionKeyStore(), persisted, lock, backgroundScope)
        c.onBackgrounded()
        advanceTimeBy(600_000); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }
}

@OptIn(ExperimentalCoroutinesApi::class)
class AutoLockNeverTest {
    @Test
    fun `never means the vault is not locked when going to the background`() = runTest {
        val lock = mockk<LockVaultUseCase>(relaxed = true)
        val session = SessionKeyStore().also { it.unlock("Str0ng!Passw0rd".toCharArray()) }
        val persisted = mockk<BiometricSessionKeyStore>(relaxed = true)
        val c = AutoLockController(FakeSettings(VaultSettings(backgroundGraceSeconds = 4 * 60 * 60, vaultSessionSeconds = VaultSettings.AUTO_LOCK_NEVER)), session, persisted, lock, backgroundScope)
        var t = 1L
        c.clock = { t }
        c.onBackgrounded()
        advanceTimeBy(3_600_000); runCurrent()
        t = 7_200_000
        c.onForegrounded(); runCurrent()
        coVerify(exactly = 0) { lock.invoke() }
    }
}
