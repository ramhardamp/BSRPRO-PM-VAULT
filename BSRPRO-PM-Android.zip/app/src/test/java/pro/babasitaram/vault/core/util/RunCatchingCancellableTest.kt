package pro.babasitaram.vault.core.util

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

class RunCatchingCancellableTest {
    @Test
    fun `returns success value`() = runTest {
        assertEquals(7, runCatchingCancellable { 7 }.getOrNull())
    }

    @Test
    fun `wraps ordinary failure`() = runTest {
        val r = runCatchingCancellable { error("boom") }
        assertTrue(r.isFailure)
    }

    @Test
    fun `rethrows cancellation instead of swallowing it`() = runTest {
        assertThrows<CancellationException> {
            runCatchingCancellable { throw CancellationException("cancelled") }
        }
    }
}
