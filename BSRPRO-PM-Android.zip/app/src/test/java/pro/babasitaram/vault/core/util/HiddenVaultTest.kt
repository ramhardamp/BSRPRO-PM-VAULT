package pro.babasitaram.vault.core.util

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.LockoutState
import pro.babasitaram.vault.core.security.LockoutStore
import pro.babasitaram.vault.core.security.RateLimiter

class HiddenVaultTest {
    @Test fun `tag is added once and removed cleanly`() {
        val on = HiddenVault.withHidden("work, bank", true)
        assertTrue(HiddenVault.isHiddenText(on))
        assertEquals(on, HiddenVault.withHidden(on, true))
        assertEquals("work, bank", HiddenVault.withHidden(on, false))
    }

    @Test fun `entry extension reads the tag`() {
        assertTrue(VaultEntry(tags = listOf("x", "Hidden-Vault")).isHiddenVault)
        assertFalse(VaultEntry(tags = listOf("x")).isHiddenVault)
    }
}

class RateLimiterPolicyTest {
    private class Store : LockoutStore {
        var s = LockoutState()
        override suspend fun load() = s
        override suspend fun save(state: LockoutState) { s = state }
    }

    @Test fun `policy from settings changes attempts and lockout length`() = runBlocking {
        var now = 1_000L
        val limiter = RateLimiter(Store(), clock = { now }, policy = { 3 to 60_000L })
        limiter.recordFailure(); limiter.recordFailure()
        val locked = limiter.recordFailure()
        assertEquals(1_000L + 60_000L, locked.lockedUntilMs)
        assertEquals(0, limiter.remainingAttempts(locked))
    }

    @Test fun `without policy the defaults stay 5 attempts and 30 seconds`() = runBlocking {
        val limiter = RateLimiter(Store(), clock = { 0L })
        repeat(4) { limiter.recordFailure() }
        assertEquals(30_000L, limiter.recordFailure().lockedUntilMs)
    }
}
