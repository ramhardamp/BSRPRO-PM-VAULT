package pro.babasitaram.vault.data

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.KeystoreMasterKeyManager
import pro.babasitaram.vault.data.local.preferences.EncryptedSensitiveActionPinStore
import pro.babasitaram.vault.testing.SoftwareKeyBackend

/** One unified App PIN; the old separate hidden-vault PIN migrates on first correct use. */
class AppPinStoreTest {
    @TempDir lateinit var dir: File
    private val keys = KeystoreMasterKeyManager(SoftwareKeyBackend(), Dispatchers.Unconfined)

    @Test fun `legacy hidden pin is accepted once and moved to the unified pin`() = runTest {
        val ds = PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "p.preferences_pb") }
        val legacy = EncryptedSensitiveActionPinStore(ds, keys, "hidden_vault_pin_v1")
        legacy.save("4821".toCharArray())

        val unified = EncryptedSensitiveActionPinStore(ds, keys, "sensitive_action_pin_v1", listOf("hidden_vault_pin_v1"))
        assertTrue(unified.isConfigured())
        assertFalse(unified.verify("0000".toCharArray()))
        assertTrue(unified.verify("4821".toCharArray()))
        // migrated: the legacy-only store no longer has it, the unified one still verifies
        assertFalse(legacy.isConfigured())
        assertTrue(unified.verify("4821".toCharArray()))
    }

    @Test fun `saving the unified pin replaces a legacy one and clear removes both`() = runTest {
        val ds = PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "q.preferences_pb") }
        EncryptedSensitiveActionPinStore(ds, keys, "hidden_vault_pin_v1").save("1111".toCharArray())
        val unified = EncryptedSensitiveActionPinStore(ds, keys, "sensitive_action_pin_v1", listOf("hidden_vault_pin_v1"))
        unified.save("2222".toCharArray())
        assertFalse(unified.verify("1111".toCharArray()))
        assertTrue(unified.verify("2222".toCharArray()))
        unified.clear()
        assertFalse(unified.isConfigured())
    }
}
