package pro.babasitaram.vault.data

import io.mockk.coVerify
import io.mockk.mockk
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.repository.VaultRepositoryImpl

class VaultRepositoryImplTest {
    @TempDir
    lateinit var dir: File

    private val pw = "Master#Pass123456".toCharArray()
    private val dao = mockk<VaultDao>(relaxed = true)

    private fun blob() = FileVaultBlobStore(dir, Dispatchers.IO)

    private fun unlockedRepo(): Pair<VaultRepositoryImpl, SessionKeyStore> {
        val session = SessionKeyStore().also { it.unlock(pw) }
        return VaultRepositoryImpl(blob(), session, dao) to session
    }

    @Test
    fun `setData hides folder markers but keeps them in the blob`() = runTest {
        val (repo, _) = unlockedRepo()
        val marker = VaultEntry(id = "m", title = "Work", metaType = "folder")
        repo.setData(VaultData(listOf(VaultEntry(id = "1", title = "A"), marker)))
        assertEquals(listOf("1"), repo.entries.value.map { it.id })
        repo.upsert(VaultEntry(id = "2", title = "B"))
        val onDisk = blob().read(pw)
        assertTrue(onDisk.entries.any { it.id == "m" })
        assertEquals(3, onDisk.entries.size)
    }

    @Test
    fun `mobile count includes only active non-hidden entries with a phone value`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.setData(VaultData(listOf(
            VaultEntry(id = "mobile", mobile = "9876543210"),
            VaultEntry(id = "phone", phone = "9123456789"),
            VaultEntry(id = "blank", recordType = "mobile"),
            VaultEntry(id = "hidden", mobile = "9999999999", tags = listOf("hidden-vault")),
            VaultEntry(id = "trash", phone = "8888888888", deletedAt = 100L),
            VaultEntry(id = "note", isNote = true, mobile = "7777777777")
        )))
        assertEquals(3, repo.mobileCount.value)

        repo.softDelete("mobile")
        assertEquals(2, repo.mobileCount.value)

        repo.restore("mobile")
        assertEquals(3, repo.mobileCount.value)

        repo.clear()
        assertEquals(0, repo.mobileCount.value)
    }

    @Test
    fun `upsert persists and updates memory`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.upsert(VaultEntry(id = "1", title = "A2"))
        assertEquals(listOf("A2"), repo.entries.value.map { it.title })
        assertEquals(listOf("A2"), blob().read(pw).entries.map { it.title })
    }

    @Test
    fun `delete moves entry to encrypted trash without losing its record`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.upsert(VaultEntry(id = "2", title = "B"))
        repo.delete("1")
        assertNull(repo.entry("1"))
        assertEquals(listOf("1"), repo.trashedEntries.value.map { it.id })
        assertTrue(repo.trashedEntries.value.single().deletedAt > 0L)
        assertEquals(setOf("1", "2"), blob().read(pw).entries.map { it.id }.toSet())
    }

    @Test
    fun `trash restore makes entry visible again and clears deletedAt`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.softDelete("1")
        repo.restore("1")
        assertEquals(listOf("1"), repo.entries.value.map { it.id })
        assertTrue(repo.trashedEntries.value.isEmpty())
        assertEquals(0L, blob().read(pw).entries.single().deletedAt)
    }

    @Test
    fun `empty trash permanently removes only trashed entries`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.upsert(VaultEntry(id = "2", title = "B"))
        repo.softDelete("1")
        repo.emptyTrash()
        assertEquals(listOf("2"), repo.entries.value.map { it.id })
        assertTrue(repo.trashedEntries.value.isEmpty())
        assertEquals(listOf("2"), blob().read(pw).entries.map { it.id })
    }

    @Test
    fun `expired trash is removed while recent trash is retained`() = runTest {
        val (repo, _) = unlockedRepo()
        val now = 2_000_000_000L
        repo.setData(VaultData(listOf(
            VaultEntry(id = "old", title = "Old", deletedAt = now - pro.babasitaram.vault.domain.repository.VaultRepository.TRASH_RETENTION_MS - 1),
            VaultEntry(id = "new", title = "New", deletedAt = now - 1)
        )))
        repo.cleanupExpiredTrash(now)
        assertEquals(listOf("new"), repo.trashedEntries.value.map { it.id })
        assertEquals(listOf("new"), blob().read(pw).entries.map { it.id })
    }

    @Test
    fun `failed write leaves memory unchanged`() = runTest {
        val session = SessionKeyStore() // locked: no password available for the write
        val repo = VaultRepositoryImpl(blob(), session, dao)
        repo.setData(VaultData(listOf(VaultEntry(id = "1", title = "A"))))
        assertThrows<VaultError.VaultLocked> { repo.upsert(VaultEntry(id = "2", title = "B")) }
        assertEquals(listOf("1"), repo.entries.value.map { it.id })
    }

    @Test
    fun `duplicate detection matches domain and username ignoring case`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.setData(VaultData(listOf(VaultEntry(id = "1", title = "GH", url = "https://www.github.com/login", username = "Bob"))))
        val dup = repo.findDuplicate(VaultEntry(id = "new", url = "http://github.com", username = "bob"))
        assertNotNull(dup)
        assertEquals("1", dup!!.id)
        assertNull(repo.findDuplicate(VaultEntry(id = "new", url = "http://github.com", username = "alice")))
        assertNull(repo.findDuplicate(VaultEntry(id = "1", url = "http://github.com", username = "bob")))
    }

    @Test
    fun `duplicate detection matches android package`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.setData(VaultData(listOf(VaultEntry(id = "1", appPackage = "com.x", username = "u"))))
        assertNotNull(repo.findDuplicate(VaultEntry(id = "n", appPackage = "com.x", username = "U")))
    }

    @Test
    fun `clear empties memory and wipes metadata`() = runTest {
        val (repo, _) = unlockedRepo()
        repo.upsert(VaultEntry(id = "1", title = "A"))
        repo.clear()
        assertTrue(repo.entries.value.isEmpty())
        coVerify { dao.wipe() }
    }
}
