package pro.babasitaram.vault.core.crypto

import java.util.Base64
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertArrayEquals
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import pro.babasitaram.vault.core.util.VaultError

class VaultCryptoTest {

    private val pw = "Master#Pass123456".toCharArray()

    // ── golden vectors produced by the extension's real crypto.js ──
    @Test
    fun `legacy golden vectors decrypt`() {
        GoldenVectors.LEGACY.forEach { v ->
            assertEquals(v.plaintext, VaultCrypto.decryptBlocking(v.encoded, v.password.toCharArray()))
        }
    }

    @Test
    fun `legacy encrypt with same salt and iv is byte-identical to the extension`() {
        GoldenVectors.LEGACY.forEach { v ->
            assertEquals(v.encoded, VaultCrypto.encryptBlocking(v.plaintext, v.password.toCharArray(), v.salt, v.iv))
        }
    }

    @Test
    fun `v3 golden containers decrypt`() {
        GoldenVectors.V3.forEach { v ->
            assertEquals(v.plaintext, VaultCrypto.decryptV3Blocking(v.encoded, v.password.toCharArray()))
        }
    }

    @Test
    fun `v3 encrypt with same salt and iv is byte-identical to the extension`() {
        GoldenVectors.V3.forEach { v ->
            assertEquals(v.encoded, VaultCrypto.encryptV3Blocking(v.plaintext, v.password.toCharArray(), v.salt, v.iv))
        }
    }

    @Test
    fun `unicode password vector matches (manual HMAC path)`() {
        val v = GoldenVectors.LEGACY.first { it.password.any { c -> c.code > 127 } }
        assertEquals(v.plaintext, VaultCrypto.decryptBlocking(v.encoded, v.password.toCharArray()))
    }

    @Test
    fun `canonical header matches the one in the extension container`() {
        val v = GoldenVectors.V3.first()
        assertTrue(v.encoded.startsWith("""{"header":""" + VaultCrypto.canonicalHeader(v.salt, v.iv)))
    }

    // ── round trips ──
    @Test
    fun `encrypt hello with password decrypts`() = runTest {
        val enc = VaultCrypto.encrypt("hello", "password".toCharArray())
        assertEquals("hello", VaultCrypto.decrypt(enc, "password".toCharArray()))
    }

    @Test
    fun `v3 round trip`() = runTest {
        val enc = VaultCrypto.encryptV3("""{"entries":[]}""", pw)
        assertEquals("""{"entries":[]}""", VaultCrypto.decryptV3(enc, pw))
    }

    @Test
    fun `round trip with unicode plaintext`() = runTest {
        val text = "पासवर्ड 🔐 ünïcode"
        assertEquals(text, VaultCrypto.decrypt(VaultCrypto.encrypt(text, pw), pw))
    }

    @Test
    fun `two encryptions of the same text differ (random salt and iv)`() = runTest {
        assertNotEquals(VaultCrypto.encrypt("same", pw), VaultCrypto.encrypt("same", pw))
    }

    // ── failure modes ──
    @Test
    fun `wrong password fails legacy decrypt`() {
        val v = GoldenVectors.LEGACY.first()
        assertThrows<VaultError.InvalidMasterPassword> { VaultCrypto.decryptBlocking(v.encoded, "nope".toCharArray()) }
    }

    @Test
    fun `wrong password fails v3 decrypt`() {
        val v = GoldenVectors.V3.first()
        assertThrows<VaultError.InvalidMasterPassword> { VaultCrypto.decryptV3Blocking(v.encoded, "nope".toCharArray()) }
    }

    @Test
    fun `too short ciphertext is invalid format`() {
        val tiny = Base64.getEncoder().encodeToString(ByteArray(10))
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptBlocking(tiny, pw) }
    }

    @Test
    fun `payload shorter than a gcm tag is invalid format`() {
        val short = Base64.getEncoder().encodeToString(ByteArray(28 + 8))
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptBlocking(short, pw) }
    }

    @Test
    fun `invalid base64 is invalid format`() {
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptBlocking("***not base64***", pw) }
    }

    @Test
    fun `tampered ciphertext fails authentication`() {
        val v = GoldenVectors.LEGACY.first()
        val raw = Base64.getDecoder().decode(v.encoded)
        raw[raw.size - 1] = (raw[raw.size - 1].toInt() xor 1).toByte()
        assertThrows<VaultError.InvalidMasterPassword> {
            VaultCrypto.decryptBlocking(Base64.getEncoder().encodeToString(raw), v.password.toCharArray())
        }
    }

    @Test
    fun `v3 container from another app is rejected`() {
        val v = GoldenVectors.V3.first()
        val foreign = v.encoded.replace("BSRPRO.Vault", "OtherApp.Vault")
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptV3Blocking(foreign, v.password.toCharArray()) }
    }

    @Test
    fun `v3 with wrong iterations is rejected`() {
        val v = GoldenVectors.V3.first()
        val bad = v.encoded.replace("\"iterations\":600000", "\"iterations\":100000")
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptV3Blocking(bad, v.password.toCharArray()) }
    }

    @Test
    fun `v3 with extra header key is non-canonical`() {
        val v = GoldenVectors.V3.first()
        val bad = v.encoded.replace("\"tagBits\":128}", "\"tagBits\":128,\"x\":1}")
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptV3Blocking(bad, v.password.toCharArray()) }
    }

    @Test
    fun `v3 with reordered header keys is non-canonical`() {
        val v = GoldenVectors.V3.first()
        val bad = v.encoded.replace("\"format\":\"BSRPRO.Vault\",\"version\":3", "\"version\":3,\"format\":\"BSRPRO.Vault\"")
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptV3Blocking(bad, v.password.toCharArray()) }
    }

    @Test
    fun `v3 garbage is invalid format`() {
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptV3Blocking("not json", pw) }
        assertThrows<VaultError.InvalidFormat> { VaultCrypto.decryptV3Blocking("{}", pw) }
    }

    // ── master hash ──
    @Test
    fun `hashMaster verifies with right password only`() = runTest {
        val hash = VaultCrypto.hashMaster(pw)
        assertTrue(VaultCrypto.verifyMaster(hash, pw))
        assertFalse(VaultCrypto.verifyMaster(hash, "wrong-password".toCharArray()))
    }

    @Test
    fun `verifyMaster returns false for garbage hash`() = runTest {
        assertFalse(VaultCrypto.verifyMaster("garbage!!", pw))
    }

    @Test
    fun `extension canary hash verifies`() = runTest {
        val v = GoldenVectors.LEGACY.first { it.plaintext == "__VAULT_CANARY__" }
        assertTrue(VaultCrypto.verifyMaster(v.encoded, v.password.toCharArray()))
    }

    // ── key derivation + helpers ──
    @Test
    fun `deriveKey is deterministic and 256 bit`() = runTest {
        val salt = ByteArray(16) { it.toByte() }
        val a = VaultCrypto.deriveKey(pw, salt)
        val b = VaultCrypto.deriveKey(pw, salt)
        assertArrayEquals(a.encoded, b.encoded)
        assertEquals(32, a.encoded.size)
    }

    @Test
    fun `deriveKey rejects wrong salt size and empty password`() {
        assertThrows<IllegalArgumentException> { VaultCrypto.deriveKeyBlocking(pw, ByteArray(8)) }
        assertThrows<IllegalArgumentException> { VaultCrypto.deriveKeyBlocking(CharArray(0), ByteArray(16)) }
    }

    @Test
    fun `manual hmac pbkdf2 equals provider pbkdf2 for ascii`() {
        val salt = ByteArray(16) { (it * 3).toByte() }
        val p = "ascii-password".toCharArray()
        assertArrayEquals(
            Pbkdf2.viaProvider(p, salt, 2_000, 32),
            Pbkdf2.viaManualHmac(p, salt, 2_000, 32)
        )
    }

    @Test
    fun `wipeChars zero fills`() {
        val c = "secret".toCharArray()
        VaultCrypto.wipeChars(c)
        assertTrue(c.all { it == '\u0000' })
    }
}
