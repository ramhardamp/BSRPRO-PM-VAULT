package pro.babasitaram.vault.core.security

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class RootDetectorTest {
    private class FakeEnv(
        override val buildTags: String? = "release-keys",
        val files: Set<String> = emptySet(),
        val packages: Set<String> = emptySet()
    ) : RootEnvironment {
        override fun fileExists(path: String) = path in files
        override fun isPackageInstalled(packageName: String) = packageName in packages
    }

    @Test fun `clean device`() = assertEquals(RootStatus.NotRooted, RootDetector(FakeEnv()).check())
    @Test fun `su binary means rooted`() =
        assertEquals(RootStatus.Rooted, RootDetector(FakeEnv(files = setOf("/system/xbin/su"))).check())
    @Test fun `magisk app means rooted`() =
        assertEquals(RootStatus.Rooted, RootDetector(FakeEnv(packages = setOf("com.topjohnwu.magisk"))).check())
    @Test fun `test-keys is suspicious`() =
        assertEquals(RootStatus.Suspicious, RootDetector(FakeEnv(buildTags = "test-keys")).check())
    @Test fun `busybox is suspicious`() =
        assertEquals(RootStatus.Suspicious, RootDetector(FakeEnv(files = setOf("/system/bin/busybox"))).check())
    @Test fun `xposed is suspicious`() =
        assertEquals(RootStatus.Suspicious, RootDetector(FakeEnv(packages = setOf("org.lsposed.manager"))).check())
}
