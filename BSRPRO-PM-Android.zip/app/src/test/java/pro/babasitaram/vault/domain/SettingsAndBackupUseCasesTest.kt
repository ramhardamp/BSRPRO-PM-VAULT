package pro.babasitaram.vault.domain

import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import android.content.Context
import io.mockk.every
import io.mockk.mockk
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.VaultData
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.core.security.RateLimiter
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.local.blob.FileVaultBlobStore
import pro.babasitaram.vault.data.local.db.VaultDao
import pro.babasitaram.vault.data.repository.AuthRepositoryImpl
import pro.babasitaram.vault.data.repository.VaultRepositoryImpl
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.domain.usecase.BuildExportUseCase
import pro.babasitaram.vault.domain.usecase.ChangeMasterPasswordUseCase
import pro.babasitaram.vault.domain.usecase.CommitImportUseCase
import pro.babasitaram.vault.domain.usecase.CreateVaultUseCase
import pro.babasitaram.vault.domain.usecase.PrepareImportUseCase
import pro.babasitaram.vault.domain.usecase.ResetVaultUseCase
import pro.babasitaram.vault.domain.usecase.UnlockVaultUseCase
import pro.babasitaram.vault.domain.usecase.VerifyMasterPasswordUseCase
import pro.babasitaram.vault.testing.FakeCredentialStore
import pro.babasitaram.vault.testing.FakeLockoutStore
import pro.babasitaram.vault.testing.FakeSettings

class SettingsAndBackupUseCasesTest {
    @TempDir
    lateinit var dir: File

    private val good = "Str0ng!Passw0rd"
    private val better = "An0ther!Str0ngOne"

    private inner class Env(initial: VaultSettings = VaultSettings(), where: File = dir) {
        val blob = FileVaultBlobStore(where, Dispatchers.IO)
        val session = SessionKeyStore()
        val repo = VaultRepositoryImpl(blob, session, mockk<VaultDao>(relaxed = true))
        val auth = AuthRepositoryImpl(blob, RateLimiter(FakeLockoutStore(), clock = { 1_000_000L }), FakeCredentialStore())
        val settings = FakeSettings(initial)
        val create = CreateVaultUseCase(blob, session, repo, auth)
        val unlock = UnlockVaultUseCase(blob, session, repo, auth, settings, mockk<BiometricSessionKeyStore>(relaxed = true), mockk<Context>(relaxed = true) { every { filesDir } returns where })
        val verify = VerifyMasterPasswordUseCase(blob, auth)
        val change = ChangeMasterPasswordUseCase(blob, session, auth, settings, mockk<BiometricSessionKeyStore>(relaxed = true))
        val reset = ResetVaultUseCase(blob, session, repo, auth, settings, verify, mockk<BiometricSessionKeyStore>(relaxed = true))
        val prepare = PrepareImportUseCase(repo)
        val commit = CommitImportUseCase(repo, mockk<AutoBackupManager>(relaxed = true))
        val export = BuildExportUseCase(repo, session)

        suspend fun createWith(vararg entries: VaultEntry) {
            create(good.toCharArray(), good.toCharArray(), VaultData(entries.toList()))
        }
    }

    private val a = VaultEntry(id = "a", title = "GitHub", url = "https://github.com", username = "me", password = "pw-a")

    // ── change master password ──
    @Test fun `old password stops working and the new one opens the same data`() = runTest {
        val e = Env(); e.createWith(a)
        assertTrue(e.change(good.toCharArray(), better.toCharArray(), better.toCharArray()) is VaultResult.Success)

        e.session.lock(); e.blob.invalidateKeyCache()
        val oldTry = e.unlock(good.toCharArray())
        assertEquals(VaultError.InvalidMasterPassword, (oldTry as VaultResult.Failure).error)
        assertTrue(e.unlock(better.toCharArray()) is VaultResult.Success)
        assertEquals("pw-a", e.repo.entry("a")?.password)
    }

    @Test fun `change keeps the session usable and removes backups of the old password`() = runTest {
        val e = Env(); e.createWith(a)
        e.repo.upsert(a.copy(title = "GitHub 2"))                  // second write → .bak exists
        assertTrue(File(dir, "vault.blob.bak").exists())
        e.change(good.toCharArray(), better.toCharArray(), better.toCharArray())
        assertFalse(File(dir, "vault.blob.bak").exists())
        assertFalse(File(dir, "vault.blob.bak2").exists())
        e.repo.upsert(a.copy(title = "after change"))               // session already holds the new password
        e.session.lock(); e.blob.invalidateKeyCache()
        assertTrue(e.unlock(better.toCharArray()) is VaultResult.Success)
        assertEquals("after change", e.repo.entry("a")?.title)
    }

    @Test fun `change validates input`() = runTest {
        val e = Env(); e.createWith(a)
        fun err(o: String, n: String, c: String) = ((e.change(o.toCharArray(), n.toCharArray(), c.toCharArray())) as VaultResult.Failure).error
        assertTrue(err(good, better, "different") is VaultError.Validation)
        assertTrue(err(good, good, good) is VaultError.Validation)
        assertTrue(err(good, "weak", "weak") is VaultError.Validation)
        assertEquals(VaultError.InvalidMasterPassword, err("Wr0ng!Passw0rdXX", better, better))
    }

    @Test fun `biometric credential is refreshed after a password change`() = runTest {
        val e = Env(VaultSettings(biometricEnabled = true)); e.createWith(a)
        e.change(good.toCharArray(), better.toCharArray(), better.toCharArray())
        assertEquals(better, String(e.auth.loadBiometricCredential()!!))
    }

    // ── reset ──
    @Test fun `reset needs the right password and then wipes everything`() = runTest {
        val e = Env(VaultSettings(biometricEnabled = true)); e.createWith(a)
        assertTrue(e.reset("Wr0ng!Passw0rdXX".toCharArray()) is VaultResult.Failure)
        assertTrue(e.auth.vaultExists())

        assertTrue(e.reset(good.toCharArray()) is VaultResult.Success)
        assertFalse(e.auth.vaultExists())
        assertFalse(e.session.isUnlocked.value)
        assertTrue(e.repo.entries.value.isEmpty())
        assertFalse(e.settings.current().biometricEnabled)
    }

    // ── export → import ──
    @Test fun `encrypted export imports into a fresh vault`() = runTest {
        val src = Env(); src.createWith(a, a.copy(id = "b", title = "Mail", url = "https://mail.com"))
        val text = (src.export(ExportFormat.V3) as VaultResult.Success).value

        val dst = Env(where = File(dir, "dst").apply { mkdirs() })
        dst.create(better.toCharArray(), better.toCharArray())
        val preview = (dst.prepare(text, good.toCharArray()) as VaultResult.Success).value
        assertEquals(2, preview.newCount)
        assertEquals(2, (dst.commit(preview, emptyMap()) as VaultResult.Success).value)
        assertEquals(setOf("GitHub", "Mail"), dst.repo.entries.value.map { it.title }.toSet())
    }

    @Test fun `wrong backup password is reported as such`() = runTest {
        val e = Env(); e.createWith(a)
        val text = (e.export(ExportFormat.V3) as VaultResult.Success).value
        val r = e.prepare(text, "Wr0ng!Passw0rdXX".toCharArray())
        assertEquals(VaultError.InvalidMasterPassword, (r as VaultResult.Failure).error)
    }

    @Test fun `skip is the default for duplicates`() = runTest {
        val e = Env(); e.createWith(a)
        val csv = "name,url,username,password\nGitHub new,https://github.com,me,NEWPW\nFresh,https://fresh.io,me,pw\n"
        val preview = (e.prepare(csv) as VaultResult.Success).value
        assertEquals(1, preview.duplicateCount)
        assertEquals(1, (e.commit(preview, emptyMap()) as VaultResult.Success).value)
        assertEquals("pw-a", e.repo.entry("a")?.password)
        assertEquals(2, e.repo.entries.value.size)
    }

    @Test fun `replace import cannot strip an existing app login`() = runTest {
        val app = VaultEntry(
            id = "app-1", title = "Bank", username = "user", password = "app-pw",
            appPackage = "com.example.bank", appName = "Bank", appPin = "1234",
            loginUri = "androidapp://com.example.bank", isPrimaryAppLogin = true
        )
        val e = Env(); e.createWith(app)
        val json = """{"schema":"BSRPRO.Vault.Payload","version":3,"entries":[{"id":"other","title":"Website","url":"https://example.com","username":"u","password":"p"}]}"""
        val preview = (e.prepare(json) as VaultResult.Success).value
        e.commit(preview, emptyMap(), mode = pro.babasitaram.vault.data.transfer.ImportMode.REPLACE)

        val restoredApp = e.repo.entries.value.firstOrNull { it.appPackage == "com.example.bank" }
        assertEquals("app-pw", restoredApp?.password)
        assertEquals("1234", restoredApp?.appPin)
        assertEquals("com.example.bank", restoredApp?.appPackage)
    }

    @Test fun `replace keeps the id and updates the data`() = runTest {
        val e = Env(); e.createWith(a)
        val preview = (e.prepare("name,url,username,password\nGitHub new,https://github.com,me,NEWPW\n") as VaultResult.Success).value
        val r = e.commit(preview, mapOf(0 to DuplicateAction.REPLACE))
        assertEquals(1, (r as VaultResult.Success).value)
        assertEquals(1, e.repo.entries.value.size)
        assertEquals("NEWPW", e.repo.entry("a")?.password)
    }

    @Test fun `keep both adds a second entry`() = runTest {
        val e = Env(); e.createWith(a)
        val preview = (e.prepare("name,url,username,password\nGitHub 2,https://github.com,me,OTHER\n") as VaultResult.Success).value
        e.commit(preview, mapOf(0 to DuplicateAction.KEEP_BOTH))
        assertEquals(2, e.repo.entries.value.size)
        assertEquals("pw-a", e.repo.entry("a")?.password)
    }

    @Test fun `imported entries never overwrite an existing id`() = runTest {
        val e = Env(); e.createWith(a)
        val json = """{"schema":"BSRPRO.Vault.Payload","version":3,"entries":[{"id":"a","title":"clash","url":"https://other.com","username":"x","password":"p"}]}"""
        val preview = (e.prepare(json) as VaultResult.Success).value
        e.commit(preview, emptyMap())
        assertEquals(2, e.repo.entries.value.size)
        assertEquals("GitHub", e.repo.entry("a")?.title)
    }

    @Test fun `plaintext exports contain the passwords`() = runTest {
        val e = Env(); e.createWith(a)
        assertTrue((e.export(ExportFormat.CHROME_CSV) as VaultResult.Success).value.contains("pw-a"))
        assertTrue((e.export(ExportFormat.PLAIN_JSON) as VaultResult.Success).value.contains("pw-a"))
    }
}
