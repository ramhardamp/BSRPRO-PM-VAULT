package pro.babasitaram.vault.core.util

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.usecase.GeneratePasswordUseCase
import pro.babasitaram.vault.domain.usecase.PasswordOptions

class TotpTest {
    private val sha1Secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"   // "12345678901234567890"

    private fun code(ms: Long, digits: Int = 8, alg: String = "SHA1", secret: String = sha1Secret) =
        Totp.generate(TotpConfig(secret, digits = digits, algorithm = alg), ms)

    @Test fun `RFC 6238 SHA1 vectors`() {
        assertEquals("94287082", code(59_000))
        assertEquals("07081804", code(1_111_111_109_000))
        assertEquals("14050471", code(1_111_111_111_000))
        assertEquals("89005924", code(1_234_567_890_000))
        assertEquals("69279037", code(2_000_000_000_000))
        assertEquals("65353130", code(20_000_000_000_000))
    }

    @Test fun `RFC 6238 SHA256 vector`() =
        assertEquals("46119246", code(59_000, alg = "SHA256", secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQGEZA===="))

    @Test fun `six digit code is the tail of the eight digit one`() = assertEquals("287082", code(59_000, digits = 6))

    @Test fun `secret is case, space and padding tolerant`() =
        assertEquals("287082", Totp.generate(TotpConfig("gezd gnbv gy3t qojq gezd gnbv gy3t qojq=="), 59_000))

    @Test fun `invalid base32 yields null`() {
        assertNull(Totp.generate(TotpConfig("not*base32!"), 0))
        assertNull(Totp.current("", 0))
    }

    @Test fun `otpauth uri is parsed`() {
        val c = Totp.parse("otpauth://totp/Mail:bob?secret=$sha1Secret&digits=8&period=60&algorithm=SHA256&issuer=Mail")!!
        assertEquals(8, c.digits)
        assertEquals(60, c.periodSeconds)
        assertEquals("SHA256", c.algorithm)
    }

    @Test fun `seconds remaining counts down inside the period`() {
        assertEquals(30, Totp.current(sha1Secret, 0)!!.secondsRemaining)
        assertEquals(1, Totp.current(sha1Secret, 29_000)!!.secondsRemaining)
        assertEquals(30, Totp.current(sha1Secret, 30_000)!!.secondsRemaining)
    }
}

class PasswordStrengthTest {
    @Test fun `scores match the extension`() {
        assertEquals(0, PasswordStrength.score(""))
        assertEquals(0, PasswordStrength.score("abc"))
        assertEquals(1, PasswordStrength.score("abcdefgh"))
        assertEquals(3, PasswordStrength.score("Abcdefg1"))
        assertEquals(5, PasswordStrength.score("Abcdefg1!xyzabc"))
    }

    @Test fun `buckets`() {
        assertEquals("weak", PasswordStrength.bucket(""))
        assertEquals("weak", PasswordStrength.bucket("abcdefgh"))
        assertEquals("medium", PasswordStrength.bucket("Abcdefg1"))
        assertEquals("strong", PasswordStrength.bucket("Abcdefg1!"))
    }

    @Test fun `master password rules`() {
        assertFalse(PasswordStrength.isAcceptableMaster("abcdefghijkl"))
        assertFalse(PasswordStrength.isAcceptableMaster("Ab1!"))
        assertTrue(PasswordStrength.isAcceptableMaster("Str0ng!Passw0rd"))
    }
}

class UrlUtilsTest {
    @Test fun `domain extraction`() {
        assertEquals("example.com", UrlUtils.domainOf("https://www.Example.com/login?x=1"))
        assertEquals("example.com", UrlUtils.domainOf("example.com:8080/a"))
        assertEquals("example.com", UrlUtils.domainOf("https://user:pw@example.com/"))
        assertEquals("", UrlUtils.domainOf("  "))
    }

    @Test fun `openable url gets a scheme`() {
        assertEquals("https://example.com", UrlUtils.toOpenable("example.com"))
        assertEquals("http://example.com", UrlUtils.toOpenable("http://example.com"))
    }
}

class EntrySearchTest {
    private val entries = listOf(
        VaultEntry(id = "1", title = "Google", url = "https://accounts.google.com", username = "bob"),
        VaultEntry(id = "2", title = "Bank", url = "https://bank.example.com", notes = "google pay linked"),
        VaultEntry(id = "3", title = "Netflix", username = "alice", tags = listOf("streaming"))
    )

    @Test fun `empty query returns everything`() = assertEquals(3, EntrySearch.filter(entries, "  ").size)

    @Test fun `title and domain matches rank above notes`() =
        assertEquals(listOf("1", "2"), EntrySearch.filter(entries, "google").map { it.id })

    @Test fun `searches tags and usernames`() {
        assertEquals(listOf("3"), EntrySearch.filter(entries, "stream").map { it.id })
        assertEquals(listOf("1"), EntrySearch.filter(entries, "bob").map { it.id })
    }

    @Test fun `typo tolerant`() = assertEquals("1", EntrySearch.filter(entries, "gogle").first().id)

    @Test fun `no match returns empty`() = assertTrue(EntrySearch.filter(entries, "zzzzzz").isEmpty())
}

class GeneratePasswordUseCaseTest {
    private val gen = GeneratePasswordUseCase()

    @Test fun `exact length and every enabled class present`() {
        repeat(50) {
            val p = gen(PasswordOptions(length = 12))
            assertEquals(12, p.length)
            assertTrue(p.any { it.isLowerCase() } && p.any { it.isUpperCase() } && p.any { it.isDigit() } && p.any { !it.isLetterOrDigit() })
        }
    }

    @Test fun `only digits when only digits are enabled`() {
        val p = gen(PasswordOptions(length = 30, lower = false, upper = false, symbols = false))
        assertTrue(p.all { it.isDigit() })
    }

    @Test fun `ambiguous characters can be excluded`() {
        repeat(30) { assertTrue(gen(PasswordOptions(length = 64, excludeAmbiguous = true)).none { it in "Il1O0o" }) }
    }

    @Test fun `keyword is a prefix and length is kept`() {
        val p = gen(PasswordOptions(length = 20, keyword = "Acme"))
        assertTrue(p.startsWith("Acme"))
        assertEquals(20, p.length)
    }

    @Test fun `overlong keyword still leaves 8 random characters`() {
        assertEquals(16, gen(PasswordOptions(length = 16, keyword = "x".repeat(30))).length)
    }

    @Test fun `length is clamped`() {
        assertEquals(8, gen(PasswordOptions(length = 1)).length)
        assertEquals(256, gen(PasswordOptions(length = 9999)).length)
    }

    @Test fun `no character class is rejected`() {
        assertThrows<IllegalArgumentException> { gen(PasswordOptions(lower = false, upper = false, digits = false, symbols = false)) }
    }

    @Test fun `outputs differ`() = assertNotEquals(gen(PasswordOptions()), gen(PasswordOptions()))

    @Test fun `passphrase shape`() {
        val p = gen.passphrase(words = 5, separator = ".", includeNumber = false)
        assertEquals(5, p.split(".").size)
        assertTrue(p.split(".").all { it.first().isUpperCase() })
        assertNotNull(WordList.WORDS.firstOrNull())
        assertTrue(WordList.WORDS.size >= 600)
    }
}
