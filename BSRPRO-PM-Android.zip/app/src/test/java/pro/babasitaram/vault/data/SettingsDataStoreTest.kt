package pro.babasitaram.vault.data

import io.mockk.mockk
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import java.io.File
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.io.TempDir
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.data.local.preferences.SettingsDataStore

class SettingsDataStoreTest {
    @TempDir
    lateinit var dir: File

    @Test
    fun `defaults are returned before anything is saved`() = runTest {
        val ds = SettingsDataStore(PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "a.preferences_pb") }, mockk<android.content.Context>(relaxed = true))
        assertEquals(VaultSettings(), ds.current())
    }

    @Test
    fun `update persists every field`() = runTest {
        val ds = SettingsDataStore(PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "b.preferences_pb") }, mockk<android.content.Context>(relaxed = true))
        val wanted = VaultSettings(
            theme = ThemeMode.DARK, autoLockSeconds = 300, clipboardClearSeconds = 15,
            biometricEnabled = true, lockOnBackground = false, generatorDefaultLength = 32,
            generatorKeyword = "kw", travelMode = true
        )
        ds.update { wanted }
        assertEquals(wanted, ds.current())
    }

    @Test
    fun `update transforms the current value`() = runTest {
        val ds = SettingsDataStore(PreferenceDataStoreFactory.create(scope = backgroundScope) { File(dir, "c.preferences_pb") }, mockk<android.content.Context>(relaxed = true))
        ds.update { it.copy(autoLockSeconds = 120) }
        ds.update { it.copy(theme = ThemeMode.LIGHT) }
        val s = ds.current()
        assertEquals(120, s.autoLockSeconds)
        assertEquals(ThemeMode.LIGHT, s.theme)
        assertEquals(30, s.clipboardClearSeconds)
    }
}
