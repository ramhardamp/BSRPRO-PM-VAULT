package pro.babasitaram.vault.data.transfer

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.model.VaultEntry

class AppLoginExportTest {
    private val site = VaultEntry(id = "w", url = "https://a.com", type = "website")
    private val app = VaultEntry(id = "a", appPackage = "com.jio.jpp1", type = "app")
    private val legacyApp = VaultEntry(id = "l", appPackage = "com.x")

    @Test fun `app logins are included by default`() {
        assertEquals(listOf("w", "a", "l"), ExportFilter.apply(listOf(site, app, legacyApp), ExportOptions()).map { it.id })
    }

    @Test fun `app logins can be left out and websites stay`() {
        val out = ExportFilter.apply(listOf(site, app, legacyApp), ExportOptions(includeAppLogins = false))
        assertEquals(listOf("w"), out.map { it.id })
    }
}
