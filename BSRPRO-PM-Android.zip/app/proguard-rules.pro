# kotlinx.serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class pro.babasitaram.vault.**$$serializer { *; }
-keepclassmembers class pro.babasitaram.vault.** { *** Companion; }
-keepclasseswithmembers class pro.babasitaram.vault.** { kotlinx.serialization.KSerializer serializer(...); }

# Room / Hilt are handled by their generated code + bundled consumer rules.
# Strip verbose logging from release builds.
-assumenosideeffects class timber.log.Timber* {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
}
