# BSRPRO Vault — GitHub Actions Build

This package contains the Android source plus the native Android CI workflow.

## Important

- The canonical encrypted vault format remains **BSRPRO.Vault V3**.
- This source package currently does not include the Gradle wrapper JAR/script; GitHub Actions installs **Gradle 8.7** directly with `gradle/actions/setup-gradle`.
- `gradle/wrapper/gradle-wrapper.properties` is retained and still points to Gradle 8.7.
- No production vault/customer data is part of this source package.

## Push to GitHub safely

Use a dedicated branch for the native Android project instead of replacing an unrelated web-app branch.

```bash
git clone https://github.com/ramhardamp/babasitaram-pro-v2.git
cd babasitaram-pro-v2
git checkout -b native-android-phase9
```

Copy the contents of this package into the target branch, then:

```bash
git add .
git status
git commit -m "Prepare BSRPRO Vault native Android Phase 9 build"
git push -u origin native-android-phase9
```

Before committing, confirm that the branch contains the native Android project at repository root (`app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle/`, and `.github/workflows/native-android-build.yml`). Do not overwrite a production/web branch unless that branch is intentionally being converted to the native project.

## Trigger CI

The workflow file is:

`.github/workflows/native-android-build.yml`

It supports both:

- **Manual:** GitHub → Actions → **BSRPRO Vault Native Android Build** → **Run workflow**.
- **Push:** a push that changes `app/**`, Gradle/build files, `gradle/**`, or the workflow itself.

## APK location

After the workflow succeeds:

1. Open the successful GitHub Actions run.
2. Open the **Artifacts** section.
3. Download **`BSRPRO-Vault-release-<run number>`** — signed release APK (package `pro.babasitaram.vault`, version `1.0.0`, no `-debug` label). **Ye wahi APK hai jo daily use ke liye hai.**
4. `BSRPRO-Vault-debug-<run number>` sirf testing/fallback ke liye hai (package `pro.babasitaram.vault.debug`, version `1.0.0-debug`).

The workflow verifies the APK with `apksigner`, checks the manifest with `aapt`, validates the APK ZIP, runs blocking unit tests and lint, installs it on an Android 35 emulator, launches `MainActivity`, and checks for fatal Android runtime exceptions. A failed unit-test or emulator-smoke job now fails the workflow.

## Release signing (one-time setup)

Format: Issue -> Fix -> Logic.

**Issue:** Debug APK har CI run par naye random debug key se sign hota hai, isliye har naya APK purane ke upar *update* nahi hota (uninstall karna padta hai) aur version par `-debug` likha aata hai.
**Fix:** Release APK apni ek permanent key se sign hota hai. Key repo me kabhi nahi jaati — sirf GitHub Secrets me rehti hai.
**Logic:** Ek hi key = ek hi signature = har naya APK purane ke upar update hota hai. Key kho gayi to us app ka update kabhi nahi ban sakta, isliye key ka backup zaroori hai.

### Step 1 — key banao (apne PC par, ek hi baar; Java chahiye)

```bash
keytool -genkeypair -v -keystore bsrpro-release.jks -alias bsrpro \
  -keyalg RSA -keysize 4096 -validity 36500
```

Jo password daalo wo yaad rakho (store password aur key password same rakh sakte ho).

### Step 2 — keystore ko base64 text me badlo

- Linux / Git Bash: `base64 -w0 bsrpro-release.jks`
- macOS: `base64 -i bsrpro-release.jks`
- Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("bsrpro-release.jks"))`

### Step 3 — GitHub me 4 secrets add karo

Repo -> **Settings -> Secrets and variables -> Actions -> New repository secret**

| Secret name | Value |
|---|---|
| `ANDROID_KEYSTORE_BASE64` | Step 2 ka poora text |
| `ANDROID_KEYSTORE_PASSWORD` | keystore (store) password |
| `ANDROID_KEY_ALIAS` | `bsrpro` (jo `-alias` diya) |
| `ANDROID_KEY_PASSWORD` | key password |

**Signing identity pin:** release workflow expected certificate SHA-256 (public) `04:77:6B:B4:0E:ED:AB:BC:5D:4F:36:C6:02:F2:BA:67:95:2F:61:0F:9B:71:30:2D:D6:58:D5:E5:A7:4A:89:E6` se match hone par hi pass hota hai. Key rotation sirf soch-samajh kar (workflow me value badalna padega; installed users ka in-place update toot jata hai).

Release APK ab `unit-tests` job pass hone ke baad hi banta hai.

### Step 4 — key ka backup (BAHUT ZAROORI)

`bsrpro-release.jks` + dono password ko 2 alag safe jagah rakho (password manager / offline drive). **Is file ko GitHub repo me commit mat karna** (`.gitignore` aur CI audit dono ise block karte hain).

### Step 5 — run karo

Actions -> **Run workflow**. Job summary me *Release APK* ke neeche `certificate SHA-256 digest` dikhega. Har build me ye **same** hona chahiye.

### Agar release job fail ho

- **"Release signing secrets missing"** -> Step 3 ke secrets poore add karo. Debug APK job is se alag hai, wo tab bhi milta hai.
- **R8 / "Missing class" error** -> Actions -> Run workflow -> **minify = false**. Isse bina-R8 ka (par non-debug) APK banta hai. Summary ka error text bhejo, sirf wahi rule add hoga. `r8-mapping-<run>` artifact me `missing_rules.txt` bhi hota hai.
- Local build (optional): repo root par `keystore.properties` banao (git-ignored) — `storeFile=`, `storePassword=`, `keyAlias=`, `keyPassword=` — phir `gradle assembleRelease`. Key na ho to `app-release-unsigned.apk` banta hai jo install nahi hota.

## Debug app se Release app par jaana (data safe rakhne ke liye)

Release app ka package alag hai (`pro.babasitaram.vault`), isliye ye debug app (`...vault.debug`) ke **upar update nahi hota — alag app ban kar saath-saath install hota hai**. Debug app ka data apne-aap release app me nahi aata; backup se laana hota hai. Purana app tab tak delete mat karo jab tak naya check na ho jaye.

1. **Purane (debug) app me**: Backup -> export `.Vault` (ya auto-backup folder me `BSRPRO.Vault`) — ek safe jagah copy rakho. Phir agar purane app me **Auto-backup** on hai (Settings -> Backup) to use band kar do: dono app ek hi folder me `BSRPRO.Vault` likh sakte hain aur ek doosre ki file overwrite/duplicate kar sakte hain.
2. **Release APK install karo** (debug app abhi mat hatao).
3. **Naye app me** setup par wahi Master Password daalo, backup folder chuno / `.Vault` import karo. Entries ki ginti purane app se milao.
4. **Android Settings -> Autofill service** me naya BSRPRO select karo (system me ek time par ek hi autofill service active hoti hai). Biometric unlock naye app me dobara on karna padega.
5. Sab sahi ho to hi purana debug app uninstall karo.

## APK test checklist

After downloading and installing the APK on a test device, use synthetic test data only.

### Core vault

- [ ] App launches and unlocks.
- [ ] Create a synthetic login entry.
- [ ] Edit username/password/TOTP/notes.
- [ ] Delete entry → it appears in Bin.
- [ ] Restore entry → it returns to active vault.
- [ ] Empty Bin → entry is permanently removed.
- [ ] Existing vault data remains unchanged during testing.

### Import / export

- [ ] Import synthetic `.Vault` V3.
- [ ] Export and re-import the synthetic vault.
- [ ] Test representative CSV imports.
- [ ] Confirm IDs remain stable when valid IDs are supplied.
- [ ] Test a blank-ID fixture and confirm deterministic ID generation.

### Backup / restore

- [ ] Automatic backup uses the single filename `BSRPRO.Vault`.
- [ ] Restore discovers an Android backup automatically.
- [ ] Restore discovers an Extension-created `BSRPRO.Vault` backup.
- [ ] Simulate/inspect interrupted-write recovery using synthetic files only.
- [ ] Confirm the original main vault remains readable after a failed backup operation.

### Autofill

- [ ] Enable BSRPRO as the Autofill service.
- [ ] Open a test login page and confirm real username/password fields are detected.
- [ ] Verify locked-vault authentication appears.
- [ ] Verify the app icon/name in the Autofill picker.
- [ ] Verify light/dark suggestion UI follows the app theme.
- [ ] Verify Travel Mode suppresses automatic Autofill suggestions when enabled.

### UI / security

- [ ] Rotate-device behavior stays portrait.
- [ ] Test LTR and an RTL locale.
- [ ] Test light and dark theme transitions.
- [ ] Test PIN rules (4–6 digits).
- [ ] Test biometric unlock/cancel path.
- [ ] Let the configured session timeout expire and confirm relock.
- [ ] Confirm screenshots are blocked on protected screens.

## Phase 10 handoff

Record the actual device/emulator results, failed cases, screenshots/logcat where useful, and the GitHub Actions run result. Phase 10 should be completed only from those real test results; this README does not pre-assert runtime PASS.
