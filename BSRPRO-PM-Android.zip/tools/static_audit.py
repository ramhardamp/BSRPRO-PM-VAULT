import re,glob,os,sys,collections
from pathlib import Path
root=str(Path(__file__).resolve().parents[1] / 'app' / 'src')
files=glob.glob(root+'/**/*.kt',recursive=True)
def strip(s):
    out=[];i=0;n=len(s)
    while i<n:
        if s.startswith('//',i):
            j=s.find('\n',i); j=n if j<0 else j; i=j; continue
        if s.startswith('/*',i):
            j=s.find('*/',i+2); i=n if j<0 else j+2; continue
        if s.startswith('"""',i):
            j=s.find('"""',i+3); j=n if j<0 else j+3
            body=s[i:j]
            out.append(' '.join(re.findall(r'\$\{?([A-Za-z_][A-Za-z0-9_.]*)',body)) +' '); i=j; continue
        if s[i]=='"':
            j=i+1; body=''
            while j<n and s[j]!='"':
                if s[j]=='\\': j+=2; continue
                j+=1
            body=s[i:j]
            out.append(' '.join(re.findall(r'\$\{?([A-Za-z_][A-Za-z0-9_]*)',body))+' '); i=j+1; continue
        if s[i]=="'" and i+2<n and (s[i+2]=="'" or s[i+1]=='\\'):
            j=s.find("'",i+2); i=j+1; continue
        out.append(s[i]); i+=1
    return ''.join(out)
decl=collections.defaultdict(set)   # name -> packages
info={}
for f in files:
    raw=open(f).read()
    pkg=re.search(r'^package\s+([\w.]+)',raw,re.M)
    pkg=pkg.group(1) if pkg else ''
    code=strip(raw)
    imps=re.findall(r'^import\s+([\w.]+(?:\.\*)?)(?:\s+as\s+(\w+))?\s*$',raw,re.M)
    info[f]=(pkg,code,imps,raw)
    for m in re.finditer(r'\b(?:class|object|interface|typealias)\s+([A-Za-z_]\w*)',code): decl[m.group(1)].add(pkg)
    for m in re.finditer(r'\b(?:fun|val|var|const val)\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?([A-Za-z_]\w*)\s*[:(=<]',code): decl[m.group(1)].add(pkg)
    for m in re.finditer(r'\benum class\s+\w+[^{]*\{([^;}]*)',code):
        for e in re.findall(r'\b([A-Z][A-Za-z0-9_]*)\b',m.group(1)): decl[e].add(pkg)
STD=set('''String Int Long Float Double Boolean Unit Any Nothing List MutableList Map MutableMap Set MutableSet Pair Triple Array ByteArray CharArray IntArray LongArray Char Byte Short Number Throwable Exception RuntimeException IllegalStateException IllegalArgumentException UnsupportedOperationException IOException Result Sequence Iterable Collection Comparable Regex RegexOption Lazy Function ArrayList HashMap LinkedHashMap HashSet LinkedHashSet ArrayDeque StringBuilder Math System Thread Date Locale UUID Volatile Suppress OptIn JvmStatic JvmField JvmOverloads Deprecated Synchronized Override Charsets Text Companion It Triple NoSuchElementException NumberFormatException ClassCastException SecurityException CancellationException TimeUnit AtomicInteger AtomicBoolean AtomicLong Timber R BuildConfig Build Log Context Intent Bundle Uri Color Modifier Composable Inject Singleton Test Before After Assert BeforeTest Serializable SerialName Transient'''.split())
unres=collections.defaultdict(set); dups=[]
for f,(pkg,code,imps,raw) in info.items():
    names=[i[1] or i[0].split('.')[-1] for i in imps]
    c=collections.Counter(names)
    for n,k in c.items():
        if k>1 and n!='*': dups.append((f,n))
    wild=[i[0][:-2] for i in imps if i[0].endswith('.*')]
    expl=set(names)
    body=re.sub(r'^import .*$','',code,flags=re.M)
    body=re.sub(r'^package .*$','',body,flags=re.M)
    # remove qualified usages: pkg.Name -> skip token preceded by '.'
    for m in re.finditer(r'(?<![\w.])([A-Z][A-Za-z0-9_]*)\b',body):
        n=m.group(1)
        if n in expl or n in STD: continue
        if pkg in decl.get(n,()): continue
        if any(w in decl.get(n,()) for w in wild): continue
        # locally declared in this file (nested)
        if re.search(r'\b(class|object|interface|enum class|typealias)\s+'+n+r'\b',body): continue
        unres[f].add((n, bool(decl.get(n)), ))
print('DUP IMPORTS:',dups)
for f,s in sorted(unres.items()):
    print(os.path.relpath(f,root))
    print('   ',sorted(x[0]+('*' if x[1] else '') for x in s))

# ---------- second pass: curated external symbols ----------
CF='androidx.compose.foundation'; CL=CF+'.layout'; M3='androidx.compose.material3'; RT='androidx.compose.runtime'; UI='androidx.compose.ui'
sets={
 CL:'Column Row Box Spacer PaddingValues Arrangement fillMaxSize fillMaxWidth fillMaxHeight padding size height width wrapContentHeight wrapContentWidth navigationBarsPadding statusBarsPadding imePadding heightIn widthIn sizeIn defaultMinSize aspectRatio offset FlowRow IntrinsicSize BoxWithConstraints requiredSize',
 M3:'Button OutlinedButton TextButton IconButton Icon Text Card OutlinedCard ElevatedCard Scaffold TopAppBar FilterChip AlertDialog Surface Switch Slider Tab TabRow OutlinedTextField TextField DropdownMenu DropdownMenuItem HorizontalDivider CircularProgressIndicator LinearProgressIndicator ExtendedFloatingActionButton FloatingActionButton ListItem MaterialTheme ModalNavigationDrawer ModalDrawerSheet NavigationDrawerItem NavigationBar NavigationBarItem Checkbox RadioButton AssistChip Badge BadgedBox SnackbarHost Divider Snackbar SnackbarHostState LargeTopAppBar CenterAlignedTopAppBar ExposedDropdownMenuBox ExposedDropdownMenuDefaults SuggestionChip InputChip ButtonDefaults CardDefaults TextFieldDefaults DrawerValue rememberDrawerState DrawerState ModalBottomSheet SingleChoiceSegmentedButtonRow SegmentedButton',
 CF:'clickable combinedClickable background border verticalScroll horizontalScroll rememberScrollState Image ScrollState isSystemInDarkTheme',
 CF+'.lazy':'LazyColumn LazyRow items itemsIndexed LazyListState rememberLazyListState',
 RT:'Composable remember mutableStateOf LaunchedEffect DisposableEffect SideEffect derivedStateOf mutableLongStateOf mutableIntStateOf rememberCoroutineScope CompositionLocalProvider produceState rememberUpdatedState snapshotFlow State MutableState',
 UI:'Modifier Alignment',
 UI+'.draw':'clip alpha shadow',
 UI+'.unit':'dp sp',
 UI+'.platform':'LocalContext LocalClipboardManager LocalDensity LocalFocusManager',
 'androidx.lifecycle.compose':'collectAsStateWithLifecycle',
 'androidx.hilt.navigation.compose':'hiltViewModel',
 'kotlinx.coroutines':'launch delay withContext Dispatchers CoroutineScope SupervisorJob Job',
 'kotlinx.coroutines.flow':'MutableStateFlow StateFlow asStateFlow update combine stateIn SharingStarted map Flow receiveAsFlow flowOf',
 'kotlinx.coroutines.channels':'Channel',
}
sym2pkg={}
for p,names in sets.items():
    for n in names.split(): sym2pkg.setdefault(n,[]).append(p)
sym2pkg['clip']=[UI+'.draw']
sym2pkg['Image']=[CF]
sym2pkg['background']=[CF]
# members that look like symbols but are scope/receiver members: skip when preceded by '.' and in scope set
SCOPE={'weight','align','fillMaxSize'}
issues=[]
for f,(pkg,code,imps,raw) in info.items():
    if '/test/' in f: continue
    names=set(i[1] or i[0].split('.')[-1] for i in imps)
    fulls=set(i[0] for i in imps)
    wild=set(i[0][:-2] for i in imps if i[0].endswith('.*'))
    body=re.sub(r'^import .*$','',code,flags=re.M)
    for n,pk in sym2pkg.items():
        if n in ('Text','items','map','update','combine','State','Modifier','Alignment') and False: pass
        pat=r'(?<![\w])'+re.escape(n)+r'(?![\w])'
        if not re.search(pat,body): continue
        # skip if it is declared in file/package
        if pkg in decl.get(n,()) and n[0].isupper() : continue
        if any(((p+'.'+n) in fulls) or (p in wild) for p in pk): continue
        # nested-class/local identifiers: skip names used only as identifiers after '.' (e.g. foo.update) for generic names
        if n in ('update','map','combine','launch','items','delay','alpha','shadow','size','height','width','padding','offset','border','State','Job') :
            if not re.search(r'(?<![\w.])'+re.escape(n)+r'\s*[({]',body) : continue
            # method calls like list.map { } are fine -> only flag when called without receiver
            if not re.search(r'(?<![\w.)\]}>])'+re.escape(n)+r'\s*[({]',body) and n not in ('size','height','width','padding','offset','border','alpha','shadow','items'): continue
        issues.append((os.path.relpath(f,root),n,pk[0]))
    # icons
    for m in set(re.findall(r'Icons\.(?:Default|Filled|Outlined|Rounded)\.(\w+)',body)):
        if ('androidx.compose.material.icons.filled.'+m) in fulls or 'androidx.compose.material.icons.filled' in wild or 'androidx.compose.material.icons.outlined.'+m in fulls: continue
        issues.append((os.path.relpath(f,root),'Icons.'+m,'icons.filled'))
    for m in set(re.findall(r'Icons\.AutoMirrored\.Filled\.(\w+)',body)):
        if ('androidx.compose.material.icons.automirrored.filled.'+m) in fulls or 'androidx.compose.material.icons.automirrored.filled' in wild: continue
        issues.append((os.path.relpath(f,root),'Icons.AutoMirrored.'+m,'automirrored'))
    if re.search(r'\bIcons\.',body) and not ('androidx.compose.material.icons.Icons' in fulls): issues.append((os.path.relpath(f,root),'Icons','icons.Icons'))
    # delegates
    if re.search(r'\bva[lr]\s+\w+(?::[^=]+)?\s+by\s+',body):
        if 'androidx.compose.runtime.getValue' not in fulls and RT not in wild: issues.append((os.path.relpath(f,root),'getValue','runtime'))
        if re.search(r'\bvar\s+\w+(?::[^=]+)?\s+by\s+',body) and 'androidx.compose.runtime.setValue' not in fulls and RT not in wild: issues.append((os.path.relpath(f,root),'setValue','runtime'))
print('\nSECOND PASS ISSUES:')
for i in sorted(set(issues)): print('  ',i)
