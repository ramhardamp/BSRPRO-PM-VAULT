#!/usr/bin/env python3
"""Fast source/package gate for production polish. Runtime/device behavior is tested separately by CI."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def require(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


# CI must never report green while its test/smoke jobs are explicitly non-blocking.
workflow = (ROOT / ".github/workflows/native-android-build.yml").read_text(encoding="utf-8")
require("continue-on-error:" not in workflow, "CI contains a non-blocking job")
require("assembleDebug lintDebug" in workflow, "blocking build/lint gate missing")
require("testDebugUnitTest" in workflow, "blocking unit-test gate missing")
require("Emulator smoke test" in workflow, "emulator smoke gate missing")

# Release pipeline: signed, non-debuggable APK with no debug identity. Keys only from secrets/env, never from source.
require("assembleRelease" in workflow, "release APK job missing")
require("application-debuggable" in workflow, "release APK debuggable check missing")
require("apksigner" in workflow and "--print-certs" in workflow, "release signature fingerprint check missing")
require("Emulator smoke test (release APK)" in workflow, "release smoke gate missing")
require("secrets.ANDROID_KEYSTORE_BASE64" in workflow, "release keystore must come from GitHub secrets")

_gradle_src = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
require("signingConfigs" in _gradle_src and "ANDROID_KEYSTORE_PATH" in _gradle_src, "release signing config missing")
require(re.search(r'(storePassword|keyPassword)\s*=\s*"', _gradle_src) is None, "hard-coded signing password in build.gradle.kts")
_dbg = _gradle_src.index("debug {")
_rel = _gradle_src.index("release {", _dbg)
require(_dbg < _gradle_src.index("versionNameSuffix") < _rel, "-debug versionNameSuffix must live only in the debug buildType")
require(_gradle_src.count("versionNameSuffix") == 1 and _gradle_src.count("applicationIdSuffix") == 1, "debug identity leaked outside the debug buildType")
require("isDebuggable = false" in _gradle_src[_rel:], "release must be explicitly non-debuggable")

# Backup publishing must be serialized because WorkManager and debounced writes can overlap.
backup = (ROOT / "app/src/main/java/pro/babasitaram/vault/data/backup/AutoBackupManager.kt").read_text(encoding="utf-8")
require("private val backupMutex = Mutex()" in backup, "backup publisher mutex missing")
require("suspend fun backupNow(): VaultResult<String> = backupMutex.withLock" in backup, "backupNow is not serialized")
require("AtomicMoveNotSupportedException" in backup, "filesystem atomic-move fallback missing")
require("IS_PENDING" in backup, "MediaStore staged-write guard missing")
require("renameDocument" in backup, "SAF transactional publish missing")

# Release source must not contain accidental debug output or work-in-progress markers.
source_files = list((ROOT / "app/src/main").rglob("*.kt"))
for path in source_files:
    text = path.read_text(encoding="utf-8")
    require("System.out" not in text and "System.err" not in text, f"debug stdout/stderr in {path}")
    require(not re.search(r"//\s*(TODO|FIXME|XXX|HACK)\b", text), f"work-in-progress marker in {path}")

# Direct dependencies removed in the polish pass must stay absent unless code actually uses them.
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
for token in ("libs.androidx.security.crypto", "libs.tink.android", "libs.coil.compose"):
    require(token not in gradle, f"unused direct dependency returned: {token}")

# Manifest and resources must remain parseable.
ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
for path in (ROOT / "app/src/main/res").rglob("*.xml"):
    ET.parse(path)

# No signing material or generated binaries belong in the source handoff.
for pattern in ("*.jks", "*.keystore", "*.pem", "*.p12", "*.apk", "*.aab", "local.properties"):
    found = list(ROOT.rglob(pattern))
    if found:
        fail(f"generated/secret artifact included: {found[0]}")

print("PASS: production polish source/package gate")
