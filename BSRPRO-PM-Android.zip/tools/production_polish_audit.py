#!/usr/bin/env python3
"""Fast source/package gate for production polish. Runtime/device behavior is tested separately by CI."""
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def require(condition: bool, message: str) -> None:
    if not condition:
        fail(message)


# CI must never report green while its test/smoke jobs are explicitly non-blocking.
workflow = (ROOT / ".github/workflows/native-android-build.yml").read_text(encoding="utf-8")
require("continue-on-error:" not in workflow, "CI contains a non-blocking job")
require("assembleDebug lintDebug" in workflow, "blocking build/lint gate missing")
require("testDebugUnitTest" in workflow, "blocking unit-test gate missing")
require("Emulator smoke test" in workflow, "emulator smoke gate missing")

# Backup publishing must be serialized because WorkManager and debounced writes can overlap.
backup = (ROOT / "app/src/main/java/pro/babasitaram/vault/data/backup/AutoBackupManager.kt").read_text(encoding="utf-8")
require("private val backupMutex = Mutex()" in backup, "backup publisher mutex missing")
require("suspend fun backupNow(): VaultResult<String> = backupMutex.withLock" in backup, "backupNow is not serialized")
require("AtomicMoveNotSupportedException" in backup, "filesystem atomic-move fallback missing")
require("IS_PENDING" in backup, "MediaStore staged-write guard missing")
require("renameDocument" in backup, "SAF transactional publish missing")

# Release source must not contain accidental debug output or work-in-progress markers.
source_files = list((ROOT / "app/src/main").rglob("*.kt"))
for path in source_files:
    text = path.read_text(encoding="utf-8")
    require("System.out" not in text and "System.err" not in text, f"debug stdout/stderr in {path}")
    require(not re.search(r"//\s*(TODO|FIXME|XXX|HACK)\b", text), f"work-in-progress marker in {path}")

# Direct dependencies removed in the polish pass must stay absent unless code actually uses them.
gradle = (ROOT / "app/build.gradle.kts").read_text(encoding="utf-8")
for token in ("libs.androidx.security.crypto", "libs.tink.android", "libs.coil.compose"):
    require(token not in gradle, f"unused direct dependency returned: {token}")

# Manifest and resources must remain parseable.
ET.parse(ROOT / "app/src/main/AndroidManifest.xml")
for path in (ROOT / "app/src/main/res").rglob("*.xml"):
    ET.parse(path)

# No signing material or generated binaries belong in the source handoff.
for pattern in ("*.jks", "*.keystore", "*.pem", "*.p12", "*.apk", "*.aab", "local.properties"):
    found = list(ROOT.rglob(pattern))
    if found:
        fail(f"generated/secret artifact included: {found[0]}")

print("PASS: production polish source/package gate")
