#!/usr/bin/env python3
"""Static guard against accidental BSRPRO theme drift."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
THEME = ROOT / "app/src/main/java/pro/babasitaram/vault/presentation/theme"


def fail(message: str) -> None:
    raise SystemExit(f"FAIL: {message}")


def require(condition: bool, message: str) -> None:
    if not condition:
        fail(message)

color = (THEME / "Color.kt").read_text(encoding="utf-8")
theme = (THEME / "Theme.kt").read_text(encoding="utf-8")
shapes = (THEME / "Shapes.kt").read_text(encoding="utf-8")
require("BrandPrimaryLight" in color and "BrandPrimaryDark" in color, "brand primary palette missing")
require("BrandGoldLight" in color and "BrandGoldDark" in color, "brand gold palette missing")
for role in ("primary", "onPrimary", "primaryContainer", "onPrimaryContainer", "secondary", "onSecondary", "secondaryContainer", "onSecondaryContainer", "tertiary", "onTertiary", "tertiaryContainer", "onTertiaryContainer", "background", "onBackground", "surface", "onSurface", "surfaceVariant", "onSurfaceVariant", "outline", "outlineVariant"):
    require(re.search(rf"\b{role}\s*=", theme) is not None, f"theme role missing: {role}")
require("shapes = VaultShapes" in theme, "central shape system not wired")
require("VaultShapes" in shapes, "central shape definition missing")

# These screens must consume MaterialTheme roles rather than hard-coded rainbow brand colors.
for rel in (
    "app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt",
    "app/src/main/java/pro/babasitaram/vault/presentation/editor/EntryTypeChooserScreen.kt",
):
    text = (ROOT / rel).read_text(encoding="utf-8")
    require("Color(0x" not in text, f"local hard-coded brand color remains in {rel}")

require(not (THEME / "SectionColors.kt").exists(), "legacy rainbow SectionColors palette still exists")
print("PASS: BSRPRO brand theme audit")
