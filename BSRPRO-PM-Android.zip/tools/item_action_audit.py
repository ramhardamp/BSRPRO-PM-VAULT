#!/usr/bin/env python3
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
PRES = ROOT / "app/src/main/java/pro/babasitaram/vault/presentation"

ROW_FILES = [
    PRES / "notes/NotesScreen.kt",
    PRES / "mobiles/MobilesScreen.kt",
    PRES / "totpmanager/TotpManagerScreen.kt",
    PRES / "files/FilesScreen.kt",
    PRES / "vault/VaultListScreen.kt",
]
FAIL = []

for p in ROW_FILES:
    text = p.read_text(encoding="utf-8")
    if "MoreVert" in text or "Icons.Default.MoreVert" in text:
        FAIL.append(f"row-level MoreVert remains in {p.relative_to(ROOT)}")

# Per-item dropdowns must not remain in the item-list screens. Dropdowns in editors/sort UI are allowed.
for p in [ROW_FILES[0], ROW_FILES[1], ROW_FILES[2], ROW_FILES[3]]:
    text = p.read_text(encoding="utf-8")
    if re.search(r"DropdownMenu|DropdownMenuItem|PopupMenu|ContextMenu", text):
        FAIL.append(f"transient item-action menu remains in {p.relative_to(ROOT)}")

# Row taps must navigate through the detail pattern.
checks = {
    PRES / "notes/NotesScreen.kt": "onOpen(entry.id)",
    PRES / "mobiles/MobilesScreen.kt": "onOpen(entry.id)",
    PRES / "totpmanager/TotpManagerScreen.kt": "onOpen(entry.id)",
    PRES / "files/FilesScreen.kt": "onOpen(entry.id)",
    PRES / "vault/VaultListScreen.kt": "onOpen(row.entry.id)",
}
for p, needle in checks.items():
    text = p.read_text(encoding="utf-8")
    if needle not in text:
        FAIL.append(f"expected detail-open contract missing in {p.relative_to(ROOT)}: {needle}")

if FAIL:
    print("FAIL")
    print("\n".join(f"- {x}" for x in FAIL))
    sys.exit(1)
print(f"PASS: {len(ROW_FILES)} item-list screens audited; no row-level overflow menus remain.")
