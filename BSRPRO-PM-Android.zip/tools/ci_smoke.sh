#!/usr/bin/env bash
# Emulator smoke test: install the APK (debug by default, release via SMOKE_APK), launch MainActivity, require a live process,
# a resumed activity and no fatal crash in logcat. Run from the repo root.
# (android-emulator-runner executes each script line separately, so all logic lives here.)
set -u
# Defaults = debug APK (purana behaviour). Release smoke job SMOKE_PKG / SMOKE_APK env se override karta hai.
PKG="${SMOKE_PKG:-pro.babasitaram.vault.debug}"
COMPONENT="$PKG/pro.babasitaram.vault.MainActivity"
APK="${SMOKE_APK:-app/build/outputs/apk/debug/app-debug.apk}"
fail() { echo "SMOKE FAIL: $1"; adb logcat -d -t 800 > runtime-logcat.txt 2>&1 || true; tail -n 120 runtime-logcat.txt; exit 1; }

adb wait-for-device
adb shell 'while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 1; done'
adb install -r "$APK" || fail "install"
adb shell am force-stop "$PKG"
adb logcat -c
adb shell am start -W -n "$COMPONENT" > am-start.txt 2>&1
cat am-start.txt
grep -q "Error" am-start.txt && fail "am start reported an error"
grep -q "Status: ok" am-start.txt || fail "am start did not report Status: ok"
sleep 10
adb shell pidof "$PKG" > pid.txt 2>&1
[ -s pid.txt ] || fail "process is not running after launch"
adb shell dumpsys activity activities | grep -E 'mResumedActivity|topResumedActivity' | grep -q "$PKG" || fail "MainActivity is not resumed"
adb logcat -d -t 1000 > runtime-logcat.txt 2>&1
grep -Eiq 'FATAL EXCEPTION|AndroidRuntime.*FATAL|Process: *'"$PKG"'.*has died' runtime-logcat.txt && fail "fatal exception in logcat"
echo "SMOKE OK"
