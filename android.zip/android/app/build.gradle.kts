import java.util.Properties
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
    alias(libs.plugins.android.junit5)
}

// ---------------------------------------------------------------------------
// Release signing + R8 switch.
// Keystore repo me KABHI commit nahi hota (audit isse block karta hai). Key in jagah se aati hai:
//   1) GitHub Actions secrets -> env vars  (ANDROID_KEYSTORE_PATH / _PASSWORD / ANDROID_KEY_ALIAS / _PASSWORD)
//   2) local keystore.properties (git-ignored): storeFile, storePassword, keyAlias, keyPassword
// Key na mile to release APK UNSIGNED banta hai (install nahi hoga) — debug key se chup-chaap sign NAHI karte.
// ---------------------------------------------------------------------------
val keystoreProps = Properties().apply {
    val propsFile = rootProject.file("keystore.properties")
    if (propsFile.exists()) propsFile.inputStream().use { load(it) }
}

fun signingValue(propKey: String, envKey: String): String? =
    (keystoreProps.getProperty(propKey) ?: System.getenv(envKey))?.takeIf { it.isNotBlank() }

val releaseSigning: Map<String, String>? = run {
    val store = signingValue("storeFile", "ANDROID_KEYSTORE_PATH") ?: return@run null
    val storePass = signingValue("storePassword", "ANDROID_KEYSTORE_PASSWORD") ?: return@run null
    val alias = signingValue("keyAlias", "ANDROID_KEY_ALIAS") ?: return@run null
    val keyPass = signingValue("keyPassword", "ANDROID_KEY_PASSWORD") ?: return@run null
    mapOf("storeFile" to store, "storePassword" to storePass, "keyAlias" to alias, "keyPassword" to keyPass)
}

// R8 (minify + shrink) default ON. Agar R8 kabhi release me error de: -Pbsrpro.minify=false se bina R8 ka (par non-debug) APK banta hai.
val minifyRelease: Boolean = (providers.gradleProperty("bsrpro.minify").orNull ?: "true").toBoolean()

android {
    namespace = "pro.babasitaram.vault"
    compileSdk = 35

    defaultConfig {
        applicationId = "pro.babasitaram.vault"
        minSdk = 26
        targetSdk = 35
        versionCode = 33
        versionName = "1.0.3"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        releaseSigning?.let { keys ->
            create("release") {
                storeFile = file(keys.getValue("storeFile"))
                storePassword = keys.getValue("storePassword")
                keyAlias = keys.getValue("keyAlias")
                keyPassword = keys.getValue("keyPassword")
            }
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            // PASS15 (APK update-in-place): pehle debug APK har CI run par naye RANDOM key se sign hota tha, isliye
            // naya APK purane ke upar install nahi hota tha ("App not installed"). Ab key mile (GitHub Secrets /
            // keystore.properties) to debug bhi usi fixed key se sign hota hai => har build purane ke upar update.
            // Key na mile (fork / local) to Android ki default debug key (pehle jaisa).
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
        release {
            isDebuggable = false
            isMinifyEnabled = minifyRelease
            isShrinkResources = minifyRelease
            // Key configured nahi to null => unsigned APK (CI verify step isko clear message ke saath pakadta hai).
            signingConfig = signingConfigs.findByName("release")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += setOf(
            "/META-INF/{AL2.0,LGPL2.1}",
            "/META-INF/LICENSE*",
            "/META-INF/NOTICE*"
        )
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(JvmTarget.JVM_17)
        freeCompilerArgs.addAll(
            "-opt-in=androidx.compose.material3.ExperimentalMaterial3Api",
            "-opt-in=androidx.compose.foundation.ExperimentalFoundationApi",
            "-opt-in=androidx.compose.animation.ExperimentalAnimationApi"
        )
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.process)

    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.ui.graphics)
    implementation(libs.compose.ui.tooling.preview)
    implementation(libs.compose.material3)
    implementation(libs.compose.material.icons.extended)

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)
    implementation(libs.androidx.datastore.preferences)
    implementation(libs.androidx.fragment)
    implementation(libs.androidx.autofill)
    implementation(libs.androidx.biometric)
    implementation(libs.androidx.work.runtime.ktx)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.navigation.compose)

    implementation(libs.kotlinx.serialization.json)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.timber)
    implementation(libs.zxing.core) // QR generation (share / TOTP detail) AND QR scanning (TOTP setup)
    implementation(libs.androidx.camera.core)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.lottie.compose)

    testImplementation(libs.junit5.api)
    testImplementation(libs.junit5.params)
    testRuntimeOnly(libs.junit5.engine)
    testImplementation(libs.junit4)
    testRuntimeOnly(libs.junit5.vintage)
    testImplementation(libs.mockk)
    testImplementation(libs.turbine)
    testImplementation(libs.kotlinx.coroutines.test)
    testImplementation(libs.androidx.test.core)
    testImplementation(libs.robolectric)
    testImplementation(libs.room.testing)

    androidTestImplementation(platform(libs.compose.bom))
    androidTestImplementation(libs.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.test.runner)
    debugImplementation(libs.compose.ui.tooling)
    debugImplementation(libs.compose.ui.test.manifest)
}
