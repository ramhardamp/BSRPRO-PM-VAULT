package pro.babasitaram.vault.autofill

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.autofill.model.AutofillFieldType.NEW_PASSWORD
import pro.babasitaram.vault.autofill.model.AutofillFieldType.OTP
import pro.babasitaram.vault.autofill.model.AutofillFieldType.PIN
import pro.babasitaram.vault.autofill.model.AutofillFieldType.PASSWORD
import pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME
import pro.babasitaram.vault.autofill.model.FieldHints
import androidx.compose.foundation.lazy.*

class AutofillParserTest {
    private fun c(h: FieldHints) = AutofillParser.classify(h)

    private val textPassword = 0x81           // TYPE_CLASS_TEXT | TYPE_TEXT_VARIATION_PASSWORD
    private val webPassword = 0xe1            // TYPE_TEXT_VARIATION_WEB_PASSWORD
    private val emailInput = 0x21             // TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    private val numberPassword = 0x12         // TYPE_CLASS_NUMBER | TYPE_NUMBER_VARIATION_PASSWORD

    @Test fun `explicit autofill hints win`() {
        assertEquals(PASSWORD, c(FieldHints(autofillHints = listOf("password"))))
        assertEquals(NEW_PASSWORD, c(FieldHints(autofillHints = listOf("newPassword"))))
        assertEquals(USERNAME, c(FieldHints(autofillHints = listOf("username"))))
        assertEquals(USERNAME, c(FieldHints(autofillHints = listOf("emailAddress"))))
        assertEquals(OTP, c(FieldHints(autofillHints = listOf("smsOTPCode"))))
    }

    @Test fun `html autocomplete attribute is honoured`() {
        assertEquals(OTP, c(FieldHints(htmlAutocomplete = "one-time-code")))
        assertEquals(NEW_PASSWORD, c(FieldHints(htmlAutocomplete = "new-password")))
        assertEquals(PASSWORD, c(FieldHints(htmlAutocomplete = "current-password")))
        assertEquals(USERNAME, c(FieldHints(htmlAutocomplete = "section-login username")))
    }

    @Test fun `password input types`() {
        assertEquals(PASSWORD, c(FieldHints(inputType = textPassword)))
        assertEquals(PASSWORD, c(FieldHints(inputType = webPassword)))
        assertEquals(PIN, c(FieldHints(inputType = numberPassword)))
        assertEquals(PASSWORD, c(FieldHints(htmlType = "password")))
    }

    @Test fun `PIN hint is recognized only with a 4 to 6 character limit`() {
        assertEquals(PIN, c(FieldHints(hint = "Enter PIN", maxLength = 4)))
        assertEquals(PIN, c(FieldHints(htmlName = "securityPin", maxLength = 6)))
        assertNull(c(FieldHints(hint = "PIN", maxLength = 8)))
    }

    @Test fun `confirm and new password fields are not filled with the old password`() {
        assertEquals(NEW_PASSWORD, c(FieldHints(inputType = numberPassword, hint = "New PIN", maxLength = 4)))
        assertEquals(NEW_PASSWORD, c(FieldHints(inputType = textPassword, idEntry = "confirm_password")))
        assertEquals(NEW_PASSWORD, c(FieldHints(inputType = textPassword, hint = "Repeat password")))
    }

    @Test fun `otp is detected from ids and hints`() {
        assertEquals(OTP, c(FieldHints(idEntry = "otp_code")))
        assertEquals(OTP, c(FieldHints(hint = "Verification code")))
        assertEquals(OTP, c(FieldHints(htmlName = "totpPin")))
        assertEquals(OTP, c(FieldHints(idEntry = "twoFactorCode")))
    }

    @Test fun `username keywords incl camelCase`() {
        assertEquals(USERNAME, c(FieldHints(idEntry = "user_email")))
        assertEquals(USERNAME, c(FieldHints(htmlType = "email")))
        assertEquals(USERNAME, c(FieldHints(inputType = emailInput)))
        assertEquals(PASSWORD, c(FieldHints(idEntry = "loginPassword")))
    }

    @Test fun `unrelated fields are ignored`() {
        assertNull(c(FieldHints(hint = "Search", inputType = 1)))
        assertNull(c(FieldHints(idEntry = "address_line", inputType = 1)))
    }

    @Test fun `a plain text field before the password becomes the username`() {
        val items = listOf(
            "a" to FieldHints(inputType = 1),
            "b" to FieldHints(inputType = textPassword)
        )
        assertEquals(listOf("a" to USERNAME, "b" to PASSWORD), AutofillParser.resolve(items))
    }

    @Test fun `plain text before numeric PIN can be inferred as username`() {
        val items = listOf("u" to FieldHints(inputType = 1), "pin" to FieldHints(inputType = numberPassword))
        assertEquals(listOf("u" to USERNAME, "pin" to PIN), AutofillParser.resolve(items))
    }

    @Test fun `the heuristic does not override an explicit username or touch non-text fields`() {
        val explicit = listOf(
            "x" to FieldHints(inputType = 1),
            "u" to FieldHints(autofillHints = listOf("username")),
            "p" to FieldHints(inputType = textPassword)
        )
        assertEquals(listOf("x" to null, "u" to USERNAME, "p" to PASSWORD), AutofillParser.resolve(explicit))

        val multiline = listOf("m" to FieldHints(inputType = 0x20001), "p" to FieldHints(inputType = textPassword))
        assertEquals(listOf("m" to null, "p" to PASSWORD), AutofillParser.resolve(multiline))
    }
    @Test fun `recharge screen does not classify generic mobile field as username`() {
        val items = listOf(
            "title" to FieldHints(hint = "Recharge number", inputType = 0),
            "mobile" to FieldHints(hint = "Enter mobile number", inputType = 1)
        )
        val resolved = AutofillParser.resolve(items, "recharge number")
        assertTrue(resolved.none { it.second == USERNAME || it.second == PASSWORD })
    }

    @Test fun `recharge mobile remains ignored when only the mobile field is present`() {
        val items = listOf("mobile" to FieldHints(hint = "Enter mobile number", inputType = 1))
        assertEquals(listOf("mobile" to null), AutofillParser.resolve(items, "Recharge number"))
    }

}

/** Extra field-name words used by Indian banking / retail native apps. */
class AutofillParserNativeWordsTest {

    @Test fun `customer and confirmation mobile fields are never login credentials`() {
        assertNull(c(FieldHints(hint = "Customer mobile number", inputType = 1)))
        assertNull(c(FieldHints(hint = "Confirm mobile number", inputType = 1)))
        assertNull(c(FieldHints(idEntry = "customerMobileNumber", inputType = 1)))
    }

    @Test fun `customer mobile fields do not become username by password fallback`() {
        val items = listOf(
            "mobile" to FieldHints(hint = "Customer mobile number", inputType = 1),
            "confirm" to FieldHints(hint = "Confirm mobile number", inputType = 1)
        )
        assertTrue(AutofillParser.resolve(items).all { it.second == null })
    }

    private fun cls(id: String? = null, hint: String? = null, input: Int = 0) =
        AutofillParser.classify(pro.babasitaram.vault.autofill.model.FieldHints(idEntry = id, hint = hint, inputType = input))

    @Test fun `customer employee and retailer ids are usernames`() {
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(id = "etCustomerId"))
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(hint = "Employee code"))
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(hint = "Retailer ID"))
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.USERNAME, cls(id = "mobileNo"))
    }

    @Test fun `password words still win`() {
        assertEquals(pro.babasitaram.vault.autofill.model.AutofillFieldType.PASSWORD, cls(hint = "Customer password"))
    }

    @Test fun `PIN field with no declared limit is still a PIN`() {
        assertEquals(PIN, c(FieldHints(hint = "Enter your PIN")))
        assertEquals(PIN, c(FieldHints(idEntry = "et_mpin", inputType = 2)))
    }

    @Test fun `postal PIN code and long numeric passwords are not PIN fields`() {
        assertNull(c(FieldHints(hint = "PIN code", maxLength = 6)))
        assertEquals(PASSWORD, c(FieldHints(inputType = numberPassword, maxLength = 12)))
    }
}

/** Phase 19: login ke BAAD wali recharge/POS screens par "ID & Password" suggestion nahi aana chahiye. */
class AutofillParserPostLoginTransactionTest {

    // Screenshot 1: "recharge number" screen, field "enter mobile number", app ne galti se "username" hint laga diya.
    @Test fun `recharge screen with explicit username hint and no password field is ignored`() {
        val items = listOf("mobile" to FieldHints(autofillHints = listOf("username"), hint = "enter mobile number", inputType = 3))
        assertEquals(listOf("mobile" to null), AutofillParser.resolve(items, "hi rupesh jatav 59.56 add balance recharge number"))
    }

    // Screenshot 2: "Customer mobile number" + masked confirmation field (numberPassword), koi asli password nahi.
    @Test fun `customer mobile with masked confirmation is ignored`() {
        val items = listOf(
            "mobile" to FieldHints(autofillHints = listOf("username"), hint = "Enter 10 digit mobile number", inputType = 3),
            "confirm" to FieldHints(hint = "Enter 10 digit mobile number", inputType = 0x12)
        )
        val resolved = AutofillParser.resolve(items, "Recharge Wallet balance Customer mobile number Continue")
        assertTrue(resolved.all { it.second == null })
    }

    @Test fun `logout word marks a logged-in screen`() {
        val items = listOf("u" to FieldHints(autofillHints = listOf("username"), hint = "Enter number"))
        assertEquals(listOf("u" to null), AutofillParser.resolve(items, "Logout Profile"))
    }

    // Zero regression: asli login screen (password field ya "login" words) pehle jaisa chalti rahe.
    @Test fun `real login with password still fills even on a customer or retailer app`() {
        val items = listOf(
            "u" to FieldHints(autofillHints = listOf("username"), hint = "Retailer ID"),
            "p" to FieldHints(inputType = 0x81)
        )
        assertEquals(listOf("u" to USERNAME, "p" to PASSWORD), AutofillParser.resolve(items, "Retailer wallet login"))
    }

    @Test fun `username only login step stays fillable when screen says login`() {
        val items = listOf("u" to FieldHints(autofillHints = listOf("username"), hint = "Enter mobile"))
        assertEquals(listOf("u" to USERNAME), AutofillParser.resolve(items, "Customer login pay"))
    }

    @Test fun `real PASSWORD or pin labelled field is not treated as masked phone`() {
        val items = listOf(
            "u" to FieldHints(hint = "Mobile number", inputType = 1),
            "p" to FieldHints(hint = "Mobile password", inputType = 0x81)
        )
        val resolved = AutofillParser.resolve(items, "Recharge")
        assertEquals(PASSWORD, resolved[1].second)
    }
}

/**
 * PASS14 (user report 2026-10-09): OTP box, customer mobile jaise fields par ID/password aa jata tha.
 * Rule: credential sirf login-jaisi form me. OTP/verification box me kabhi ID/password/PIN nahi.
 */
class AutofillParserOtpAndGateTest {
    private val numberPassword = 0x12      // TYPE_CLASS_NUMBER | NUMBER_VARIATION_PASSWORD
    private val textPassword = 0x81

    // --- OTP box ---
    @Test fun `masked numeric box on OTP screen is OTP, never PIN`() {
        val items = listOf("code" to FieldHints(hint = "Enter code", inputType = numberPassword, maxLength = 6))
        assertEquals(listOf("code" to OTP), AutofillParser.resolve(items, "Verify OTP sent to your mobile Resend"))
    }

    @Test fun `masked numeric box alone with no PIN name is not a credential`() {
        val items = listOf("code" to FieldHints(inputType = numberPassword, maxLength = 6))
        assertEquals(listOf("code" to null), AutofillParser.resolve(items, ""))
    }

    @Test fun `explicit PIN or mPIN name stays a PIN even on its own`() {
        val items = listOf("p" to FieldHints(idEntry = "et_mpin", inputType = numberPassword, maxLength = 4))
        assertEquals(listOf("p" to PIN), AutofillParser.resolve(items, ""))
    }

    @Test fun `unlabeled 6 digit numeric box on OTP screen becomes OTP`() {
        val items = listOf("b" to FieldHints(inputType = 2, maxLength = 6))
        assertEquals(listOf("b" to OTP), AutofillParser.resolve(items, "We sent a verification code"))
    }

    @Test fun `unlabeled numeric box on a non OTP screen is ignored`() {
        val items = listOf("b" to FieldHints(inputType = 2, maxLength = 6))
        assertEquals(listOf("b" to null), AutofillParser.resolve(items, "Place order"))
    }

    @Test fun `OTP detected from sibling label and compound ids`() {
        assertEquals(OTP, AutofillParser.classify(FieldHints(label = "Enter OTP", inputType = 2)))
        assertEquals(OTP, AutofillParser.classify(FieldHints(idEntry = "smsotp")))
        assertEquals(OTP, AutofillParser.classify(FieldHints(idEntry = "et_otp_code")))
        assertNull(AutofillParser.classify(FieldHints(idEntry = "footprint_text", inputType = 1)))
    }

    @Test fun `phone box is not mistaken for a code box on OTP screen`() {
        val items = listOf("m" to FieldHints(hint = "Mobile number", inputType = 2, maxLength = 10))
        assertTrue(AutofillParser.resolve(items, "Login with OTP").none { it.second == OTP })
    }

    // --- username gate ---
    @Test fun `generic mobile field on a non login screen gets no username`() {
        val items = listOf("m" to FieldHints(hint = "Mobile number", inputType = 1))
        assertEquals(listOf("m" to null), AutofillParser.resolve(items, "Delivery address Place order"))
    }

    @Test fun `generic mobile field on a login screen is still a username`() {
        val items = listOf("m" to FieldHints(hint = "Mobile number", inputType = 1))
        assertEquals(listOf("m" to USERNAME), AutofillParser.resolve(items, "Login Welcome back"))
    }

    @Test fun `heuristic username next to a password field is kept`() {
        val items = listOf(
            "u" to FieldHints(hint = "Customer ID", inputType = 1),
            "p" to FieldHints(inputType = textPassword)
        )
        assertEquals(listOf("u" to USERNAME, "p" to PASSWORD), AutofillParser.resolve(items, ""))
    }

    @Test fun `explicit username hint is honoured even without login words`() {
        val items = listOf("u" to FieldHints(autofillHints = listOf("username"), inputType = 1))
        assertEquals(listOf("u" to USERNAME), AutofillParser.resolve(items, "Account"))
    }

    @Test fun `username box on an OTP login step does not swallow the OTP box`() {
        val items = listOf(
            "u" to FieldHints(autofillHints = listOf("username"), inputType = 1),
            "o" to FieldHints(inputType = numberPassword, maxLength = 6)
        )
        val r = AutofillParser.resolve(items, "Login verify OTP")
        assertEquals(USERNAME, r[0].second)
        assertEquals(OTP, r[1].second)
    }
}

/** Source-level guards (JVM test me AutofillId nahi bana sakte, isliye static check). */
class AutofillNoCrossTypeFillStaticTest {
    private val factory = java.io.File("src/main/java/pro/babasitaram/vault/autofill/AutofillDatasetFactory.kt").readText()
    private val service = java.io.File("src/main/java/pro/babasitaram/vault/autofill/VaultAutofillService.kt").readText()
    private val model = java.io.File("src/main/java/pro/babasitaram/vault/autofill/model/AutofillField.kt").readText()

    @Test fun `positional fallback (first field gets username, second password) is gone`() {
        assertTrue(!factory.contains("positionalFallback"))
    }

    @Test fun `locked unlock entry uses authFields and service skips credential-less screens`() {
        assertTrue(factory.contains("for (f in parsed.authFields) builder.setValue(f.id, null)"))
        assertTrue(service.contains("parsed.authFields.isEmpty()"))
        assertTrue(model.contains("if (credentialFields.isEmpty()) emptyList() else fillableFields"))
    }

    @Test fun `OTP type never receives a stored username or password`() {
        val e = pro.babasitaram.vault.core.model.VaultEntry(id = "x", title = "x", username = "u", password = "123456", appPin = "1234")
        assertEquals("", AutofillValues.valueFor(pro.babasitaram.vault.autofill.model.AutofillFieldType.OTP, e, 0L))
    }
}
