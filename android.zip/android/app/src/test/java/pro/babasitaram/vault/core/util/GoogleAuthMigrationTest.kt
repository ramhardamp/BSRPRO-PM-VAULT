package pro.babasitaram.vault.core.util

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/** Google Authenticator "Export accounts" QR (otpauth-migration://). Vector: 3 account (2 TOTP + 1 HOTP), batch 1/1. */
class GoogleAuthMigrationTest {
    private val sample = "otpauth-migration://offline?data=" +
        "CjQKCkhlbGxvId6tvu8SGEdvb2dsZTphbGljZUBleGFtcGxlLmNvbRoGR29vZ2xlIAEoATACCikKFDEyMzQ1Njc4OTAxMjM0NTY3ODkwEgNib2IaBkdpdEh1YiACKAIwAgogCgtob3RwLXNlY3JldBIGbGVnYWN5GgNPbGQgASgBMAEQARgBIAAoKg%3D%3D"

    @Test fun `detects migration links only`() {
        assertTrue(GoogleAuthMigration.isMigration(sample))
        assertTrue(GoogleAuthMigration.isMigration("  OTPAUTH-MIGRATION://offline?data=x"))
        assertFalse(GoogleAuthMigration.isMigration("otpauth://totp/a?secret=ABC"))
        assertFalse(GoogleAuthMigration.isMigration("https://example.com"))
    }

    @Test fun `parses TOTP accounts and skips HOTP`() {
        val b = GoogleAuthMigration.parse(sample)!!
        assertEquals(2, b.accounts.size)
        assertEquals(1, b.skipped)
        assertEquals(42, b.batchId)
        assertEquals(1, b.batchSize)
        val g = b.accounts[0]
        assertEquals("JBSWY3DPEHPK3PXP", g.secret)
        assertEquals("Google", g.issuer)
        assertEquals("alice@example.com", g.account)      // "Issuer:" prefix name se hata
        assertEquals("SHA1", g.algorithm)
        assertEquals(6, g.digits)
        val gh = b.accounts[1]
        assertEquals("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", gh.secret)
        assertEquals("GitHub", gh.title)
        assertEquals("SHA256", gh.algorithm)
        assertEquals(8, gh.digits)
    }

    @Test fun `parsed accounts pass the strict TOTP parser`() {
        val b = GoogleAuthMigration.parse(sample)!!
        b.accounts.forEach { a ->
            val uri = Totp.buildUri(a.secret, a.title, a.account, a.algorithm, a.digits, 30)
            assertTrue(Totp.parseStrict(uri, allowBareSecret = false) is TotpParseResult.Ok)
        }
    }

    @Test fun `unencoded padding is tolerated`() {
        val plusForm = sample.replace("%3D%3D", "==")
        assertEquals(2, GoogleAuthMigration.parse(plusForm)!!.accounts.size)
    }

    @Test fun `garbage never throws`() {
        assertNull(GoogleAuthMigration.parse("otpauth-migration://offline"))
        assertNull(GoogleAuthMigration.parse("otpauth-migration://offline?data="))
        assertNull(GoogleAuthMigration.parse("otpauth-migration://offline?data=!!!notbase64!!!"))
        assertNull(GoogleAuthMigration.parse("otpauth-migration://offline?data=AAAA"))
        // truncated protobuf
        assertNull(GoogleAuthMigration.parse(sample.substring(0, sample.length - 60)))
        assertNull(GoogleAuthMigration.parse("https://example.com"))
    }

    @Test fun `base32 encoder matches RFC vectors`() {
        assertEquals("", GoogleAuthMigration.base32Encode(ByteArray(0)))
        assertEquals("MY", GoogleAuthMigration.base32Encode("f".toByteArray()))
        assertEquals("MZXQ", GoogleAuthMigration.base32Encode("fo".toByteArray()))
        assertEquals("MZXW6", GoogleAuthMigration.base32Encode("foo".toByteArray()))
        assertEquals("MZXW6YQ", GoogleAuthMigration.base32Encode("foob".toByteArray()))
        assertEquals("MZXW6YTB", GoogleAuthMigration.base32Encode("fooba".toByteArray()))
        assertEquals("MZXW6YTBOI", GoogleAuthMigration.base32Encode("foobar".toByteArray()))
    }

    @Test fun `collector joins multi QR exports and dedupes repeats`() {
        fun batch(id: Int, idx: Int, size: Int, secret: String) = MigrationBatch(
            listOf(MigrationAccount(secret, "I$idx", "a", "SHA1", 6)), 0, id, idx, size
        )
        val c = MigrationCollector()
        c.add(batch(7, 0, 3, "AAAA"))
        c.add(batch(7, 0, 3, "AAAA"))           // same QR dobara scan
        assertEquals(1, c.received); assertEquals(3, c.expected); assertFalse(c.isComplete)
        c.add(batch(7, 2, 3, "CCCC"))
        c.add(batch(7, 1, 3, "BBBB"))
        assertTrue(c.isComplete)
        assertEquals(listOf("AAAA", "BBBB", "CCCC"), c.accounts.map { it.secret })
        // naya export (alag batchId) => purana reset
        c.add(batch(8, 0, 2, "ZZZZ"))
        assertEquals(1, c.received); assertFalse(c.isComplete)
    }
}
