package pro.babasitaram.vault.core.util

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

/** Spec sec 20-22, 69-70, 88: TOTPParserTest / TOTPValidationTest. Strict parser for NEW input, lenient parse unchanged. */
class TotpStrictParserTest {
    private val secret = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"

    private fun ok(input: String, allowBare: Boolean = true) =
        Totp.parseStrict(input, allowBare) as TotpParseResult.Ok

    private fun invalid(input: String, allowBare: Boolean = true) =
        (Totp.parseStrict(input, allowBare) as TotpParseResult.Invalid).reason

    @Test fun `full uri keeps algorithm digits period issuer and account`() {
        val r = ok("otpauth://totp/Mail:bob%40x.com?secret=$secret&digits=8&period=60&algorithm=SHA256&issuer=Mail")
        assertEquals("SHA256", r.config.algorithm)
        assertEquals(8, r.config.digits)
        assertEquals(60, r.config.periodSeconds)
        assertEquals(secret, r.config.secret)
        assertEquals("Mail", r.issuer)
        assertEquals("bob@x.com", r.account)
    }

    @Test fun `defaults are sha1 six digits thirty seconds`() {
        val c = ok("otpauth://totp/x?secret=$secret").config
        assertEquals("SHA1", c.algorithm); assertEquals(6, c.digits); assertEquals(30, c.periodSeconds)
    }

    @Test fun `sha512 and sha-256 spelling are accepted and canonical`() {
        assertEquals("SHA512", ok("otpauth://totp/x?secret=$secret&algorithm=sha512").config.algorithm)
        assertEquals("SHA256", ok("otpauth://totp/x?secret=$secret&algorithm=SHA-256").config.algorithm)
    }

    @Test fun `hotp is rejected clearly`() {
        assertEquals(TotpInvalidReason.UNSUPPORTED_TYPE, invalid("otpauth://hotp/x?secret=$secret&counter=1"))
    }

    @Test fun `lenient parse no longer returns a totp config for hotp`() {
        assertNull(Totp.parse("otpauth://hotp/x?secret=$secret&counter=1"))
    }

    @Test fun `missing and invalid secret are rejected`() {
        assertEquals(TotpInvalidReason.MISSING_SECRET, invalid("otpauth://totp/x?issuer=A"))
        assertEquals(TotpInvalidReason.INVALID_SECRET, invalid("otpauth://totp/x?secret=not*base32!"))
        assertEquals(TotpInvalidReason.INVALID_SECRET, invalid("1189!"))
    }

    @Test fun `unsupported algorithm digits and period are rejected not defaulted`() {
        assertEquals(TotpInvalidReason.UNSUPPORTED_ALGORITHM, invalid("otpauth://totp/x?secret=$secret&algorithm=MD5"))
        assertEquals(TotpInvalidReason.UNSUPPORTED_DIGITS, invalid("otpauth://totp/x?secret=$secret&digits=7"))
        assertEquals(TotpInvalidReason.UNSUPPORTED_DIGITS, invalid("otpauth://totp/x?secret=$secret&digits=5"))
        assertEquals(TotpInvalidReason.UNSUPPORTED_PERIOD, invalid("otpauth://totp/x?secret=$secret&period=0"))
        assertEquals(TotpInvalidReason.UNSUPPORTED_PERIOD, invalid("otpauth://totp/x?secret=$secret&period=301"))
        assertEquals(TotpInvalidReason.UNSUPPORTED_PERIOD, invalid("otpauth://totp/x?secret=$secret&period=abc"))
    }

    @Test fun `bare secret is normalized and validated`() {
        assertEquals(secret, ok("gezd gnbv-gy3t qojq gezd gnbv gy3t qojq==").config.secret)
        assertEquals(TotpInvalidReason.EMPTY, invalid("   "))
    }

    @Test fun `links only mode rejects a bare secret`() {
        assertEquals(TotpInvalidReason.NOT_OTPAUTH, invalid(secret, allowBare = false))
    }

    @Test fun `explicit issuer parameter wins over the label prefix`() {
        assertEquals("Real", ok("otpauth://totp/Old:me?secret=$secret&issuer=Real").issuer)
        assertEquals("Old", ok("otpauth://totp/Old%3Ame?secret=$secret").issuer)
    }

    @Test fun `duplicate detection ignores case spacing padding and uri wrapping`() {
        val uri = "otpauth://totp/A:me?secret=gezd%20gnbv%20gy3t%20qojq%20gezd%20gnbv%20gy3t%20qojq&issuer=A"
        assertTrue(Totp.sameSecret(uri, secret))
        assertTrue(Totp.sameSecret(secret.lowercase(), "$secret=="))
        assertFalse(Totp.sameSecret(secret, "JBSWY3DPEHPK3PXP"))
        assertFalse(Totp.sameSecret("", secret))
        assertFalse(Totp.sameSecret("not*base32", "not*base32"))
    }

    @Test fun `unknown algorithm gives no code instead of a wrong sha1 code`() {
        assertNull(Totp.generate(TotpConfig(secret, algorithm = "MD5"), 59_000))
        assertNotNull(Totp.generate(TotpConfig(secret, algorithm = "SHA1"), 59_000))
    }

    @Test fun `lenient parse of stored entries is unchanged`() {
        val c = Totp.parse("otpauth://totp/Mail:bob?secret=$secret&digits=8&period=60&algorithm=SHA256")!!
        assertEquals(8, c.digits); assertEquals(60, c.periodSeconds); assertEquals("SHA256", c.algorithm)
        assertEquals("ABC", Totp.parse("ABC")!!.secret)
    }
}
