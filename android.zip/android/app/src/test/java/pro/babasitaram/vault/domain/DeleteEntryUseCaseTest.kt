package pro.babasitaram.vault.domain

import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.coVerifyOrder
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import kotlinx.coroutines.test.runTest
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.data.backup.AutoBackupManager
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase

/** Spec sec 25 / 70 (DeleteEntryTest): delete result is independent of the backup request that follows it. */
class DeleteEntryUseCaseTest {
    private val repo = mockk<VaultRepository>()
    private val backup = mockk<AutoBackupManager>(relaxed = true)

    @Test fun `success commits the delete first and then queues a backup`() = runTest {
        coEvery { repo.softDelete("a") } returns Unit
        val result = DeleteEntryUseCase(repo, backup)("a")
        assertTrue(result is VaultResult.Success)
        coVerifyOrder {
            repo.softDelete("a")
            backup.requestBackup()
        }
    }

    @Test fun `a failing backup request never turns a finished delete into an error`() = runTest {
        coEvery { repo.softDelete("a") } returns Unit
        every { backup.requestBackup() } throws IllegalStateException("prefs broken")
        val result = DeleteEntryUseCase(repo, backup)("a")
        assertTrue(result is VaultResult.Success)
    }

    @Test fun `a failing delete is an error and no backup is requested`() = runTest {
        coEvery { repo.softDelete("a") } throws IllegalStateException("db")
        val result = DeleteEntryUseCase(repo, backup)("a")
        assertTrue(result is VaultResult.Failure)
        verify(exactly = 0) { backup.requestBackup() }
    }
}
