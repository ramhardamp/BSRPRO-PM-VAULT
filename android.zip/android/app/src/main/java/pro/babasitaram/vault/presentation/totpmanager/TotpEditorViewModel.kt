package pro.babasitaram.vault.presentation.totpmanager

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.MigrationAccount
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.core.util.TotpInvalidReason
import pro.babasitaram.vault.core.util.TotpParseResult
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L

@Stable
data class TotpEditorState(
    val title: String = "",
    val username: String = "",
    val secret: String = "",
    val algorithm: String = "SHA1",
    val digits: Int = 6,
    val period: Int = 30,
    val backupCodes: String = "",
    val saving: Boolean = false,
    val saved: Boolean = false,
    val error: String? = null,
    val existing: VaultEntry? = null,
    /** Title of another entry that already uses the same secret (spec sec 88); non-null => confirm dialog is shown. */
    val duplicateTitle: String? = null,
    /** Non-null => "Google Authenticator se N account mile, import karein?" dialog dikhta hai. */
    val migration: MigrationPreview? = null,
    /** Bulk import ke baad kitne account bane (screen Toast ke liye). */
    val importedCount: Int = 0
)

/** Google Authenticator export scan ka summary (secrets state me nahi rakhte, sirf ginti). */
data class MigrationPreview(val total: Int, val fresh: Int, val duplicates: Int, val unsupported: Int)

/** TOTP-only editor: Title, Username, Secret (base32), Algorithm, Digits, Period, Backup codes. */
@HiltViewModel
class TotpEditorViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase
) : ViewModel() {
    private val id = savedStateHandle.get<String>("id").orEmpty()
    private val existing = id.takeIf { it.isNotBlank() }?.let(repository::entry)
    private val parsed = existing?.totp?.let { Totp.parse(it) }

    private val _state = MutableStateFlow(
        TotpEditorState(
            title = existing?.title.orEmpty(),
            username = existing?.username.orEmpty().ifEmpty { existing?.email.orEmpty() },
            secret = parsed?.secret.orEmpty(),
            algorithm = parsed?.algorithm ?: "SHA1",
            digits = parsed?.digits ?: 6,
            period = parsed?.periodSeconds ?: 30,
            backupCodes = existing?.notes.orEmpty(),
            existing = existing
        )
    )
    val state: StateFlow<TotpEditorState> = _state.asStateFlow()

    fun setTitle(v: String) = _state.update { it.copy(title = v, error = null) }
    fun setUsername(v: String) = _state.update { it.copy(username = v, error = null) }
    /**
     * Secret box accepts a bare secret OR a pasted otpauth:// link. A link is parsed strictly and its algorithm,
     * digits and period are applied too (before: only the secret was kept, so SHA256 / 8-digit / 60s links gave wrong codes).
     */
    fun setSecret(v: String) {
        if (v.trim().startsWith("otpauth://", ignoreCase = true)) {
            when (val r = Totp.parseStrict(v, allowBareSecret = false)) {
                is TotpParseResult.Ok -> _state.update { cur ->
                    cur.copy(
                        secret = r.config.secret,
                        algorithm = r.config.algorithm,
                        digits = r.config.digits,
                        period = r.config.periodSeconds,
                        title = cur.title.ifBlank { r.issuer },
                        username = cur.username.ifBlank { r.account },
                        error = null,
                        duplicateTitle = null
                    )
                }
                is TotpParseResult.Invalid -> _state.update { it.copy(secret = v, error = messageFor(r.reason), duplicateTitle = null) }
            }
        } else {
            _state.update { it.copy(secret = v, error = null, duplicateTitle = null) }
        }
    }

    private fun messageFor(reason: TotpInvalidReason): String = L.s(
        when (reason) {
            TotpInvalidReason.UNSUPPORTED_TYPE -> R.string.p21_totp_err_hotp
            TotpInvalidReason.UNSUPPORTED_ALGORITHM -> R.string.p21_totp_err_algorithm
            TotpInvalidReason.UNSUPPORTED_DIGITS -> R.string.p21_totp_err_digits
            TotpInvalidReason.UNSUPPORTED_PERIOD -> R.string.p21_totp_err_period
            else -> R.string.p18_totp_editor_secret_must_be_a_valid
        }
    )

    // ───────────── Google Authenticator "Export accounts" QR ─────────────
    // Secrets sirf is private list me rehte hain (state/log me nahi); user ke Import dabane par hi vault me jaate hain.
    private var pendingMigration: List<MigrationAccount> = emptyList()

    /** Scanner se saare accounts aa gaye: duplicates (same secret) alag karke preview dikhao. Abhi kuch save nahi hota. */
    fun onMigrationScanned(accounts: List<MigrationAccount>, unsupported: Int) {
        val stored = repository.entries.value.filter { it.deletedAt == 0L && it.totp.isNotBlank() }
        val fresh = ArrayList<MigrationAccount>()
        var duplicates = 0
        for (a in accounts) {
            val dup = stored.any { Totp.sameSecret(it.totp, a.secret) } || fresh.any { Totp.sameSecret(it.secret, a.secret) }
            if (dup) duplicates++ else fresh.add(a)
        }
        pendingMigration = fresh
        _state.update { it.copy(migration = MigrationPreview(accounts.size, fresh.size, duplicates, unsupported), error = null) }
    }

    fun dismissMigration() {
        pendingMigration = emptyList()
        _state.update { it.copy(migration = null) }
    }

    /** User ne Import dabaya: saare naye accounts ek hi write me (background thread, UI freeze nahi). */
    fun confirmMigration() {
        val list = pendingMigration
        if (list.isEmpty()) { dismissMigration(); return }
        launchCatching {
            _state.update { it.copy(saving = true, migration = null, error = null) }
            val entries = list.map { a ->
                VaultEntry().copy(
                    title = a.title.trim().ifBlank { "2FA" },
                    username = a.account.trim(),
                    totp = Totp.buildUri(a.secret, a.title.trim(), a.account.trim(), a.algorithm, a.digits, 30),
                    recordType = "totp",
                    isNote = false
                )
            }
            when (val r = saveEntry.saveAll(entries)) {
                is VaultResult.Success -> {
                    pendingMigration = emptyList()
                    _state.update { it.copy(saving = false, saved = true, importedCount = r.value) }
                }
                is VaultResult.Failure -> _state.update { it.copy(saving = false, error = r.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }

    fun dismissDuplicate() = _state.update { it.copy(duplicateTitle = null) }
    fun setAlgorithm(v: String) = _state.update { it.copy(algorithm = v) }
    fun setDigits(v: Int) = _state.update { it.copy(digits = v) }
    fun setPeriod(v: Int) = _state.update { it.copy(period = v) }
    fun setBackupCodes(v: String) = _state.update { it.copy(backupCodes = v) }

    fun save() = doSave(confirmedDuplicate = false)

    /** User saw the "may already exist" dialog and chose to save anyway. */
    fun saveDespiteDuplicate() = doSave(confirmedDuplicate = true)

    private fun doSave(confirmedDuplicate: Boolean) {
        val s = _state.value
        if (s.title.isBlank()) { _state.update { it.copy(error = L.s(R.string.p18_totp_editor_enter_a_service_name)) }; return }
        // Strict validation of the secret box (bare secret or link). Invalid input is rejected, never guessed.
        val cleanSecret = when (val r = Totp.parseStrict(s.secret, allowBareSecret = true)) {
            is TotpParseResult.Ok -> r.config.secret
            is TotpParseResult.Invalid -> { _state.update { it.copy(error = messageFor(r.reason)) }; return }
        }
        if (!confirmedDuplicate) {
            val dup = repository.entries.value.firstOrNull { e ->
                e.id != s.existing?.id && e.deletedAt == 0L && e.totp.isNotBlank() && Totp.sameSecret(e.totp, cleanSecret)
            }
            if (dup != null) {
                _state.update { it.copy(duplicateTitle = dup.title.ifBlank { dup.username }) }
                return
            }
        }
        launchCatching {
            _state.update { it.copy(saving = true, error = null, duplicateTitle = null) }
            val uri = Totp.buildUri(cleanSecret, s.title.trim(), s.username.trim(), s.algorithm, s.digits, s.period)
            val entry = (s.existing ?: VaultEntry()).copy(
                title = s.title.trim(),
                username = s.username.trim(),
                totp = uri,
                notes = s.backupCodes,
                recordType = "totp",
                isNote = false
            )
            when (val r = saveEntry(entry, s.existing)) {
                is VaultResult.Success -> _state.update { it.copy(saving = false, saved = true) }
                is VaultResult.Failure -> _state.update { it.copy(saving = false, error = r.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }
}
