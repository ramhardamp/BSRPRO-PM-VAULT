// file: app/src/main/java/pro/babasitaram/vault/presentation/totpmanager/QrScannerOverlay.kt
package pro.babasitaram.vault.presentation.totpmanager

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.ReaderException
import com.google.zxing.common.HybridBinarizer
import com.google.zxing.qrcode.QRCodeReader
import android.os.Handler
import android.os.Looper
import android.util.Size
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.delay
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.GoogleAuthMigration
import pro.babasitaram.vault.core.util.MigrationAccount
import pro.babasitaram.vault.core.util.MigrationCollector

/**
 * Full-screen TOTP QR scanner (audit A-10).
 *
 * CameraX (preview + analysis) -> ZXing `QRCodeReader` (already in the app for QR generation), QR only, fully offline. On the first `otpauth://` QR the raw text is
 * handed to [onResult] ONCE and the caller closes the overlay; the caller then runs it through the existing strict
 * parser (`TotpEditorViewModel.setSecret` -> `Totp.parseStrict`), so HOTP / bad algorithm / bad digits are rejected
 * there with the normal messages.
 *
 * Google Authenticator "Export accounts" QR (`otpauth-migration://`) bhi chalta hai: saare accounts ek (ya kai) QR me aate
 * hain. Multi-QR export me progress dikhta hai ("QR 1 / 3") aur sab QR milte hi [onMigration] ek baar chalta hai.
 * [onMigration]=null ho to migration QR purane tareeke se "not 2FA" maana jata hai.
 *
 * Privacy rules (spec sec 21): no frame is saved, no QR text or secret is logged, nothing is stored until the user
 * presses Save in the editor. The overlay sits inside MainActivity's window, so FLAG_SECURE stays in force.
 */
@Composable
fun QrScannerOverlay(
    onResult: (String) -> Unit,
    onClose: () -> Unit,
    onMigration: ((accounts: List<MigrationAccount>, unsupported: Int) -> Unit)? = null
) {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(context.hasCameraPermission()) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
    }
    // rememberSaveable: do not re-prompt on every rotation / process-return once the system dialog was shown.
    var asked by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (!hasPermission && !asked) {
            asked = true
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Coming back from app settings with the permission just granted.
    androidx.lifecycle.compose.LifecycleResumeEffect(Unit) {
        hasPermission = context.hasCameraPermission()
        onPauseOrDispose { }
    }

    BackHandler(onBack = onClose)

    val collector = remember { MigrationCollector() }
    var migrationProgress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var migrationDelivered by remember { mutableStateOf(false) }
    var wrongQr by remember { mutableStateOf(false) }
    val currentOnMigration by rememberUpdatedState(onMigration)
    val handleMigrationText: (String) -> Unit = { text ->
        val batch = GoogleAuthMigration.parse(text)
        if (batch == null) {
            wrongQr = true
        } else {
            collector.add(batch)
            migrationProgress = collector.received to collector.expected
            if (collector.isComplete && !migrationDelivered) {
                migrationDelivered = true
                currentOnMigration?.invoke(collector.accounts, collector.skipped)
            }
        }
    }
    LaunchedEffect(wrongQr) {
        if (wrongQr) {
            delay(2_500)
            wrongQr = false
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Color.Black, contentColor = Color.White) {
        Box(Modifier.fillMaxSize()) {
            if (hasPermission) {
                ScannerCamera(
                    onResult = onResult,
                    onWrongQr = { wrongQr = true },
                    acceptMigration = onMigration != null,
                    onMigrationText = handleMigrationText
                )
                // Viewfinder frame (decorative; the whole preview is analysed).
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .size(260.dp)
                        .border(BorderStroke(3.dp, Color.White.copy(alpha = 0.85f)), RoundedCornerShape(20.dp))
                )
            } else {
                PermissionNeeded(
                    onAllow = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                    onOpenSettings = { context.openAppSettings() }
                )
            }

            Row(
                Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = stringResource(R.string.totp_scan_close), tint = Color.White)
                }
                Text(stringResource(R.string.totp_scan_title), style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
            }

            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (wrongQr) {
                    Text(
                        stringResource(R.string.totp_scan_not_2fa),
                        color = Color(0xFFFFB4AB),
                        textAlign = TextAlign.Center
                    )
                }
                migrationProgress?.let { (got, total) ->
                    if (!migrationDelivered) {
                        Text(
                            stringResource(R.string.totp_scan_migration_progress, got, total),
                            textAlign = TextAlign.Center,
                            style = androidx.compose.material3.MaterialTheme.typography.titleMedium
                        )
                    }
                }
                Text(stringResource(R.string.totp_scan_hint), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun PermissionNeeded(onAllow: () -> Unit, onOpenSettings: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(stringResource(R.string.totp_scan_permission_needed), textAlign = TextAlign.Center)
        Column(Modifier.padding(top = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Button(onClick = onAllow) { Text(stringResource(R.string.totp_scan_allow)) }
            // After "Don't ask again" the system dialog no longer appears; app settings is the only way back.
            OutlinedButton(onClick = onOpenSettings) { Text(stringResource(R.string.totp_scan_open_settings)) }
        }
    }
}

@Composable
private fun ScannerCamera(
    onResult: (String) -> Unit,
    onWrongQr: () -> Unit,
    acceptMigration: Boolean,
    onMigrationText: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnResult by rememberUpdatedState(onResult)
    val currentOnWrongQr by rememberUpdatedState(onWrongQr)
    val currentOnMigrationText by rememberUpdatedState(onMigrationText)
    var cameraFailed by remember { mutableStateOf(false) }

    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }

    DisposableEffect(lifecycleOwner) {
        val analysisExecutor: ExecutorService = Executors.newSingleThreadExecutor()
        val analyzer = OtpauthQrAnalyzer(
            acceptMigration = acceptMigration,
            onFound = { text -> currentOnResult(text) },
            onMigration = { text -> currentOnMigrationText(text) },
            onWrongQr = { currentOnWrongQr() }
        )
        // 720p: the 640x480 default is too coarse for dense TOTP QR codes.
        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(1280, 720), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    )
                    .build()
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { it.setAnalyzer(analysisExecutor, analyzer) }

        val providerFuture = ProcessCameraProvider.getInstance(context)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                provider.unbindAll()
                provider.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                // Deliberately no message/stack of the scan content; only the fact that the camera failed.
                cameraFailed = true
            }
        }, ContextCompat.getMainExecutor(context))

        onDispose {
            analysis.clearAnalyzer()
            if (providerFuture.isDone) runCatching { providerFuture.get().unbindAll() }
            analysisExecutor.shutdown()
        }
    }

    AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())
    if (cameraFailed) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(stringResource(R.string.totp_scan_camera_error), textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
        }
    }
}

/**
 * Decodes camera frames with ZXing. QR codes are rotation-invariant, so the luminance (Y) plane is used as-is. The first
 * `otpauth://` QR wins ([done] makes it one-shot); any other QR only raises [onWrongQr] so the user sees a hint.
 * Runs on the analysis thread; results are posted to the main thread. The QR text is never logged.
 */
private class OtpauthQrAnalyzer(
    private val acceptMigration: Boolean,
    private val onFound: (String) -> Unit,
    private val onMigration: (String) -> Unit,
    private val onWrongQr: () -> Unit
) : ImageAnalysis.Analyzer {
    private val done = AtomicBoolean(false)
    // Migration QR ek se zyada baar chalta hai (multi-QR export); har alag QR text sirf ek baar bheja jata hai.
    // Sirf analysis thread se touch hota hai. Text kabhi log nahi hota.
    private val seenMigration = HashSet<String>()
    private val main = Handler(Looper.getMainLooper())
    private val reader = QRCodeReader()
    private val hints = mapOf(
        DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
        DecodeHintType.TRY_HARDER to true
    )

    override fun analyze(imageProxy: ImageProxy) {
        try {
            if (done.get()) return
            val plane = imageProxy.planes.firstOrNull() ?: return
            val width = imageProxy.width
            val height = imageProxy.height
            val rowStride = plane.rowStride
            val buffer = plane.buffer
            // Copy the Y plane into a tight width*height array (rowStride may include padding).
            val luma = ByteArray(width * height)
            val row = ByteArray(rowStride)
            for (y in 0 until height) {
                val start = y * rowStride
                if (start >= buffer.limit()) break
                buffer.position(start)
                val n = minOf(rowStride, buffer.remaining())
                buffer.get(row, 0, n)
                System.arraycopy(row, 0, luma, y * width, minOf(width, n))
            }
            val source = PlanarYUVLuminanceSource(luma, width, height, 0, 0, width, height, false)
            val text = decode(source) ?: decode(source.invert()) // second try: light-on-dark QR (dark-mode screens)
            if (text != null) {
                if (text.startsWith("otpauth://", ignoreCase = true)) {
                    if (done.compareAndSet(false, true)) main.post { onFound(text.trim()) }
                } else if (acceptMigration && GoogleAuthMigration.isMigration(text)) {
                    val t = text.trim()
                    if (seenMigration.add(t)) main.post { onMigration(t) }
                } else {
                    main.post { onWrongQr() }
                }
            }
        } catch (e: Exception) {
            // A bad frame must never crash the scanner; the next frame is tried.
        } finally {
            imageProxy.close() // always release the frame
        }
    }

    private fun decode(source: com.google.zxing.LuminanceSource): String? = try {
        reader.decode(BinaryBitmap(HybridBinarizer(source)), hints).text?.takeIf { it.isNotBlank() }
    } catch (e: ReaderException) {
        null
    } finally {
        reader.reset()
    }
}

private fun Context.hasCameraPermission(): Boolean =
    ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

private fun Context.openAppSettings() {
    runCatching {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
