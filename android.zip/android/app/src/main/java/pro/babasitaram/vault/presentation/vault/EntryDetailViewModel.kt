package pro.babasitaram.vault.presentation.vault

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L
import pro.babasitaram.vault.core.util.TotpCode
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.domain.usecase.GenerateTotpCodeUseCase
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class EntryDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val deleteEntry: DeleteEntryUseCase,
    private val totpUseCase: GenerateTotpCodeUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {

    val id: String = savedStateHandle.get<String>("id").orEmpty()

    val entry: StateFlow<VaultEntry?> = repository.entries
        .map { list -> list.firstOrNull { it.id == id } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), repository.entry(id))

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun totp(secret: String, nowMs: Long): TotpCode? = totpUseCase(secret, nowMs)

    fun copy(label: String, text: String) {
        launchCatching { _messages.send(clipboard.copy(text, label)) }
    }

    fun toggleStar() {
        val e = entry.value ?: return
        launchCatching { saveEntry(e.copy(starred = !e.starred), existing = e) }
    }

    private val _events = Channel<EntryDetailEvent>(Channel.BUFFERED)
    val events: Flow<EntryDetailEvent> = _events.receiveAsFlow()
    private var deleting = false

    /**
     * Soft-delete. Success => ONE [EntryDetailEvent.Deleted] (the UI navigates back once). A second tap while a delete
     * is running is ignored, so the screen can never be popped twice. Backup is requested after the delete has been
     * reported (see DeleteEntryUseCase) and can no longer turn a finished delete into an error.
     */
    fun delete() {
        if (deleting) return
        deleting = true
        launchCatching {
            var done = false
            try {
                when (deleteEntry(id)) {
                    is VaultResult.Success -> { done = true; _events.send(EntryDetailEvent.Deleted) }
                    is VaultResult.Failure -> _events.send(EntryDetailEvent.Error(L.s(R.string.p20_could_not_delete)))
                    VaultResult.Loading -> Unit
                }
            } finally {
                if (!done) deleting = false
            }
        }
    }
}
