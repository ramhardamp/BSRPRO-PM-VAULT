package pro.babasitaram.vault.presentation.totpmanager

import pro.babasitaram.vault.core.util.L
import pro.babasitaram.vault.R
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.DeleteEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions
import pro.babasitaram.vault.presentation.vault.EntryDetailEvent
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class TotpDetailViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    repository: VaultRepository,
    private val deleteEntry: DeleteEntryUseCase,
    private val clipboard: ClipboardActions
) : ViewModel() {
    val id: String = savedStateHandle.get<String>("id").orEmpty()
    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    /** Live entry (null once deleted) so edits made in the editor show up immediately. */
    val entry: StateFlow<VaultEntry?> = repository.entries
        .map { list -> list.firstOrNull { it.id == id && it.deletedAt == 0L } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), repository.entry(id))

    fun copy(text: String, label: String) {
        launchCatching { _messages.send(clipboard.copy(text, label)) }
    }

    private val _events = Channel<EntryDetailEvent>(Channel.BUFFERED)
    val events: Flow<EntryDetailEvent> = _events.receiveAsFlow()
    private var deleting = false

    /** Same contract as EntryDetailViewModel.delete(): one Deleted event, double-tap ignored, no raw error text. */
    fun delete() {
        if (deleting) return
        deleting = true
        launchCatching {
            var done = false
            try {
                when (deleteEntry(id)) {
                    is VaultResult.Success -> {
                        done = true
                        _messages.send(L.s(R.string.p20_moved_to_bin))
                        _events.send(EntryDetailEvent.Deleted)
                    }
                    is VaultResult.Failure -> _events.send(EntryDetailEvent.Error(L.s(R.string.p20_could_not_delete)))
                    VaultResult.Loading -> Unit
                }
            } finally {
                if (!done) deleting = false
            }
        }
    }
}
