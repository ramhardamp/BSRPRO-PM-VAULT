package pro.babasitaram.vault.autofill

import android.app.assist.AssistStructure
import android.os.Build
import android.view.View
import android.view.autofill.AutofillId
import pro.babasitaram.vault.autofill.model.AutofillField
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.FieldHints
import pro.babasitaram.vault.autofill.model.ParsedStructure
import androidx.compose.foundation.lazy.*

/** Turns an AssistStructure into classified username / password / OTP fields. */
object AutofillParser {
    private const val MAX_DEPTH = 120   // Compose / web trees can be deep
    private const val MAX_FIELDS = 120
    private const val MAX_LABEL = 60      // field label ki max length (lamba paragraph label nahi hota)

    // View.AUTOFILL_HINT_* values (some constants are newer than minSdk 26, so the literals are used)
    private val USERNAME_HINTS = setOf("username", "newusername", "emailaddress", "email")
    private const val HINT_PASSWORD = "password"
    private const val HINT_NEW_PASSWORD = "newpassword"
    private val OTP_HINTS = setOf("smsotpcode", "otp", "onetimecode")

    private val OTP_TOKENS = setOf("otp", "totp", "mfa", "2fa", "tfa", "onetime")
    private val OTP_JOINED = listOf("onetime", "verificationcode", "authenticatorcode", "authcode", "twofactor", "2stepcode")
    private val PASSWORD_TOKENS = setOf("password", "passwd", "pwd")
    private val NEW_TOKENS = setOf("new", "confirm", "repeat", "retype", "create", "again", "reenter")
    private val USERNAME_TOKENS = setOf("username", "userid", "login", "loginid", "email", "mail", "phone", "mobile", "mobileno", "user", "uid", "customer", "cust", "employee", "emp", "member", "agent", "retailer")
    // Transaction/customer forms must never be treated as login forms. These labels are
    // common in recharge, billing, POS and payment apps. In particular, a field such as
    // "Customer mobile number" must not receive the saved username, and its confirmation
    // field must not receive the saved password.
    private val NON_CREDENTIAL_PHRASES = setOf(
        "customer mobile", "customer phone", "customer number",
        "confirm mobile", "confirm phone", "confirm customer mobile",
        "recipient mobile", "recipient phone", "beneficiary mobile", "beneficiary phone",
        "receiver mobile", "receiver phone", "contact mobile", "contact phone",
        "alternate mobile", "alternate phone"
    )

    // android.text.InputType (literal values keep this object JVM-testable)
    private const val CLASS_MASK = 0xf
    private const val VARIATION_MASK = 0xff0
    private const val CLASS_TEXT = 0x1
    private const val CLASS_NUMBER = 0x2
    private const val TEXT_PASSWORD = 0x80
    private const val TEXT_VISIBLE_PASSWORD = 0x90
    private const val TEXT_WEB_PASSWORD = 0xe0
    private const val TEXT_EMAIL = 0x20
    private const val TEXT_WEB_EMAIL = 0xd0
    private const val NUMBER_PASSWORD = 0x10
    private const val FLAG_MULTI_LINE = 0x20000

    // ───────────────────────── framework entry point ─────────────────────────

    private class RawNode(val id: AutofillId, val focused: Boolean, val value: String?)

    private class Collector {
        val items = ArrayList<Pair<RawNode, FieldHints>>()
        val contextText = ArrayList<String>()
        var domain: String? = null
        var scheme: String? = null
    }

    fun parse(structure: AssistStructure): ParsedStructure? {
        val packageName = structure.activityComponent?.packageName ?: return null
        val collector = Collector()
        for (i in 0 until structure.windowNodeCount) {
            walk(structure.getWindowNodeAt(i).rootViewNode, collector, 0)
        }
        val fields = resolve(collector.items, collector.contextText.joinToString(" ")).mapNotNull { (raw, type) ->
            if (type == null) null else AutofillField(raw.id, type, raw.focused, raw.value)
        }
        return ParsedStructure(
            packageName = packageName,
            webDomain = collector.domain?.trim()?.lowercase()?.takeIf { it.isNotEmpty() },
            webScheme = collector.scheme?.trim()?.lowercase()?.takeIf { it.isNotEmpty() },
            fields = fields
        )
    }

    /** Input-like node = EditText / web input. Uska node.text user ki typed value hoti hai, label nahi. */
    private fun isInputLike(node: AssistStructure.ViewNode): Boolean =
        node.autofillType == View.AUTOFILL_TYPE_TEXT ||
            !node.autofillHints.isNullOrEmpty() ||
            (node.autofillType == View.AUTOFILL_TYPE_NONE && node.inputType != 0)

    /** Leaf TextView ka chhota visible text = agle input ka label ban sakta hai ("Mobile number", "Enter OTP"). */
    private fun labelText(node: AssistStructure.ViewNode): String? {
        if (isInputLike(node) || node.childCount > 0) return null
        if (node.visibility != View.VISIBLE || node.alpha < 0.1f) return null
        return node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() && it.length <= MAX_LABEL }
    }

    private fun walk(node: AssistStructure.ViewNode, c: Collector, depth: Int, labelBefore: String? = null) {
        if (depth > MAX_DEPTH || c.items.size >= MAX_FIELDS) return
        if (c.domain == null) {
            val d = node.webDomain
            if (!d.isNullOrBlank()) {
                c.domain = d
                c.scheme = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) node.webScheme else null
            }
        }
        val inputLike = isInputLike(node)
        // Collect visible screen-level labels too. Native POS/recharge apps often put
        // the transaction title in a sibling TextView rather than the input hint itself.
        // This lets the classifier distinguish a recharge/mobile-number form from a login form.
        // Input field ka apna text (user ne jo type kiya) context me nahi jaata.
        if (node.visibility == View.VISIBLE && node.alpha >= 0.1f) {
            if (!inputLike) node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() && it.length <= 120 }?.let { c.contextText.add(it) }
            node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() && it.length <= 120 }?.let { c.contextText.add(it) }
        }
        val id = node.autofillId
        val textual = inputLike
        // Security: invisible / ~transparent / 1px field (phishing honeypot) me kabhi autofill nahi.
        val reallyVisible = node.visibility == View.VISIBLE && node.alpha >= 0.1f && node.width >= 2 && node.height >= 2
        if (id != null && textual && reallyVisible) {
            val attrs = HashMap<String, String>()
            node.htmlInfo?.attributes?.forEach { p ->
                val k = p.first
                val v = p.second
                if (k != null && v != null) attrs[k.lowercase()] = v
            }
            val ownDescription = node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() && it.length <= MAX_LABEL }
            val hints = FieldHints(
                autofillHints = node.autofillHints?.toList().orEmpty(),
                idEntry = node.idEntry,
                hint = node.hint,
                inputType = node.inputType,
                htmlType = attrs["type"],
                htmlName = attrs["name"],
                htmlId = attrs["id"],
                htmlAutocomplete = attrs["autocomplete"],
                htmlPlaceholder = attrs["placeholder"],
                maxLength = node.maxTextLength,
                label = listOfNotNull(ownDescription, labelBefore).joinToString(" ").takeIf { it.isNotBlank() }
            )
            val value = node.autofillValue?.takeIf { it.isText }?.textValue?.toString()
            c.items.add(RawNode(id, node.isFocused, value) to hints)
        }
        // Sibling label tracking: text-only sibling ke turant baad aane wale input ko wahi label milta hai.
        var lastLabel: String? = null
        for (i in 0 until node.childCount) {
            val child = node.getChildAt(i)
            walk(child, c, depth + 1, lastLabel)
            lastLabel = if (isInputLike(child)) null else (labelText(child) ?: lastLabel)
        }
    }

    // ───────────────────────── pure classification ─────────────────────────

    /**
     * Classifies every item, then applies the safety gates (BSRPRO "kahan autofill NAHI karna" rules).
     *
     * Google Password Manager jaisa principle: credential sirf tab jab form sach me login form ho.
     *  1. OTP / verification-code box: kabhi ID, password ya PIN nahi (sirf TOTP, agar entry me ho).
     *  2. Weak PIN (sirf numeric-masked inputType, naam me pin/mpin nahi): sirf login-jaisi screen par PIN,
     *     OTP-jaisi screen par OTP, baaki jagah kuch nahi.
     *  3. Heuristic username (mobile/customer/phone/email jaise shabd): sirf tab jab saath me password/PIN
     *     field ho ya screen login jaisi ho. Explicit app hint (autofillHints=username) pe ye gate nahi.
     *  4. Transaction (recharge/POS/payment) screen = login nahi.
     */
    fun <T> resolve(items: List<Pair<T, FieldHints>>, screenContext: String = ""): List<Pair<T, AutofillFieldType?>> {
        val transactionForm = isTransactionContext(screenContext) || items.any { isTransactionContext(Words.of(it.second).joined) }
        val otpScreen = screenSaysOtp(screenContext)
        val loginEvidence = looksLikeLoginScreen(screenContext) ||
            items.any { item -> Words.of(item.second).tokens.any { it in LOGIN_FIELD_TOKENS } }
        val types = items.map { item ->
            val h = item.second          // items Pair<T, FieldHints> hain; classify/Words ko FieldHints chahiye (compile fix)
            val words = Words.of(h)
            val classified = classify(h)
            // A generic mobile/phone field on a recharge/payment/customer form is data entry,
            // not a credential. Keep explicit password/OTP/PIN fields usable, but never invent
            // a username/password mapping for the transaction phone number.
            if (transactionForm && isGenericTransactionContact(words, h) &&
                classified == AutofillFieldType.USERNAME) null
            // Masked phone confirmation (numberPassword inputType + "mobile/phone" label) PIN/PASSWORD
            // ban jata tha aur poori recharge screen "login form" lagti thi. Ab ye bhi ignore.
            else if (transactionForm && isMaskedPhoneEntry(words, h, classified)) null
            else classified
        }.toMutableList()

        // Gate 2: weak PIN. OTP box aksar numeric-masked hota hai (inputType numberPassword) bina "pin" naam ke;
        // use PIN maan kar saved password/PIN bhar dena hi "OTP ki jagah ID/password" wala bug tha.
        val hasPasswordField = types.any { it == AutofillFieldType.PASSWORD }
        for (i in types.indices) {
            if (types[i] != AutofillFieldType.PIN || !isWeakPin(items[i].second)) continue
            val textFieldBefore = (0 until i).any { j ->
                types[j] == AutofillFieldType.USERNAME ||
                    (types[j] == null && isPlainText(items[j].second) && !isNonCredentialField(Words.of(items[j].second)))
            }
            types[i] = when {
                otpScreen && !hasPasswordField -> AutofillFieldType.OTP
                otpScreen -> null
                loginEvidence || textFieldBefore -> AutofillFieldType.PIN
                else -> null
            }
        }
        // Gate 1b: OTP screen par bina label wala numeric 4-8 digit box bhi OTP hai (kuch bhi fill nahi hoga).
        if (otpScreen) {
            for (i in types.indices) {
                if (types[i] == null && isUnlabeledCodeBox(items[i].second)) types[i] = AutofillFieldType.OTP
            }
        }
        // Phase 19 (Fix: post-login recharge/POS screen par suggestion): transaction screen jis par koi
        // password/PIN field nahi hai woh login nahi ho sakti. Is case me explicit "username" hint wala field
        // bhi ignore hota hai (app aksar phone-number widget me galat hint laga deta hai).
        // Login screen (login/sign in/password jaise words) ko is rule se bahar rakha hai => normal login unchanged.
        if (transactionForm && !looksLikeLoginScreen(screenContext) &&
            types.none { it == AutofillFieldType.PASSWORD || it == AutofillFieldType.PIN || it == AutofillFieldType.NEW_PASSWORD }
        ) {
            for (i in types.indices) if (types[i] == AutofillFieldType.USERNAME) types[i] = null
        }
        // Gate 3: heuristic username ko login-jaisi form chahiye (password/PIN saath me ya login evidence).
        val hasSecret = types.any { it == AutofillFieldType.PASSWORD || it == AutofillFieldType.PIN || it == AutofillFieldType.NEW_PASSWORD }
        for (i in types.indices) {
            if (types[i] != AutofillFieldType.USERNAME) continue
            if (hasExplicitUsernameSignal(items[i].second)) continue
            if (hasSecret || (loginEvidence && !transactionForm)) continue
            types[i] = null
        }
        val hasUsername = types.any { it == AutofillFieldType.USERNAME }
        val firstPassword = types.indexOfFirst { it == AutofillFieldType.PASSWORD || it == AutofillFieldType.PIN || it == AutofillFieldType.NEW_PASSWORD }
        if (!hasUsername && firstPassword > 0) {
            for (i in firstPassword - 1 downTo 0) {
                val hints = items[i].second
                // Never turn customer/recipient/confirmation fields into a synthetic username.
                if (types[i] == null && isPlainText(hints) && !isNonCredentialField(Words.of(hints))) {
                    types[i] = AutofillFieldType.USERNAME
                    break
                }
            }
        }
        return items.mapIndexed { i, item -> item.first to types[i] }
    }

    fun classify(h: FieldHints): AutofillFieldType? {
        val earlyWords = Words.of(h)
        val earlyAutocomplete = h.htmlAutocomplete?.lowercase()?.split(' ', '\t')?.filter { it.isNotEmpty() }.orEmpty()
        // Transaction/customer fields are a hard deny. Some native POS/recharge apps
        // expose a phone field with a password inputType (masked confirmation) or even
        // an incorrect credential hint. We must not release a saved username/password
        // into such a field merely because the widget metadata is ambiguous.
        if (isNonCredentialField(earlyWords)) return null
        if (h.autofillHints.any { it.equals(HINT_NEW_PASSWORD, true) } || "new-password" in earlyAutocomplete) {
            return AutofillFieldType.NEW_PASSWORD
        }
        if (h.autofillHints.any { it.lowercase() in OTP_HINTS } ||
            "one-time-code" in earlyAutocomplete || isOtp(earlyWords)) return AutofillFieldType.OTP
        // Many apps leave maxLength unset (-1/0), so an unset limit must not hide a PIN field. A long numeric
        // "password" (more than 8 digits) is a real password, not a PIN.
        val pinLength = h.maxLength <= 0 || h.maxLength in 4..8
        val earlyNumericPassword = (h.inputType and CLASS_MASK) == CLASS_NUMBER &&
            (h.inputType and VARIATION_MASK) == NUMBER_PASSWORD && pinLength
        val earlyPinHint = h.autofillHints.any { it.equals("pin", true) || it.equals("mpin", true) }
        val earlyPinNamed = earlyPinHint || isPinNamed(earlyWords)
        val pinShaped = earlyNumericPassword || (earlyPinNamed && (h.maxLength <= 0 || h.maxLength in 4..6))
        if (pinShaped && earlyWords.tokens.any { it in NEW_TOKENS }) {
            return AutofillFieldType.NEW_PASSWORD
        }
        if (pinShaped) return AutofillFieldType.PIN
        // 1. explicit autofill hints
        for (raw in h.autofillHints) {
            val hint = raw.lowercase()
            when {
                hint == HINT_PASSWORD -> return AutofillFieldType.PASSWORD
                hint == HINT_NEW_PASSWORD -> return AutofillFieldType.NEW_PASSWORD
                hint in OTP_HINTS -> return AutofillFieldType.OTP
                hint in USERNAME_HINTS -> return AutofillFieldType.USERNAME
            }
        }
        // 2. HTML autocomplete attribute (Chrome / WebView)
        val ac = h.htmlAutocomplete?.lowercase()?.split(' ', '\t')?.filter { it.isNotEmpty() }.orEmpty()
        when {
            "one-time-code" in ac -> return AutofillFieldType.OTP
            "new-password" in ac -> return AutofillFieldType.NEW_PASSWORD
            "current-password" in ac -> return AutofillFieldType.PASSWORD
            "username" in ac || "email" in ac -> return AutofillFieldType.USERNAME
        }
        // 3. keywords, input type, html type
        val words = Words.of(h)
        if (isOtp(words)) return AutofillFieldType.OTP
        val htmlType = h.htmlType?.lowercase()
        if (isPasswordInput(h.inputType) || htmlType == "password" || words.tokens.any { it in PASSWORD_TOKENS }) {
            return if (words.tokens.any { it in NEW_TOKENS }) AutofillFieldType.NEW_PASSWORD else AutofillFieldType.PASSWORD
        }
        if (htmlType == "email" || isEmailInput(h.inputType)) return AutofillFieldType.USERNAME
        if (words.tokens.any { it in USERNAME_TOKENS }) return AutofillFieldType.USERNAME
        return null
    }


    private fun isTransactionContext(text: String): Boolean {
        val normalized = text.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        if (normalized.isEmpty()) return false
        val tokens = normalized.split(" ").filter { it.isNotEmpty() }.toSet()
        return tokens.any { it in TRANSACTION_TOKENS }
    }

    // Words jo sirf login ke BAAD wali (logged-in) transaction screens par aate hain.
    private val TRANSACTION_TOKENS = setOf(
        "recharge", "recharging", "bill", "billing", "payment", "pay", "wallet",
        "balance", "beneficiary", "recipient", "receiver", "customer", "pos", "retailer",
        "topup", "top-up", "transfer",
        "amount", "operator", "commission", "ledger", "dth", "passbook", "cashback", "logout", "signout"
    )

    // Ye words dikhein to screen login/registration hai; post-login rule (username drop) lagu nahi hota.
    // Field ke apne naam me ye shabd = login form ka saboot (screen text na ho tab bhi).
    private val LOGIN_FIELD_TOKENS = setOf("login", "loginid", "signin", "username", "userid", "password", "passcode", "passwd", "pwd")
    private val PHONE_WORDS = setOf("mobile", "phone", "telephone", "contact", "msisdn")
    private val OTP_SCREEN_TOKENS = setOf("otp", "totp", "verification", "verify", "resend", "sms", "onetime", "2fa", "mfa")

    private val LOGIN_SCREEN_TOKENS = setOf(
        "login", "signin", "sign", "register", "signup", "forgot", "password", "passcode", "authenticate"
    )

    private fun looksLikeLoginScreen(text: String): Boolean {
        val normalized = text.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        if (normalized.isEmpty()) return false
        return normalized.split(" ").any { it in LOGIN_SCREEN_TOKENS }
    }

    /** Phone-number entry (mobile/phone label) jo password/PIN inputType se mask hai, par asli password/PIN nahi hai. */
    private fun isMaskedPhoneEntry(w: Words, h: FieldHints, classified: AutofillFieldType?): Boolean {
        if (classified != AutofillFieldType.PIN && classified != AutofillFieldType.PASSWORD) return false
        val phoneLabel = w.tokens.any { it in setOf("mobile", "phone", "telephone", "contact") }
        val realSecretLabel = w.tokens.any { it in PASSWORD_TOKENS || it == "pin" || it == "mpin" } ||
            h.autofillHints.any { it.equals(HINT_PASSWORD, true) || it.equals("pin", true) || it.equals("mpin", true) }
        return phoneLabel && !realSecretLabel
    }

    private fun isGenericTransactionContact(w: Words, h: FieldHints): Boolean {
        val j = w.joined
        val hasMobile = w.tokens.any { it in setOf("mobile", "phone", "telephone", "contact") }
        val hasNumber = w.tokens.any { it in setOf("number", "no", "num") }
        val generic = hasMobile || hasNumber || j.contains("mobilenumber") || j.contains("phonenumber")
        val strongCredential = h.autofillHints.any { it.equals("username", true) || it.equals("emailAddress", true) } ||
            h.htmlAutocomplete?.lowercase()?.split(' ', '\t')?.any { it == "username" || it == "email" } == true
        return generic && !strongCredential
    }

    private fun isNonCredentialField(words: Words): Boolean =
        NON_CREDENTIAL_PHRASES.any { phrase ->
            words.joined.contains(phrase.replace(" ", "")) ||
            phrase.split(" ").all { it in words.tokens }
        }

    private class Words(val tokens: Set<String>, val joined: String) {
        companion object {
            private val CAMEL = Regex("([a-z0-9])([A-Z])")
            private val SPLIT = Regex("[^a-z0-9]+")

            fun of(h: FieldHints): Words {
                val text = listOfNotNull(h.idEntry, h.hint, h.htmlName, h.htmlId, h.htmlPlaceholder, h.label)
                    .joinToString(" ") { it.replace(CAMEL, "$1 $2") }
                    .lowercase()
                val list = text.split(SPLIT).filter { it.isNotEmpty() }
                return Words(list.toSet(), list.joinToString(""))
            }
        }
    }

    /** "pin", "mpin", "securityPin", "app_pin" — but never postal "PIN code" / zip / address fields. */
    private fun isPinNamed(w: Words): Boolean {
        val j = w.joined
        if (j.contains("pincode") || j.contains("postal") || j.contains("zip") || j.contains("address") || j.contains("area")) return false
        return w.tokens.any { it == "pin" || it == "mpin" || (it.length >= 5 && it.endsWith("pin")) }
    }

    private fun isOtp(w: Words): Boolean =
        w.tokens.any { it in OTP_TOKENS || isOtpCompound(it) } || OTP_JOINED.any { w.joined.contains(it) }

    /** "smsotp", "otpcode", "otp1", "emailotp" jaise jude hue shabd. "footprint" jaise shabd match nahi hote (start/end check). */
    private fun isOtpCompound(token: String): Boolean =
        token.length in 4..14 && (token.startsWith("otp") || token.endsWith("otp"))

    /** Numeric-masked field jiske naam/label me pin/mpin nahi => PIN hone ka koi saboot nahi (OTP bhi ho sakta hai). */
    private fun isWeakPin(h: FieldHints): Boolean {
        val numericPassword = (h.inputType and CLASS_MASK) == CLASS_NUMBER && (h.inputType and VARIATION_MASK) == NUMBER_PASSWORD
        val explicit = h.autofillHints.any { it.equals("pin", true) || it.equals("mpin", true) } || isPinNamed(Words.of(h))
        return numericPassword && !explicit
    }

    /** OTP screen par naam/label ke bina 4-8 digit ka numeric box (phone/mobile nahi). */
    private fun isUnlabeledCodeBox(h: FieldHints): Boolean {
        val numeric = (h.inputType and CLASS_MASK) == CLASS_NUMBER || (h.htmlType?.lowercase() ?: "") in setOf("tel", "number")
        val phoneWords = Words.of(h).tokens.any { it in PHONE_WORDS }
        return numeric && !phoneWords && h.maxLength in 4..8
    }

    /** Developer ne khud "username/email" declare kiya ho (autofill hint ya html autocomplete) => heuristic gate lagu nahi. */
    private fun hasExplicitUsernameSignal(h: FieldHints): Boolean =
        h.autofillHints.any { it.lowercase() in USERNAME_HINTS } ||
            h.htmlAutocomplete?.lowercase()?.split(' ', '\t')?.any { it == "username" || it == "email" } == true

    /** Screen text "OTP / verification / resend / sms" bol raha hai => code-entry screen. */
    private fun screenSaysOtp(text: String): Boolean {
        if (text.isEmpty()) return false
        if (text.contains("ओटीपी")) return true
        val normalized = text.lowercase().replace(Regex("[^a-z0-9]+"), " ").trim()
        if (normalized.isEmpty()) return false
        return normalized.split(" ").any { it in OTP_SCREEN_TOKENS || isOtpCompound(it) }
    }

    private fun isPasswordInput(inputType: Int): Boolean {
        val cls = inputType and CLASS_MASK
        val variation = inputType and VARIATION_MASK
        return (cls == CLASS_TEXT && (variation == TEXT_PASSWORD || variation == TEXT_VISIBLE_PASSWORD || variation == TEXT_WEB_PASSWORD)) ||
            (cls == CLASS_NUMBER && variation == NUMBER_PASSWORD)
    }

    private fun isEmailInput(inputType: Int): Boolean {
        val variation = inputType and VARIATION_MASK
        return (inputType and CLASS_MASK) == CLASS_TEXT && (variation == TEXT_EMAIL || variation == TEXT_WEB_EMAIL)
    }

    private fun isPlainText(h: FieldHints): Boolean {
        val textual = h.inputType == 0 || ((h.inputType and CLASS_MASK) == CLASS_TEXT && (h.inputType and FLAG_MULTI_LINE) == 0)
        val htmlOk = h.htmlType == null || h.htmlType.lowercase() in setOf("text", "tel", "url", "search", "email")
        return textual && htmlOk
    }
}
