// file: app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesViewModel.kt
package pro.babasitaram.vault.presentation.mobiles

import pro.babasitaram.vault.core.util.runCatchingCancellable
import android.content.Context
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.isHiddenVault
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.util.ClipboardActions
import pro.babasitaram.vault.presentation.util.launchCatching

@HiltViewModel
class MobilesViewModel @Inject constructor(
    private val repository: VaultRepository,
    private val saveEntry: SaveEntryUseCase,
    private val clipboard: ClipboardActions,
    private val autoBackup: pro.babasitaram.vault.data.backup.AutoBackupManager,
    @ApplicationContext private val context: Context
) : ViewModel() {
    val entries: StateFlow<List<VaultEntry>> = repository.entries
        .map { values ->
            values.filter {
                it.deletedAt == 0L &&
                    !it.isFolderMarker &&
                    !it.isHiddenVault &&
                    (it.mobile.isNotBlank() || it.phone.isNotBlank())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _favoritesOnly = MutableStateFlow(false)
    val favoritesOnly: StateFlow<Boolean> = _favoritesOnly

    val visibleEntries: StateFlow<List<VaultEntry>> = combine(entries, favoritesOnly) { list, onlyFavorites ->
        if (onlyFavorites) list.filter { it.starred } else list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _selectedIds = MutableStateFlow<Set<String>>(emptySet())
    val selectedIds: StateFlow<Set<String>> = _selectedIds

    private val _selectionMode = MutableStateFlow(false)
    val selectionMode: StateFlow<Boolean> = _selectionMode

    private val _messages = Channel<String>(Channel.BUFFERED)
    val messages: Flow<String> = _messages.receiveAsFlow()

    fun beginSelection(id: String) {
        _selectionMode.value = true
        _selectedIds.update { it + id }
    }

    fun toggleSelection(id: String) {
        if (!_selectionMode.value) beginSelection(id) else {
            _selectedIds.update { current ->
                if (id in current) current - id else current + id
            }
        }
    }

    fun toggleSelectAll() {
        // visibleEntries is collected by MobilesScreen, so .value is live here. (Old code read selectableIds.value,
        // a WhileSubscribed StateFlow nobody collected => always emptySet() => "Select all" silently did nothing.)
        val ids = visibleEntries.value.mapTo(HashSet()) { it.id }
        if (ids.isEmpty()) return
        _selectedIds.value = if (_selectedIds.value.containsAll(ids)) emptySet() else ids
        _selectionMode.value = true
    }

    fun exitSelection() {
        _selectedIds.value = emptySet()
        _selectionMode.value = false
    }

    fun toggleFavoritesOnly() {
        _favoritesOnly.update { !it }
        exitSelection()
    }

    fun toggleFavorite(id: String) {
        val entry = repository.entry(id) ?: return
        launchCatching {
            runCatchingCancellable { saveEntry(entry.copy(starred = !entry.starred), existing = entry) }
                .onSuccess {
                    _messages.send(
                        context.getString(
                            if (entry.starred) R.string.vault_removed_favorite else R.string.vault_added_favorite
                        )
                    )
                }
                .onFailure { _messages.send(it.message ?: context.getString(R.string.selection_favorite_done, 1)) }
        }
    }

    fun copy(number: String) {
        launchCatching {
            _messages.send(clipboard.copy(number, context.getString(R.string.p15_mobile_number)))
        }
    }

    fun delete(id: String) {
        launchCatching {
            runCatchingCancellable { repository.softDelete(id) }
                .onSuccess {
                    runCatchingCancellable { autoBackup.requestBackup() }
                    _messages.send(context.getString(R.string.mobiles_move_bin))
                }
                .onFailure { _messages.send(it.message ?: context.getString(R.string.mobiles_move_bin)) }
        }
    }

    fun deleteSelected() {
        val ids = selectedIds.value.toList()
        if (ids.isEmpty()) return
        launchCatching {
            // One atomic write for the whole selection (same as Vault list), then queue a backup.
            var failed = false
            runCatchingCancellable { repository.softDeleteAll(ids) }.onFailure { failed = true }
            if (!failed) runCatchingCancellable { autoBackup.requestBackup() }
            exitSelection()
            _messages.send(
                if (failed) context.getString(R.string.selection_delete_failed)
                else context.getString(R.string.selection_deleted_to_bin, ids.size)
            )
        }
    }

    fun favoriteSelected() {
        val selected = selectedIds.value
        if (selected.isEmpty()) return
        launchCatching {
            val current = visibleEntries.value.filter { it.id in selected }
            for (entry in current) {
                runCatchingCancellable { saveEntry(entry.copy(starred = !entry.starred), existing = entry) }
            }
            exitSelection()
            _messages.send(context.getString(R.string.selection_favorite_done, current.size))
        }
    }
}
