package pro.babasitaram.vault.core.util

import java.net.URLDecoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

data class TotpConfig(
    val secret: String,
    val digits: Int = 6,
    val periodSeconds: Int = 30,
    val algorithm: String = "SHA1"
)

data class TotpCode(val code: String, val secondsRemaining: Int, val periodSeconds: Int)

/** Why a NEW otpauth:// / secret input was rejected by [Totp.parseStrict] (spec sec 21: invalid input is rejected, never guessed). */
enum class TotpInvalidReason {
    EMPTY, NOT_OTPAUTH, UNSUPPORTED_TYPE, MISSING_SECRET, INVALID_SECRET,
    UNSUPPORTED_ALGORITHM, UNSUPPORTED_DIGITS, UNSUPPORTED_PERIOD
}

/** Result of [Totp.parseStrict]. [Ok.config] is fully normalized (canonical secret / algorithm). */
sealed interface TotpParseResult {
    data class Ok(val config: TotpConfig, val issuer: String = "", val account: String = "") : TotpParseResult
    data class Invalid(val reason: TotpInvalidReason) : TotpParseResult
}

/** RFC 6238 TOTP. Accepts a bare base32 secret or an otpauth:// URI (as the extension stores them). */
object Totp {
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    fun parse(input: String): TotpConfig? {
        val t = input.trim()
        if (t.isEmpty()) return null
        if (!t.startsWith("otpauth://", ignoreCase = true)) return TotpConfig(secret = t)
        // HOTP (counter based) is not supported: showing a TOTP code for it would be wrong, so there is no config.
        val type = otpauthType(t)
        if (type.isNotEmpty() && type != "totp") return null
        val query = t.substringAfter('?', "")
        val params = query.split('&').filter { it.contains('=') }.associate {
            val k = it.substringBefore('=').lowercase()
            val v = runCatching { URLDecoder.decode(it.substringAfter('='), "UTF-8") }.getOrDefault("")
            k to v
        }
        val secret = params["secret"] ?: return null
        return TotpConfig(
            secret = secret,
            digits = params["digits"]?.toIntOrNull()?.takeIf { it in 6..8 } ?: 6,
            periodSeconds = params["period"]?.toIntOrNull()?.takeIf { it > 0 } ?: 30,
            algorithm = (params["algorithm"] ?: "SHA1").uppercase()
        )
    }

    /** Supported HMAC algorithms (RFC 6238). Anything else is rejected, never silently treated as SHA1. */
    val SUPPORTED_ALGORITHMS: Set<String> = setOf("SHA1", "SHA256", "SHA512")

    /** Upper bound for a "period" value coming from an untrusted URI (generous; real services use 15/30/60). */
    const val MAX_PERIOD_SECONDS = 300

    private fun otpauthType(uri: String): String =
        uri.substringAfter("://", "").substringBefore('/').substringBefore('?').lowercase()

    /** Canonical secret form: upper case, without spaces, '-' and '=' padding. */
    fun normalizeSecret(input: String): String =
        input.filterNot { it.isWhitespace() || it == '-' || it == '=' }.uppercase()

    /**
     * Strict parser for NEW input (pasted link, QR scan, manual secret). Unlike [parse] (which stays lenient so
     * entries that are already stored keep working) this validates every field and never falls back silently.
     * [allowBareSecret]=false accepts only otpauth:// links.
     */
    fun parseStrict(input: String, allowBareSecret: Boolean = true): TotpParseResult {
        val t = input.trim()
        if (t.isEmpty()) return TotpParseResult.Invalid(TotpInvalidReason.EMPTY)
        if (!t.startsWith("otpauth://", ignoreCase = true)) {
            if (!allowBareSecret) return TotpParseResult.Invalid(TotpInvalidReason.NOT_OTPAUTH)
            val secret = normalizeSecret(t)
            val ok = base32Decode(secret)?.isNotEmpty() == true
            return if (ok) TotpParseResult.Ok(TotpConfig(secret = secret))
            else TotpParseResult.Invalid(TotpInvalidReason.INVALID_SECRET)
        }
        if (otpauthType(t) != "totp") return TotpParseResult.Invalid(TotpInvalidReason.UNSUPPORTED_TYPE)

        fun dec(v: String) = runCatching { URLDecoder.decode(v, "UTF-8") }.getOrDefault("")
        val params = t.substringAfter('?', "").split('&').filter { it.contains('=') }.associate {
            it.substringBefore('=').lowercase() to dec(it.substringAfter('='))
        }

        val rawSecret = params["secret"]?.takeIf { it.isNotBlank() }
            ?: return TotpParseResult.Invalid(TotpInvalidReason.MISSING_SECRET)
        val secret = normalizeSecret(rawSecret)
        if (base32Decode(secret)?.isNotEmpty() != true) return TotpParseResult.Invalid(TotpInvalidReason.INVALID_SECRET)

        val algorithm = (params["algorithm"] ?: "SHA1").uppercase().replace("-", "")
        if (algorithm !in SUPPORTED_ALGORITHMS) return TotpParseResult.Invalid(TotpInvalidReason.UNSUPPORTED_ALGORITHM)

        val digits = if (params.containsKey("digits")) params["digits"]?.toIntOrNull() else 6
        if (digits == null || (digits != 6 && digits != 8)) return TotpParseResult.Invalid(TotpInvalidReason.UNSUPPORTED_DIGITS)

        val period = if (params.containsKey("period")) params["period"]?.toIntOrNull() else 30
        if (period == null || period !in 1..MAX_PERIOD_SECONDS) return TotpParseResult.Invalid(TotpInvalidReason.UNSUPPORTED_PERIOD)

        // Label: "Issuer:account" (path after the type); the explicit issuer= parameter wins.
        val label = dec(t.substringAfter("://", "").substringAfter('/', "").substringBefore('?')).trim()
        val labelIssuer = if (label.contains(':')) label.substringBefore(':').trim() else ""
        val account = (if (label.contains(':')) label.substringAfter(':') else label).trim()
        val issuer = (params["issuer"] ?: "").trim().ifEmpty { labelIssuer }

        return TotpParseResult.Ok(
            TotpConfig(secret = secret, digits = digits, periodSeconds = period, algorithm = algorithm),
            issuer = issuer,
            account = account
        )
    }

    /** True when both inputs carry the same secret (spec sec 88 duplicate detection). Compares decoded bytes, so case / spaces / padding do not matter. */
    fun sameSecret(a: String, b: String): Boolean {
        fun key(x: String): ByteArray? {
            val c = if (x.trim().startsWith("otpauth://", true)) (parse(x)?.secret ?: return null) else x
            return base32Decode(c)?.takeIf { it.isNotEmpty() }
        }
        val ka = key(a) ?: return false
        val kb = key(b) ?: return false
        return ka.contentEquals(kb)
    }

    /** Builds an otpauth:// URI from editor fields (same shape the browser extension stores). */
    fun buildUri(secret: String, issuer: String, account: String, algorithm: String = "SHA1", digits: Int = 6, period: Int = 30): String {
        fun enc(v: String) = java.net.URLEncoder.encode(v, "UTF-8").replace("+", "%20")
        val cleanSecret = secret.filterNot { it.isWhitespace() || it == '-' }.uppercase()
        val label = if (account.isBlank()) enc(issuer) else "${enc(issuer)}:${enc(account)}"
        return "otpauth://totp/$label?secret=$cleanSecret&issuer=${enc(issuer)}&algorithm=$algorithm&digits=$digits&period=$period"
    }

    fun base32Decode(input: String): ByteArray? {
        val clean = input.filterNot { it.isWhitespace() || it == '-' || it == '=' }.uppercase()
        if (clean.isEmpty()) return null
        var buffer = 0
        var bits = 0
        val out = java.io.ByteArrayOutputStream()
        for (c in clean) {
            val v = ALPHABET.indexOf(c)
            if (v < 0) return null
            buffer = (buffer shl 5) or v
            bits += 5
            if (bits >= 8) {
                bits -= 8
                out.write((buffer shr bits) and 0xFF)
            }
        }
        return out.toByteArray()
    }

    fun generate(config: TotpConfig, timeMs: Long): String? {
        val key = base32Decode(config.secret) ?: return null
        val macName = when (config.algorithm.uppercase()) {
            "SHA1" -> "HmacSHA1"
            "SHA256" -> "HmacSHA256"
            "SHA512" -> "HmacSHA512"
            else -> return null   // unknown algorithm: no code is better than a wrong SHA1 code
        }
        val counter = timeMs / 1000L / config.periodSeconds
        val msg = ByteArray(8) { i -> ((counter shr (8 * (7 - i))) and 0xFF).toByte() }
        val mac = Mac.getInstance(macName)
        mac.init(SecretKeySpec(key, macName))
        val h = mac.doFinal(msg)
        val offset = h[h.size - 1].toInt() and 0x0F
        val bin = ((h[offset].toInt() and 0x7F) shl 24) or
            ((h[offset + 1].toInt() and 0xFF) shl 16) or
            ((h[offset + 2].toInt() and 0xFF) shl 8) or
            (h[offset + 3].toInt() and 0xFF)
        var mod = 1
        repeat(config.digits) { mod *= 10 }
        return (bin % mod).toString().padStart(config.digits, '0')
    }

    fun current(input: String, timeMs: Long): TotpCode? {
        val cfg = parse(input) ?: return null
        val code = generate(cfg, timeMs) ?: return null
        val period = cfg.periodSeconds
        val remaining = period - ((timeMs / 1000L) % period).toInt()
        return TotpCode(code, remaining, period)
    }
}
