package pro.babasitaram.vault.autofill.model

import android.view.autofill.AutofillId

enum class AutofillFieldType { USERNAME, PASSWORD, PIN, NEW_PASSWORD, OTP }

/** One classified input of the screen being filled. [value] is only populated for save requests. */
data class AutofillField(
    val id: AutofillId,
    val type: AutofillFieldType,
    val focused: Boolean = false,
    val value: String? = null
)

/**
 * Framework-free description of a single view. Classification works on this type
 * (not on AssistStructure.ViewNode) so it can be unit-tested on the JVM.
 */
data class FieldHints(
    val autofillHints: List<String> = emptyList(),
    val idEntry: String? = null,
    val hint: String? = null,
    val inputType: Int = 0,
    val htmlType: String? = null,
    val htmlName: String? = null,
    val htmlId: String? = null,
    val htmlAutocomplete: String? = null,
    val htmlPlaceholder: String? = null,
    val maxLength: Int = -1,
    /**
     * Visible label of the field: its own contentDescription + the text sibling right before it
     * (native apps put "Mobile number" / "Enter OTP" in a TextView above the EditText, not in hint).
     * Sirf classification ke liye; kabhi store/log nahi hota.
     */
    val label: String? = null
)

/** Result of parsing an AssistStructure. */
data class ParsedStructure(
    val packageName: String,
    val webDomain: String?,
    val webScheme: String?,
    val fields: List<AutofillField>
) {
    val usernameFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.USERNAME }
    val passwordFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.PASSWORD || it.type == AutofillFieldType.NEW_PASSWORD }
    val pinFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.PIN }
    val secretFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.PASSWORD || it.type == AutofillFieldType.PIN || it.type == AutofillFieldType.NEW_PASSWORD }
    val otpFields: List<AutofillField> get() = fields.filter { it.type == AutofillFieldType.OTP }

    /** Asli login credential fields (ID / password / PIN). OTP aur new-password isme nahi aate. */
    val credentialFields: List<AutofillField>
        get() = fields.filter {
            it.type == AutofillFieldType.USERNAME || it.type == AutofillFieldType.PASSWORD || it.type == AutofillFieldType.PIN
        }

    /**
     * Locked-vault "Unlock" entry kin fields par dikhe. Rule: jis screen par ek bhi credential field nahi
     * (sirf OTP / kuch nahi) wahan "ID & Password" unlock entry KABHI nahi dikhti. Login screen par OTP
     * box bhi saath me cover hota hai (ek hi form).
     */
    val authFields: List<AutofillField>
        get() = if (credentialFields.isEmpty()) emptyList() else fillableFields

    /** Fields that can receive an existing credential (new-password fields never do). */
    val fillableFields: List<AutofillField>
        get() = fields.filter { it.type != AutofillFieldType.NEW_PASSWORD }

    val isFillable: Boolean get() = fillableFields.isNotEmpty()
    val isOtpOnly: Boolean get() = otpFields.isNotEmpty() && fields.all { it.type == AutofillFieldType.OTP }
}
