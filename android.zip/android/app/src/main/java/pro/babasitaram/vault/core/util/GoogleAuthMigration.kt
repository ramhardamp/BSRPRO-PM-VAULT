package pro.babasitaram.vault.core.util

import java.net.URLDecoder
import java.util.Base64

/**
 * Google Authenticator "Transfer accounts -> Export accounts" QR parser.
 *
 * Issue: Google Authenticator export me har account ka alag `otpauth://` QR nahi banta. Saare accounts ek (ya zyada
 * batch) QR me `otpauth-migration://offline?data=<base64 protobuf>` ke roop me aate hain. Scanner sirf `otpauth://`
 * leta tha, isliye ye QR "not a 2FA code" bol kar reject ho jata tha.
 *
 * Logic: data = URL-decode -> base64 -> protobuf (Google ka MigrationPayload). Koi extra library nahi; chhota
 * hand-written protobuf reader, saari limits ke saath (untrusted QR input hai).
 *
 *   MigrationPayload { repeated OtpParameters otp_parameters = 1; int32 version = 2;
 *                      int32 batch_size = 3; int32 batch_index = 4; int32 batch_id = 5; }
 *   OtpParameters    { bytes secret = 1; string name = 2; string issuer = 3; Algorithm algorithm = 4;
 *                      DigitCount digits = 5; OtpType type = 6; int64 counter = 7; }
 *   Algorithm  0 unspecified, 1 SHA1, 2 SHA256, 3 SHA512, 4 MD5      DigitCount 0 unspecified, 1 SIX, 2 EIGHT
 *   OtpType    0 unspecified, 1 HOTP, 2 TOTP
 *
 * Privacy: secrets kabhi log nahi hote. Is object me koi Android dependency nahi => JVM unit test possible.
 */
data class MigrationAccount(
    /** Canonical base32 secret (upper case, no padding). */
    val secret: String,
    val issuer: String,
    val account: String,
    val algorithm: String,
    val digits: Int
) {
    /** List/entry title: issuer, warna account name. */
    val title: String get() = issuer.ifBlank { account }
}

/** Ek QR ka result. [skipped] = HOTP / MD5 jaise unsupported accounts jo is QR me the. */
data class MigrationBatch(
    val accounts: List<MigrationAccount>,
    val skipped: Int,
    val batchId: Int,
    val batchIndex: Int,
    val batchSize: Int
)

object GoogleAuthMigration {
    private const val PREFIX = "otpauth-migration://"
    private const val ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"

    // Limits: QR text untrusted hai. Real export 10 account/QR ke aas-paas hota hai.
    private const val MAX_DATA_CHARS = 200_000
    private const val MAX_ACCOUNTS = 500
    private const val MAX_SECRET_BYTES = 128
    private const val MAX_TEXT_BYTES = 512

    fun isMigration(text: String): Boolean = text.trim().startsWith(PREFIX, ignoreCase = true)

    /** null = kharab / unreadable QR. */
    fun parse(text: String): MigrationBatch? {
        val t = text.trim()
        if (!isMigration(t)) return null
        val raw = t.substringAfter('?', "").split('&')
            .firstOrNull { it.startsWith("data=", ignoreCase = true) }
            ?.substring(5)
            ?.takeIf { it.isNotEmpty() && it.length <= MAX_DATA_CHARS }
            ?: return null
        // '+' query me space ban jata hai: pehle '+' ko %2B kar do, phir percent-decode.
        val decoded = runCatching { URLDecoder.decode(raw.replace("+", "%2B"), "UTF-8") }.getOrNull() ?: return null
        val b64 = decoded.filterNot { it.isWhitespace() }.replace('-', '+').replace('_', '/').trimEnd('=')
        val padded = b64 + "=".repeat((4 - b64.length % 4) % 4)
        val bytes = runCatching { Base64.getDecoder().decode(padded) }.getOrNull() ?: return null
        return try {
            decodePayload(bytes)
        } catch (e: Malformed) {
            null
        }
    }

    // ───────────────────────── protobuf ─────────────────────────

    private class Malformed : Exception()

    private class Reader(private val b: ByteArray) {
        var pos = 0
        fun hasMore() = pos < b.size

        fun varint(): Long {
            var result = 0L
            var shift = 0
            while (true) {
                if (pos >= b.size || shift > 63) throw Malformed()
                val x = b[pos++].toInt()
                result = result or ((x and 0x7F).toLong() shl shift)
                if ((x and 0x80) == 0) return result
                shift += 7
            }
        }

        fun bytes(): ByteArray {
            val n = varint()
            if (n < 0 || n > b.size - pos) throw Malformed()
            val out = b.copyOfRange(pos, pos + n.toInt())
            pos += n.toInt()
            return out
        }

        fun skip(wire: Int) {
            when (wire) {
                0 -> varint()
                1 -> advance(8)
                2 -> bytes()
                5 -> advance(4)
                else -> throw Malformed()
            }
        }

        private fun advance(n: Int) {
            if (n > b.size - pos) throw Malformed()
            pos += n
        }
    }

    private fun decodePayload(bytes: ByteArray): MigrationBatch? {
        val r = Reader(bytes)
        val accounts = ArrayList<MigrationAccount>()
        var skipped = 0
        var batchSize = 1
        var batchIndex = 0
        var batchId = 0
        while (r.hasMore()) {
            val tag = r.varint()
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7).toInt()
            when {
                field == 1 && wire == 2 -> {
                    if (accounts.size + skipped >= MAX_ACCOUNTS) throw Malformed()
                    val acc = decodeOtp(r.bytes())
                    if (acc != null) accounts.add(acc) else skipped++
                }
                field == 3 && wire == 0 -> batchSize = r.varint().toInt()
                field == 4 && wire == 0 -> batchIndex = r.varint().toInt()
                field == 5 && wire == 0 -> batchId = r.varint().toInt()
                else -> r.skip(wire)    // version (2) aur unknown fields
            }
        }
        if (accounts.isEmpty() && skipped == 0) return null
        return MigrationBatch(accounts, skipped, batchId, batchIndex, batchSize.coerceAtLeast(1))
    }

    /** null = supported nahi (HOTP, MD5, kharab secret). Throw sirf tab jab protobuf hi toota ho. */
    private fun decodeOtp(bytes: ByteArray): MigrationAccount? {
        val r = Reader(bytes)
        var secret = ByteArray(0)
        var name = ""
        var issuer = ""
        var algorithm = 0
        var digitEnum = 0
        var type = 0
        while (r.hasMore()) {
            val tag = r.varint()
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7).toInt()
            when {
                field == 1 && wire == 2 -> secret = r.bytes()
                field == 2 && wire == 2 -> name = r.bytes().takeIf { it.size <= MAX_TEXT_BYTES }?.toString(Charsets.UTF_8).orEmpty()
                field == 3 && wire == 2 -> issuer = r.bytes().takeIf { it.size <= MAX_TEXT_BYTES }?.toString(Charsets.UTF_8).orEmpty()
                field == 4 && wire == 0 -> algorithm = r.varint().toInt()
                field == 5 && wire == 0 -> digitEnum = r.varint().toInt()
                field == 6 && wire == 0 -> type = r.varint().toInt()
                else -> r.skip(wire)    // counter (7) aur unknown fields
            }
        }
        if (type == 1) return null                                    // HOTP: TOTP code galat hota
        val algo = when (algorithm) {
            0, 1 -> "SHA1"
            2 -> "SHA256"
            3 -> "SHA512"
            else -> return null                                       // MD5 etc.: galat code se behtar hai skip
        }
        val digits = when (digitEnum) {
            0, 1 -> 6
            2 -> 8
            else -> return null
        }
        if (secret.isEmpty() || secret.size > MAX_SECRET_BYTES) return null

        // Name aksar "Issuer:account" hota hai.
        var accountName = name.trim()
        var issuerName = issuer.trim()
        if (issuerName.isEmpty() && accountName.contains(':')) {
            issuerName = accountName.substringBefore(':').trim()
            accountName = accountName.substringAfter(':').trim()
        } else if (issuerName.isNotEmpty() && accountName.startsWith("$issuerName:")) {
            accountName = accountName.removePrefix("$issuerName:").trim()
        }
        return MigrationAccount(base32Encode(secret), issuerName, accountName, algo, digits)
    }

    /** RFC 4648 base32, bina padding (Totp.normalizeSecret bhi '=' hata deta hai). */
    fun base32Encode(data: ByteArray): String {
        val sb = StringBuilder((data.size * 8 + 4) / 5)
        var buffer = 0
        var bits = 0
        for (byte in data) {
            buffer = (buffer shl 8) or (byte.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(ALPHABET[(buffer shr (bits - 5)) and 31])
                bits -= 5
            }
            buffer = buffer and ((1 shl bits) - 1)
        }
        if (bits > 0) sb.append(ALPHABET[(buffer shl (5 - bits)) and 31])
        return sb.toString()
    }
}

/**
 * Multi-QR export (10+ accounts => Google kai QR deta hai, "batch_index / batch_size") jodta hai.
 * Same QR dobara dikhe to dedupe by batchIndex; naya export (alag batchId) aaye to purana reset.
 */
class MigrationCollector {
    private var batchId: Int? = null
    private var total = 1
    private val parts = java.util.TreeMap<Int, MigrationBatch>()

    fun add(batch: MigrationBatch) {
        if (batchId != null && batchId != batch.batchId) parts.clear()
        batchId = batch.batchId
        total = batch.batchSize.coerceAtLeast(1)
        parts[batch.batchIndex] = batch
    }

    val received: Int get() = parts.size
    val expected: Int get() = total
    val isComplete: Boolean get() = parts.isNotEmpty() && parts.size >= total
    val accounts: List<MigrationAccount> get() = parts.values.flatMap { it.accounts }
    val skipped: Int get() = parts.values.sumOf { it.skipped }
}
