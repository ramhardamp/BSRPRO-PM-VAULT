@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.vault

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import kotlinx.coroutines.delay
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.StrengthMeter
import pro.babasitaram.vault.presentation.util.CollectMessages
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import pro.babasitaram.vault.core.util.L

@Composable
fun EntryDetailScreen(
    onBack: () -> Unit,
    onEdit: (VaultEntry) -> Unit,
    onShare: (String) -> Unit = {},
    vm: EntryDetailViewModel = hiltViewModel()
) {
    val entry by vm.entry.collectAsStateWithLifecycle()
    BackHandler { onBack() }
    val context = LocalContext.current
    var confirmDelete by remember { mutableStateOf(false) }
    CollectMessages(vm.messages)

    CollectEntryDetailEvents(vm.events, onDeleted = onBack)
    val e = entry ?: run { EntryUnavailable(onBack); return }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(e.title.ifEmpty { stringResource(pro.babasitaram.vault.R.string.p17_untitled_paren) }, maxLines = 1) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } },
                actions = {
                    IconButton(onClick = vm::toggleStar) {
                        Icon(if (e.starred) Icons.Default.Star else Icons.Default.StarBorder, "Star")
                    }
                    IconButton(onClick = { onShare(e.id) }) { Icon(Icons.Default.Share, stringResource(R.string.vault_share_securely)) }
                    IconButton(onClick = { onEdit(e) }) { Icon(Icons.Default.Edit, "Edit") }
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Delete") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            DetailField("Username", e.username) { vm.copy(L.s(R.string.p15_username), e.username) }
            if (e.password.isNotEmpty()) {
                DetailField("Password", e.password, secret = true) { vm.copy(L.s(R.string.type_password), e.password) }
                StrengthMeter(e.password)
            }
            if (e.appPin.isNotEmpty()) {
                DetailField("App PIN", e.appPin, secret = true) { vm.copy(L.s(R.string.p18_common_app_pin), e.appPin) }
            }
            if (e.url.isNotEmpty()) {
                DetailField("Website", e.url, extraIcon = {
                    IconButton(onClick = {
                        runCatching {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(UrlUtils.toOpenable(e.url))))
                        }
                    }) { Icon(Icons.Default.Link, "Open website") }
                }) { vm.copy(L.s(R.string.p17_loc_131), e.url) }
            }
            DetailField("Mobile", e.mobile) { vm.copy(L.s(R.string.p15_mobile), e.mobile) }
            DetailField("Email", e.email) { vm.copy(L.s(R.string.p15_email), e.email) }
            if (e.totp.isNotBlank()) {
                TotpField(e, vm)
            } else if (!e.isNote && e.recordType.equals("login", ignoreCase = true)) {
                TextButton(onClick = { onEdit(e) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_031)) }
            }
            DetailField("Card number", e.cardNumber, secret = true) { vm.copy(L.s(R.string.p18_entry_detail_card_number), e.cardNumber) }
            DetailField("Cardholder", e.cardholder) { vm.copy(L.s(R.string.p18_entry_detail_cardholder), e.cardholder) }
            DetailField("Expiry", e.cardExpiry) { vm.copy(L.s(R.string.p15_expiry), e.cardExpiry) }
            DetailField("CVV", e.cardCvv, secret = true) { vm.copy(L.s(R.string.p15_cvv), e.cardCvv) }
            DetailField("Full name", e.fullName) { vm.copy(L.s(R.string.p18_entry_detail_full_name), e.fullName) }
            DetailField("Phone", e.phone) { vm.copy(L.s(R.string.p15_phone), e.phone) }
            DetailField("Address", e.address) { vm.copy(L.s(R.string.p15_address), e.address) }
            DetailField("ID number", e.idNumber, secret = true) { vm.copy(L.s(R.string.p18_entry_detail_id_number), e.idNumber) }
            DetailField("ID expiry", e.idExpiry) { vm.copy(L.s(R.string.p18_entry_detail_id_expiry), e.idExpiry) }
            e.customFields.filter { it.k.isNotBlank() }.forEach { f ->
                DetailField(f.k, f.v) { vm.copy(f.k, f.v) }
            }
            DetailField("Notes", e.notes) { vm.copy(L.s(R.string.drawer_notes), e.notes) }
            DetailField("Category", e.category.replaceFirstChar { it.uppercase() })
            if (e.tags.isNotEmpty()) DetailField("Tags", e.tags.joinToString(", "))
            if (e.appName.isNotEmpty() || e.appPackage.isNotEmpty()) {
                DetailField("Android app", when {
                    e.appName.isNotBlank() && e.appPackage.isNotBlank() -> "${e.appName} (${e.appPackage})"
                    e.appPackage.isNotBlank() -> e.appPackage
                    else -> "${e.appName} · Not linked — edit entry to re-link"
                })
            }
            if (e.passwordHistory.isNotEmpty()) PasswordHistory(e, vm)
            if (e.editHistory.isNotEmpty()) EditHistory(e)
            if (e.updatedAt > 0) {
                Text(
                    L.s(R.string.p18_entry_detail_updated, DateFormat.getDateTimeInstance().format(Date(e.updatedAt))),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_032), style = MaterialTheme.typography.titleLarge) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_bin_restore, e.title)) },
            confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete() }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) } },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun DetailField(
    label: String,
    value: String,
    secret: Boolean = false,
    extraIcon: (@Composable () -> Unit)? = null,
    onCopy: (() -> Unit)? = null
) {
    if (value.isEmpty()) return
    var shown by remember { mutableStateOf(!secret) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                if (shown) value else "••••••••••",
                style = MaterialTheme.typography.bodyLarge,
                fontFamily = if (secret) FontFamily.Monospace else FontFamily.Default
            )
        }
        if (secret) {
            IconButton(onClick = { shown = !shown }) {
                Icon(if (shown) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (shown) "Hide" else "Show")
            }
        }
        extraIcon?.invoke()
        if (onCopy != null) IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, "Copy $label") }
    }
}

@Composable
private fun TotpField(entry: VaultEntry, vm: EntryDetailViewModel) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(250)
        }
    }
    val code = vm.totp(entry.totp, now)
    if (code == null) {
        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_034), color = MaterialTheme.colorScheme.error)
        return
    }
    // fraction of the period left, computed from wall-clock milliseconds so the ring is smooth and flips exactly at the boundary
    val periodMs = code.periodSeconds * 1000L
    val fraction = 1f - ((now % periodMs).toFloat() / periodMs)
    val expiring = code.secondsRemaining <= 5
    Row(
        Modifier.fillMaxWidth().clickable { vm.copy(L.s(R.string.notes_code), code.code) }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_035), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                code.code.chunked(3).joinToString(" "),
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Monospace,
                color = if (expiring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        }
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { fraction },
                modifier = Modifier.size(44.dp),
                strokeWidth = 4.dp,
                color = if (expiring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
            Text("${code.secondsRemaining}", style = MaterialTheme.typography.labelLarge)
        }
        IconButton(onClick = { vm.copy(L.s(R.string.notes_code), code.code) }) { Icon(Icons.Default.ContentCopy, "Copy code") }
    }
}

@Composable
private fun PasswordHistory(entry: VaultEntry, vm: EntryDetailViewModel) {
    var open by remember { mutableStateOf(false) }
    Column {
        TextButton(onClick = { open = !open }) { Text(if (open) stringResource(pro.babasitaram.vault.R.string.p17_hide_password_history) else stringResource(pro.babasitaram.vault.R.string.p17_password_history_count, entry.passwordHistory.size)) }
        if (open) {
            entry.passwordHistory.forEach { h ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_036), fontFamily = FontFamily.Monospace)
                        if (h.changedAt > 0) {
                            Text(DateFormat.getDateInstance().format(Date(h.changedAt)), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    IconButton(onClick = { vm.copy(L.s(R.string.p18_entry_detail_old_password), h.pw) }) { Icon(Icons.Default.ContentCopy, "Copy old password") }
                }
            }
        }
    }
}

@Composable
private fun EditHistory(entry: VaultEntry) {
    var open by remember { mutableStateOf(false) }
    Column {
        TextButton(onClick = { open = !open }) { Text(if (open) stringResource(pro.babasitaram.vault.R.string.p17_hide_edit_history) else stringResource(pro.babasitaram.vault.R.string.p17_edit_history_count, entry.editHistory.size)) }
        if (open) {
            entry.editHistory.forEach { h ->
                Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Text(
                        if (h.changedAt > 0) DateFormat.getDateTimeInstance().format(Date(h.changedAt)) else stringResource(R.string.p18_entry_detail_unknown_time),
                        style = MaterialTheme.typography.labelMedium
                    )
                    val what = h.fields.joinToString(", ").ifEmpty { "details" }
                    Text(
                        L.s(R.string.p18_entry_detail_changed, what) + if (h.source.isNotEmpty()) " · ${h.source}" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
