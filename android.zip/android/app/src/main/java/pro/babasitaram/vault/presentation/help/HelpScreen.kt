@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.help

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import androidx.annotation.StringRes
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import pro.babasitaram.vault.core.constants.AppLinks

/**
 * FAQ ab string resources (R.string.faq_qNN / faq_aNN) se aata hai, hardcoded English se nahi.
 * Isliye Hindi (values-b+hi) me Hindi aur baaki me English dikhta hai. Order = screen par dikhne ka order.
 */
data class HelpFaq(@StringRes val question: Int, @StringRes val answer: Int)

private val faqs = listOf(
    HelpFaq(R.string.faq_q01, R.string.faq_a01),
    HelpFaq(R.string.faq_q02, R.string.faq_a02),
    HelpFaq(R.string.faq_q03, R.string.faq_a03),
    HelpFaq(R.string.faq_q04, R.string.faq_a04),
    HelpFaq(R.string.faq_q05, R.string.faq_a05),
    HelpFaq(R.string.faq_q06, R.string.faq_a06),
    HelpFaq(R.string.faq_q07, R.string.faq_a07),
    HelpFaq(R.string.faq_q08, R.string.faq_a08),
    HelpFaq(R.string.faq_q09, R.string.faq_a09),
    HelpFaq(R.string.faq_q10, R.string.faq_a10),
    HelpFaq(R.string.faq_q11, R.string.faq_a11),
    HelpFaq(R.string.faq_q12, R.string.faq_a12),
    HelpFaq(R.string.faq_q13, R.string.faq_a13),
    HelpFaq(R.string.faq_q14, R.string.faq_a14),
    HelpFaq(R.string.faq_q15, R.string.faq_a15),
    HelpFaq(R.string.faq_q16, R.string.faq_a16)
)

@Composable
fun HelpScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    BackHandler { onBack() }
    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.p15_help), style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.HelpOutline, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_126), style = MaterialTheme.typography.titleMedium); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_127)) } } }
            item { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_128), style = MaterialTheme.typography.titleLarge) }
            items(faqs, key = { it.question }, contentType = { "item" }) { faq -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { Text(stringResource(faq.question), style = MaterialTheme.typography.titleMedium); Text(stringResource(faq.answer)) } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_129), style = MaterialTheme.typography.titleMedium); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_130)) } } }
            item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppLinks.WEBSITE))) } }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_131)) } }
            item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppLinks.GITHUB_ISSUES))) } }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_132)) } }
            item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${AppLinks.EMAIL}"))) } }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_email_support, AppLinks.EMAIL)) } }
        }
    }
}
