@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.supportdeveloper

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

private const val WEBSITE_URL = "https://ramhardamp.github.io/babasitaram-pro/"
private const val SUPPORT_UPI_ID = "Totalpay@upi"
private val AppLinksDeveloper = pro.babasitaram.vault.core.constants.AppLinks.DEVELOPER

/**
 * UPI payment link (NPCI standard): pa = payee VPA, pn = payee name, cu = currency (INR), tn = note.
 * Pehle `cu` nahi tha, aur GPay/PhonePe/Paytm ke private schemes (gpay://, phonepe://, paytmmp://) use hote the.
 * Ye schemes documented nahi hain: app khulta tha aur thodi der me band ho jata tha. Ab sirf standard `upi://pay`
 * use hota hai, aur app chunne ke liye `setPackage` (neeche), taaki har UPI app ek hi jaisa chale.
 */
private val upiPayUri: String =
    "upi://pay?pa=$SUPPORT_UPI_ID&pn=BabaSitaRam%20Pro&cu=INR&tn=Support%20Developer"

/** Label to Android package. App install na ho to generic chooser par fallback hota hai. */
private val UPI_APPS = listOf(
    "Google Pay" to "com.google.android.apps.nbu.paisa.user",
    "PhonePe" to "com.phonepe.app",
    "Paytm" to "net.one97.paytm"
)

/**
 * UPI app kholta hai. [packageName] diya ho to usi app me; na mile (ya null) to Android ka UPI app chooser.
 * Dono fail hon to toast (pehle chupchap kuch nahi hota tha).
 */
private fun openUpiApp(context: android.content.Context, packageName: String?) {
    fun upiIntent() = Intent(Intent.ACTION_VIEW, Uri.parse(upiPayUri)).addCategory(Intent.CATEGORY_BROWSABLE)
    val direct = packageName != null && runCatching {
        context.startActivity(upiIntent().setPackage(packageName))
    }.isSuccess
    if (direct) return
    val chooser = runCatching {
        context.startActivity(Intent.createChooser(upiIntent(), null))
    }.isSuccess
    if (!chooser) {
        android.widget.Toast.makeText(context, context.getString(R.string.support_no_upi_app), android.widget.Toast.LENGTH_LONG).show()
    }
}

@Composable
fun SupportDeveloperScreen(onBack: () -> Unit = {}) {
    val context = LocalContext.current
    val upiUri = upiPayUri
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    val upiQr = rememberQr(upiUri)
    val websiteQr = rememberQr(WEBSITE_URL)
    BackHandler { onBack() }
    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.p15_support_developer), style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }) }) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Icon(Icons.Default.VolunteerActivism, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_207), style = MaterialTheme.typography.titleMedium); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_208)) } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_209), style = MaterialTheme.typography.titleMedium)
                Text(SUPPORT_UPI_ID, style = MaterialTheme.typography.headlineSmall)
                upiQr?.let { Image(it.asImageBitmap(), "UPI QR code", Modifier.size(240.dp)) }
                Button(onClick = { openUpiApp(context, null) }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_210)) }
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.support_pay_options), style = MaterialTheme.typography.titleMedium)
                OutlinedButton(
                    onClick = {
                        clipboard.setText(androidx.compose.ui.text.AnnotatedString(SUPPORT_UPI_ID))
                        android.widget.Toast.makeText(context, context.getString(R.string.support_copied), android.widget.Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.support_copy_upi)) }
                UPI_APPS.forEach { (label, pkg) ->
                    OutlinedButton(onClick = { openUpiApp(context, pkg) }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                }
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(AppLinksDeveloper, style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.support_dev_role), style = MaterialTheme.typography.bodySmall)
                Text(stringResource(R.string.support_where_title), style = MaterialTheme.typography.titleSmall)
                Text(stringResource(R.string.support_where_items))
                Text(stringResource(R.string.support_thanks), style = MaterialTheme.typography.titleMedium)
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.QrCode2, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_131), style = MaterialTheme.typography.titleMedium); websiteQr?.let { Image(it.asImageBitmap(), androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_211), Modifier.size(220.dp)) }; Text(WEBSITE_URL, style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(WEBSITE_URL))) }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Language, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_212)) }
            } } }
        }
    }
}

@Composable
private fun rememberQr(value: String): Bitmap? = androidx.compose.runtime.remember(value) {
    runCatching {
        val matrix: BitMatrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 600, 600)
        val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.ARGB_8888)
        for (x in 0 until 600) for (y in 0 until 600) bitmap.setPixel(x, y, if (matrix[x, y]) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        bitmap
    }.getOrNull()
}
