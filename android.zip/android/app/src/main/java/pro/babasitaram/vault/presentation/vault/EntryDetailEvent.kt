package pro.babasitaram.vault.presentation.vault

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.Flow
import pro.babasitaram.vault.R

/**
 * One-shot UI events of the entry detail screens (Entry / TOTP / File).
 * Navigation after a delete is driven ONLY by [Deleted] (spec sec 24); a screen never infers it from `entry == null`.
 */
sealed interface EntryDetailEvent {
    data object Deleted : EntryDetailEvent
    data class Error(val message: String) : EntryDetailEvent
}

/** Consumes [events] once each: [EntryDetailEvent.Deleted] -> [onDeleted] (navigate back exactly once), errors -> toast. */
@Composable
fun CollectEntryDetailEvents(events: Flow<EntryDetailEvent>, onDeleted: () -> Unit) {
    val context = LocalContext.current
    val latestOnDeleted by rememberUpdatedState(onDeleted)
    LaunchedEffect(events) {
        events.collect { event ->
            when (event) {
                EntryDetailEvent.Deleted -> latestOnDeleted()
                is EntryDetailEvent.Error -> Toast.makeText(context, event.message, Toast.LENGTH_SHORT).show()
            }
        }
    }
}

/** Shown instead of a blank screen when the entry is not available (e.g. removed elsewhere). Back is always possible. */
@Composable
fun EntryUnavailable(onBack: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(stringResource(R.string.p21_entry_unavailable), style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(16.dp))
        TextButton(onClick = onBack) { Text(stringResource(R.string.p21_back)) }
    }
}
