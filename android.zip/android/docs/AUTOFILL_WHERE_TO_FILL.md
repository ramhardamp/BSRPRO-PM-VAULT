# Autofill: kahan fill hona chahiye, kahan nahi (PASS14)

> Format: Issue -> Fix -> Logic. Hinglish. Gradle/device testing: NOT RUN.
> Ye file isliye hai ki aap research karke naye rule bata sako: har rule ek line me, aur code me `AutofillParser.resolve` ke ek Gate se juda hai.

## Issue
OTP box par aur "Customer mobile number" jaise field par saved ID/password aa jata tha.

## Fix (root cause)
1. `positionalFallback` (field ko sirf position se bharna) hata diya. Ab har field me sirf uske apne type ki value jati hai.
2. Numeric-masked box ko bina saboot PIN nahi maante (OTP box aksar yahi hota hai).
3. Heuristic "username" (mobile/phone/customer/email shabd) ko login-jaisi form chahiye.
4. OTP-only screen par locked "Unlock ID & Password" entry nahi.

## Logic: rule table

| # | Situation | Kya hoga | Code |
|---|---|---|---|
| 1 | Field me `otp`, `totp`, `2fa`, `verification code`, `smsotp`, `otpcode` ya hint `smsOTPCode`/`oneTimeCode`/html `one-time-code` | OTP type. Sirf TOTP (agar entry me ho). ID/password/PIN KABHI nahi | `classify`, `isOtp` |
| 2 | Numeric-masked box (`numberPassword`), naam me `pin`/`mpin` NAHI | "Weak PIN": OTP-jaisi screen (otp/verify/resend/sms/OTP) => OTP; login-jaisi screen ya upar plain text field => PIN; warna kuch nahi | Gate 2, `isWeakPin` |
| 3 | Naam me `pin`/`mpin` (postal "PIN code" nahi) | PIN, apni jagah | `classify` |
| 4 | OTP-jaisi screen par naam/label ke bina 4-8 digit numeric box (phone nahi) | OTP | Gate 1b, `isUnlabeledCodeBox` |
| 5 | Generic mobile/phone/customer/email field, saath me password/PIN field | Username (login form) | Gate 3 |
| 6 | Generic mobile/phone/customer/email field, password nahi, par screen/field me login/sign in/username/userid | Username (multi-step login) | Gate 3, `LOGIN_FIELD_TOKENS` |
| 7 | Generic mobile/phone/customer/email field, password nahi, login words nahi (checkout, address, profile, recharge) | KUCH NAHI | Gate 3 |
| 8 | App ne khud hint diya (`autofillHints=username/emailAddress`, html `autocomplete=username/email`) | Username (developer ka declare kiya hua). Sirf post-login transaction screen par ignore (11.1) | `hasExplicitUsernameSignal` |
| 9 | Recharge/POS/payment/wallet/logout wali screen, password nahi | Koi username nahi (11.1) | `isTransactionContext` |
| 10 | "Customer/Confirm/Recipient mobile" jaise phrase | Hard deny | `NON_CREDENTIAL_PHRASES` |
| 11 | Hidden / 1px / ~transparent field | Kabhi nahi (phishing honeypot) | `reallyVisible` |
| 12 | OTP-only screen (koi ID/password/PIN field nahi) + vault locked | Koi unlock entry nahi | `ParsedStructure.authFields` |
| 13 | OTP-only screen + vault unlocked + entry me TOTP hai | TOTP code suggest hota hai | `AutofillValues.otpFor` |
| 14 | Related (parent/sub-domain) site | OTP kabhi nahi; password sirf confirm ke baad | `relatedDataset` |
| 15 | Plain `http` page | Kabhi nahi | `VaultAutofillService` |

## Android ka documented guidance (jo verify kiya)
- Autofill framework app ke diye hints ko bina validate kiye service ko pass karta hai (isliye app ka galat hint bhi aa sakta hai; rule 7/9 isi liye heuristics lagate hain).
- Single OTP view ke liye `AUTOFILL_HINT_SMS_OTP` hai; CAPTCHA jaise field `importantForAutofill=no` se hat sakte hain.
- Source: developer.android.com "Optimize your app for autofill".
- Google Password Manager ka internal logic public nahi hai; maine uski nakal ka dava nahi kiya. Upar ka table isi app ke code ka rule-set hai.

## Aap kya research karke bata sakte ho
Kisi app me galat jagah suggestion aaye to: app ka package name + screen ka screenshot + field ka label. Main usse table me ek nayi row (aur test) bana dunga.
Diagnostics: `AutofillDiagnostics` (app ka autofill diagnostics log) me `2 parsed ... username=N password=N pin=N otp=N` line dikhti hai.

## Tradeoff (jaan-boojh kar)
OTP-only screen par vault LOCKED ho to ab "Unlock" prompt nahi aata (pehle har SMS-OTP box par aata tha). TOTP autofill tab hi chalega jab vault unlocked ho.
