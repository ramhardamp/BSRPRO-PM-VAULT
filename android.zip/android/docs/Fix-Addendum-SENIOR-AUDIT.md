# Fix Addendum — Senior Audit (fix pass #8 applied)

Format: Issue -> Fix -> Logic (Fix.md style), Hinglish.
Status: **Fix pass #8 applied** - sabse taaza section 0.8 (phir 0.7, 0.6, 0.5) (0.5 > 0.4 > 0.3 > 0.2 > 0.1); dekho section 0.4 (0.4 > 0.3 > 0.2 > 0.1 > neeche ke har STATUS line; naya section purane ko override karta hai). Fix pass #1: section 0.1. Items ka status har finding ke neeche bhi likha hai.
Original status: **PROPOSED**. Yeh file `Fix.md` ka replacement nahi hai aur abhi Source of Truth nahi hai.
Jab tak user har item ko approve na kare, koi code change / migration / refactor NAHI hoga.

Scope: `BSRPRO-Android-v1_0_3-AUTOFILL-TRANSACTION-FIX-SOURCE.zip`, `BSRPRO-Extension-v5_43_0-FIXED.zip`, `FIXED_CODE.md`.
Android aur Extension ke fixes alag rakhe gaye hain (IDs: `AND-*`, `EXT-*`, `X-*` = dono / process).

---

## 0. Overall status (sach, bina badhai ke)

| Area | Status | Wajah |
|---|---|---|
| Overall | **FAIL** | Open HIGH/CRITICAL items neeche |
| Security | FAIL | EXT-01, EXT-02, EXT-05 |
| Data Safety | FAIL | EXT-03 (race), AND-02 (pending save loss) |
| Android | NOT VERIFIED | Build / unit test / device test chala nahi |
| Chrome | NOT VERIFIED | Browser me load nahi hua |
| Firefox | FAIL (static) | EXT-07 manifest |
| Backup/Restore | PARTIAL | V3/V4 interop script PASS; Android<->Extension live round-trip nahi hua |
| Autofill | NOT VERIFIED | Sirf code padha |
| Performance | FAIL (static) | EXT-04 |
| 10-Clean-Loop | **0 / 10** | Pehla cycle hi clean nahi |


## 0.8 Pass #8 (2026-10-09) — Master Spec batch 1: TOTP bugs + delete double-back + backup toast

**Source:** user ka "Master AI Fix & Production Upgrade Specification" (99 sections). Spec sec 2 ke hisaab se pehle read-only audit (`AUDIT-REPORT-PASS7.md`), phir yeh pehla chhota batch. **Poora spec implement NAHI hua** — niche "Is pass me NAHI hua" dekho.

### A. Fixes
| # | Issue | Fix | Logic | Files | Test | Status |
|---|---|---|---|---|---|---|
| 1 | `Totp.parse` `otpauth://hotp/...` ko bhi TOTP maan ke **galat code** dikhata tha | lenient `parse` HOTP par `null`; naya `parseStrict` `UNSUPPORTED_TYPE` deta hai | spec sec 21: HOTP clear reject | `core/util/Totp.kt` | `TotpStrictParserTest` (13) + purane 10 TOTP test (RFC 6238 vectors) kotlinc 2.0.20 + mini JUnit shim me **23/23 PASS** | Logic: PASS (sandbox). Gradle `testDebugUnitTest`: **NOT RUN** |
| 2 | Editor me paste kiye link se sirf `secret` rakha jata tha; `algorithm / digits / period` chhut jate => SHA256 / 8-digit / 60s QR ka code **galat** | `setSecret` link ko strict parse karke algorithm, digits, period, (khali ho to) title / username bhar deta hai | spec sec 20, 22; `Totp.kt` reuse, replace nahi | `TotpEditorViewModel.kt` | ViewModel behaviour harness (stubs ke saath) **17/17 PASS** | ViewModel type-check + behaviour: PASS (stubs). Asli Hilt/Android compile: **NOT VERIFIED** |
| 3 | Invalid secret / unsupported algorithm / digits / period guess ho jate the (defaults) | `parseStrict`: algorithm SHA1/SHA256/SHA512, digits 6 ya 8, period 1..300 (`MAX_PERIOD_SECONDS`, udar upper limit) nahi to reject + localized error | spec sec 20, 21 | `Totp.kt`, `TotpEditorViewModel.kt`, strings EN+HI | upar ke tests | PASS (sandbox) |
| 4 | Unknown algorithm par `generate` chupchap SHA1 se **galat code** deta tha | `generate` unsupported algorithm par `null` | galat code se behtar "code nahi" | `Totp.kt` | `unknown algorithm gives no code...` | PASS (sandbox) |
| 5 | Duplicate TOTP detect nahi hota tha | `Totp.sameSecret` (decoded bytes, case / space / padding / link-wrapping se beparwah) + editor me "may already exist" dialog (Save anyway / Cancel); bin ki entry duplicate nahi | spec sec 88 | `Totp.kt`, `TotpEditorViewModel.kt`, `TotpEditorScreen.kt`, strings | VM harness (5 cases) | Logic PASS (sandbox). **Compose dialog compile / UI: NOT VERIFIED** |
| 6 | **Delete par double back (white-screen ka sabse mazboot karan).** `softDelete` ke baad `_entries` se entry hat jati hai => `entry == null` => `LaunchedEffect(entry == null){ onBack() }` chalta hai, aur `vm.delete(onBack)` bhi `onBack()` chalata hai => `nav.popBackStack()` **do baar** (Entry, TOTP, File teeno detail screens me) | `EntryDetailEvent.Deleted` / `Error` ek-baar wala event; screen sirf event par back jati hai; `entry == null` se navigation infer nahi; delete double-tap guard; entry nahi mile to khali screen ki jagah "This item is no longer available" + Back | spec sec 24 | `presentation/vault/EntryDetailEvent.kt` (naya), `EntryDetailViewModel.kt`, `EntryDetailScreen.kt`, `TotpDetailViewModel.kt`, `TotpDetailScreen.kt`, `FileDetailScreen.kt`, strings | (Compose / Hilt, sandbox me nahi chalta) | Karan **code padh kar** nikala (static); device par reproduce **NOT DONE**, fix **NOT VERIFIED**; Kotlin syntax-only check: errors 0 |
| 7 | Delete failure par raw `error.message` (English / exception text) toast hota tha | teeno VM ab localized `p20_could_not_delete` bhejte hain | spec sec 36 | upar ki VM files | — | NOT VERIFIED (compile) |
| 8 | Backup request delete ke result ke andar thi (`requestBackup()` throw => "delete fail" jabki ho chuka) | softDelete result pehle; backup request uske baad, best-effort (`runCatchingCancellable`) | spec sec 25. **Sudhaar:** `requestBackup()` khud halka hai (flag + apna scope, errors wahin pakde jate hain), isliye audit me jo HIGH likha tha woh **LOW** tha | `domain/usecase/VaultSessionUseCases.kt` | `DeleteEntryUseCaseTest` (3 tests) likha | Test: **NOT RUN** (mockk + coroutines-test => Gradle chahiye) |
| 9 | Har unlock par English-only "Pending backup completed / will retry" toast | toast hata diya; pending request abhi bhi retry hoti hai | spec sec 27, 29 | `SaveRouterViewModel.kt` | — | NOT VERIFIED (compile). **Settings -> Backup me status row abhi nahi bana** — tab tak pending state kahin dikhti nahi |

### B. Behaviour badlaav (jaanbujh kar)
- Stored HOTP entry ab "code nahi" dikhati hai (pehle galat TOTP code).
- Unknown algorithm wali entry par code nahi (pehle galat SHA1 code).
- Detail screen par entry missing ho to auto-back nahi, "not available" + Back button (jaise vault lock par detail khuli rah sakti hai jab tak global lock navigation use nahi hatata).
- Unlock par pending-backup toast nahi.

### C. Is pass me NAHI hua (spec ka baaki — jhoot nahi)
QR **scan** (A-10: camera dependency ka faisla chahiye: CameraX + ZXing / ML Kit / Play code scanner), backup state machine (A-03), central snackbar system (A-05), HelpScreen + hard-coded English ka Hindi / completeness test (A-12), Autofill Safety Engine / SensitiveTargetPolicy / Fill-Save-Update split / blocked targets / Allow once-always / exact-host default (A-06..A-09), performance benchmark (A-18), extension policy parity (A-14), spec sec 33, 42, 43, 45–48 aur 53–99 ka audit (search, accessibility, dark mode, notifications, clipboard, logging, dependencies, code quality), Android Gradle build / lint / release, real-device regression, 10-Clean-Loop.

### D. Test ledger (pass #8)
| Check | Result (mere sandbox me) |
|---|---|
| `Totp.kt` standalone compile (kotlinc 2.0.20) | OK |
| TOTP tests (13 naye + 10 purane) | 23/23 PASS |
| `TotpEditorViewModel` stubs ke saath compile + 17 behaviour checks | 17/17 PASS |
| Baaki 8 badli Kotlin files (Compose / Hilt / use case / test) | sirf syntax check: 0 syntax-class error; **type-check NAHI ho saka** (Android + coroutines libraries nahi) |
| EN vs HI strings | 1004 / 1004, 0 missing; code me use hue sab `R.string.*` EN me maujood |
| Extension code | is pass me badla nahi (PASS7 jaisa) |
| Gradle `assembleDebug` / `testDebugUnitTest` / `lint` / `assembleRelease` | **NOT RUN** |
| Real device (delete flow, Logcat, QR) | **NOT RUN** |

**Zaroori:** pehle Gradle build chalao (compile errors ho sakte hain — sandbox me sirf syntax + pure-logic verify hua). Delete fix ke liye device par spec sec 76 wala test (delete -> Vault -> 10 sec -> navigate -> lock/unlock -> reopen) karke Logcat bhejna.

### E. Sandbox tools
`android/tools/sandbox-kotlin/` (Gradle ka hissa nahi): JUnit shim, stubs, ViewModel harness, `run.sh` — kotlinc 2.0.20 se upar ke Totp / VM checks dobara chalane ke liye.

## 0.7 Pass #7 (2026-10-09) — user ka updated EXTENSION review + 3 bug fix + source merge

**Source:** user ne `EXTENSION.zip` (CHROME-EXTENSION + FIREFOX-EXTENSION, v5.43.2) diya aur kaha: update sahi ho to `BSRPRO-PASS6-ALL-IN-ONE` source aur saare documents me merge karke ek zip do. Review: 14 runtime files ka PASS6 se diff, `node --check` har `.js`, 11 purani QA scripts, aur naya `qa-pass7-fixes.js`. Review me 2 asli regression mile, isliye pehle fix + user ki permission, phir merge.

### A. User ke update me jo sahi nikla (merge ho gaya)
| Area | Files | Detail |
|---|---|---|
| Brand parity | `popup/passwords/settings/setup/sidepanel/share/emergency.html` | `bsrpro-brand-parity` style block (purple/gold tokens, focus ring, Devanagari font); sidepanel title/brand = "BabaSitaRam Pro"; version text v5.43.2 |
| Website / App Logins sections | `popup.html/js` | Popup me "Website" aur "App Logins" tab + counts; search me `appName` / package |
| App Login filter + grouping | `passwords.html/js` | "Website Login" / "App Login" chips; Login filter sirf website; app entries `app://package` group, 📱 icon, "Copy package name" |
| Bulk move (target) | `passwords.html/js` | Move picker me Website Login / App Login (category alag dimension, `category` nahi badalti); read-back verification |
| CSV / JSON round-trip | `src/import-export.js` | Header-based CSV parse (`app_name`, `app_package`, `login_uri`, `target`, `type`, ...); JSON import poora entry object rakhta hai; appName title preserve (technical title par) |
| Save origin match | `src/background.js`, `src/content.js` | `VERIFY_*` ab `location.href` bhejta hai; stored URL me scheme/port ho to exact origin match (hostname-only legacy records chalte rahte hain) |
| Sensitive PIN target | `src/background.js`, `src/content.js` | UPI / mPIN / wallet / ATM / card / transaction / net-banking PIN jaise targets par auto-save/update band (explicit in-app entry chahiye) |
| Single Master Password (import/setup) | `src/import-export.js`, `setup.html/js` | Unlocked session me import par dobara password nahi; Setup me alag backup-password box nahi, "Complete Setup" wahi Master Password se decrypt karta hai |
| Restore title | `setup.js` | Technical title (package / URL) par `appName` use hota hai; custom title kabhi overwrite nahi |

### B. Review me mile bugs (user ki permission se FIXED, source)
| # | File | Issue | Fix | Logic |
|---|---|---|---|---|
| 1 | `src/entry-target.js` | **Naya `legacyPackageFromEntry` hostname ko package maan leta tha.** Regex `^[A-Za-z0-9_]+(\.[A-Za-z0-9_]+)+$` `github.com` / `example.co.in` se bhi match karta hai. Purane website logins (url=`github.com`, title=`github.com`) "App Login" ban jate, website autofill band. `type=app` aur "appPackage + https url" (linked) bhi app ban jate. `qa-fixes-audit` ke 2 check FAIL (`old type=app is NOT interpreted...`, `linked web+app kept`). | PASS6 wali `kindOf` / `packageOf` wapas: kind sirf explicit `target.kind`, `androidapp://`, ya (package + khali url). Hostname / title / purana `type` se package kabhi infer nahi hota. | `TARGET_KIND_MODEL.md` 1.1 / 1.2: "URL se packageName nahi banta", "purane `type` interpret nahi hote". `com.jio.jpp1` aur `github.com` regex se alag nahi kiye ja sakte, isliye guess hata diya. |
| 2 | `src/background.js` | `VERIFY_AND_SILENT_SAVE` me `const domain` hata di gayi, par nayi entry banate waqt `domain` ab bhi use hoti hai => `ReferenceError`, naya password silently save nahi hota. | `domain` wapas define (`msg.url` se host, `[/?#]` par split). | Sirf wahi variable restore; baaki nayi origin-match logic jaisi hai. |
| 3 | `src/import-export.js`, `setup.js`, `passwords.js` | Import / restore / bulk-move bhi wahi guess karte the: title==url ya sirf title package-jaisa => app; appPackage + url => app. Bulk move "App Login" title ko package bana deta tha. | Rule Android `ImportParser` jaisa: **appPackage + khali url (ya `androidapp://`) = App Login; url ho to Website.** Explicit `target.kind` hamesha jeetta hai. Bulk move me package na mile to user se poocha jata hai (title se nahi). | Android aur Extension ek hi rule; Android CSV me `target` column nahi hota, isliye yahi rule use hota hai. |

### C. Jo user ne rakha (design, jaisa hai waisa) — sach / limits
- **Import / Setup me sirf current Master Password.** Kisi *dusre ya purane* master password se bane backup ko dobara password dene ka rasta nahi (unlocked session me prompt aata hi nahi; Setup me alag box nahi). Workaround: Setup me us backup wala master password rakho, ya Android me restore karke export dobara karo. Agar chaho to fallback prompt baad me add ho sakta hai (abhi nahi kiya, user decision).
- **Sensitive-target block regex-based hai** (`upi`, `mpin`, `wallet pin`, `atm pin`, `card pin`, `transaction pin`, `net banking pin` — title / username / URL / page ke 80 elements ka text). False positive ho sakta hai (aisa page jisme ye shabd hon); tab auto-save/update band rehta hai aur toast aata hai.
- `GET_SESSION` extension pages ko `masterPassword` deta hai (PASS6 se hi, `_isExtensionPage` se gated). Isme koi badlaav nahi; EXT-05 ka purana note jaisa hai.
- `content.js` ab `location.href` bhejta hai par naya entry `fullUrl` (sirf origin) se banta hai, isliye query-string / token storage me nahi jata.
- Move to App Login `url` khali kar deta hai (target XOR); wapas Website karne ke liye URL dena padega (poochha jata hai).

### D. Test ledger (pass #7)
| Check | Result (mere sandbox me) |
|---|---|
| `node --check` har extension `.js` (Chrome + Firefox) | 0 error |
| User ka raw update + purani QA | `qa-fixes-audit` **2 FAIL** (Bug 1), baaki PASS |
| Fix ke baad 11 purani QA | batch6 6, e1-bsrz1 12, ext-integration 63, ext04 20, ext05 21, ext10 11, ext14 13, ext15 6, fixes-audit 19, list-hidden 10, target-backup 10 — **sab PASS, 0 FAIL** |
| Naya `qa-pass7-fixes.js` | fix ke baad **16/16 PASS**; user ke raw update par **8 FAIL** (yani test asli bug pakadta hai) |
| Chrome vs Firefox code | manifest ke alawa identical |

**Abhi bhi NOT RUN:** asli Chrome/Firefox me load, `web-ext lint`, content.js asli pages par, Android Gradle `assembleDebug` + `testDebugUnitTest`, device test, live Android<->Extension backup round-trip. **10-Clean-Loop: 0/10.** Android code is pass me badla nahi gaya (sirf docs sync).

### E. Is pass me badli files
Extension: `src/entry-target.js` (PASS6 logic wapas), `src/background.js`, `src/content.js`, `src/import-export.js`, `setup.js`, `setup.html`, `passwords.js`, `passwords.html`, `popup.js`, `popup.html`, `settings.html`, `sidepanel.html`, `share.html`, `emergency.html`; naya `qa-pass7-fixes.js`. Docs: yeh file, `CHANGELOG_PASS7.md` (naya), `TARGET_KIND_MODEL.md` (sec 4), `EXTENSION-FINAL-REPORT.md`, `README.txt`.

## 0.6 Pass #6 (2026-10-08) — pehla ASLI Gradle build (user ne CI par chalaya)

**Evidence (user ka Gradle log, GitHub Actions):** `:app:compileDebugKotlin FAILED` — 4 error lines, 2 root causes. Dono **originally uploaded source me pehle se the** (pass #1 wali `BSRPRO-Android-v1_0_3-AUTOFILL-TRANSACTION-FIX-SOURCE.zip` me bhi `AutofillParser.resolve` ka wahi code hai); mere ya PASS2-5 ke edits se nahi aaye. Isse yeh bhi sabit hua ki `all_fixes_regression.py` / `bracket_check.py` (source-text checks) compile errors nahi pakadte.

| # | File:line | Error | Root cause | Fix |
|---|---|---|---|---|
| 1 | `autofill/AutofillParser.kt:138,139,143` | `Pair<T, FieldHints>` mila, `FieldHints` chahiye | `resolve(items: List<Pair<T, FieldHints>>)` ke `items.map { h -> ... }` me `h` poora Pair tha, par `Words.of(h)`, `classify(h)`, `isGenericTransactionContact(words, h)` FieldHints lete hain | lambda me `val h = item.second` |
| 2 | `data/local/blob/VaultBlobStore.kt:178` | `Mac.update` ke koi candidate applicable nahi | `mac.update(QUICK_KEY_VERSION.toInt())`: `Mac.update` sirf `Byte` / `ByteArray` / `ByteBuffer` leta hai, `Int` nahi | `mac.update(QUICK_KEY_VERSION)` (Byte) |

**Is log se jo nayi jaankari mili:** compile ke dauran meri pass-5 ki nayi Kotlin files (`PendingSaveStore.kt`, `PendingSavePersistence.kt`, `BsrApplication.kt`) par **koi error report nahi hua**. Par Kotlin ke baad ke phases (baaki modules, `compileDebugUnitTestKotlin`, `testDebugUnitTest`, R8, lint, device) abhi chale nahi: yeh "no error in reported log", poora PASS nahi.

**Status:** 2 compile errors FIXED (source). Rebuild + `testDebugUnitTest` ka naya log chahiye. Android build abhi bhi **NOT VERIFIED** jab tak poora `assembleDebug` + `testDebugUnitTest` green na ho.

## 0.5 Pass #5 (2026-10-08) — remaining list ka final sweep + independent re-verification

**Source:** user ne `BSRPRO-Extension-FULL-SOURCE.zip` (PASS4 bundle) bheja aur kaha: addendum ki baaki list poori karo, final result do. Pehle PASS4 ke claims ko maine apne sandbox me dobara chalaya (neeche), phir baaki items kiye.

### A. PASS4 claims ka independent re-run (pass #5 se pehle)
| Check | Result (mere sandbox me) |
|---|---|
| `node --check` har extension `.js` | 0 error |
| 9 QA scripts (`qa-batch6` 7 PASS-lines, `qa-e1-bsrz1` 12, `qa-ext-integration` 63, `qa-ext04-key-cache` 20, `qa-ext05-pin` 21 + 1 SKIP, `qa-ext10-content` 11, `qa-ext14-crypto-dedupe` 13, `qa-fixes-audit` 19, `qa-target-backup` 10) | sab exit 0, 0 FAIL — PASS4 ledger se match |
| Android `all_fixes_regression.py` / `bracket_check.py` | 78/78 / 0 issues (source-text only) |

### B. Pass #5 ke naye fixes
| ID | Status | Detail |
|---|---|---|
| EXT-06 (hidden-vault list/view) | **FIXED (source)** | Faisla (safest default, Android ke saath consistent: Android Vault list me hidden-vault dikhata hi nahi): extension popup / passwords page / sidepanel list aur stats me `hidden-vault` tag wali entries nahi dikhti. **Sirf display-level filter** (`EntryTarget.isListHidden`); `allEntries`/save path poori array rakhta hai, isliye backup me data jas ka tas. Test: `qa-list-hidden.js` 10/10. |
| **EXT-16 (naya)** Android Bin extension me | **FIXED (source)** | Issue: popup/passwords list sirf `e.deleted` dekhti thi, Android ki `deletedAt>0` entries extension me normal active dikhti thi (autofill me pehle se filtered tha). Fix: wahi `isListHidden` (`deletedAt>0`) list + stats me. Data delete nahi. |
| **EXT-15 (naya, HIGH)** breach-check cache | **FIXED (source)** | Issue: `hibp_cache_v1` har checked password ka poora unsalted **SHA-1** `chrome.storage.local` me rakhta tha (breach=0 wale unique passwords ka bhi, 24h TTL, expired entry kabhi delete nahi) -> disk par vault encryption (PBKDF2 600k) ke bahar fast-crackable hash. Fix: cache sirf `storage.session` (memory, browser restart par saaf), purana local key ek baar remove, expired entries trim. Test: `qa-ext15-hibp.js` 5/5. Note: breach check abhi bhi health panel kholte hi apne aap chalta hai (k-anonymity: sirf 5-char hash prefix jata hai). |
| Firefox `data_collection_permissions` | **DONE (decision lagayi)** | `gecko.data_collection_permissions.required = ["authenticationInfo"]` (5-char password-hash prefix `api.pwnedpasswords.com` ko jata hai => accurate declaration; `"none"` likhna galat hota). Policy faisla hai: agar aap breach check ko opt-in banana chahein to `optional` + permission gate lagega. **`web-ext lint` is sandbox me nahi hai => lint dobara NOT RUN**; `strict_min_version` 128 nahi badla (key purane Firefox me ignore hoti hai — AMO par confirm karein). |
| Hindi/English audit (Android) | **DONE (Compose/Notification literals)** | Audit: poore `java/` me hard-coded English `Text("...")`/notification strings = 11 (BinScreen 5, FileDetailScreen 3, SettingsScreen 2 Hinglish "Karan"/"Chhota summary", SaveNotifier 3). Sab `strings.xml` (`values` + `values-b+hi`, 995/995, koi duplicate nahi) me gaye (`loc_*`). Settings ke "Karan"/"Chhota summary" ab "Reason/कारण", "Short summary/संक्षिप्त सारांश". **Limit:** grep-pattern audit (Text(, text=, label=, contentDescription=, setContentTitle/Text); `Toast`, error-message `String` vars aur extension JS ke dynamic strings ka poora semantic audit NAHI hua. **Gradle compile NOT RUN** (imports `stringResource` / `R` check ki). |
| **AND-02 process-death** | **FIXED (source, Kotlin compile NOT RUN)** | `PendingSavePersistence` (interface) + `KeystorePendingPersistence` (Android Keystore AES-256-GCM, non-exportable, user-auth nahi; file `noBackupFilesDir/pending_saves.bin`, backup me nahi) + `PendingSaveStore.attachPersistence()` (restore ek baar; TTL 5 min sliding / 15 min cap restore ke baad bhi lagu; put/attach/clear/clearAll/expiry par persist ya delete). `BsrApplication.onCreate` me attach (service + activity dono same process). Keystore tabhi chhua jata hai jab pending save file maujood ho. Persistence na ho to behavior pehle jaisa (purane unit tests unchanged). Naye JVM tests: `PendingSavePersistenceTest` (6: restore, null domain/existingId round-trip, TTL after restore, clear/clearAll delete, corrupt data wipe, attach se pehle ke slots). **Honest limit:** same app-uid par chalta code Keystore key use kar sakta hai: yeh file-copy/backup/disk-image se bachata hai, compromised app process se nahi. Plaintext disk par kabhi nahi, sirf encrypted, <=15 min. |
| EXT-15b breach check opt-in | **FIXED (source)** | Health panel kholne par ab network call nahi; "Re-check" dabane par hi consent store (`hibp_optin_v1`) aur check chalta hai. Status text me batata hai ki sirf 5-char hash prefix jata hai. `qa-ext15-hibp.js` 6/6. |
| Version | 5.43.2 | dono manifests. |

### C. Jo ab bhi OPEN hai (sach)
| Item | Wajah |
|---|---|
| AND-02 | Ab B table me FIXED (source). Gradle compile / JUnit / device kill-test NOT RUN. |
| **EXT-11** share link (key+data ek URL) | Design limitation, DOCUMENTED ("link = secret"); badla nahi. |
| `all_frames` (iframe login) | Jaan-bujhkar nahi (user decision pass #2: pehle iframe origin-binding test; test 12 PASS, par asli browser test NOT RUN). |
| Chrome/Firefox asli load, `web-ext lint` (is pass me), Android Gradle build / JUnit / device / launcher-logo visual, live Android<->Extension backup round-trip, multi-tab race, content.js asli pages par | Sandbox me browser/Gradle/device nahi. |
| EXT-01 / EXT-02 | Source me FIXED (30 din cap / VERIFIER hata) par honest limit: extension me OS keystore nahi, isliye remember-me aur PIN abhi bhi obfuscation-level hain (docs: `EXTENSION_THREAT_MODEL.md`). |
| **10-Clean-Loop** | **0/10. FINAL PASS NAHI** (compile / browser / device runs ke bina clean cycle ginti nahi ho sakti). |

### D. Test ledger (pass #5, naye code ke baad)
`node --check` sab OK | 11 QA scripts (purane 9 + `qa-ext15-hibp` + `qa-list-hidden`) sab exit 0, 0 FAIL | Android `bracket_check` 0 issues, `all_fixes_regression` 78/78 (source-text) | strings.xml en/hi key parity 995/995.

### E. Changed files (pass #5)
Extension: `src/entry-target.js`, `popup.js`, `passwords.js`, `sidepanel.js`, `manifest.json`, `manifest.firefox.json`, `qa-list-hidden.js` (new), `qa-ext15-hibp.js` (new). Android: `PendingSavePersistence.kt` (new), `PendingSaveStore.kt`, `BsrApplication.kt`, `PendingSavePersistenceTest.kt` (new), `BinScreen.kt`, `FileDetailScreen.kt`, `SettingsScreen.kt`, `SaveNotifier.kt`, `values/strings.xml`, `values-b+hi/strings.xml`.

## 0.4 Pass #4 (2026-10-08) — naya logo + alag packaging

**User decision (source: user message):** `premium_devotional_brand_pack_final.zip` ka logo sab jagah lage; Chrome extension zip, Firefox extension zip aur Android zip alag-alag, teeno ek bundle me; saare documents update.

| Item | Status (pass #4) |
|---|---|
| Logo — Extension | DONE (source). `icons/icon16/48/128.png` pack ke `favicon-16/48/128` se badle, naya `icons/icon32.png` (pack `favicon-32`). Dono manifests (`manifest.json`, `manifest.firefox.json`) ke `icons` me `"32"` jora. Popup/passwords/settings/setup/sidepanel HTML `icons/icon128.png` hi use karte hain, isliye wahan bhi naya logo. `branding/` folder me master + 1024/512/256/192/180 PNG. |
| Logo — Android | DONE (source). `drawable-nodpi/brand_logo.png` (256) = pack `logo-256`; `mipmap-{m,h,xh,xxh,xxxh}dpi/ic_launcher_foreground.png` master-transparent se banaye (108/162/216/324/432 px canvas, logo = 64% => adaptive-icon safe zone ke andar). Background colour (`ic_launcher_background` + teal/orange/blue alias) nahi badle. Circle-mask preview dekha (ThemedIcon / monochrome layer pehle bhi nahi tha, abhi bhi nahi). `branding/` folder me master + PNG. Kotlin/XML code nahi badla (`brand_logo` kai screens me `clip(shapes.small)` ke saath dikhta hai: circular logo ke kone transparent hain, isliye koi kata hua nahi dikhega, par device par visual check NOT RUN). |
| Brand pack ke `extension/`, `android_project/`, `website/` | Use NAHI kiye: yeh chhote starter stubs hain (apna manifest/gradle), BSRPRO ke asli code ko replace nahi karne chahiye. Sirf PNG assets liye. |
| Packaging | Chrome zip (runtime files, `manifest.json`), Firefox zip (runtime files, `manifest.firefox.json` => `manifest.json`), Android source zip, aur `Extension-QA-and-Docs/` (qa-*.js, fixtures, docs) — sab ek bundle zip me. Har zip ke manifest me likhi har file zip me hone ki jaanch script se hui. |
| Tests | Logo badalne ke baad extension ke 9 QA scripts dobara chalaye, `web-ext lint` Firefox zip par dobara chalaya, Android `all_fixes_regression.py` dobara chalayi (natije neeche ledger me). |

### Pass #4 ledger (logo badalne ke baad dobara chala)
| Check | Result |
|---|---|
| `qa-batch6`, `qa-e1-bsrz1` (12), `qa-ext-integration` (63), `qa-ext04-key-cache` (20), `qa-ext05-pin` (21 + 1 SKIP), `qa-ext10-content` (11), `qa-ext14-crypto-dedupe` (13), `qa-target-backup` (10), `qa-fixes-audit` | sab exit 0, 0 FAIL |
| Android `all_fixes_regression.py` | 78/78 (source-text, compile nahi) |
| Android `bracket_check.py` | 0 issues |
| Zip manifest-reference check + `web-ext lint` (Firefox zip) | neeche "Packaging result" me |

### Packaging result (pass #4)
| Zip | Check | Result |
|---|---|---|
| Chrome | manifest + HTML ki 33 referenced files zip me; `node --check` har `.js` | 0 missing, 0 syntax error |
| Firefox | 34 referenced files; `web-ext lint` | 0 missing; 0 errors, 13 warnings (12 `UNSAFE_VAR_ASSIGNMENT` + 1 `MISSING_DATA_COLLECTION_PERMISSIONS`, decision pending) |
| Chrome manifest par `web-ext lint` | sirf jaankari ke liye | 2 "errors" (`service_worker` fallback, gecko `id`): yeh Firefox ke niyam hain, isiliye Chrome aur Firefox zip alag hain |
| Android | zip banaya; Gradle | NOT RUN |
Bundle: `BSRPRO-PASS4-ALL-IN-ONE.zip` = Chrome zip + Firefox zip + Android source zip + Extension FULL source (QA ke saath) + `Documents/`. Chrome/Firefox zip me `qa-*.js`, `docs`, `fixtures`, `branding` nahi hain (store ke liye sirf runtime files).

### NOT RUN (pass #4, sach)
- Chrome/Firefox me asli load aur toolbar/popup me logo ka visual check.
- Android build + launcher/splash/autofill dropdown par logo ka device check.
- Play Store / AMO listing graphics (512 PNG `branding/` me hai, par listing ka submission/policy check nahi hua).

## 0.3 Fix pass #3 (2026-10-08) — baki bache items

| ID | Status (pass #3) |
|---|---|
| EXT-14 | **Duplicate crypto FIXED (source).** `background.js` ka inline `importCrypto` (V3/V4 + encrypt/decrypt/verifyMaster ki dusri copy) hata; ab global `VaultCrypto` (`src/crypto.js`) hi use hota hai. `background.js` me sirf EXT-04 ke cached-key `encryptVault/decryptVault` bache (format wahi: `salt16‖iv12‖ct`). `crypto.js` ne `deriveKey` export kiya. Chrome: `importScripts('crypto.js', ...)` sabse pehle; Firefox: `manifest.firefox.json` `background.scripts` me `src/crypto.js` `background.js` se pehle. `crypto.js` load na ho to saaf error (silent fail nahi). Silent catches pass #2 me ho chuke. Test: `qa-ext14-crypto-dedupe.js` 13/13 (background<->page interop V3/V4/vault blob/canary). |
| EXT-07 | **Polyfill item CLOSED (code-evidence).** `browser-polyfill.js` kisi HTML/manifest me load hi nahi hota (grep: 0 references) aur extension ka poora code callback + `chrome.runtime.lastError` style me hai, jo Firefox ke `chrome.*` namespace par bhi chalta hai; isliye promise-wrapping ki zaroorat nahi. (Yeh code-padh kar nikala nishkarsh hai, Firefox me chalaya nahi.) `web-ext lint` (naya version): **0 errors**, 12 `UNSAFE_VAR_ASSIGNMENT` (pehle jaise) + 1 naya `MISSING_DATA_COLLECTION_PERMISSIONS`. **Asli Firefox me load abhi bhi NOT RUN.** |

**NAYA DECISION chahiye (maine nahi badla):** `MISSING_DATA_COLLECTION_PERMISSIONS` — Firefox naye extensions se `browser_specific_settings.gecko.data_collection_permissions` maangta hai. `passwords.js` (breach check) `api.pwnedpasswords.com/range/<5-char hash prefix>` ko call karta hai (k-anonymity). Yeh "none" kehna sahi hai ya nahi, yeh product/privacy-policy faisla hai: user bataye, tab manifest me likhunga.

**Abhi bhi OPEN (jaan-bujhkar nahi kiya, wajah ke saath):**
- **AND-02 process-death:** Keystore-wrapped short-lived storage naya security design hai; Gradle compile/device test ke bina Android me nahi chheda. Pehle design approve karein.
- **EXT-06 hidden-vault list/view:** list/view me abhi dikhti hain (sirf autofill band) — decision pending.
- **Hindi/English audit:** poora hard-coded Kotlin/JS string audit abhi nahi hua.
- **Android Gradle build / JUnit / device**, **Chrome/Firefox asli load**, **content.js asli pages par**: NOT RUN (sandbox me Gradle/browser nahi).
- **10-Clean-Loop: abhi bhi 0/10. FINAL PASS NAHI.**

### Test evidence ledger (pass #3)
| Check | Result |
|---|---|
| `node --check` `src/background.js`, `src/crypto.js` | OK |
| `qa-ext14-crypto-dedupe.js` (naya) | 13/13 |
| `qa-ext04-key-cache.js` (harness ab `VaultCrypto` inject karta hai) | 20/20 |
| `qa-ext-integration.js` (Chrome importScripts + Firefox order dono) | 63/63 |
| `qa-batch6`, `qa-e1-bsrz1` (12), `qa-ext10-content` (11), `qa-target-backup` (10), `qa-fixes-audit` | PASS |
| `qa-ext05-pin.js` | 21/21 (legacy-compat case SKIP: `OLD_PIN_JS` set nahi; pass #2 me ye 26 kehkar likha tha, ye 21+SKIP hai) |
| `web-ext lint` | 0 errors, 13 warnings (upar) |

### Changed files (pass #3)
Extension: `src/background.js`, `src/crypto.js`, `manifest.firefox.json`, `qa-ext04-key-cache.js`, `qa-ext14-crypto-dedupe.js` (new), docs. Android: koi code change nahi.

---

## 0.2 Fix pass #2 (2026-10-08) — user decisions ke saath

**User decisions (source: user message):** product launch nahi hua -> koi migration / grandfather / notice nahi. Entry = `type:"login"` + `target.kind` (`website`->origin, `android_package`->packageName); backup format ek; AND-06 naya versioned blob, purana reader nahi; EXT-01 sirf 30 din; EXT-12 cap 1000 configurable; EXT-10 `all_frames` abhi nahi (pehle iframe origin-binding test); EXT-07 Firefox script order; Android par website + app dono autofill, Extension par sirf website autofill; har platform par do sections (Website logins / App logins).
Detail: `docs/TARGET_KIND_MODEL.md`, `docs/EXTENSION_THREAT_MODEL.md`.

| ID | Status (pass #2) |
|---|---|
| X-01 | E1 BSRZ1 reader FIXED (Kotlin `pack()` se bana fixture 12/12). E12: naye extension logins `type:"login"` + `target.kind:"website"` (user decision ne `type:"website"` ko replace kiya). COMPRESS_EXPORT false hi rakha (backup format ek). |
| EXT-01 | FIXED (source) - fixed 30 din, selector hata; honest limit: ab bhi obfuscation, docs me likha. Integration test PASS. |
| EXT-02 | FIXED (source) - VERIFIER hata; PIN offline-guess limit docs me. 26/26 PASS (purane pin.js state ke saath bhi). |
| EXT-04 | FIXED (source) - key cache, 20/20 PASS (save ~191 ms -> ~0.1 ms). |
| EXT-05 | FIXED (source) - `PIN_UNLOCK` background me, `pinVerified` hata. |
| EXT-06 | FIXED (source) - hidden-vault tag autofill se bahar (case-insensitive) + target.kind routing. List/view me hidden-vault entries abhi bhi dikhti hain (sirf autofill band). |
| EXT-07 | PARTIAL - manifest.firefox.json order set (+ history-policy, entry-target); background.js Firefox-order me vm me load + PIN unlock PASS; `web-ext lint` 0 errors (12 warnings original me bhi). **Asli Firefox me load NOT RUN.** Polyfill promise-wrapping OPEN. |
| EXT-10 | FIXED (source) - debounce (120 ms, max-wait 600), 200 ms/500 ms polling hata (event-driven); iframe/origin binding test 12 PASS. `all_frames` NAHI lagaya. Asli page par browser test NOT RUN. |
| EXT-11 | DOCUMENTED - "link = secret"; design badla nahi. share.html browser test NOT RUN. |
| EXT-12 | FIXED (source) - cap 1000, settings me configurable (10..10000), oldest trim. |
| EXT-13 | FIXED - comment sach kiya, `storage.session` TRUSTED_CONTEXTS. |
| EXT-14 | PARTIAL - 28 silent catch (background.js) ab debug-gated `_warn`; decrypt length validation. Duplicate crypto (background `importCrypto` vs `crypto.js`) abhi OPEN. |
| AND-02 | FIXED (source) - sliding TTL 5 min (absolute cap 15), 3-slot queue, **manual lock par clear** (Auto / Session expired par nahi: items locked state me hi bante hain). Process-death OPEN. |
| AND-04 | FIXED (source) - `SafeRegex` (length cap, nested-quantifier filter, 20 ms time-box), `PublicSuffix` (compact approximation, poori PSL nahi). |
| AND-05 | FIXED (source) - `isAppLogin` ab `target.kind` se; `AppLoginTypeTest` naye model par likha. |
| AND-06 | FIXED (source) - quick-key blob v2: `version(1)‖salt‖key‖HMAC(key,"BSRPRO-QUICKKEY-FP"‖ver‖salt)`; password se bana koi fast hash disk par nahi; purana layout reject (reader nahi). Trade-off: prime waqt password-binding nahi, caller (biometric ke baad Keystore password) par trust. |

### Issue -> Fix -> Logic (pass #2, naye / badle items)

**Target model (Android + Extension)** — Issue: linked (website+app) + `type` + data se ambiguous routing, `androidapp://` URL package se banta tha, import me alag packages "duplicate" ho jate the (data drop). Fix: `target.kind` routing, editor `type="login"`, `loginUri` kabhi synthesize nahi, extension `EntryTarget`, `deduplicateImport` package-identity. Logic: ek login = ek target; URL<->package kabhi mix nahi. Regression risk: editor me linked picker hata; purani both-field entry re-save par ek target bachta hai.

**AND-04 regex/PSL** — Issue: user/backup ka `autofillRegex` FillRequest me ReDoS; entry `github.io` har `*.github.io` se RELATED. Fix: SafeRegex + PublicSuffix. Logic: static filter sirf classic nested forms pakadta hai (JDK 21 `(a|aa)+` khud memoize karta hai); asli guarantee 20 ms time-box: `(.*a){25}` unguarded ~800-1000 ms, guarded ~20 ms. Known false positive: `(\.[a-z]+)+\.com` reject hota hai (URL match phir bhi kaam karta hai).

**AND-02 pending saves** — Issue: ek hi slot, fixed TTL, doosra login pehle ko overwrite. Fix: queue + sliding TTL. Logic: `peek()` newest, `clear()` sirf consumed slot.

**Hindi/English mix** — Issue: Android `values-b+hi` me `filter_website`, `filter_mobile_app` missing (filter chips English me dikhte the) aur counts line hard-coded English; extension me naye strings. Fix: do strings + `list_summary_counts` resource; extension naye labels `data-en/data-hi`. Logic: baaki 979/981 Hindi strings pehle se the. **Poora hard-coded Kotlin/JS English audit NAHI hua.**

**Bug jo pass #2 me mila** — `deduplicateImport` (extension): do alag app logins (alag package, same username, khali URL) ek-dusre ke duplicate ban jate the -> fixed + test.

### Test evidence ledger (pass #2) — kya chala
| Check | Result |
|---|---|
| `node --check` ext ki har `.js` | 0 syntax issues |
| `qa-batch6-backup-compatibility.js` | 6/6 PASS (harness ab shared modules production jaise load karta hai) |
| `qa-fixes-audit.js` | 19/19 PASS (purana `type=app skipped` assertion naye model par badla: old `type` ab interpret nahi hota) |
| `qa-ext04-key-cache.js` | 20/20 |
| `qa-ext05-pin.js` | 26/26 (legacy pin.js state compat) |
| `qa-ext-integration.js` | 63/63 (background.js vm me: Firefox-order + Chrome importScripts) |
| `qa-ext10-content.js` | 11/11 |
| `qa-e1-bsrz1.js` | 12/12 (Kotlin se bana fixture, zip-bomb, damaged) |
| `qa-target-backup.js` | 10/10 |
| Android `bracket_check.py`, `all_fixes_regression.py` | 0 issues, 78/78 (source-text) |
| Android baaki 7 audit scripts | original ke barabar (symbol/static_audit me sirf heuristic false positives) |
| Kotlin logic harness (`tools/kotlin-check`, kotlinc 2.0.21 + stubs) | 86/86 |
| `web-ext lint` (Firefox manifest) | 0 errors, 12 warnings (original me bhi) |

### NOT RUN (sach)
- **Gradle build / JUnit tests / device tests**: sandbox me Maven, Google Maven, Gradle distribution 403 hain. Naye JUnit tests (`AppLoginTypeTest`, `PendingSaveStoreTest`, `SafeRegexTest`, `PublicSuffixTest`, `LockClearsPendingSavesTest`, `AutofillMatcherTargetRoutingTest`, `FileVaultBlobStoreTest` ke naye cases) likhe gaye par chale nahi; unka logic harness se mirror hua.
- Compile-checked NAHI: `EntryEditorScreen`, `VaultListScreen`, `VaultSessionUseCases` (Hilt), `ImportParser`, `AppLoginRestorePolicy`, `VaultBlobStore` — inhe maine padhkar review kiya. Gradle me pehle yahi compile karein.
- Chrome / Firefox me asli load, popup/passwords UI sections ka visual check, content.js asli pages par, multi-tab race.
- Android Hilt wiring (`LockVaultUseCase` + `PendingSaveStore`), device autofill.
**10-Clean-Loop: abhi bhi 0/10 (Gradle + browser + device clean cycle chala nahi). FINAL PASS NAHI.**

### Changed files (pass #2)
Extension: manifest.firefox.json, src/{background,content,pin,import-export}.js, src/{remember-policy,history-policy,entry-target,vault-plaintext}.js (new), popup.html/js, passwords.html/js, settings.html/js, setup.html/js, src/vault-health.js, qa-*.js (naye + 2 updated), fixtures/, docs/.
Android: VaultEntry, UrlUtils, AutofillMatcher, SafeRegex (new), PublicSuffix (new), PendingSaveStore, VaultSessionUseCases, VaultBlobStore, EntryEditorViewModel/Screen, VaultListScreen, ImportParser, AppLoginRestorePolicy, strings (en + hi), tests (above), tools/kotlin-check, docs.

## 0.1 Status summary after fix pass #1

| ID | Status |
|---|---|
| X-01 | FIXED (docs sach kiye; E2/E4 code laga) | E1 BSRZ1 reader aur E12 type:"website" OPEN |
| EXT-01 | OPEN - DECISION chahiye (code nahi badla) |
| EXT-02 | OPEN - DECISION chahiye (code nahi badla) |
| EXT-03 | FIXED (source) - race test NOT RUN |
| EXT-04 | OPEN - DECISION chahiye (key cache) |
| EXT-05 | PARTIAL - sender/GET_SESSION/pinVerified/rate-limit FIXED; PIN flow ko background me le jana OPEN |
| EXT-06 | FIXED (source, read-time filter) | hidden-vault extension decision OPEN |
| EXT-07 | PARTIAL - manifest.firefox.json bana; Firefox me load/web-ext lint NOT RUN; polyfill promise-wrapping OPEN |
| EXT-08 | FIXED (4-20, Extension + Android) - min 4 final hai ya 8, user confirm kare |
| EXT-09 | FIXED |
| EXT-10 | OPEN - DECISION chahiye (debounce, polling, all_frames) |
| EXT-11 | PARTIAL - share-inject aur web_accessible_resources hataye; share link design (key+data ek URL) OPEN; share.html browser test NOT RUN |
| EXT-12 | OPEN - DECISION chahiye (history cap) |
| EXT-13 | OPEN (low) |
| EXT-14 | PARTIAL - SET_SESSION verify ab fail-closed; duplicate crypto / silent catches OPEN |
| AND-01 | FIXED (source) - naya unit test likha, chala nahi |
| AND-02 | PARTIAL - TTL 5 min; sliding TTL, multi-slot queue, process-death OPEN |
| AND-03 | FIXED (source) - upsertAll updatedAt compare + history union; Gradle test NOT RUN, purane test assertions ka risk |
| AND-04 | OPEN - DECISION chahiye (regex guard, PSL) |
| AND-05 | OPEN (verify AppLoginTypeTest pehle) |
| AND-06 | OPEN (format change, approval chahiye) |

**Fixed (6 poore):** X-01 (docs), EXT-03, EXT-08, EXT-09, AND-01, AND-03 (+ EXT-06 ka filter).
**Partial (7):** EXT-05, EXT-07, EXT-11, EXT-14, AND-02, EXT-06 (hidden-vault), X-01 (E1/E12).
**Open (9):** EXT-01, 02, 04, 10, 12, 13; AND-04, 05, 06.

**Verified in this pass:** `node --check` (sab JS) PASS; `qa-batch6` PASS; `qa-fixes-audit.js` 14/14 PASS; Android `bracket_check` 0 issues; `all_fixes_regression.py` 78/78 (source-text only).
**NOT RUN:** Gradle build/unit tests (UtilTests clamp assertions 8->4, 256->20 badle; naya hidden-vault test joda), Chrome/Firefox load, multi-tab race, device tests.
**Changed files:** Extension: manifest.json, manifest.firefox.json (new), src/background.js, src/content.js, popup.html/js, settings.html/js, passwords.js, qa-fixes-audit.js (new). Android: AutofillMatcher, PendingSaveStore, VaultRepositoryImpl, GeneratePasswordUseCase, GeneratorScreen/ViewModel, SettingsScreen/ViewModel, EntryEditorViewModel, UtilTests, AutofillMatcherTest, docs/EXTENSION_UPDATE.md.
**10-Clean-Loop: 0/10. FINAL PASS nahi.**

---

## 1. Test evidence ledger (kya chala, kya nahi)

**Actually chala (is sandbox me):**
1. `node --check` extension ki har `.js` file par: koi syntax error nahi.
2. `node qa-batch6-backup-compatibility.js`: 6/6 PASS (canonical V3, manual V3, canonical V4, legacy AES-GCM 100000/310000/600000).
3. `tools/all_fixes_regression.py` (Android): 78/78 PASS. Yeh **source-text checks** hain, compile ya runtime test nahi.
4. `tools/bracket_check.py`: 0 issues.
5. HTML me inline `<script>` / inline `on*=` handler grep: koi nahi mila (CSP `script-src 'self'` ke saath consistent).

**Chala par bharosemand nahi (heuristic):**
- `tools/static_audit.py` aur `tools/symbol_check.py` ki lists (~39 entries) text-matching heuristics hain; Compose/Kotlin imports ko galat flag kar sakti hain. Inhe "bug" mat maano jab tak Gradle compile fail na dikhaye.

**NAHI chala (environment limitation / is pass me scope nahi):**
- Gradle build, `testDebugUnitTest`, lint, R8, instrumented tests, koi bhi device/emulator.
- Chrome / Firefox me extension load, popup, autofill, save prompt, SPA / iframe / shadow DOM.
- Android <-> Extension live backup round-trip, golden-vector run (`tools/golden/gen.js`).
- Multi-tab race, SW termination, browser restart, offline/network failure.

**Coverage (files poori tarah nahi padhi gayin):**
- Poora padha / deep: extension `manifest.json`, `src/crypto.js`, `qa-batch6`, docs; Android `AndroidManifest.xml`, `AutofillMatcher`, `VaultAutofillService`, `PendingSaveStore`, `VaultRepositoryImpl`, `data_extraction_rules.xml`.
- Partial: extension `background.js` (~40%, baaki grep), `content.js` (~25%), `pin.js` (grep + setPin), `FileVaultBlobStore` (write path), `SecureShareActivity` (pehli ~80 lines).
- Abhi nahi padha: `popup.js`, `passwords.js`, `settings.js`, `setup.js`, `import-export.js` (sirf grep), `AutofillParser`, `AutofillDatasetFactory`, `AutofillAuthActivity`, `MainActivity`, `SessionKeyStore` (grep), `BiometricSessionKeyStore`, `RootDetector`, DI modules, backup managers, widget/tile.
- Isliye: **"no issue found" ka matlab "clean" nahi hai** in unread files ke liye.

---

## 2. Senior AI vs Local AI — kaam karne ke rules

Yeh section isliye hai ki koi bhi AI (chhota ya bada) project ko ek jaise standard par jaanche.

**Senior AI ka standard (default mode):**
1. Claim = evidence. Har "DONE / PASS" ke saath ek chali hui command, test ka naam, ya `file:line` hona chahiye. Warna status `SOURCE APPLIED, UNVERIFIED` likho.
2. Root cause pehle, fix baad me. Symptom patch (jaise sirf `applyPopupTheme` define kar dena) manzoor nahi.
3. Docs ko code ke against verify karo. Doc likha hai isliye feature hai, yeh maan'na galat hai (dekho X-01).
4. Race / crash / process-death ke liye har write path ko "beech me kat jaye to kya bachta hai?" se jaanchna.
5. Chhoti, reversible, backward-compatible change. Data delete / schema reset kabhi nahi.

**Local / chhote AI ke liye STOP rules (inme se kuch bhi ho to ruko aur user se poochho):**
- Fix.md me jo scenario nahi hai -> likho: *"Yeh scenario Fix.md me covered nahi hai. Aap kaise proceed karna chahte hain? Exact logic dijiye."* Andaza mat lagao.
- Crypto, KDF, backup header (AAD), vault blob format, DB schema, `type` field semantics, ya migration badalni pade -> **STOP**.
- Android aur Extension dono me shared contract (V3/V4, IDs, folders, history) chhuna pade -> dono clients ka impact likho, tabhi aage.
- Test chala nahi sakte -> "tested" kabhi mat likho. `NOT RUN (reason)` likho.
- Kisi file ko poora padhe bina us par "no bug" mat likho.
- Koi bhi destructive operation (delete, wipe, overwrite, reset) -> STOP.

**Zero-regression checklist (har fix ke baad):**
`node --check` | `qa-batch6` | `all_fixes_regression.py` | affected area ka unit test | Android<->Extension round-trip (jab device ho) | docs update.

---

## 3. Findings

Severity: CRITICAL / HIGH / MEDIUM / LOW. "Decision" = user ka faisla chahiye (Fix.md me nahi hai).

### X-01 — Docs bol rahe hain "DONE", extension zip me code hai hi nahi — HIGH (process + data safety)
**STATUS (fix pass #1): FIXED (docs sach kiye; E2/E4 code laga) | E1 BSRZ1 reader aur E12 type:"website" OPEN**
- **Issue:** `android/docs/EXTENSION_UPDATE.md` status table me E1 (`BSRZ1` reader, `src/vault-plaintext.js`), E2 (`_isAppLogin` + index filter), E4 (`deletedAt` skip), E12 (naye login par `type:"website"`) ko `[x]` mark karta hai. Extension v5.43.0 zip me: `src/vault-plaintext.js` maujood nahi, `_isAppLogin` 0 matches, `BSRZ1` / `DecompressionStream` 0 matches, `type:'website'` 0 matches, `deletedAt` ka koi filter background/autofill me nahi. Extension ki apni `EXTENSION-FINAL-REPORT.md` khud kehti hai ki BSRZ1 nahi hai (aur version 5.42.0 likhti hai, manifest 5.43.0 hai).
- **Impact:** Fix.md 1.1 (App vs Website separation) extension me implement nahi hai. Android ki Bin (`deletedAt>0`) entries extension me autofill ho sakti hain (EXT-06). Android me `COMPRESS_EXPORT = true` karte hi extension backup nahi padh payega.
- **Fix:** (a) Status docs ko sach karo: E1/E2/E4/E12 = `NOT IN v5.43.0`. (b) `VaultPlaintext.COMPRESS_EXPORT` abhi `false` hai (verified, `VaultPlaintext.kt:33`): isse `false` hi rakho jab tak extension reader + dono taraf interop test na ho. (c) Fix code alag items me (EXT-06) approval ke baad.
- **Logic:** Galat "DONE" sabse khatarnak hai kyunki agla AI us par bharosa karke aage badh jata hai.
- **Verification:** `grep -rn "BSRZ1\|_isAppLogin\|vault-plaintext" ext/` => abhi 0 hits; fix ke baad hits + test.

### EXT-01 — Remember-me me master password ka "encryption key" public hai — CRITICAL
**STATUS (fix pass #1): OPEN - DECISION chahiye (code nahi badla)**
- **File:** `src/background.js` ~L440-446 (restore) aur ~L648-656 (save). Key = `chrome.runtime.id`.
- **Issue:** Master password `VaultCrypto.encrypt(masterPassword, chrome.runtime.id)` se `chrome.storage.local` me rakha jata hai. Extension ID koi secret nahi hai; PBKDF2 ka salt blob me hi hota hai. Profile files padhne wala koi bhi (malware, disk copy, shared PC) master password nikal sakta hai, aur usse poora vault. "Forever" option (`36500` din) is risk ko permanent bana deta hai.
- **Fix (Decision):** Feature (browser restart ke baad bhi unlock) product behavior hai, isliye mai khud nahi badlunga. Options: (1) master password ko local storage me kabhi persist na karo; sirf `storage.session` (browser restart par saaf); (2) restart-persistence ke liye WebAuthn / Windows Hello credential se bandhi key (PRF/hmac-secret) se wrap karo; (3) agar feature rakhna hi hai: "Forever" hatao, max duration cap karo, aur UI me saaf warning do.
- **Logic:** Extension me OS keystore nahi hota; "obfuscation with known constant" encryption nahi hai. Existing users ka remembered blob migrate karte waqt sirf tab hatao jab naya mechanism kaam kar chuka ho (data delete nahi, vault blob ko chhuna nahi).
- **Regression risk:** Existing remember-me users ko ek baar dobara unlock karna padega.

### EXT-02 — PIN master password ko 6-digit PIN se wrap karta hai, offline brute-force possible — HIGH
**STATUS (fix pass #1): OPEN - DECISION chahiye (code nahi badla)**
- **File:** `src/pin.js` `setPin()` L112-126; `ITERATIONS=600000`, `MAX_ATTEMPTS=5`, `LOCK_MS=60000`.
- **Issue:** `ENC_MP` (master password, PIN-derived AES key se) + `VERIFIER` + salt, sab `chrome.storage.local` me. Lockout (5 attempts / 60s) sirf software state hai (`vault_pin_lockout`); disk-copy attacker use bypass karta hai. PIN space = 10^6 hai, har guess 600k PBKDF2. GPU par yeh ghanto ka kaam hai. Saath me `VERIFIER` ek alag oracle deta hai.
- **Fix (Decision):** PIN ko vault-unlock ke liye sirf *convenience layer* maano jo `storage.session` ya OS-bound credential (Windows Hello/WebAuthn) ke saath ho; ya PIN ko master password ke saath combine karke longer secret banao. Kam se kam: `VERIFIER` hatao (decrypt-success hi verification ho), aur doc me threat model likho.
- **Logic:** 6-digit secret + local stored ciphertext = offline attack ke saamne kamzor, chahe KDF kitna bhi bhaari ho.
- **Note:** FIXED_CODE.md (sec. 9) "PIN plaintext me store na ho" maangta hai: yeh pura hota hai. Par master password PIN-wrapped hai, isliye risk alag hai.

### EXT-03 — Vault write par koi lock nahi: lost update aur galat rollback (DATA LOSS) — HIGH
**STATUS (fix pass #1): FIXED (source) - race test NOT RUN**
- **File:** `src/background.js` `_persistVaultAtomic()` L310-331; callers L1008, L1041, L1104, L1116.
- **Issue:** Concurrent saves (do tabs, popup + content script, auto-backup/import) ke beech koi Mutex/queue nahi. Sequence: Save A `JSON.stringify` karta hai, Save B entry add karke apna blob likh deta hai, phir A ka (purana snapshot) blob B ke upar likha jata hai => B ki entry disk se gayab (memory me rehti hai, restart par khatam). Dusra: verify step `roundTrip.length !== entries.length` mismatch dikhaye to `catch` **purana `oldBlob` wapas likh deta hai**, jisse doosre save ka valid write bhi mit sakta hai.
- **Fix:** Ek single promise-chain/mutex (`_vaultWriteChain`) jo har `mutate -> persist` ko serialize kare; snapshot lock ke andar lo; rollback sirf apne hi blob par ho (current blob == apna blob ho tabhi restore); extra `.bak` copy (Android jaisa `vault.blob.bak/.bak2`).
- **Logic:** Android me yehi pattern pehle se hai (`Mutex` + write-first-then-publish + 2 backups), extension ko uske barabar laao.
- **Verification (jab ho sake):** 2 tabs se parallel save script; 50 parallel `SAVE` messages => final entry count == expected; SW kill beech me.
- **Regression risk:** Save latency order-dependent ho jayegi; EXT-04 ke saath hi karo.

### EXT-04 — Har save par 2x PBKDF2(600k): save "milliseconds" me nahi hota — HIGH (performance)
**STATUS (fix pass #1): OPEN - DECISION chahiye (key cache)**
- **File:** `src/background.js` `_persistVaultAtomic` (encrypt + verify-decrypt), `reloadMemVault`; `importCrypto()` me `deriveKey` har baar.
- **Issue:** Har save me encrypt (1 derive) + verification decrypt (1 derive) = 2 x 600k iterations service worker par; typical hardware par ~0.5-2s, slow PC par zyada. Preferences/FIXED_CODE rule: save milliseconds me ho, UI freeze na ho. Android me key cache hota hai (`FileVaultBlobStore.obtainKey`), extension me nahi.
- **Fix:** Session ke dauran derived `CryptoKey` (non-extractable) ko SW memory me salt ke saath cache karo; naye IV ke saath encrypt (blob format `salt16||iv12||ct` wahi rahega, isliye purani/nayi dono blobs readable). Verification: cached key se decrypt (extra PBKDF2 nahi). Cache lock/CLEAR_SESSION par saaf.
- **Logic:** Salt same rakhna AES-GCM me safe hai jab IV har baar random 12 byte ho. Format change nahi => backward compatible.
- **Decision:** Per-write fresh salt ki security property chahiye ya speed? (Android pehle se cache choose kar chuka hai.)

### EXT-05 — `GET_SESSION` master password plaintext me return karta hai + `pinVerified` client-supplied bypass — HIGH
**STATUS (fix pass #1): PARTIAL - sender/GET_SESSION/pinVerified/rate-limit FIXED; PIN flow ko background me le jana OPEN**
- **File:** `src/background.js` L598 (listener), L616-635 (`SET_SESSION`), L670 (`GET_SESSION`).
- **Issue:** (a) `GET_SESSION` har sender ko `{masterPassword}` deta hai, content script ko bhi (`content.js` L1790 isse sirf SW wake karne ke liye bulata hai, par response me master password aa jata hai). Content script web-page ke process me chalti hai; kisi renderer/content-script bug par master password leak. (b) `SET_SESSION` me `msg.pinVerified` message se aata hai: true hone par master verification aur failed-attempt counting dono skip; aur `_resetRateLimit()` verification se *pehle* chal jata hai. Koi bhi extension context rate-limit reset kar ke unlimited guess kar sakta hai.
- **Fix:** Listener me sender check: `sender.id === chrome.runtime.id`; sensitive messages (`GET_SESSION` value, `SET_SESSION`, exports) sirf extension pages se (`!sender.tab` aur `sender.url` extension origin se); content script ko sirf `{ok:true/false}`. `pinVerified` hatao: PIN flow background me hi verify ho aur internal function se session set kare. `_resetRateLimit()` sirf successful verify ke baad.
- **Logic:** Trust boundary content script / page ke beech hai; master password us boundary ke paar nahi jana chahiye.
- **Regression risk:** `popup.js`, `settings.js`, `sidepanel.js`, `passwords.js`, `pin.js` ke `GET_SESSION` callers ko extension-page se hi chalna hai: har caller test karo.

### EXT-06 — Extension me Login vs Website separation aur Bin filter implement nahi — HIGH
**STATUS (fix pass #1): FIXED (source, read-time filter) | hidden-vault extension decision OPEN**
- **File:** `src/background.js` `_rebuildIndex()` L283-294; `GET_ENTRIES_FOR_URL` L850+; `_credentialMatchesOrigin` L335.
- **Issue:** Index sirf `e.url` ke domain se banta hai. `type` field, `appPackage`, `deletedAt`, `isNote/recordType`, `hidden-vault` tag, `_metaType` par koi filter nahi. Android ki Bin me gayi (`deletedAt>0`) website entry extension me autofill ho sakti hai. Agar app-entry ka `url` `androidapp://<pkg>` jaisa ho to bhi index me ghus sakta hai. Naye login par `type` likha nahi jata (X-01).
- **Fix:** Ek hi helper `_isAutofillEligible(e)`: `deletedAt>0` skip, `_metaType` skip, `recordType` sirf `login`, `type==="app"` (case-insens.) ya (`type` khali + `appPackage` bhara + `url` khali) skip, `url` jo `androidapp://` se shuru ho skip. Index aur `GET_ENTRIES_FOR_URL` dono isi helper se. **Read-time filter only: data kabhi delete nahi.** Naye website login par `type:"website"` (purani entries ka `type` overwrite nahi).
- **Logic:** Android `AppLoginRestorePolicy` aur `VaultEntry.isAppLogin` ke rule se same hona chahiye, warna dono clients alag behave karenge.
- **Decision:** `hidden-vault` tagged entries extension me dikhein ya chhupein (E9, abhi pending).

### EXT-07 — Firefox: manifest load nahi hoga / features chup-chaap fail honge — HIGH (required: Firefox PASS)
**STATUS (fix pass #1): PARTIAL - manifest.firefox.json bana; Firefox me load/web-ext lint NOT RUN; polyfill promise-wrapping OPEN**
- **File:** `manifest.json`.
- **Issue:** Sirf `background.service_worker` hai (Firefox MV3 `background.scripts` / event page use karta hai), `sidePanel` permission + `side_panel` key Chrome-only hain (Firefox me `sidebar_action`), `browser_specific_settings.gecko.id` nahi hai, `minimum_chrome_version` hai. `chrome.storage.session`, `chrome.sidePanel`, `downloads`, `idle` ka behavior Firefox me alag ho sakta hai. *(Yeh knowledge se hai; Firefox yahan chala nahi, isliye latest Firefox docs se confirm karo.)*
- **Fix:** Chrome manifest ko **bilkul mat chhedo**. Alag `manifest.firefox.json` (build-time swap): `background.scripts`, `sidebar_action`, `gecko.id` + `strict_min_version`, aur feature detection (`chrome.sidePanel?.`). Code me `browser-polyfill.js` ke bharose na raho: wo sirf alias hai, promise-wrapping nahi karta.
- **Verification:** `web-ext lint` + Firefox me manual load (abhi NOT RUN).

### EXT-08 — Generator length 8-256, spec 4-20 — HIGH (spec violation, dono clients)
**STATUS (fix pass #1): FIXED (4-20, Extension + Android) - min 4 final hai ya 8, user confirm kare**
- **Files:** `popup.html` L2322 (`lenSlider 8..256`), `settings.html` L936 (`defaultLength 8..256`); Android `GeneratePasswordUseCase.kt` L63-64 (`MIN 8 / MAX 256`), `GeneratorScreen.kt` L102 (`8f..256f`).
- **Issue:** FIXED_CODE.md sec. 7: allowed range 4-20, kahin 20+ nahi. Dono clients 8-256 allow karte hain.
- **Fix:** Har platform par ek constant (`MIN=4`, `MAX=20`); UI slider, saved-settings load (clamp), aur generator function teeno me wahi constant. Existing saved passwords ko **chhuna nahi** (sirf generator). Passphrase / PIN modes ki apni range alag rahegi (PIN 4-6 Android me pehle se).
- **Logic:** Ek source-of-truth constant => contradictory range ka chance nahi.
- **Decision:** Min 4 bahut kamzor hai; kya "4-20" final hai ya min 8 chahiye? (Fix.md me confirm karo.)

### AND-01 — Android: Hidden-vault entries autofill me aa sakti hain — MEDIUM (Decision)
**STATUS (fix pass #1): FIXED (source) - naya unit test likha, chala nahi**
- **File:** `autofill/AutofillMatcher.kt` `match()`; `VaultRepositoryImpl.publish()` (`_entries` me hidden entries rehti hain).
- **Issue:** Hidden Vault (tag `hidden-vault`) ko sirf list/count se bahar rakha gaya hai, autofill me koi `isHiddenVault` check nahi. User ne entry PIN-protected Hidden Vault me rakhi, par doosre app me autofill suggest kar sakta hai.
- **Fix (Decision):** Option A: autofill me skip (privacy-first). Option B: allow, par Hidden-vault PIN maango. Fix.md me nahi hai, isliye abhi code nahi.

### AND-02 — Android: autofill se capture hui nayi credential 30 sec me chup-chaap kho sakti hai — MEDIUM (data loss)
**STATUS (fix pass #1): PARTIAL - TTL 5 min; sliding TTL, multi-slot queue, process-death OPEN**
- **File:** `autofill/PendingSaveStore.kt` (`TTL_MS = 30_000`, single slot, memory only); `VaultAutofillService.onSaveRequest`.
- **Issue:** User ne naya password daala, Android ne Save request diya; app khulne ke liye unlock (biometric/master password) chahiye. 30s me na kare, ya process kill ho, ya doosra login ho jaye (single slot overwrite) => credential bina warning ke gayab. FIXED_CODE.md sec. 5: popup practical time de.
- **Fix (Decision):** Plaintext kabhi disk par nahi (security rule rahe). Options: sliding TTL (e.g. 5 min, activity par reset) + 3-slot queue + lock par clear; process-death ke liye Keystore-wrapped short-lived storage. Notification ko tab tak rakho jab tak user dismiss na kare.
- **Logic:** "Memory only" sahi hai, par 30s unlock flow ke liye kam hai.

### AND-03 — Android import/restore merge: last-writer-wins, Bin entry zinda ho sakti hai — MEDIUM (data loss)
**STATUS (fix pass #1): FIXED (source) - upsertAll updatedAt compare + history union; Gradle test NOT RUN, purane test assertions ka risk**
- **File:** `VaultRepositoryImpl.upsertAll()`; callers `BackupUseCases.kt` L173, `AutoBackupManager.kt` L133.
- **Issue:** `merged[it.id] = incoming` bina `updatedAt` compare ke. Purana backup naye local edit ko overwrite karta hai (password history bhi us entry ki purani ho jati hai). Local Bin me padi entry (`deletedAt>0`) ko incoming `deletedAt=0` wapas zinda kar deti hai. Sirf app-login records ke liye `AppLoginRestorePolicy` bachata hai.
- **Fix (Decision):** MERGE me `local.updatedAt > incoming.updatedAt` ho to local rakho; `passwordHistory` ko `(pw, changedAt)` se union karo; REPLACE ka behavior user choice par chhodo. Contract ("Preserve imported IDs") se conflict nahi, kyunki ID wahi rehti hai.
- **Note:** Auto-import sirf khali vault par hota hai (FIX_MD_STATUS 1.3), isliye wahan risk kam; manual MERGE import me asli risk.

### AND-04 — Android autofill: user-supplied regex request path me, aur naive related-domain match — MEDIUM
**STATUS (fix pass #1): OPEN - DECISION chahiye (regex guard, PSL)**
- **File:** `AutofillMatcher.kt` `webKind()`.
- **Issue:** `autofillRegex` custom field (backup import se bhi aa sakti hai) `containsMatchIn(host)` me chalti hai FillRequest ke andar: catastrophic backtracking par request deadline cross, system request cancel (yehi purana bug 8.6 ka root tha). `RELATED` match me `endsWith(".$entryHost")` public-suffix list ke bina: entry `github.io` har `*.github.io` se match. Confirm dialog (8.2) se risk kam hai, khatam nahi.
- **Fix:** Regex length cap + nested-quantifier reject + time-boxed evaluation; related-match me PSL (registrable domain) use karo. Behavior change hai => Decision.

### EXT-09 — Page ke sessionStorage me username likha jata hai — MEDIUM (privacy)
**STATUS (fix pass #1): FIXED**
- **File:** `src/content.js` ~L2066-2073 (`sessionStorage.setItem('__vlt_u__', ...)`).
- **Issue:** Content script ka `sessionStorage` website ka hi hota hai: page ka koi bhi script email / mobile number padh sakta hai.
- **Fix:** Sirf content-script closure variable + SW (`UPDATE_LOGIN_CONTEXT`) me rakho; existing `__vlt_u__` keys ko aage padhna band karo (purane keys page ke apne session ke saath khatam ho jate hain: kuch delete karne ki zaroorat nahi).

### EXT-10 — Content script performance: unbounded polling, unthrottled scan, per-keystroke messages, iframes cover nahi — MEDIUM
**STATUS (fix pass #1): OPEN - DECISION chahiye (debounce, polling, all_frames)**
- **File:** `src/content.js` L2136 (MutationObserver -> `scan` har mutation), L2169 `setInterval(scan,200)` (load tak), L2150+ `_spaInterval` har 500ms hamesha, `input` handler har keystroke par `UPDATE_LOGIN_CONTEXT`; `manifest.json` me `all_frames` nahi.
- **Issue:** Heavy SPA par CPU, SW wakeups; iframe logins (FIXED_CODE sec. 6) par content script hi nahi chalti.
- **Fix:** `scan` ko `requestIdleCallback`/80-150ms debounce; SPA detection `history` events + observer se, polling nahi; `UPDATE_LOGIN_CONTEXT` ko blur/submit/300ms debounce; iframe ke liye `all_frames:true` **sirf tab** jab origin binding (token redeem me frame origin check) pehle test ho, warna phishing risk badhega. Decision.

### EXT-11 — Share link: key aur ciphertext ek hi URL me; share.html har site ko exposed; share-inject har page par — MEDIUM
**STATUS (fix pass #1): PARTIAL - share-inject aur web_accessible_resources hataye; share link design (key+data ek URL) OPEN; share.html browser test NOT RUN**
- **Files:** `share-inject.js` L84-90; `manifest.json` (`web_accessible_resources` `share.html` + `<all_urls>`, `content_scripts` me `share-inject.js` `<all_urls>`).
- **Issue:** `share.html#<ciphertext>|<key>`: link jisne dekha wo padh leta hai; expiry (`exp`) sirf receiver ki JS check karti hai. `share.html` ko koi bhi website embed / probe kar sakti hai (extension fingerprinting). `share-inject.js` ko har website par inject kiya ja raha hai, jabki yeh sirf `passwords.html` ke `#pwList` ke liye hai (aur wahan `passwords.html` L2152 se pehle se load hota hai).
- **Fix (safe, chhota):** `content_scripts` se `share-inject.js` hatao; `web_accessible_resources` ko hatao ya `matches` ko tight karo (agar share receiver ko woh chahiye to Decision). Share ki design limitation docs me likho: "link = secret".
- **Regression risk:** `passwords.html` ka share button test karo.

### EXT-12 — Password history cap aur silent truncate — LOW (Decision)
**STATUS (fix pass #1): OPEN - DECISION chahiye (history cap)**
- **File:** `popup.js` L2040-2044, `passwords.js` L1389-1417.
- **Issue:** `history.length = 10`, `editHistory.length = 30`: 11th change par sabse purana password history se chup-chaap hat jata hai. FIXED_CODE.md sec. 8: old password accidentally delete na ho.
- **Fix:** Cap hatao ya bada karo (size-based), ya truncate se pehle user ko batao. Backup/restore me history preserve hoti hai (import-export L521 field list me hai).

### EXT-13 — Credential-flow `generatedPassword` storage.session me; doc comment galat — LOW
**STATUS (fix pass #1): OPEN (low)**
- **File:** `background.js` L28-32, L57-60, `_persistCredentialFlow`.
- **Issue:** Comment kehta hai "No plaintext password is persisted" par generated password `chrome.storage.session` me likha jata hai. Yeh memory-only aur default trusted-contexts-only hai, to risk kam, par claim galat.
- **Fix:** Ya to password sirf SW memory me, ya comment/doc sach karo; `storage.session` ka access level explicitly `TRUSTED_CONTEXTS` set karo.

### EXT-14 — Duplicate crypto + silent catches — LOW (maintainability)
**STATUS (fix pass #1): PARTIAL - SET_SESSION verify ab fail-closed; duplicate crypto / silent catches OPEN**
- **File:** `src/crypto.js` aur `background.js` ka inline `importCrypto()` (V3/V4 helpers 2-3 baar); `importCrypto.decrypt` me length validation nahi (`crypto.js` me hai); jagah-jagah `catch {}` / `.catch(() => {})`.
- **Fix:** Ek hi module (SW me `importScripts`/static import), ek hi validation; silent catch ki jagah debug-gated log + safe-fail. `SET_SESSION` me verify ka `catch {}` fail-open nahi hona chahiye (verify throw => reject, abhi aage badh jata hai).

### AND-05 — `isAppLogin` `type` field ko ignore karta hai — LOW (verify pehle)
**STATUS (fix pass #1): OPEN (verify AppLoginTypeTest pehle)**
- **File:** `core/model/VaultEntry.kt` L58.
- **Issue:** `isAppLogin = appPackage.isNotBlank() && url.isBlank()`. EXTENSION_UPDATE E2 pehla rule `type=="app"` batata hai. `type:"app"` + `androidapp://` url wali entry website-login ginji jayegi.
- **Fix:** `type.equals("app",true) || (type.isBlank() && appPackage.isNotBlank() && url.isBlank())`; pehle `AppLoginTypeTest` aur `LinkedLoginInteropTest` padho, kyunki linked (web + app) logins ka semantics unme define hai. Steps ke bina mat badlo.

### AND-06 — Keystore-wrapped quick-unlock blob me `SHA-256(salt||password)` — LOW (verify)
**STATUS (fix pass #1): OPEN (format change, approval chahiye)**
- **File:** `data/local/blob/VaultBlobStore.kt` (`exportKeyBlob` doc).
- **Issue:** Fast hash of password blob ke andar. Keystore wrap tootne par yeh fast offline oracle banta hai.
- **Fix:** `HMAC(derivedKey, "fingerprint")` use karo (password hash ki jagah). Cache ka format change => migration chahiye => pehle approval.

---

## 4. Jo sahi nikla (verified, bina badlaav)

- Android vault write: `Mutex` + tmp-write + fsync + atomic rename + `.bak/.bak2` (`FileVaultBlobStore`), repository me "disk pehle, memory baad".
- `allowBackup=false`, `data_extraction_rules` me sab domain excluded, `usesCleartextTraffic=false`.
- `FLAG_SECURE` default ON; clipboard `IS_SENSITIVE` + 30s auto-clear.
- `AutofillAuthActivity` `exported=false`; autofill plain-http pages par skip; `NEW_PASSWORD` field me purana password fill nahi hota.
- Autofill ab `FillRequest` ke andar slow restore nahi karta (8.6/8.9 ka code-level design theek lagta hai; device test baaki).
- Extension CSP `script-src 'self'`, `object-src 'none'`; inline scripts/handlers nahi mile.
- Extension autofill capability token: 24 random bytes, 15s TTL, tab+origin bound, memory only (design theek; redeem function poori padhi nahi).
- Backup V3/V4: header AAD, 600k PBKDF2, AES-256-GCM, canonical-header check (`qa-batch6` PASS).

---

## 5. Agla kaam (user ke approval ke baad, is order me)

1. User: ek-ek item par `APPROVE / REJECT / MODIFY`, aur Decision items ka jawab (EXT-01, 02, 04, 08, 10, 11, 12; AND-01, 02, 03, 04).
2. Pehle low-risk, reversible: X-01 (docs sach), EXT-11 (share-inject hatao), EXT-09, EXT-13.
3. Phir data-safety: EXT-03 + EXT-04 saath me (ek hi writer design).
4. Phir trust boundary: EXT-05, EXT-06.
5. Phir Firefox build (EXT-07) alag manifest se.
6. Generator range (EXT-08 + Android) ek saath, dono clients me.
7. Har fix: Issue -> Root Cause -> Fix -> Test -> Re-audit. 10 consecutive clean cycles (abhi 0/10) se pehle FINAL PASS nahi.

## 6. Regression risks (summary)
- EXT-05 sender checks: kisi purane caller (`sidepanel.js`, `settings.js`) ka `GET_SESSION` toot sakta hai.
- EXT-03/04: save order aur latency badlenge; auto-backup (15s throttle) ke saath interaction test karo.
- EXT-06: filter galat ho to valid logins autofill se gayab: sirf read-time filter, delete nahi.
- EXT-07: Firefox manifest ko Chrome manifest se alag rakho warna Chrome toot sakta hai.
- AND-03: merge rule badalne se existing users ka import behavior badlega.
