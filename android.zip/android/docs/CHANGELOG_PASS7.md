# CHANGELOG PASS7 (2026-10-09)
Detail: Fix-Addendum-SENIOR-AUDIT.md section 0.7.

## User ke updated EXTENSION se merge (v5.43.2)
- Brand parity CSS + sidepanel naam "BabaSitaRam Pro"
- Popup: Website / App Logins tabs + counts; passwords: Website Login / App Login filter, app grouping, package copy
- Bulk move: Website Login / App Login (category alag)
- CSV / JSON import: Android app columns + poora entry round-trip
- Save origin match (scheme/port), sensitive PIN target auto-save band
- Import / Setup: sirf current Master Password

## Review me mile bugs (FIXED)
- entry-target.js: hostname / type=app / package+url ko app maan leta tha => PASS6 rule wapas (qa-fixes-audit 2 FAIL -> PASS)
- background.js: VERIFY_AND_SILENT_SAVE me `domain` undefined (ReferenceError) => define kiya
- import-export.js / setup.js / passwords.js: package guess hata, Android ImportParser wala rule (package + khali url = app)

## Tests
- node --check: 0 error; 11 purani QA: sab PASS; naya qa-pass7-fixes.js 16/16
- OPEN: asli browser load, Gradle, device, 10-clean-loop 0/10
