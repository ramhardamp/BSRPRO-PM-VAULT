# CHANGELOG PASS9 (2026-10-09) — source patch on top of PASS8

Status for everything below: **FIXED IN SOURCE — NOT COMPILED, NOT DEVICE-TESTED** (no Gradle / SDK / device in the sandbox).

## F-01 Mobiles: "Select all" did nothing, so "select all -> delete" never worked
- Root cause: `MobilesViewModel.toggleSelectAll()` read `selectableIds.value`. `selectableIds` is a `stateIn(WhileSubscribed)`
  flow that no screen collects, so `.value` is always the initial `emptySet()` and the function returned early.
- Fix: `toggleSelectAll()` now uses `visibleEntries.value` (collected by `MobilesScreen`); the unused `selectableIds` was removed.
- Also: bulk delete now uses one `softDeleteAll(ids)` (same as Vault list) and queues `autoBackup.requestBackup()` after
  success; single delete queues a backup too (Mobiles deletes never requested a backup before).
  `MobilesViewModel` gets one new constructor dependency (`AutoBackupManager`, Hilt-provided).

## F-02 Vault list: "New entry" FAB floated over the Favourite button in selection mode
- Root cause: the FAB is in `VaultNavHost`'s Scaffold (outside `VaultListScreen`) and was shown whenever `route == LIST`.
- Fix: `VaultListScreen(onSelectionModeChange)` reports selection mode; `VaultNavHost` hides the FAB while selecting.

## A-10 TOTP QR scan (CameraX + ZXing `QRCodeReader`, QR only, fully offline)
- Decision: ZXing (already a dependency) instead of ML Kit. No new network traffic / Google SDK; privacy text stays "offline-first".
- New: `QrScannerOverlay.kt`; "Scan QR code" button in `TotpEditorScreen`; result goes through existing
  `TotpEditorViewModel.setSecret()` -> `Totp.parseStrict` (A-11), so HOTP / bad algorithm / digits / period are rejected normally
  and SHA256 / 8-digit / 60 s links fill the full config.
- Decoder: Y (luminance) plane at ~720p, `TRY_HARDER`, second attempt on the inverted image (dark-mode screens).
- Manifest: `CAMERA` + `uses-feature camera / autofocus required=false`. Runtime permission with "Allow" and "Open app settings".
- Deps added: CameraX 1.3.4 (core, camera2, lifecycle, view). `zxing-core` now also used for scanning.
- Strings: 9 new `totp_scan_*` keys, EN + HI. Privacy text has one sentence on camera use; licences list CameraX.
- No frame saved, no QR text / secret logged.
- Known limit: ZXing is weaker than ML Kit on blurry / low-light / damaged QR; screen-shown TOTP QR codes are normally fine.

## Verify on device (manual)
1. Mobiles: long-press one row -> top bar "Select all" -> all rows tick -> Delete -> confirm -> rows gone, Bin has them.
2. Mobiles: filter "Starred" -> Select all selects only starred rows.
3. Vault list: long-press -> new-entry "+" disappears; Favourite / Share / Delete all tappable; exit selection -> "+" returns.
4. TOTP -> New -> Scan QR: permission prompt; scan SHA1/6/30, SHA256/8/60 and an HOTP QR; a normal website QR shows "not a 2FA code".
5. Deny camera permanently -> "Open app settings" works; granting there and returning shows the camera.

## Pre-build static audit (sandbox, no Gradle)
Checked and OK:
- CI scripts `production_polish_audit.py`, `brand_theme_audit.py`, `phase_smart_session_audit.py`: PASS (original and patched).
- XML valid (manifest, strings EN + HI); 857 `R.string.*` references all exist; EN and HI keys identical (0 missing either way).
- Brace/paren balance of all 6 changed Kotlin files; project-internal imports resolve (3 flagged names are `tailrec fun` / generated `BuildConfig`, pre-existing).
- `AutoBackupManager` is `@Singleton @Inject` (needed by new `MobilesViewModel` constructor); no test constructs `MobilesViewModel`.
- Same "uncollected StateFlow `.value`" bug scanned in every ViewModel: no other occurrence.
- No leftover ML Kit / `@ExperimentalGetImage` references (no lint opt-in error); `uses-feature ... required=false` present (no ChromeOS-hardware lint error).
NOT possible here: kotlinc / Gradle compile, lint, unit tests, device run. Treat compile as UNVERIFIED.
Known cosmetic: the bottom NavigationBar of the outer Scaffold stays visible under the scanner overlay.
Not changed: `versionCode` still 33 (bump before Play upload; same code is fine for sideload update).
