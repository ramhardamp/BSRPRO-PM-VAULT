# BSRPRO AUDIT REPORT — PASS7 source vs Master Spec (sections 1–52)

Format: Issue -> Fix (proposed) -> Logic (Fix.md style), Hinglish.
Date: 2026-10-09. **Koi code is audit me badla nahi gaya** (spec sec 2: pehle audit, phir fix).

## 0. Sach / limits (pehle padho)
- Yeh **static audit** hai (source padha + grep + Python). Android Gradle build, device, Logcat, browser load — **NOT RUN**. Isliye white-screen jaise bug ka karan "pakka" nahi, **hypothesis** hai.
- Spec ka text sec **52 ke baad kat gaya** (aakhri line `#`). Sec 53+ mujhe nahi mile — unka audit nahi hua.
- Sec 33 (UI/UX), 42 (password generator), 43 (import/export), 45 (database), 46–48 (lifecycle / Android versions / browser matrix) **abhi audit nahi hue**.
- Counts regex se nikale gaye hain (approx), file/line sandbox ke PASS7 source ke hain.

## 1. Spec section status (ek nazar me)
| Spec sec | Topic | Status |
|---|---|---|
| 3, 8 | Autofill Safety & Decision Engine, confidence | **MISSING** (sirf `package OR host` match + parser heuristics) |
| 4 | Website exact-host default | **PARTIAL** (A-08) |
| 5 | App identity = package; certificate digest | PARTIAL (package hai, digest nahi) |
| 6, 7 | Field classification / negative signals | **PARTIAL** (A-07) |
| 9–15 | SensitiveTargetPolicy, Fill/Save/Update split, Allow once/always, blocked targets | **MISSING** (sirf global `autofillExcludedPackages`) (A-06) |
| 16, 18 | Extension policy parity; native-app entry fill nahi | 18 = **OK** (QA PASS); 16 = **MISSING** (A-14) |
| 17 | App Login filter verify | Extension: **OK** (PASS7 QA). Android UI: **NOT VERIFIED** (docs me `ListFilter.MOBILE_APP`) |
| 19–22 | TOTP QR scan | **MISSING scan** + 2 bugs (A-10, A-11) |
| 23–27 | Delete white screen, backup separation, state machine, "Backup pending" | **BUG + PARTIAL** (A-01..A-04) |
| 28, 36 | Central message system, raw errors | **MISSING** (A-05) |
| 29–31 | Hindi / HelpScreen / completeness test | resources **OK**, code hard-codes + test **MISSING** (A-12) |
| 32 | Extension Hindi | PARTIAL, NOT VERIFIED (A-13) |
| 38 | Autofill performance | PARTIAL (A-18) |
| 39–41 | Security (Android manifest, extension) | PARTIAL audit (A-15, A-14) |
| 44 | Backup/restore tests | existing tests hain; spec ki matrix pura NOT VERIFIED |
| 49–51 | Autofill / save-prompt / false-positive test matrix | **MOSTLY MISSING** (A-19) |
| 52 | Manual fallback | NOT VERIFIED |

## 2. Findings

### A-01 — CRITICAL / BUG — Delete par `onBack` do baar chalta hai (white screen ka sabse mazboot karan; teeno detail screens me)
- **Issue:** `EntryDetailScreen.kt:83` `LaunchedEffect(entry == null) { if (entry == null) onBack() }` aur delete button `vm.delete(onBack)` (L169) — success par `EntryDetailViewModel.delete` bhi `onDone()` = `onBack()` chalata hai. Soft-delete ke baad entry flow `null` hota hai => **dono rasto se `onBack` => do pop** => Vault list ke upar ka back-stack khali / white screen ho sakta hai.
- **Fix (proposed):** `EntryDetailEvent { Deleted, Error }` (spec sec 24); delete success par ViewModel ek baar `Deleted` emit kare, UI use **ek baar** consume karke navigate kare; `entry == null` se navigation infer **hata do** (null par sirf "entry nahi mili" state).
- **Logic:** navigation ka ek hi source. **Zaroori:** is hypothesis ko device Logcat se confirm karna hoga (spec sec 23); bina reproduce kiye "fixed" nahi likhunga.

### A-02 — LOW / ARCHITECTURE — Backup request delete ke transaction ke andar *(pass #8 me HIGH se LOW kiya: `requestBackup()` khud halka hai, flag + apna scope)*
- **Issue:** `DeleteEntryUseCase` (`VaultSessionUseCases.kt:167`): `vaultCatching { repository.softDelete(id); autoBackup.requestBackup() }`. `requestBackup()` throw kare to user ko "delete fail" dikhega jabki entry pehle hi bin me ja chuki.
- **Fix:** soft-delete ka result pehle return; backup request uske **baad**, alag (failure UI se alag).
- **Logic:** spec sec 25: Delete -> UI success -> navigation -> backup queue.

### A-03 — MEDIUM / ARCHITECTURE — Backup state machine nahi
- **Issue:** `AutoBackupManager` me `pending_backup_v1` boolean + `backupMutex` + debounce hai. States `IDLE/PENDING/RUNNING/SUCCESS/FAILED/RETRY_WAIT` aur generation/version nahi (spec sec 26). Purana run naye ko overwrite kar sakta hai ya nahi — Mutex serialize karta hai par generation se "stale" pehchan nahi.
- **Fix:** existing mutex + persisted-pending **preserve** karke upar state enum + generation counter.
- **Logic:** sec 1 ke hisaab se backup transaction system rewrite nahi, extend.

### A-04 — MEDIUM / UX — "Pending backup ..." Toast normal screens par
- **Issue:** `SaveRouterViewModel.kt:~38` har unlock par (agar pending ho) English literal Toast: "Pending backup completed" / "Pending backup will retry; keep your vault data intact". Technical state + Hindi me nahi (spec sec 27, 29).
- **Fix:** Toast hata do; status sirf Settings -> Backup me.

### A-05 — MEDIUM / UX + SECURITY — Central message system nahi; raw error text
- **Issue:** `SnackbarHost` 0 jagah; 11 ViewModels apna `_messages` Channel rakhte hain; 11 jagah `result.error.message ?: "Could not ..."` (English literal ya raw exception text) UI par jata hai (jaise `EntryDetailViewModel.kt:60`).
- **Fix:** ek `UiMessage` (localized resource id) + ek host (max 1 snackbar, dedupe, navigation par clear); ViewModels raw `message` na bhejen, log me rakhen.
- **Logic:** spec sec 28, 36.

### A-06 — HIGH / AUTOFILL — SensitiveTargetPolicy / Fill-Save-Update split / blocked targets nahi
- **Issue:** grep me `SensitiveTarget`, `NeverFill`, `AllowOnce`, `FillAllowed/SaveAllowed` ka koi code nahi. Sirf `cfg.autofillExcludedPackages` (global package list) — ek hi switch (fill+save alag nahi), websites ke liye nahi, per-entry nahi, "allow once / always" nahi.
- **Fix (proposed, naya layer, purana `AutofillMatcher` preserve):** `SensitiveTargetPolicy` (package list alag config file), `TargetPolicy{fill,save,update}` per app / host, resolution order spec sec 12 ke hisaab se.
- **Logic:** deny > user-explicit allow > entry > global; deny kabhi silently allow se override nahi.
- **Decision chahiye:** (a) sensitive package ki initial list kaun banayega / kitni badi; (b) UPI / banking app par default Fill=OFF **par user override ke saath** (spec yahi kehta hai — confirm).

### A-07 — HIGH / AUTOFILL — Field classification chhota, confidence engine nahi
- **Issue:** `AutofillFieldType` = `{USERNAME, PASSWORD, PIN, NEW_PASSWORD, OTP}`; spec ke 17 types (UPI_PIN, PAYMENT_CARD, SEARCH, CHAT, ...) nahi. `AutofillParser` me kuch negative heuristics hain (recharge/billing/payment/wallet words, `pin`/`mpin` token) — yeh **achhi neev** hai, preserve karna.
- **Fix:** types badhana + signals se HIGH/MEDIUM/LOW decision.
- **Logic:** thresholds **test se calibrate** (spec sec 8) — abhi koi number hard-code nahi karunga.

### A-08 — MEDIUM / AUTOFILL — Website match host-only, default "related" bhi
- **Issue:** `AutofillMatcher.webKind`: `entryHost == host` = EXACT; `PublicSuffix.isRelated` (parent / sub-domain) = RELATED (warning ke saath dikhta hai). Scheme / port nahi dekhta (`UrlUtils.domainOf`). Spec default "exact host / safe origin".
  - **Achha:** `evil-example.com` vs `login.example.com` — match **nahi** hota (`endsWith(".$b")` dot-boundary), public suffix / IP parent related nahi. Yeh behaviour tests me hai.
- **Fix:** default exact-host; related sirf entry-level option ("Only fill on this exact host" sec 14) se; port / scheme **meaningful** hone par compare.
- **Logic:** backward-compatible rakhna hai — default badalna **user decision** (abhi RELATED chalta hai).

### A-09 — LOW / SECURITY — Certificate digest support nahi
- `appKind` sirf `targetPackage == packageName`. `packageName + certificateDigest` field model me nahi (spec sec 5 "support tayyar karo"). Optional; sensitive apps ke liye.

### A-10 — HIGH / TOTP — QR scan mojood nahi
- **Issue:** ZXing (`libs.zxing.core`) sirf QR **banane** (`TotpDetailScreen.kt:188`, `QRCodeWriter`) me use hota hai. `CAMERA` permission manifest me nahi, scanner screen nahi. Editor me sirf secret ya `otpauth://` paste (spec ke 3 options me se "Scan QR" gayab).
- **Fix:** scanner (decode ke liye `zxing-core` ya CameraX + ML Kit — **dependency decision**), runtime permission, preview screen, confirm -> save.
- **Logic:** QR image kabhi save / log nahi; secret log nahi (sec 21).

### A-11 — HIGH / TOTP BUG — otpauth parse galat cheezen maan leta hai
- **Issue (code se pakka):** `Totp.parse` (`Totp.kt:20`) `otpauth://hotp/...` ko bhi TOTP maan leta hai (type check nahi); `algorithm` ko validate nahi karta (koi bhi string); `period` koi bhi >0; `digits` 6..8. Editor save (`TotpEditorViewModel.kt:~73`) paste kiye URI se **sirf `secret`** leta hai — URI ke `algorithm / digits / period` **ignore** hote hain, editor ke default (SHA1/6/30) lag jate hain => SHA256 / 8-digit / 60s wale QR ka code **galat** banega.
- **Fix:** parse me `totp` type + `SHA1/SHA256/SHA512` + digits 6/8 validate, HOTP clear reject; editor paste par parse ki hui poori config state me bharo; duplicate-TOTP check.
- **Logic:** sec 20–22; `Totp.kt` reuse, replace nahi.
- **Verify baaki:** `Totp.generate` SHA256/512 sahi chalata hai ya nahi (maine abhi test nahi kiya); duplicate detection ka maujooda behaviour.

### A-12 — MEDIUM / LOCALIZATION
- **Sahi:** `values-b+hi/strings.xml` me **995 / 995** strings (EN ke barabar, 0 missing, 10 same-as-EN sirf brand / technical jaise `app_name`).
- **Issue:** `HelpScreen.kt` me **17 `HelpFaq("English", "English")`** hard-coded (sec 30); ViewModel / Toast English literals (A-04, A-05, "Could not delete entry"); `contentDescription` / `Icon(..., "Delete")` jaise ~18 literals; **EN-vs-HI completeness test nahi** (sec 31) — `app/src/test` me `values-b+hi` ka koi reference nahi.
- **Fix:** FAQ -> `@StringRes`; literals -> resources; ek JVM test jo EN / HI keys + placeholders compare kare.

### A-13 — LOW / EXTENSION LOCALIZATION — NOT VERIFIED
- `src/lang.js` me in-JS Hindi dictionary (`_HI`) + `data-en/data-hi` attributes; `setup.html` me 0 attributes (dictionary se bhi cover ho sakta hai). Screen-by-screen check baaki (sec 32).

### A-14 — HIGH / EXTENSION — policy parity nahi
- **Issue:** extension me blocked sites / never-save / never-fill / exact-host policy ka koi code nahi (grep khali). Sirf PASS7 ka regex-based "sensitive PIN target" block hai. Manifest: `host_permissions: <all_urls>`, content script `<all_urls>` + `document_start` (autofill ke liye zaroori par broad); CSP `script-src 'self'` achhi; `web_accessible_resources` nahi (achha); `GET_SESSION` `_isExtensionPage` se gated.
- **Fix:** Android policy ka JS equivalent (A-06 ke baad, same resolution order); `optional_host_permissions` option **design decision**.

### A-15 — MEDIUM / SECURITY — Android manifest review baaki
- **Achha:** `allowBackup=false`, `usesCleartextTraffic=false`, `fullBackupContent=false`, `dataExtractionRules` set.
- **Review chahiye:** exported components — `SecureShareActivity` (intent / deep-link input validation), `VaultAutofillService`, `VaultWidgetProvider`, `VaultQuickTileService` (permission attributes aur data jo bahar jata hai); permissions `INTERNET`, `READ_CONTACTS` (contacts import ka purpose + consent text).

### A-16 — INFO — Jo already theek hai (preserve)
- Hidden-vault entries autofill me nahi aate; note / folder marker skip; `SafeRegex` (length cap + nested-quantifier filter + 20 ms time-box); `PublicSuffix`; locked vault par dataset authentication (`lockedResponse`); extension `android_package` entries par browser fill nahi (QA `qa-fixes-audit` PASS).

### A-18 — MEDIUM / PERFORMANCE
- **Achha:** autofill har request par vault **decrypt nahi** karta — `repository.entries.value` (session me already memory me) par chalta hai.
- **Issue:** `AutofillMatcher.match` poori list par linear loop (O(n)), index nahi; sirf ek timing assert (`AutofillMatcherTest` L201, < 400 ms, size verify nahi kiya); spec ka 10 / 100 / 1k / 5k / 10k benchmark nahi.
- **Fix:** pehle benchmark, number dekh kar hi index (host / package map) decide.

### A-19 — MEDIUM / TESTS
- Autofill tests: Diagnostics, Matcher, Parser, Presentation, PendingSave*, SafeRegex. Spec sec 49–51 ka matrix (sensitive package, certificate mismatch, UPI PIN / MPIN / CVV / card / search / chat, save-prompt cases, false-positive list) **zyada tar nahi**.

## 3. Sujhav kiya hua order (chhote batch, har batch ke baad test + docs)
1. **Batch 1 — Delete / backup / messages:** A-01, A-02, A-04, A-05 (+ Logcat confirmation).
2. **Batch 2 — TOTP:** A-11 (bug fix, chhota) phir A-10 (QR scan).
3. **Batch 3 — Localization:** A-12 (HelpScreen + literals + completeness test).
4. **Batch 4 — Autofill engine:** A-06, A-07, A-08, A-09, A-18, A-19 (sabse bada; decisions chahiye).
5. **Batch 5 — Extension policy parity:** A-14, A-13.
6. **Batch 6 — Baaki audit:** sec 33, 42, 43, 45–48 + A-15 + spec sec 53+.

## 4. Mujhe tumse chahiye
1. Spec ka **sec 53 se aage ka text** (file attach karke).
2. **Pehla batch** kaun sa? (mera sujhav: Batch 1 ya A-11 — dono chhote, lagbhag bina decision ke.)
3. A-01 ke liye: **device Logcat** (delete -> back par) agar bhej sako; warna fix source-hypothesis par hoga aur "NOT device-tested" likha jayega.
4. Batch 4 ke liye (baad me): sensitive-app list ka source, aur RELATED subdomain match ka default badalna hai ya nahi.

## 5. Status after Pass #8 (2026-10-09)
| ID | Status | Note |
|---|---|---|
| A-01 | FIXED in source — **NOT VERIFIED** (no compile, no device) | Karan code padh kar confirm (softDelete -> `_entries` se hat -> `entry == null` + `vm.delete(onBack)` = double `popBackStack`); Entry + TOTP + File detail |
| A-02 | FIXED — test NOT RUN | rating LOW |
| A-03 | NOT FIXED | backup state machine |
| A-04 | FIXED — NOT VERIFIED (compile) | Settings -> Backup status row abhi nahi |
| A-05 | PARTIAL | sirf delete errors localized; central snackbar NOT FIXED |
| A-06..A-09 | NOT FIXED | Autofill engine / policy / exact-host / cert digest |
| A-10 | NOT FIXED | QR scan (dependency faisla chahiye) |
| A-11 | FIXED — logic PASS (sandbox) | Compose dialog NOT VERIFIED |
| A-12 | NOT FIXED | HelpScreen + literals + completeness test |
| A-13 | NOT VERIFIED | extension Hindi |
| A-14 | NOT FIXED | extension policy parity |
| A-15 | NOT VERIFIED | exported components review |
| A-18, A-19 | NOT FIXED | benchmark, test matrix |
| Spec 33, 42, 43, 45-48, 53-99 audit | NOT DONE | Phase 1 adhura |
