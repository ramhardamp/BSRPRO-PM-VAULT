# Target-kind model (Android + Extension) — Fix.md format

Status: **IMPLEMENTED in source (fix pass #2)**. Decision: user (product abhi launch nahi hua; purane users nahi; migration/grandfather/notice nahi).

## 1. Issue -> Fix -> Logic

### 1.1 Ek login = ek target
- **Issue:** pehle website+app "linked" ek hi entry me ho sakte the aur `type` (app/website) aur data (url/appPackage) dono se kind nikalta tha. Isse routing ambiguous thi; `androidapp://<package>` jaisa URL package se bana diya jata tha; extension import me alag packages same-username par "duplicate" ho jate the.
- **Fix:** entry me `type = "login"` aur `target = { kind, origin | packageName }`.
  - `kind = "website"` -> `origin` (`scheme://host[:port]`). Browser / website autofill.
  - `kind = "android_package"` -> `packageName`. Native-app autofill.
  - Backup format ek hi rehta hai (V3/V4 payload ki entry me sirf `target` field jodta hai).
- **Logic:** routing sirf `target.kind` se. `packageName` kabhi URL/URI nahi banta; URL se `packageName` nahi banta. Purane `type` values (`app` / `website`) interpret nahi hote, koi runtime migration nahi.

### 1.2 Untagged entries (target ke bina)
- Koi rewrite nahi. Sirf padhte waqt data se kind nikalta hai: `androidapp://...` ya (package and url khali) -> `android_package`; url -> `website`; warna kind khali (sirf "All" me dikhti hai).

### 1.3 Platform behavior

| Platform | Website logins | App logins |
|---|---|---|
| Android | autofill ON (browser me, origin se) | autofill ON (app me, packageName se) |
| Extension (PC) | autofill ON | sirf view / manage, autofill NAHI |

Dono platforms par UI me do sections/filters: **Website logins** / **App logins**.
Extension import karne par dono sections me sahi jagah; koi data drop / duplicate nahi.

## 2. Code map

| Kaam | Android | Extension |
|---|---|---|
| Model + kind derive | `core/model/VaultEntry.kt` (`EntryTarget`, `targetKind`, `isAppLogin`, `isWebsiteLogin`) | `src/entry-target.js` |
| Origin normalise | `UrlUtils.originOf` | `EntryTarget.originOf` |
| Create / edit tag | `EditorForm.resolvedTarget/toEntry`, `PendingSave.toCandidate`, `ImportParser` | `EntryTarget.sync` (popup.js, passwords.js, background SAVE) |
| Autofill routing | `AutofillMatcher.match` | `_isAutofillEligible` (background.js) |
| Import safety | `AppLoginRestorePolicy` (URI synthesis hata) | `validateV3Payload` (target validate), `deduplicateImport` (package identity) |
| Sections | `ListFilter.WEBSITE / MOBILE_APP` (labels "Website logins" / "App logins") | popup stat-pills, passwords filter select |

## 3. Known limits (sach)
- Editor me "same credentials, website + app" (linked) ab nahi banta. Purani both-field entry editor me dobara save karne par sirf ek target bachta hai (website kind => `appPackage/appName/loginUri` khali).
- `DuplicateDetector` (Android) data-based hai (domain / package), model se mel khata hai; untagged linked entries ab bhi ek identity maani jati hain.
- Extension me app entry ko URL dena `EntryTarget.sync` se nahi hota (app kind kabhi origin nahi leta).
- Test: Kotlin logic harness (86 checks) + Node (qa-target-backup 10). Gradle/device NOT RUN.

## 4. Pass #7 spasht-ikaran (Extension import / restore / move)
- **Issue:** updated extension ne hostname / title / purane `type=app` se package guess kiya (`github.com` => App Login) aur package + url ko app mana.
- **Fix:** `entry-target.js`, `import-export.js` (CSV, JSON, normalize), `setup.js` restore, `passwords.js` bulk-move ab ek hi rule use karte hain.
- **Logic:** App Login sirf jab `target.kind=android_package`, ya `androidapp://`, ya (`appPackage` + khali url). url ho to Website. Hostname / title / `type` se package kabhi nahi banta. Android `ImportParser` ka rule yahi hai.
- **Test:** `qa-pass7-fixes.js` 16/16 (extension). Browser / Gradle NOT RUN.

