package pro.babasitaram.vault.domain.repository
import kotlinx.coroutines.flow.StateFlow
import pro.babasitaram.vault.core.model.VaultEntry
interface VaultRepository { val entries: StateFlow<List<VaultEntry>>; fun entry(id: String): VaultEntry? }
