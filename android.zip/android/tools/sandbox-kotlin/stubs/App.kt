package pro.babasitaram.vault
object R { object string {
  const val p18_totp_editor_enter_a_service_name = 1; const val p18_totp_editor_secret_must_be_a_valid = 2
  const val p21_totp_err_hotp = 3; const val p21_totp_err_algorithm = 4; const val p21_totp_err_digits = 5; const val p21_totp_err_period = 6 } }
