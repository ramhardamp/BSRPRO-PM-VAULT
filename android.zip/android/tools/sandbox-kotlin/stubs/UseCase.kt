package pro.babasitaram.vault.domain.usecase
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.VaultResult
class SaveEntryUseCase { operator fun invoke(e: VaultEntry, old: VaultEntry?): VaultResult<Unit> = VaultResult.Success(Unit) }
