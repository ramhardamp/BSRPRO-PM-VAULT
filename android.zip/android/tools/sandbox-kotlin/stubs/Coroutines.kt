package kotlinx.coroutines
fun launch(b: () -> Unit) = b()
