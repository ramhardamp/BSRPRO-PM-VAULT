package pro.babasitaram.vault.core.model
data class VaultEntry(val id: String = "", val title: String = "", val username: String = "", val email: String = "",
  val totp: String = "", val notes: String = "", val recordType: String = "", val isNote: Boolean = false, val deletedAt: Long = 0L)
