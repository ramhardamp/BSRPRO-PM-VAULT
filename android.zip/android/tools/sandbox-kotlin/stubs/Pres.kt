package pro.babasitaram.vault.presentation.util
import androidx.lifecycle.ViewModel
fun Throwable.toUserMessage(): String = "x"
fun ViewModel.launchCatching(b: () -> Unit) = b()
