package pro.babasitaram.vault.core.util
object L { fun s(id: Int): String = "str$id" }
sealed interface VaultResult<out T> {
  data class Success<T>(val value: T) : VaultResult<T>
  data class Failure(val error: Throwable) : VaultResult<Nothing>
  data object Loading : VaultResult<Nothing>
}
