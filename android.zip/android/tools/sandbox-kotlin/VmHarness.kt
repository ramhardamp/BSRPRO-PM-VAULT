import androidx.lifecycle.SavedStateHandle
import kotlinx.coroutines.flow.*
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.SaveEntryUseCase
import pro.babasitaram.vault.presentation.totpmanager.TotpEditorViewModel

var pass = 0; var fail = 0
fun check(n: String, c: Boolean) { if (c) { pass++; println("PASS  $n") } else { fail++; println("FAIL  $n") } }

fun main() {
    val sec = "GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ"
    val list = mutableListOf<VaultEntry>()
    val repo = object : VaultRepository {
        override val entries: StateFlow<List<VaultEntry>> = MutableStateFlow<List<VaultEntry>>(list)
        override fun entry(id: String) = null
    }
    fun vm() = TotpEditorViewModel(SavedStateHandle(), repo, SaveEntryUseCase())

    // 1) pasted link: config is applied (the old bug kept only the secret)
    var v = vm(); v.setSecret("otpauth://totp/Mail:bob%40x.com?secret=$sec&digits=8&period=60&algorithm=SHA256&issuer=Mail")
    var s = v.state.value
    check("paste link -> algorithm SHA256", s.algorithm == "SHA256")
    check("paste link -> digits 8 / period 60", s.digits == 8 && s.period == 60)
    check("paste link -> secret normalized, title/username filled", s.secret == sec && s.title == "Mail" && s.username == "bob@x.com")
    check("paste link -> no error", s.error == null)

    // 2) existing title / username are not overwritten
    v = vm(); v.setTitle("My Mail"); v.setUsername("me"); v.setSecret("otpauth://totp/Mail:bob?secret=$sec&issuer=Mail")
    s = v.state.value; check("existing title/username kept", s.title == "My Mail" && s.username == "me")

    // 3) rejected links keep the text and show the matching error (ids 3..6 = hotp, algorithm, digits, period)
    for ((u, id) in listOf("otpauth://hotp/x?secret=$sec&counter=1" to 3, "otpauth://totp/x?secret=$sec&algorithm=MD5" to 4,
            "otpauth://totp/x?secret=$sec&digits=7" to 5, "otpauth://totp/x?secret=$sec&period=0" to 6, "otpauth://totp/x?secret=!!!" to 2)) {
        v = vm(); v.setSecret(u); check("reject -> error str$id", v.state.value.error == "str$id" && v.state.value.secret == u)
    }

    // 4) save validation + success
    v = vm(); v.setSecret(sec); v.save(); check("blank title -> error, not saved", v.state.value.error == "str1" && !v.state.value.saved)
    v = vm(); v.setTitle("T"); v.setSecret("not*base32!"); v.save(); check("bad secret on save -> error", v.state.value.error == "str2" && !v.state.value.saved)
    v = vm(); v.setTitle("T"); v.setSecret("gezd gnbv gy3t qojq gezd gnbv gy3t qojq"); v.save()
    check("valid bare secret saves", v.state.value.saved && v.state.value.error == null)

    // 5) duplicate: warning first, saved only after confirmation; deleted entries ignored
    list.add(VaultEntry(id = "a", title = "Old Mail", totp = "otpauth://totp/Old?secret=${sec.lowercase()}"))
    list.add(VaultEntry(id = "b", title = "Bin", totp = "otpauth://totp/Bin?secret=JBSWY3DPEHPK3PXP", deletedAt = 5L))
    v = vm(); v.setTitle("New"); v.setSecret(sec); v.save()
    check("duplicate -> dialog title shown, NOT saved", v.state.value.duplicateTitle == "Old Mail" && !v.state.value.saved)
    v.dismissDuplicate(); check("dismiss clears dialog, still not saved", v.state.value.duplicateTitle == null && !v.state.value.saved)
    v.save(); v.saveDespiteDuplicate(); check("save anyway -> saved", v.state.value.saved && v.state.value.duplicateTitle == null)
    v = vm(); v.setTitle("New"); v.setSecret("JBSWY3DPEHPK3PXP"); v.save()
    check("secret only in a deleted entry is not a duplicate", v.state.value.saved)

    println("VM HARNESS: pass=$pass fail=$fail"); if (fail > 0) System.exit(1)
}
