#!/bin/bash
# Sandbox-only checks (NOT part of the Gradle build). Needs: JDK 17+, kotlinc 2.0.20 (set KOTLINC=/path/to/kotlinc/bin/kotlinc).
# Runs: Totp.kt + TOTP unit tests through a tiny JUnit5 shim, and the TotpEditorViewModel behaviour harness (Android stubs).
set -e
K=${KOTLINC:?set KOTLINC}; HERE=$(cd "$(dirname "$0")" && pwd); APP=$HERE/../../app/src; OUT=$(mktemp -d)
M=$APP/main/java/pro/babasitaram/vault; T=$APP/test/java/pro/babasitaram/vault/core/util
python3 - "$T/UtilTests.kt" "$OUT/ExistingTotpTest.kt" <<'PY'
import sys
s=open(sys.argv[1],encoding='utf-8').read(); a=s.index('class TotpTest'); b=s.index('class PasswordStrengthTest')
hdr='package pro.babasitaram.vault.core.util\n'+''.join(f'import org.junit.jupiter.api.Assertions.{n}\n' for n in ('assertEquals','assertNull','assertNotNull','assertTrue','assertFalse'))+'import org.junit.jupiter.api.Test\n'
open(sys.argv[2],'w',encoding='utf-8').write(hdr+s[a:b])
PY
$K $M/core/util/Totp.kt $T/TotpStrictParserTest.kt $T/TotpRoadmapVectorTest.kt $OUT/ExistingTotpTest.kt $HERE/shim/org/junit/jupiter/api/Shim.kt $HERE/shim/org/junit/Shim4.kt $HERE/shim/Runner.kt -d $OUT/t 2>&1 | grep "error:" && exit 1 || true
CP="$OUT/t:$(dirname $K)/../lib/kotlin-stdlib.jar"
java -cp "$CP" RunnerKt pro.babasitaram.vault.core.util.TotpStrictParserTest pro.babasitaram.vault.core.util.TotpTest pro.babasitaram.vault.core.util.TotpRoadmapVectorTest pro.babasitaram.vault.core.util.TotpBuildUriTest | tail -1
$K $HERE/stubs/*.kt $HERE/VmHarness.kt $M/core/util/Totp.kt $M/presentation/totpmanager/TotpEditorViewModel.kt -d $OUT/v 2>&1 | grep "error:" && exit 1 || true
java -cp "$OUT/v:$(dirname $K)/../lib/kotlin-stdlib.jar" VmHarnessKt | tail -1
