import java.lang.reflect.InvocationTargetException
fun main(args: Array<String>) {
    var pass = 0; var fail = 0
    for (cn in args) {
        val c = Class.forName(cn)
        for (m in c.declaredMethods.sortedBy { it.name }) {
            val isTest = m.annotations.any { it.annotationClass.simpleName == "Test" }
            if (!isTest) continue
            val inst = c.getDeclaredConstructor().newInstance()
            try { m.invoke(inst); pass++; println("PASS  ${c.simpleName}.${m.name}") }
            catch (e: InvocationTargetException) { fail++; println("FAIL  ${c.simpleName}.${m.name}: ${e.targetException}") }
        }
    }
    println("TOTAL pass=$pass fail=$fail"); if (fail > 0) System.exit(1)
}
