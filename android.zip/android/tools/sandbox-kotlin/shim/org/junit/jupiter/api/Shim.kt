package org.junit.jupiter.api
annotation class Test
annotation class BeforeEach
object Assertions {
    fun assertEquals(e: Any?, a: Any?) { if (e != a) throw AssertionError("expected <$e> but was <$a>") }
    fun assertNotEquals(e: Any?, a: Any?) { if (e == a) throw AssertionError("expected not <$e>") }
    fun assertTrue(c: Boolean) { if (!c) throw AssertionError("expected true") }
    fun assertFalse(c: Boolean) { if (c) throw AssertionError("expected false") }
    fun assertNull(a: Any?) { if (a != null) throw AssertionError("expected null but was <$a>") }
    fun assertNotNull(a: Any?) { if (a == null) throw AssertionError("expected not null") }
}
