package org.junit
annotation class Test
object Assert {
    fun assertEquals(e: Any?, a: Any?) { if (e != a) throw AssertionError("expected <$e> but was <$a>") }
}
