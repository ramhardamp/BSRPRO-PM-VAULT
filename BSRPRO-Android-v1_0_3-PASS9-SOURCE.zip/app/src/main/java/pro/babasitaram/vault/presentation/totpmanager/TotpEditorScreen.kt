@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.totpmanager

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun TotpEditorScreen(onDone: () -> Unit, vm: TotpEditorViewModel = hiltViewModel()) {
    val s by vm.state.collectAsStateWithLifecycle()
    var scanning by rememberSaveable { mutableStateOf(false) }
    BackHandler(enabled = !s.saving && !scanning) { onDone() }
    LaunchedEffect(s.saved) { if (s.saved) onDone() }
    s.duplicateTitle?.let { dupTitle ->
        AlertDialog(
            onDismissRequest = vm::dismissDuplicate,
            title = { Text(stringResource(R.string.p21_totp_duplicate_title)) },
            text = { Text(stringResource(R.string.p21_totp_duplicate_message, dupTitle)) },
            confirmButton = { TextButton(onClick = vm::saveDespiteDuplicate) { Text(stringResource(R.string.p21_totp_save_anyway)) } },
            dismissButton = { TextButton(onClick = vm::dismissDuplicate) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    Box(Modifier.fillMaxSize()) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (s.existing == null) stringResource(pro.babasitaram.vault.R.string.p17_new_totp) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_173)) },
                navigationIcon = { IconButton(onClick = onDone, enabled = !s.saving) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } },
                actions = { Button(onClick = vm::save, enabled = !s.saving && !s.saved) { Text(stringResource(R.string.p15_save)) } }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            s.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedButton(onClick = { scanning = true }, enabled = !s.saving, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                Text(stringResource(R.string.totp_scan_button), modifier = Modifier.padding(start = 8.dp))
            }
            OutlinedTextField(s.title, vm::setTitle, label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_161)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(s.username, vm::setUsername, label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_162)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(
                s.secret, vm::setSecret,
                label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_163)) },
                singleLine = true,
                keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters),
                modifier = Modifier.fillMaxWidth()
            )
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_164), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("SHA1", "SHA256", "SHA512").forEach { a ->
                    FilterChip(selected = s.algorithm == a, onClick = { vm.setAlgorithm(a) }, label = { Text(a) })
                }
            }
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_165), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(6, 8).forEach { d ->
                    FilterChip(selected = s.digits == d, onClick = { vm.setDigits(d) }, label = { Text("$d") })
                }
            }
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_166), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(30, 60).forEach { p ->
                    FilterChip(selected = s.period == p, onClick = { vm.setPeriod(p) }, label = { Text(stringResource(pro.babasitaram.vault.R.string.p17_seconds_suffix, p)) })
                }
            }
            OutlinedTextField(
                s.backupCodes, vm::setBackupCodes,
                label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_167)) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
    if (scanning) {
        // Registered after the screen's own BackHandler, so Back closes the scanner first.
        QrScannerOverlay(
            onResult = { text -> scanning = false; vm.setSecret(text) },
            onClose = { scanning = false }
        )
    }
    }
}
