# Changelog — Phase 16A to 16E

Format: Issue -> Fix -> Logic (Fix.md style). Sab badlav source-level hain: Gradle build aur device test abhi baaki hai.

## 16A — backup incident + follow-up
| Issue | Fix | Logic |
|---|---|---|
| Raw `BSRZ1:` payload CSV path me jaakar fail hota tha | `ImportParser.detectKind()` ab `BSRZ1:` pehchanta hai (BOM/whitespace ke saath bhi) | Pehle koi bhi non-JSON text CSV maana jaata tha |
| Backup/import me failure ki jagah pata nahi chalti thi | Metadata-only `BSRPROBackup` log (size, marker, counts, exception class; password/records kabhi nahi) | Device logcat se failure stage pakadna |
| CI me unit-test failure chhup jaata tha | `testDebugUnitTest` ab required step | Test fail = build fail |
| Quick Settings tile (API 34+) | `startActivityAndCollapse(PendingIntent)` | Purane Android par Intent overload |

## 16B — setup par backup folder
| Issue | Fix | Logic |
|---|---|---|
| Naye phone par backup folder chunna / folder se restore nahi hota tha | Setup screen: SAF folder picker + "Restore from backup folder" (exact `BSRPRO.Vault` dhoondh kar purane V3 restore flow me) | Persistable permission `backupFolderUri` me save; galat password par dialog khula rehta hai |

## 16C — UI polish
| Issue | Fix | Logic |
|---|---|---|
| Light theme me primary button par white text 2.7:1 | Light primary `#6D4AE8` (5.5:1) | WCAG AA 4.5:1 |
| Android 15 (targetSdk 35) me keyboard fields dhak deta tha | `MainActivity` me `imePadding()` | Edge-to-edge me `adjustResize` kaam nahi karta |
| Keyboard Done/Enter kuch nahi karta tha | `PasswordField` me `imeAction` / `onImeAction`; Lock = Unlock, Setup confirm = Create | Purane callers unchanged (defaults) |
| LockScreen scroll nahi hoti thi | `verticalScroll` | Chhoti screen / bada font |
| Setup: restore upar, form neeche; hardcoded strings | Form pehle, restore/folder neeche; strings en + hi me | Primary flow pehle |
| Avatar initial amber/mint par unreadable; EmptyState left-aligned; off-grid 6/10/14/18dp | Contrast-aware initial; centered text; 4/8dp grid | 11 jagah |

## 16D — duplicate backup files, import/export, suggestions, direct share
| Issue | Fix | Logic |
|---|---|---|
| Folder me 8+ `BSRPRO-Recovery-*.Vault` | SAF delete `DocumentsContract.deleteDocument` se; publish ke baad purani file turant delete | `ContentResolver.delete()` DocumentsProvider par kaam nahi karta, isliye cleanup fail hoke har retry par nayi copy bani |
| Ek unreadable purani file poore backup ko fail karti thi | Ab sirf log; backup success | Jo file is vault ke password se decrypt nahi hoti use jaanbujh kar nahi hatate |
| Settings ki 6 rows ek hi page kholti thin | `BackupDeepLink`: har row sahi tab / picker par | One-shot, rotation par dobara trigger nahi |
| Export me ek hi button + radio list | 4 buttons: .Vault, CSV, JSON, generated-password backup | Dialog me format pehle se chuna |
| Import me sab `*/*` | .Vault / CSV / JSON / Contacts alag; CSV aur JSON ke file-type filters | .Vault ka MIME standard nahi |
| Suggestions default OFF | `autofillInline = true`, DataStore key `autofill_inline_v2` | Purane installs par bhi default ON; user OFF kar sakta hai |
| Vault/Notes/Mobiles se share par beech ka page | Ek item = sirf auth, phir seedha OS share sheet | Multi-select aur drawer ka Sharing page pehle jaisa |
| `VaultJson.copy { }` compile error (`EntryExporter.kt`) | `Json(from = VaultJson) { prettyPrint = true }` | `Json` me `copy` nahi hota; ye 16A follow-up me aaya tha |

## Device par dekhna
1. Gradle build + `testDebugUnitTest`.
2. Ek backup ke baad purani Recovery files hat rahi hain; folder me sirf ek `BSRPRO.Vault`.
3. Settings ki har row sahi jagah; keyboard suggestions (Android 11+).
4. Light theme, Hindi font scale, chhoti screen par Setup/Lock.

## 16E — backup import / folder restore fix
Format: Issue -> Fix -> Logic. Source-level; Gradle build + device test baaki.

| Issue | Fix | Logic |
|---|---|---|
| Folder me `BSRPRO.Vault` hone par bhi restore/auto-import "No backup found" deta tha | `AutoBackupManager.findRestorableBackup()` + naya `BackupFolderFinder`: chuna hua folder (aur 2 level sub-folder) scan | Pehle `findBackupFile()` sirf last-write URI aur app-owned MediaStore dekhta tha; user ka picked folder kabhi nahi. Android 10+ par dusre install ki files MediaStore me dikhti hi nahi |
| Folder me exact naam na ho (`BSRPRO_Backup_<date>.Vault`, `(1)`) to file ignore | `BackupCandidates.order()`: exact `BSRPRO.Vault` pehle, phir baaki `.Vault` newest-first; header (`BSRPRO.Vault`) check; `.csv.Vault`, hidden/staging, 0-byte, 25MB+ skip | Fix.md 7.2 ki exact-name priority waisi hi; sirf fallback chaura kiya |
| Import me "0 entries" aur purani backup file ka overwrite | `emptyVaultWouldOverwriteBackup()` guard `backupNow()` aur `runPendingOrDue()` me | Khali vault (entries + bin + folders sab 0) ka backup tab skip jab koi maujooda backup mile; pehli entry aate hi normal backup |
| Preview me "0 new · 0 duplicate" ka matlab samajh nahi aata, Replace se purani entries Bin me ja sakti thi | `ReviewPane`: file khali ho to error text (`bk_import_file_empty`, en+hi) aur Import button disabled | Khali file se kuch import nahi hota; user ko wajah dikhti hai |
| `startFolderRestore()` main thread par file IO | Ab `launchCatching` + IO thread (busy indicator ke saath) | UI freeze / ANR nahi |
| Setup folder restore sirf exact naam, main thread par query | `SetupViewModel.onBackupTreeSelected` ab `BackupFolderFinder` (IO thread) | Backup screen jaisa hi logic |
| Tests | `BackupFolderFinderTest` (ranking + header sniff) | Pure Kotlin, Android ke bina |

Jo badla nahi: V3 format, encryption, DB schema, `type` (app/website) logic, SAF publish/cleanup (Fix.md 7.1).

## 17 — Autofill smooth + secure + fast
Format: Issue -> Fix -> Logic. Source-level; Gradle build + device test baaki.

| Issue | Fix | Logic |
|---|---|---|
| App me unlock ke baad bhi autofill dobara "Unlock" maangta tha | `AutofillSessionGate` ab `SessionKeyStore.isUnlocked` ko observe karta hai; `BsrApplication` me eager init | Gate pehle sirf autofill ke andar khulta tha; ab vault unlock = window open, lock = window band |
| Gate expire hone par poora vault lock ho jaata tha | `VaultAutofillService`: `lockVault` sirf jab `!session.hasValidSession()` | Autofill window aur vault session alag cheezein hain |
| Vault unlocked hone par bhi KDF dobara chalta tha | `AutofillAuthActivity.reauthenticateOnly()` | Sirf biometric/device-PIN verify, phir seedha dataset |
| Process kill ke baad har baar Unlock tap | Service me `silentRestore()` (Mutex + 3.5s timeout) | Sharte: biometric ON, quick autofill ON, Key-B auth window + metadata + background grace valid. Suggestion par tap user ko phir bhi karna padta hai |
| Related (sub/parent) domain ka password pehle hi system ko chala jaata tha | `relatedDataset()`: null values + dataset authentication; tap par confirm dialog | Subdomain takeover / shared hosting me credential leak ka risk kam |
| Hidden / transparent / 1px field me fill (honeypot) | `AutofillParser.walk`: alpha >= 0.1, width/height >= 2 | Jo field user ko dikhta hi nahi usme credential nahi jaata |
| Release build me domain/package logcat me | `AutofillDiagnostics.logcatEnabled = BuildConfig.DEBUG` | In-app diagnostics screen jaisi hi rahi |
| Exception message diagnostics me | Sirf class name | Message me kabhi kuch sensitive aa sakta tha |
| Har request par regex compile | `AutofillMatcher.compiled()` cache (max 256) | Galat pattern = NEVER regex, crash nahi |
| Tests | `AutofillMatcherTest`: regex cache + invalid regex | Pure Kotlin |

Jo badla nahi: V3 format, encryption, DB schema, `type` (app/website) logic, screen-off par gate band hona.

### 17b — App khula hone par bhi autofill nahi bharta
| Issue | Fix | Logic |
|---|---|---|
| App me vault unlocked, par autofill tab tak nahi bharta jab tak band karke autofill se dobara unlock na karo | (17 me) gate unlock se sync. (17b) `ACTION_USER_PRESENT` par gate dobara khulta hai (vault session valid ho aur mode "Until screen locks" na ho) | Pehle sirf autofill ka apna unlock gate kholta tha; screen-off ke baad gate band ho jaata tha aur app ka unlock use nahi hota tha |

### 17c — Diagnostics me seedha "Karan"
| Issue | Fix | Logic |
|---|---|---|
| "No autofill requests received yet" / kaccha log se samajh nahi aata ki password kyon nahi aaya | `AutofillDiagnostics.explain()` + `summaryLines()`; Settings dialog me "Karan" + "Chhota summary" + (button se) detail log | Aakhri request ke stage dekhkar Hinglish me wajah: service select nahi, koi field nahi, http page, travel mode, vault locked, 0 saved login, entry khali, suggestion bheje, error |
| Copy button sirf kaccha log copy karta tha | `report(serviceEnabled)`: KARAN + summary + detail | Support ke liye ek hi paste me sab |
| Tests | `AutofillDiagnosisTest` (user ka KDE Connect log) | Pure Kotlin |

### 17d — Senior review: baaki bugs
| Issue | Fix | Logic |
|---|---|---|
| Process-restore (`RestorePersistedSessionUseCase`) har baar session ki 24h umar naye sire se shuru kar deta tha (absolute limit khisakti rehti; silent restore ke saath aur badhta) | Restore ke baad `SessionKeyStore.restore(password, metadata.expiresAtWallMs)` + purani metadata wapas | Doc me likha "absolute expiry" ab sach me absolute. Expiry nikal chuki ho to vault lock |
| Unlock ke baad `AutofillAuthActivity` excluded packages aur "regex OFF" ignore karti thi (service alag, activity alag matching) | Activity ab wahi `autofillExcludedPackages` / `autofillRegexEnabled` use karti hai | Dono raste ek jaisa fill/skip karein |
| `registerReceiver` bina flag (Android 14+) | `ContextCompat.registerReceiver(..., RECEIVER_NOT_EXPORTED)` | Doosre apps nakli SCREEN_OFF/USER_PRESENT nahi bhej sakte |

## 18 — Final Production Polish + Master Rules integration
Date: 2026-10-06
Format: Detect -> Root Cause -> Fix -> Retest -> Regression.

| Issue | Root Cause | Fix / Logic | Verification | Result |
|---|---|---|---|---|
| Automatic backup publish race | Debounced backup and WorkManager could enter publish path concurrently | `AutoBackupManager.backupNow()` serialized with coroutine `Mutex`; existing transactional publish/verify flow retained | FIX1-FIX9 regression + backup targeted checks + source audit | PASS |
| CI could report green while required runtime/test gates were non-blocking | Required jobs used `continue-on-error` / lacked strict lint gate | Unit tests and emulator smoke made blocking; `lintDebug` added to build gate | Workflow/source inspection + production audit | PASS |
| Production source hygiene had unnecessary direct dependencies | Coil, Tink and AndroidX Security Crypto were unused direct dependencies in this package | Removed unused direct dependencies and stale license residue | Dependency residue scan | PASS |
| Autofill wording was misleading | Intentional authentication dataset was described as a generic placeholder | Reworded user/developer-facing references without changing authentication behavior | Smart session/autofill audit + regression | PASS |
| Project needed one permanent AI/developer operating contract | Rules existed as pasted project guidance rather than a tracked project document | Added `docs/BSRPRO_VAULT_AI_MASTER_RULES.md` as the permanent development/security/QA rules reference | File/package verification | PASS |
| Final package needed history continuity | Latest production polish had audit notes but not a single chronological change-history entry | Added this entry to `CHANGELOG_PHASE16.md`; no separate Fix/FinalFix history files created | Fresh ZIP extraction + changelog verification | PASS |

### 18 — Verification record
- FIX1-FIX9 regression: **78/78 PASS**
- Smart session/autofill audit: **67/67 PASS**
- Bracket/structural audit: **0 issues**
- Item-action audit: **PASS**
- Phase 15M targeted regression: **10 + 8 PASS**
- Production source/package gate: **PASS**
- Android XML parsing: **PASS**
- Python audit compilation: **PASS**
- Dependency residue check: **PASS**
- Secret/generated-artifact scan: **PASS**
- Final ZIP extraction/integrity verification: **PASS**

### 18 — Data/Security impact
- Existing V3 backup format unchanged.
- Encryption/key architecture unchanged.
- Database schema unchanged.
- No user credential data intentionally modified by this documentation/CI/dependency-cleanup pass.
- Backup replacement remains verify-before-replace/cleanup.
- No sensitive secrets added to source or logs.

### 18 — Rollback reference
- Previous production-polished package remains the rollback baseline.
- The master rules document is additive documentation only.
- Code rollback target: revert the `AutoBackupManager` serialization change and the dependency/CI polish changes as one reviewed commit/change set; do not restore obsolete or insecure logic blindly.

**Status: PASS — source/package verified. Real Android SDK/device runtime execution remains a CI/device responsibility and is not claimed as locally executed in the authoring environment.**

### 19 — Final ZIP Naming Rule
- **Reported requirement:** Final ZIP files must be immediately identifiable by a clean sequential filename.
- **Rule added:** Final ZIP naming is now strictly `BSRPRO PM Android.<SEQUENTIAL_NUMBER>.zip`.
- **Examples:** `BSRPRO PM Android.1.zip`, `BSRPRO PM Android.2.zip`, `BSRPRO PM Android.3.zip`.
- **Prohibited suffixes:** `final`, `fixed`, `polished`, `updated`, `cl-updated`, date/time, commit hash, or any other extra filename suffix.
- **History:** Build/version/commit details remain in CHANGE HISTORY, not in the ZIP filename.
- **Verification:** Master Rules updated and package rechecked after documentation change.
- **Status:** PASS

