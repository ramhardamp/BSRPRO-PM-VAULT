@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.vault

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.compose.LifecycleResumeEffect
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.autofill.AutofillStatus
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.Avatar
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.components.SelectionBottomBar
import pro.babasitaram.vault.presentation.components.SelectionTopBar
import pro.babasitaram.vault.presentation.components.bucketColor
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity

private sealed interface ListRow {
    data class Header(val key: String, val count: Int, val expanded: Boolean) : ListRow
    data class Item(val entry: VaultEntry, val indented: Boolean) : ListRow
}

private fun groupKey(e: VaultEntry): String =
    UrlUtils.domainOf(e.url).ifEmpty { e.appName.ifEmpty { e.title.ifEmpty { "other" } } }

private fun buildRows(entries: List<VaultEntry>, grouped: Boolean, expanded: Set<String>): List<ListRow> {
    if (!grouped) return entries.map { ListRow.Item(it, false) }
    return entries.groupBy { groupKey(it) }.flatMap<String, List<VaultEntry>, ListRow> { (key, list) ->
        if (list.size == 1) {
            listOf<ListRow>(ListRow.Item(list.first(), false))
        } else {
            val open = key in expanded
            buildList<ListRow> {
                add(ListRow.Header(key, list.size, open))
                if (open) list.forEach { add(ListRow.Item(it, true)) }
            }
        }
    }
}

@Composable
fun VaultListScreen(
    onOpen: (String) -> Unit,
    onOpenDrawer: () -> Unit,
    onShare: (String) -> Unit = {},
    onShareSelected: (List<String>) -> Unit = { ids -> ids.forEach(onShare) },
    vm: VaultListViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val selectedIds by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode by vm.selectionMode.collectAsStateWithLifecycle()
    val selectableIds by vm.selectableIds.collectAsStateWithLifecycle()
    var confirmBulkDelete by remember { mutableStateOf(false) }
    var sortMenuOpen by remember { mutableStateOf(false) }
    var createFolderOpen by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(emptySet<String>()) }
    var autofillEnabled by remember { mutableStateOf(AutofillStatus.isEnabled(context)) }
    LifecycleResumeEffect(Unit) {
        autofillEnabled = AutofillStatus.isEnabled(context)
        onPauseOrDispose { }
    }
    CollectMessages(vm.messages)

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (!selectionMode && !autofillEnabled) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(18.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    tonalElevation = 1.dp
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            androidx.compose.material.icons.Icons.Default.Security,
                            contentDescription = null,
                            modifier = Modifier.size(32.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                stringResource(R.string.p20_turn_on_bsrpro_autofill),
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                stringResource(R.string.p20_set_bsrpro_default_autofill),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = {
                            val intent = AutofillStatus.enableIntent(context)
                            runCatching { context.startActivity(intent) }
                                .onFailure { runCatching { context.startActivity(AutofillStatus.fallbackIntent()) } }
                        }) {
                            Text(stringResource(R.string.p20_set_up))
                        }
                    }
                }
            }
            if (selectionMode) {
                SelectionTopBar(
                    selectedCount = selectedIds.size,
                    allSelected = selectableIds.isNotEmpty() && selectedIds.containsAll(selectableIds),
                    onExit = vm::exitSelection,
                    onToggleSelectAll = vm::toggleSelectAll
                )
            } else {
                // Main vault header: menu + brand logo + large password search.
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onOpenDrawer) {
                        Icon(
                            androidx.compose.material.icons.Icons.Default.Menu,
                            contentDescription = stringResource(R.string.p17_open_navigation_drawer)
                        )
                    }
                    Image(
                        painter = painterResource(R.drawable.brand_logo),
                        contentDescription = stringResource(R.string.app_name),
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Surface(
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(26.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.weight(1f).height(48.dp)
                    ) {
                        Row(
                            Modifier.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = null,
                                modifier = Modifier.size(AppDimens.SmallIconSize),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                                if (state.query.isEmpty()) {
                                    Text(
                                        stringResource(R.string.vault_search_passwords),
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                androidx.compose.foundation.text.BasicTextField(
                                    value = state.query,
                                    onValueChange = vm::setQuery,
                                    singleLine = true,
                                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                                    cursorBrush = androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.primary),
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                // Secondary actions are kept compact so the search field stays large and easy to use.
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 8.dp, bottom = 2.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box {
                        IconButton(onClick = { sortMenuOpen = true }) {
                            Icon(Icons.Default.Sort, contentDescription = stringResource(R.string.vault_sort))
                        }
                        DropdownMenu(expanded = sortMenuOpen, onDismissRequest = { sortMenuOpen = false }) {
                            SortMode.values().forEach { option ->
                                DropdownMenuItem(
                                    text = { Text(stringResource(option.labelRes())) },
                                    onClick = { sortMenuOpen = false; vm.setSort(option) }
                                )
                            }
                        }
                    }
                    IconButton(onClick = vm::toggleGrouped) {
                        Icon(Icons.AutoMirrored.Filled.ViewList, contentDescription = stringResource(R.string.vault_group_by_site))
                    }
                }


            Text(
                "All ${state.totalCount}  •  Website ${state.websiteCount}  •  Mobile App ${state.mobileAppCount}",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(ListFilter.values().toList(), key = { it.name  }, contentType = { "item" }) { filter ->
                    CompactChip(selected = state.filter == filter, onClick = { vm.setFilter(filter) }, label = stringResource(filter.labelRes()))
                }
            }

            if (state.showCategories) LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(CATEGORIES, key = { it }, contentType = { "category" }) { category ->
                    CompactChip(selected = state.category == category, onClick = { vm.setCategory(category) }, label = categoryLabelRes(category).let { stringResource(it) })
                }
                item { CompactChip(selected = state.folderId == null, onClick = { vm.setFolder(null) }, label = stringResource(R.string.vault_all_folders)) }
                items(state.folders, key = { it.id  }, contentType = { "item" }) { folder ->
                    CompactChip(selected = state.folderId == folder.id, onClick = { vm.setFolder(folder.id) }, label = folder.name)
                }
                item { CompactChip(selected = false, onClick = { createFolderOpen = true }, label = stringResource(R.string.vault_add_folder)) }
            }

            }

            val rows = remember(state.entries, state.grouped, expanded) { buildRows(state.entries, state.grouped, expanded) }

            when {
                state.totalCount == 0 -> EmptyState(
                    stringResource(R.string.vault_no_passwords),
                    stringResource(R.string.vault_no_passwords_message)
                )
                rows.isEmpty() -> EmptyState(stringResource(R.string.vault_no_matches), stringResource(R.string.vault_no_matches_message))
                else -> {
                    LazyColumn(
                        Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(
                            rows,
                            key = { row -> if (row is ListRow.Header) "h:${row.key}" else "e:${(row as ListRow.Item).entry.id}" },
                            contentType = { row -> if (row is ListRow.Header) 0 else 1 }
                        ) { row ->
                            when (row) {
                                is ListRow.Header -> ListItem(
                                    headlineContent = { Text(row.key) },
                                    supportingContent = { Text(stringResource(R.string.vault_entries_count, row.count)) },
                                    leadingContent = { Icon(Icons.Default.Folder, contentDescription = null) },
                                    trailingContent = {
                                        Icon(
                                            if (row.expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                            contentDescription = null
                                        )
                                    },
                                    modifier = Modifier.clickable {
                                        expanded = if (row.key in expanded) expanded - row.key else expanded + row.key
                                    }
                                )
                                is ListRow.Item -> EntryRow(
                                    entry = row.entry,
                                    indented = row.indented,
                                    selectionMode = selectionMode,
                                    selected = row.entry.id in selectedIds,
                                    onClick = { onOpen(row.entry.id) },
                                    onLongClick = { vm.beginSelection(row.entry.id) },
                                    onToggleSelection = { vm.toggleSelection(row.entry.id) },
                                    onCopy = { vm.copyPassword(row.entry) },
                                    onToggleStar = { vm.toggleStar(row.entry) }
                                )
                            }
                        }
                        if (state.canLoadMore && !state.grouped) {
                            item {
                                TextButton(onClick = vm::loadMore, modifier = Modifier.fillMaxWidth()) {
                                    Text(stringResource(R.string.load_more_entries))
                                }
                            }
                        }
                    }
                }
            }
        }

        if (selectionMode) {
            SelectionBottomBar(
                selectedCount = selectedIds.size,
                onDelete = { confirmBulkDelete = true },
                onShare = { onShareSelected(selectedIds.toList()) },
                onFavorite = vm::favoriteSelected,
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

    }

    if (confirmBulkDelete && selectedIds.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { confirmBulkDelete = false },
            title = { Text(stringResource(R.string.selection_delete_title)) },
            text = { Text(stringResource(R.string.selection_delete_text, selectedIds.size)) },
            confirmButton = {
                TextButton(onClick = { confirmBulkDelete = false; vm.deleteSelected() }) {
                    Text(stringResource(R.string.p15_delete))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmBulkDelete = false }) {
                    Text(stringResource(R.string.p15_cancel))
                }
            }
        )
    }

    if (createFolderOpen) {
        AlertDialog(
            onDismissRequest = { newFolderName = ""; createFolderOpen = false },
            title = { Text(stringResource(R.string.vault_new_folder)) },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text(stringResource(R.string.vault_folder_name)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        vm.createFolder(newFolderName)
                        newFolderName = ""
                        createFolderOpen = false
                    },
                    enabled = newFolderName.trim().isNotEmpty()
                ) { Text(stringResource(R.string.vault_create)) }
            },
            dismissButton = { TextButton(onClick = { newFolderName = ""; createFolderOpen = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun EntryRow(
    entry: VaultEntry,
    indented: Boolean,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onToggleSelection: () -> Unit,
    onCopy: () -> Unit,
    onToggleStar: () -> Unit
) {
    val subtitle = entry.username.ifEmpty { UrlUtils.domainOf(entry.url).ifEmpty { entry.appName } }
    val targetLabel = when {
        entry.url.isNotBlank() && entry.isAppLogin -> "Website + Mobile App"
        entry.isAppLogin -> "Mobile App"
        entry.url.isNotBlank() -> "Website"
        else -> "Login"
    }

    ListItem(
        headlineContent = {
            Text(
                entry.title.ifEmpty { stringResource(R.string.health_untitled) },
                maxLines = 1
            )
        },
        supportingContent = {
            Column {
                if (subtitle.isNotEmpty()) Text(subtitle, maxLines = 1)
                Text(targetLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1)
                if (entry.url.isNotBlank()) Text(UrlUtils.domainOf(entry.url), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                if (entry.isAppLogin) {
                    val df = java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM)
                    val parts = buildList {
                        if (entry.createdAt > 0L) add("Saved " + df.format(java.util.Date(entry.createdAt)))
                        if (entry.lastUsedAt > 0L) add("Used " + df.format(java.util.Date(entry.lastUsedAt)))
                    }
                    if (parts.isNotEmpty()) {
                        Text(
                            parts.joinToString(" · "),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1
                        )
                    }
                }
            }
        },
        leadingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (selectionMode) {
                    androidx.compose.material3.Checkbox(checked = selected, onCheckedChange = { onToggleSelection() })
                }
                Avatar(entry.title.ifEmpty { subtitle })
            }
        },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!selectionMode) {
                    IconButton(onClick = onToggleStar) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = stringResource(
                                if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite
                            ),
                            tint = if (entry.starred) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(AppDimens.IconSize)
                        )
                    }
                    if (entry.password.isNotEmpty()) {
                        Box(
                            Modifier
                                .padding(horizontal = 8.dp)
                                .size(8.dp)
                                .background(bucketColor(entry.strengthBucket()), CircleShape)
                        )
                        IconButton(onClick = onCopy) {
                            Icon(Icons.Default.ContentCopy, stringResource(R.string.vault_copy_password))
                        }
                    }
                }
            }
        },
        modifier = Modifier
            .combinedClickable(
                onClick = { if (selectionMode) onToggleSelection() else onClick() },
                onLongClick = { if (selectionMode) onToggleSelection() else onLongClick() }
            )
            .padding(start = if (indented) 24.dp else 0.dp)
    )
}


private fun ListFilter.labelRes(): Int = when (this) {
    ListFilter.ALL -> R.string.p15_all
    ListFilter.STRONG -> R.string.p15_strong
    ListFilter.WEAK -> R.string.p15_weak
    ListFilter.STARRED -> R.string.p15_starred
    ListFilter.WEBSITE -> R.string.filter_website
    ListFilter.MOBILE_APP -> R.string.filter_mobile_app
}

private fun SortMode.labelRes(): Int = when (this) {
    SortMode.NAME -> R.string.sort_name
    SortMode.UPDATED -> R.string.sort_recently_updated
    SortMode.USED -> R.string.sort_recently_used
    SortMode.STRENGTH -> R.string.sort_strength
}

private fun categoryLabelRes(category: String): Int = when (category.lowercase()) {
    "work" -> R.string.p15_work
    "personal" -> R.string.p15_personal
    "banking" -> R.string.p15_banking
    "social" -> R.string.p15_social
    else -> R.string.p15_other
}

@Composable
private fun CompactChip(selected: Boolean, onClick: () -> Unit, label: String) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelMedium, maxLines = 1) },
        modifier = Modifier.height(32.dp)
    )
}
