package pro.babasitaram.vault.data.backup

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertFalse
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class BackupFixedNameTest {
    @Test fun `automatic backup uses one stable canonical filename`() {
        assertEquals("BSRPRO.Vault", AutoBackupManager.FINAL_NAME)
        assertEquals("BSRPRO_Backups", AutoBackupManager.FOLDER)
        assertFalse(AutoBackupNames.isLegacyDated(AutoBackupManager.FINAL_NAME))
    }

    @Test fun `extension backup folder is discoverable but not the Android auto-backup destination`() {
        assertEquals("BSRPRO Vault Password_Backups", AutoBackupManager.EXTENSION_FOLDER)
        assertTrue(AutoBackupManager.EXTENSION_FOLDER != AutoBackupManager.FOLDER)
    }
}

@Test
fun `numbered MediaStore duplicate names are recognized as the canonical family`() {
    assertTrue(AutoBackupNames.isNumberedDuplicate("BSRPRO (1).Vault", "BSRPRO.Vault"))
    assertTrue(AutoBackupNames.isNumberedDuplicate("bsrpro (7).vault", "BSRPRO.Vault"))
    assertFalse(AutoBackupNames.isNumberedDuplicate("BSRPRO-OLD.Vault", "BSRPRO.Vault"))
}

