package pro.babasitaram.vault.autofill

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.presentation.components.PasswordField
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.autofill.AutofillId
import android.view.autofill.AutofillManager
import android.view.inputmethod.InlineSuggestionsRequest
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.IntentCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.autofill.model.AutofillField
import pro.babasitaram.vault.autofill.model.AutofillFieldType
import pro.babasitaram.vault.autofill.model.ParsedStructure
import pro.babasitaram.vault.core.crypto.SessionKeyStore
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.core.security.ScreenshotGuard
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.repository.VaultRepository
import pro.babasitaram.vault.domain.usecase.RestorePersistedSessionUseCase
import pro.babasitaram.vault.domain.usecase.UnlockVaultUseCase
import pro.babasitaram.vault.presentation.theme.VaultTheme
import pro.babasitaram.vault.presentation.util.toUserMessage
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import pro.babasitaram.vault.core.util.L

/**
 * Opened by the autofill framework when the user taps "Unlock BSRPRO Vault" in the suggestion list.
 * Biometric prompt first (when enabled); falls back to a master-password dialog.
 * On success it returns a FillResponse with the matching datasets.
 */
@AndroidEntryPoint
class AutofillAuthActivity : FragmentActivity() {

    @Inject lateinit var biometric: BiometricAuthenticator
    @Inject lateinit var biometricStore: BiometricSessionKeyStore
    @Inject lateinit var restoreSession: RestorePersistedSessionUseCase
    @Inject lateinit var settings: SettingsRepository
    @Inject lateinit var unlockVault: UnlockVaultUseCase
    @Inject lateinit var session: SessionKeyStore
    @Inject lateinit var repository: VaultRepository
    @Inject lateinit var factory: AutofillDatasetFactory
    @Inject lateinit var autofillSession: AutofillSessionGate

    data class Choice(val entryId: String, val title: String, val subtitle: String, val related: Boolean)

    data class AuthUi(
        val showPassword: Boolean = false,
        val busy: Boolean = false,
        val error: String? = null,
        val choices: List<Choice> = emptyList(),
        val notice: String? = null,
        val noticeIsError: Boolean = false
    )

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val ui = MutableStateFlow(AuthUi())
    private var parsed: ParsedStructure? = null
    private var inlineRequest: InlineSuggestionsRequest? = null
    private var candidates: List<EntryMatch> = emptyList()
    private var nightTheme: Boolean = false
    private var autofillSessionSeconds: Int = 5 * 60

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScreenshotGuard.enable(this)
        parsed = readRequest(intent)
        if (parsed == null) {
            AutofillDiagnostics.record("A0 auth activity: unreadable request")
            cancelAndFinish()
            return
        }
        parsed?.let {
            AutofillDiagnostics.record(
                "A1 auth activity started",
                "pkg=${it.packageName} domain=${it.webDomain ?: "-"} fields=${it.fields.size} unlocked=${session.isUnlocked.value}"
            )
        }
        setContent {
            val cfg by settings.settings.collectAsStateWithLifecycle(initialValue = pro.babasitaram.vault.core.model.VaultSettings())
            val darkTheme = when (cfg.theme) {
                ThemeMode.DARK -> true
                ThemeMode.LIGHT -> false
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
            }
            nightTheme = darkTheme
            VaultTheme(darkTheme = darkTheme) {
                val state by ui.collectAsStateWithLifecycle()
                if (state.showPassword) {
                    PasswordDialog(state = state, onSubmit = ::submitPassword, onCancel = ::cancelAndFinish)
                }
                if (state.choices.isNotEmpty()) {
                    ChoiceDialog(state.choices, onPick = ::pick, onCancel = ::cancelAndFinish)
                }
                state.notice?.let { NoticeDialog(it, state.noticeIsError, onClose = ::cancelAndFinish) }
            }
        }
        scope.launch {
            try { start() } catch (t: Throwable) {
                AutofillDiagnostics.record("A5 auth flow exception", "${t.javaClass.simpleName}: ${t.message.orEmpty()}")
                showSafeFailure("Autofill could not continue. Open BSRPRO Vault and try again.")
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun start() {
        val cfg = settings.current()
        autofillSessionSeconds = cfg.autofillSessionSeconds

        // Reuse the in-memory session first. This keeps normal navigation and repeated
        // Autofill requests smooth without starting a new authentication flow.
        if (cfg.quickAutofillEnabled && session.hasValidSession() && autofillSession.isValid()) {
            deliver()
            return
        }

        // If Android recreated/killed the process, restore only from the encrypted Key-B
        // credential and the persisted, time-bounded session metadata. A boolean flag is never enough.
        if (cfg.quickAutofillEnabled) {
            when (restoreSession(forAutofill = true)) {
                RestorePersistedSessionUseCase.Result.Restored -> {
                    deliver()
                    return
                }
                RestorePersistedSessionUseCase.Result.RequiresAuthentication -> Unit
                RestorePersistedSessionUseCase.Result.NotAvailable -> Unit
            }
        }

        val biometricUsable = cfg.biometricEnabled && biometricStore.hasSecureCredential() &&
            biometric.availability() == BiometricAvailability.Available
        if (!biometricUsable) {
            ui.update { it.copy(showPassword = true) }
            return
        }

        unlockWithQuickAuthentication()
    }

    private suspend fun unlockWithQuickAuthentication() {
        try {
            val prepared = biometricStore.prepareDecryptCipher()
            if (prepared == null) {
                ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_autofill_auth_quick_unlock_is_not_configured)) }
                return
            }
            biometric.authenticateWithCipher(
                activity = this,
                cipher = prepared.cipher,
                title = L.s(R.string.autofill_unlock_title),
                negativeButtonText = L.s(R.string.p18_common_use_device_pin),
                subtitle = L.s(R.string.p18_autofill_auth_confirm_your_identity_to_autofill)
            ).collect { result ->
                when (result) {
                    is AuthResult.Success -> unlockFromPreparedCredential(prepared)
                    AuthResult.FallbackRequested -> unlockWithDeviceCredential()
                    AuthResult.Cancelled -> cancelAndFinish()
                    is AuthResult.Error -> ui.update { it.copy(showPassword = true, error = result.message) }
                    AuthResult.Failed -> Unit
                }
            }
        } catch (_: android.security.keystore.UserNotAuthenticatedException) {
            unlockWithDeviceCredential()
        } catch (_: android.security.keystore.KeyPermanentlyInvalidatedException) {
            biometricStore.resetForSecurityChange()
            settings.update { it.copy(biometricEnabled = false) }
            ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_common_biometric_security_changed_enter_you)) }
        }
    }

    private suspend fun unlockWithDeviceCredential() {
        biometric.authenticate(this, "Unlock BSRPRO Vault", "Use fingerprint, face or device PIN").collect { result ->
            when (result) {
                is AuthResult.Success -> {
                    try {
                        val prepared = biometricStore.prepareDecryptCipher()
                        if (prepared == null) {
                            ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_autofill_auth_quick_unlock_is_not_configured)) }
                        } else {
                            unlockFromPreparedCredential(prepared)
                        }
                    } catch (_: android.security.keystore.UserNotAuthenticatedException) {
                        ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_autofill_auth_quick_unlock_authentication_expired)) }
                    } catch (_: android.security.keystore.KeyPermanentlyInvalidatedException) {
                        biometricStore.resetForSecurityChange()
                        settings.update { it.copy(biometricEnabled = false) }
                        ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_common_biometric_security_changed_enter_you)) }
                    }
                }
                AuthResult.Cancelled, AuthResult.Failed, AuthResult.FallbackRequested -> Unit
                is AuthResult.Error -> ui.update { it.copy(showPassword = true, error = result.message) }
            }
        }
    }

    private suspend fun unlockFromPreparedCredential(prepared: BiometricSessionKeyStore.PreparedDecrypt) {
        val pw = try {
            biometricStore.decryptPrepared(prepared)
        } catch (_: android.security.keystore.UserNotAuthenticatedException) {
            ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_common_authentication_expired_try_again)) }
            return
        } catch (_: android.security.keystore.KeyPermanentlyInvalidatedException) {
            biometricStore.resetForSecurityChange()
            settings.update { it.copy(biometricEnabled = false) }
            ui.update { it.copy(showPassword = true, error = L.s(R.string.p18_common_biometric_security_changed_enter_you)) }
            return
        }
        try {
            unlockWith(pw)
        } finally {
            pw.fill('\u0000')
        }
    }

    private fun submitPassword(password: String) {
        val pw = password.toCharArray()
        scope.launch {
            ui.update { it.copy(busy = true, error = null) }
            try {
                unlockWith(pw)
            } finally {
                pw.fill('\u0000')
                ui.update { it.copy(busy = false) }
            }
        }
    }

    private suspend fun unlockWith(pw: CharArray) {
        when (val r = unlockVault(pw)) {
            is VaultResult.Success -> {
                autofillSession.touch(autofillSessionSeconds)
                deliver()
            }
            is VaultResult.Failure -> {
                if (r.error == VaultError.InvalidMasterPassword && settings.current().biometricEnabled) {
                    // master password changed since biometrics were enabled
                    biometricStore.clearSecureCredential()
                    biometricStore.clearSessionMetadata()
                    settings.update { it.copy(biometricEnabled = false) }
                }
                ui.update { it.copy(showPassword = true, error = r.error.toUserMessage()) }
            }
            VaultResult.Loading -> Unit
        }
    }

    private fun deliver() {
        val p = parsed ?: return cancelAndFinish()
        var matches = AutofillMatcher.match(repository.entries.value, p.packageName, p.webDomain)
        if (p.isOtpOnly) matches = matches.filter { it.entry.totp.isNotBlank() }
        candidates = matches
        AutofillDiagnostics.record(
            "A2 after unlock",
            "entries=${repository.entries.value.size} matches=${matches.size} for ${p.webDomain ?: p.packageName}"
        )
        when {
            matches.isEmpty() -> {
                ui.update {
                    it.copy(
                        showPassword = false, busy = false, noticeIsError = false,
                        notice = "No saved login for this " + (if (p.webDomain != null) "website" else "app") +
                            ". Open BSRPRO Vault, add one and link it to this " + (if (p.webDomain != null) "site" else "app") + "."
                    )
                }
            }
            // a single exact match is filled straight away; anything else is confirmed by the user
            matches.size == 1 && matches[0].kind == MatchKind.EXACT -> returnDataset(matches[0])
            else -> ui.update {
                it.copy(
                    showPassword = false, busy = false,
                    choices = matches.map { m ->
                        Choice(
                            entryId = m.entry.id,
                            title = m.entry.title.ifBlank { m.entry.appName.ifBlank { m.entry.url.ifBlank { "BSRPRO" } } },
                            subtitle = m.entry.username.ifEmpty { m.entry.email.ifEmpty { m.entry.mobile } },
                            related = m.kind == MatchKind.RELATED
                        )
                    }
                )
            }
        }
    }

    private fun pick(entryId: String) {
        val m = candidates.firstOrNull { it.entry.id == entryId } ?: return cancelAndFinish()
        returnDataset(m)
    }

    /** Returns ONE dataset built from the ids the framework gave us — they are never rebuilt or filtered. */
    private fun returnDataset(m: EntryMatch) {
        val p = parsed ?: return cancelAndFinish()
        val dataset = try {
            factory.datasetFor(p, m, System.currentTimeMillis(), nightTheme)
        } catch (t: Throwable) {
            AutofillDiagnostics.record("A6 dataset exception", "${t.javaClass.simpleName}: ${t.message.orEmpty()}")
            showSafeFailure("Could not prepare autofill. Open BSRPRO Vault and try again.")
            return
        }
        if (dataset == null) {
            AutofillDiagnostics.record("A3 dataset EMPTY", "entry has no value for the detected fields")
            ui.update { it.copy(choices = emptyList(), notice = L.s(R.string.p18_autofill_auth_this_entry_has_nothing_to)) }
            return
        }
        AutofillDiagnostics.record(
            "A3 returning dataset",
            "ids=${p.fillableFields.size} types=${p.fillableFields.joinToString(",") { it.type.name }} kind=${m.kind}"
        )
        autofillSession.touch(autofillSessionSeconds)
        try {
            deliverResult(dataset)
        } catch (t: Throwable) {
            AutofillDiagnostics.record("A7 result delivery exception", "${t.javaClass.simpleName}: ${t.message.orEmpty()}")
            // second attempt: bare dataset (no presentation extras) built from the same ids
            val retry = runCatching { factory.datasetFor(p, m, System.currentTimeMillis(), nightTheme, lightweight = true) }.getOrNull()
            val ok = retry != null && runCatching { deliverResult(retry) }.onFailure {
                AutofillDiagnostics.record("A7b retry failed", "${it.javaClass.simpleName}: ${it.message.orEmpty()}")
            }.isSuccess
            if (!ok) showSafeFailure("Autofill delivery failed. Open BSRPRO Vault and copy the login manually.", isError = true)
        }
    }

    private fun deliverResult(dataset: android.service.autofill.Dataset) {
        setResult(RESULT_OK, Intent().putExtra(AutofillManager.EXTRA_AUTHENTICATION_RESULT, dataset))
        AutofillDiagnostics.record("A3b result set", "finishing")
        finish()
    }

    private fun showSafeFailure(message: String, isError: Boolean = true) {
        if (isFinishing || isDestroyed) return
        runCatching {
            ui.update { it.copy(showPassword = false, busy = false, choices = emptyList(), notice = message, noticeIsError = isError) }
        }.onFailure { AutofillDiagnostics.record("A8 failure UI exception", it.javaClass.simpleName) }
    }

    private fun cancelAndFinish() {
        AutofillDiagnostics.record("A4 auth cancelled/closed")
        setResult(RESULT_CANCELED)
        finish()
    }

    private fun readRequest(intent: Intent): ParsedStructure? {
        val ids = IntentCompat.getParcelableArrayListExtra(intent, EXTRA_IDS, AutofillId::class.java) ?: return null
        val types = intent.getStringArrayExtra(EXTRA_TYPES) ?: return null
        if (ids.isEmpty() || ids.size != types.size) return null
        val fields = ids.mapIndexedNotNull { i, id ->
            val type = runCatching { AutofillFieldType.valueOf(types[i]) }.getOrNull() ?: return@mapIndexedNotNull null
            AutofillField(id, type)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            inlineRequest = IntentCompat.getParcelableExtra(intent, EXTRA_INLINE, InlineSuggestionsRequest::class.java)
        }
        return ParsedStructure(
            packageName = intent.getStringExtra(EXTRA_PACKAGE).orEmpty(),
            webDomain = intent.getStringExtra(EXTRA_DOMAIN),
            webScheme = intent.getStringExtra(EXTRA_SCHEME),
            fields = fields
        )
    }

    companion object {
        const val EXTRA_IDS = "pro.babasitaram.vault.autofill.IDS"
        const val EXTRA_TYPES = "pro.babasitaram.vault.autofill.TYPES"
        const val EXTRA_PACKAGE = "pro.babasitaram.vault.autofill.PACKAGE"
        const val EXTRA_DOMAIN = "pro.babasitaram.vault.autofill.DOMAIN"
        const val EXTRA_SCHEME = "pro.babasitaram.vault.autofill.SCHEME"
        const val EXTRA_INLINE = "pro.babasitaram.vault.autofill.INLINE"
    }
}

@Composable
private fun PasswordDialog(state: AutofillAuthActivity.AuthUi, onSubmit: (String) -> Unit, onCancel: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(stringResource(R.string.autofill_unlock_title)) },
        text = {
            Column {
                PasswordField(value = pw, onValueChange = { pw = it }, label = stringResource(R.string.p17_loc_074), enabled = !state.busy)
                state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSubmit(pw); pw = "" }, enabled = pw.isNotEmpty() && !state.busy) { Text(stringResource(R.string.p15_unlock)) }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun ChoiceDialog(choices: List<AutofillAuthActivity.Choice>, onPick: (String) -> Unit, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(stringResource(R.string.p18_autofill_auth_choose_a_login)) },
        text = {
            androidx.compose.foundation.lazy.LazyColumn {
                items(choices.size) { i ->
                    val c = choices[i]
                    TextButton(onClick = { onPick(c.entryId) }, modifier = androidx.compose.ui.Modifier.fillMaxWidth()) {
                        Column(androidx.compose.ui.Modifier.fillMaxWidth()) {
                            Text(c.title)
                            val sub = (if (c.related) "\u26A0 related site \u2022 " else "") + c.subtitle
                            if (sub.isNotBlank()) Text(sub, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onCancel) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun NoticeDialog(message: String, isError: Boolean, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (isError) stringResource(R.string.p18_autofill_auth_autofill_problem) else stringResource(R.string.p18_autofill_auth_nothing_to_fill)) },
        text = { Text(message) },
        confirmButton = { TextButton(onClick = onClose) { Text("OK") } }
    )
}
