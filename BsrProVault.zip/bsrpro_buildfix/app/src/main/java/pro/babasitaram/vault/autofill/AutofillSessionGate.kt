package pro.babasitaram.vault.autofill

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import dagger.hilt.android.qualifiers.ApplicationContext
import android.os.SystemClock
import pro.babasitaram.vault.core.model.VaultSettings
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Short-lived authentication window used only by Android Autofill.
 * It never stores credentials; the vault session remains the source of decrypted data.
 * Screen-off immediately invalidates the Autofill window.
 */
@Singleton
class AutofillSessionGate @Inject constructor(
    @ApplicationContext private val context: Context,
) {
    @Volatile private var expiresAtElapsedMs: Long = 0L
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (Intent.ACTION_SCREEN_OFF == intent.action) clear()
        }
    }

    init {
        context.registerReceiver(receiver, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    fun isValid(nowElapsedMs: Long = SystemClock.elapsedRealtime()): Boolean {
        val expiry = expiresAtElapsedMs
        return expiry > nowElapsedMs
    }

    fun touch(seconds: Int = 5 * 60, nowElapsedMs: Long = SystemClock.elapsedRealtime()) {
        expiresAtElapsedMs = if (seconds == VaultSettings.AUTOFILL_UNTIL_SCREEN_LOCK) {
            Long.MAX_VALUE
        } else {
            nowElapsedMs + seconds.coerceIn(60, 30 * 60) * 1000L
        }
    }

    fun clear() {
        expiresAtElapsedMs = 0L
    }
}

