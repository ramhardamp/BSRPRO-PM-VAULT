package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.StrengthLevel

fun strengthColor(level: StrengthLevel): Color = when (level) {
    StrengthLevel.VERY_WEAK -> Color(0xFFF87171)
    StrengthLevel.WEAK -> Color(0xFFFB923C)
    StrengthLevel.FAIR -> Color(0xFFFBBF24)
    StrengthLevel.GOOD -> Color(0xFF34D399)
    StrengthLevel.VERY_STRONG -> Color(0xFF22D3A5)
}

fun bucketColor(bucket: String): Color = when (bucket) {
    "strong" -> Color(0xFF22D3A5)
    "medium" -> Color(0xFFFBBF24)
    else -> Color(0xFFF87171)
}

private val AVATAR_COLORS = listOf(
    0xFF7C5CFC, 0xFFC084FC, 0xFF22D3A5, 0xFFF59E0B, 0xFF3B82F6,
    0xFFEF4444, 0xFF10B981, 0xFF6366F1, 0xFFEC4899, 0xFF14B8A6
)

fun avatarColor(seed: String): Color {
    var h = 0
    for (c in seed) h = h * 31 + c.code
    return Color(AVATAR_COLORS[Math.abs(h % AVATAR_COLORS.size)])
}

/** Background ke hisaab se white ya black chunta hai, jiska contrast zyada ho (amber/mint par white 2:1 se kam tha). */
private fun readableOn(bg: Color): Color {
    val l = bg.luminance()
    val whiteContrast = 1.05f / (l + 0.05f)
    val blackContrast = (l + 0.05f) / 0.05f
    return if (whiteContrast >= blackContrast) Color.White else Color.Black
}

@Composable
fun Avatar(text: String, modifier: Modifier = Modifier) {
    val bg = avatarColor(text)
    Box(
        modifier = modifier.size(AppDimens.AvatarSize).background(bg, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.trim().take(1).uppercase().ifEmpty { "?" },
            color = readableOn(bg),
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun StrengthMeter(password: String, modifier: Modifier = Modifier) {
    if (password.isEmpty()) return
    val level = PasswordStrength.level(password)
    Column(modifier.fillMaxWidth()) {
        LinearProgressIndicator(
            progress = { (PasswordStrength.score(password) / 5f).coerceIn(0.05f, 1f) },
            color = strengthColor(level),
            modifier = Modifier.fillMaxWidth()
        )
        Text(level.label, style = MaterialTheme.typography.labelSmall, color = strengthColor(level))
    }
}

@Composable
fun PasswordField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    showStrength: Boolean = false,
    enabled: Boolean = true,
    keyboardType: KeyboardType = KeyboardType.Password,
    imeAction: ImeAction = ImeAction.Done,
    onImeAction: (() -> Unit)? = null,
    trailingExtra: @Composable (() -> Unit)? = null
) {
    var visible by rememberSaveable { mutableStateOf(false) }
    Column(modifier) {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label) },
            singleLine = true,
            enabled = enabled,
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
            // onImeAction null ho to Compose ka default behaviour (Next = focus aage, Done = keyboard band) rehta hai
            keyboardActions = if (onImeAction != null) KeyboardActions(onDone = { onImeAction() }) else KeyboardActions.Default,
            trailingIcon = {
                Row {
                    trailingExtra?.invoke()
                    IconButton(onClick = { visible = !visible }) {
                        Icon(
                            if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                            contentDescription = androidx.compose.ui.res.stringResource(if (visible) pro.babasitaram.vault.R.string.p17_hide_password else pro.babasitaram.vault.R.string.p17_show_password)
                        )
                    }
                }
            },
            modifier = Modifier.fillMaxWidth()
        )
        if (showStrength) StrengthMeter(value, Modifier.padding(top = 4.dp))
    }
}

@Composable
fun EmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    icon: ImageVector = Icons.Default.Inbox,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Box(modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)
        ) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(40.dp), tint = MaterialTheme.colorScheme.primary)
            Text(title, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
            Text(
                message,
                textAlign = TextAlign.Center,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!actionLabel.isNullOrBlank() && onAction != null) {
                androidx.compose.material3.TextButton(onClick = onAction) {
                    Text(actionLabel)
                }
            }
        }
    }
}
