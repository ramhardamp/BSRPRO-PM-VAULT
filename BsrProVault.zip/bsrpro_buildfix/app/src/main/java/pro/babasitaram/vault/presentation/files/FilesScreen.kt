@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
package pro.babasitaram.vault.presentation.files

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.EmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens

@Composable
fun FilesScreen(onBack: () -> Unit = {}, vm: FilesViewModel = hiltViewModel()) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> uri?.let(vm::importFile) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.p15_files), style = MaterialTheme.typography.titleLarge) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }) },
        floatingActionButton = { ExtendedFloatingActionButton(onClick = { picker.launch(arrayOf(context.getString(pro.babasitaram.vault.R.string.p17_loc_119))) }, icon = { Icon(Icons.Default.Add, null) }, text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_120)) }) }
    ) { padding ->
        if (entries.isEmpty()) {
            EmptyState(
                stringResource(R.string.p15_no_files),
                stringResource(R.string.files_empty_message),
                Modifier.padding(padding).fillMaxWidth(),
                actionLabel = stringResource(R.string.files_upload),
                onAction = { picker.launch(arrayOf("*/*")) }
            )
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(AppDimens.ScreenHorizontal), verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)) {
                items(entries, key = { it.id  }, contentType = { "item" }) { entry -> FileItem(entry, context, onDelete = { vm.delete(entry.id) }) }
            }
        }
    }
}

@Composable
private fun FileItem(entry: VaultEntry, context: android.content.Context, onDelete: () -> Unit) {
    val primaryUriField = entry.customFields.firstOrNull {
        it.k.equals("file_uri", true) || it.k.startsWith("attachment_uri_", true)
    }
    val suffix = primaryUriField?.k?.removePrefix("attachment_uri_")
    val uri = primaryUriField?.v?.let(Uri::parse)
    val name = entry.fileField("file_name").orEmpty().ifBlank {
        entry.customFields.firstOrNull { it.k.equals("attachment_name_$suffix", true) }?.v.orEmpty()
    }.ifBlank { entry.title }
    val mime = entry.fileField("mime_type").orEmpty().ifBlank {
        entry.customFields.firstOrNull { it.k.equals("attachment_mime_$suffix", true) }?.v.orEmpty()
    }.ifBlank { "application/octet-stream" }
    val size = entry.fileField("file_size")?.toLongOrNull() ?:
        primaryUriField?.let {
            context.contentResolver.query(Uri.parse(it.v), arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val i = c.getColumnIndex(OpenableColumns.SIZE)
                    if (i >= 0 && !c.isNull(i)) c.getLong(i) else 0L
                } else 0L
            }
        } ?: 0L
    var menu by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().combinedClickable(onClick = { openFile(context, uri, mime) }, onLongClick = { menu = true })) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row {
                Column(Modifier.weight(1f)) {
                    Text(name.ifBlank { "File" }, style = MaterialTheme.typography.titleMedium)
                    Text(mime, style = MaterialTheme.typography.bodySmall)
                    Text(formatSize(size), style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, "More") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { openFile(context, uri, mime) }, enabled = uri != null) { Icon(Icons.Default.FolderOpen, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_121)) }
                TextButton(onClick = { shareFile(context, uri, mime) }, enabled = uri != null) { Icon(Icons.Default.Download, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_122)) }
            }
        }
    }
    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
        DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_068)) }, onClick = { menu = false; openFile(context, uri, mime) })
        DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_123)) }, onClick = { menu = false; shareFile(context, uri, mime) })
        DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) }, onClick = { menu = false; confirmDelete = true })
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false }, title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_124)) }, text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_125)) }, confirmButton = { TextButton(onClick = { confirmDelete = false; onDelete() }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) } }, dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } })
}

private fun openFile(context: android.content.Context, uri: Uri?, mime: String) {
    if (uri == null) return
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mime)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }
}

private fun shareFile(context: android.content.Context, uri: Uri?, mime: String) {
    if (uri == null) return
    context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }, "Export file"))
}

private fun formatSize(size: Long): String = when {
    size <= 0 -> "Size unavailable"
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> "${size / 1024} KB"
    else -> "${size / (1024 * 1024)} MB"
}
