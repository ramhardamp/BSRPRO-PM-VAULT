package pro.babasitaram.vault.autofill

import java.text.SimpleDateFormat
import java.util.ArrayDeque
import java.util.Date
import java.util.Locale

/**
 * In-memory trace of the last autofill requests, shown in Settings → Autofill → Diagnostics.
 * Stores ONLY structural facts (package, domain, counts, outcome) — never usernames, passwords or field values.
 */
object AutofillDiagnostics {
    const val TAG = "BSRPROAutofill"
    private const val MAX = 40
    private val events = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun record(stage: String, detail: String = "") {
        if (events.size >= MAX) events.removeFirst()
        events.addLast("${fmt.format(Date())}  $stage${if (detail.isNotEmpty()) " — $detail" else ""}")
        // logcat: adb logcat -s BSRPROAutofill   (structure only — never usernames, passwords or values)
        try {
            android.util.Log.d(TAG, "$stage${if (detail.isNotEmpty()) " | $detail" else ""}")
        } catch (e: Throwable) {
            // plain JVM unit tests have no android.util.Log
        }
    }

    @Synchronized
    fun snapshot(): List<String> = events.toList().asReversed()

    @Synchronized
    fun clear() = events.clear()

    @Synchronized
    fun report(): String =
        if (events.isEmpty()) "No autofill requests received yet." else events.toList().asReversed().joinToString("\n")
}
