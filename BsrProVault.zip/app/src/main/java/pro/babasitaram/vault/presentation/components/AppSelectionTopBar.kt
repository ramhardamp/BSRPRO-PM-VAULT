package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.RowScope
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.size
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.R

/** Full multi-select top bar: back, selected count, select-all, delete and share, spec §2.3. */
@Composable
fun AppSelectionTopBar(
    selectedCount: Int,
    allSelected: Boolean,
    onBack: () -> Unit,
    onToggleSelectAll: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        modifier = modifier,
        title = {
            androidx.compose.material3.Text(
                text = stringResource(R.string.selection_selected_count, selectedCount),
                style = MaterialTheme.typography.titleLarge
            )
        },
        navigationIcon = {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.common_back), modifier = Modifier.size(AppDimens.IconSize))
            }
        },
        actions = {
            IconButton(onClick = onToggleSelectAll) {
                Icon(Icons.Default.CheckBox, contentDescription = stringResource(if (allSelected) R.string.selection_deselect_all else R.string.selection_select_all), modifier = Modifier.size(AppDimens.IconSize))
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = stringResource(R.string.p15_delete), modifier = Modifier.size(AppDimens.IconSize))
            }
            IconButton(onClick = onShare) {
                Icon(Icons.Default.Share, contentDescription = stringResource(R.string.p15_share), modifier = Modifier.size(AppDimens.IconSize))
            }
            actions()
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            navigationIconContentColor = MaterialTheme.colorScheme.onSurface,
            actionIconContentColor = MaterialTheme.colorScheme.onSurface
        )
    )
}
