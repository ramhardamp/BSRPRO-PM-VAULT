package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.height
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import pro.babasitaram.vault.presentation.theme.CategoryAppLogin
import pro.babasitaram.vault.presentation.theme.CategoryCards
import pro.babasitaram.vault.presentation.theme.CategoryIdentities
import pro.babasitaram.vault.presentation.theme.CategoryNotes
import pro.babasitaram.vault.presentation.theme.CategoryVault

/** Vault category identifiers and their Section §1.1 category colors. */
enum class AppCategory { VAULT, APP_LOGIN, CARDS, IDENTITIES, NOTES }

@Composable
fun AppCategoryChip(
    category: AppCategory,
    label: String,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val color = when (category) {
        AppCategory.VAULT -> CategoryVault
        AppCategory.APP_LOGIN -> CategoryAppLogin
        AppCategory.CARDS -> CategoryCards
        AppCategory.IDENTITIES -> CategoryIdentities
        AppCategory.NOTES -> CategoryNotes
    }
    AssistChip(
        onClick = { onClick?.invoke() },
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        modifier = modifier.height(AppDimens.ChipHeight),
        shape = RoundedCornerShape(AppShapes.Pill),
        colors = AssistChipDefaults.assistChipColors(
            containerColor = color.copy(alpha = AppTokens.SecondaryContentAlpha),
            labelColor = color
        )
    )
}
