package pro.babasitaram.vault.presentation.about

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import pro.babasitaram.vault.domain.repository.SettingsRepository

/** Hilt wiring for About; repository reuse is presentation-only and does not mutate vault data. */
@HiltViewModel
class AboutScreenViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel()
