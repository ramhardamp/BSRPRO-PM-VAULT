package pro.babasitaram.vault.autofill

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.autofill.AutofillManager

object AutofillStatus {
    /** True when BSRPRO Vault is the autofill service the user selected. */
    fun isEnabled(context: Context): Boolean =
        runCatching { context.getSystemService(AutofillManager::class.java)?.hasEnabledAutofillServices() == true }
            .getOrDefault(false)

    fun enableIntent(context: Context): Intent =
        Intent(Settings.ACTION_REQUEST_SET_AUTOFILL_SERVICE, Uri.parse("package:${context.packageName}"))

    fun fallbackIntent(): Intent = Intent(Settings.ACTION_SETTINGS)

    fun isSupported(context: Context): Boolean =
        runCatching { context.getSystemService(AutofillManager::class.java)?.isAutofillSupported == true }.getOrDefault(false)

    // The first-run "Enable Autofill?" dialog is shown at most once per install (non-secret UI flag).
    private const val UI_PREFS = "bsrpro_ui_state"
    private const val KEY_PROMPT_SEEN = "autofill_prompt_seen_v1"

    fun promptSeen(context: Context): Boolean =
        context.getSharedPreferences(UI_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PROMPT_SEEN, false)

    fun markPromptSeen(context: Context) {
        context.getSharedPreferences(UI_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_PROMPT_SEEN, true).apply()
    }
}
