package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import pro.babasitaram.vault.R

/** Full empty state from UI/UX spec §2.9 and §4 Consistency Rules; 100dp logo, 24sp heading, 14sp body, optional CTA. */
@Composable
fun AppEmptyState(
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(AppDimens.Large),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painter = painterResource(R.drawable.brand_logo),
            contentDescription = null,
            modifier = Modifier.size(AppDimens.LogoMedium)
        )
        Text(
            text = title,
            style = MaterialTheme.typography.headlineMedium,
            color = MaterialTheme.colorScheme.onSurface,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = AppDimens.Large)
        )
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = AppTokens.SecondaryContentAlpha),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = AppDimens.Medium)
        )
        if (!actionLabel.isNullOrBlank() && onAction != null) {
            AppButton(
                label = actionLabel,
                onClick = onAction,
                variant = AppButtonVariant.PRIMARY,
                modifier = Modifier.padding(top = AppDimens.Large)
            )
        }
    }
}
