// file: app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesScreen.kt
@file:OptIn(
    androidx.compose.foundation.ExperimentalFoundationApi::class,
    androidx.compose.material3.ExperimentalMaterial3Api::class
)

package pro.babasitaram.vault.presentation.mobiles

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.R

import pro.babasitaram.vault.presentation.components.AppScreenState
import pro.babasitaram.vault.presentation.components.AppHeadingText
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.Avatar
import pro.babasitaram.vault.presentation.components.AppEmptyState
import pro.babasitaram.vault.presentation.components.SelectionBottomBar
import pro.babasitaram.vault.presentation.components.SelectionTopBar
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens

/** Phase16G Batch6 migration: tokenized UI, Hilt ViewModel reuse, state contract, dark-mode and accessibility semantics. */
@Composable
fun MobilesScreen(
    onBack: () -> Unit = {},
    onAdd: () -> Unit = {},
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    onShareSelected: (List<String>) -> Unit = { ids -> ids.forEach(onShare) },
    onImportContacts: () -> Unit = {},
    loading: Boolean = false,
    errorMessage: String? = null,
    onRetry: () -> Unit = {},
    vm: MobilesViewModel = hiltViewModel()
) {
    val entries by vm.visibleEntries.collectAsStateWithLifecycle()
    val favoritesOnly by vm.favoritesOnly.collectAsStateWithLifecycle()
    val selectedIds by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode by vm.selectionMode.collectAsStateWithLifecycle()
    var confirmBulkDelete by remember { mutableStateOf(false) }

    BackHandler {
        if (selectionMode) vm.exitSelection() else onBack()
    }
    CollectMessages(vm.messages)

    val allSelected = entries.isNotEmpty() && selectedIds.containsAll(entries.map { it.id })

    Scaffold(
        topBar = {
            if (selectionMode) {
                SelectionTopBar(
                    selectedCount = selectedIds.size,
                    allSelected = allSelected,
                    onExit = vm::exitSelection,
                    onToggleSelectAll = vm::toggleSelectAll
                )
            } else {
                androidx.compose.foundation.layout.Column {
                    TopAppBar(
                        title = {
                            Text(
                                stringResource(R.string.p15_mobiles),
                                style = MaterialTheme.typography.titleLarge
                            )
                        },
                        navigationIcon = {
                            IconButton(onClick = onBack) {
                                Icon(
                                    Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = stringResource(R.string.p15_back)
                                )
                            }
                        },
                        actions = {
                            TextButton(onClick = onImportContacts) {
                                Text(stringResource(R.string.mobiles_import_contacts))
                            }
                        }
                    )
                    androidx.compose.foundation.layout.Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = AppDimens.Small, vertical = AppDimens.Xxs),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = !favoritesOnly,
                            onClick = { if (favoritesOnly) vm.toggleFavoritesOnly() },
                            label = { Text(stringResource(R.string.p15_all)) }
                        )
                        androidx.compose.foundation.layout.Spacer(Modifier.size(AppDimens.Xs))
                        FilterChip(
                            selected = favoritesOnly,
                            onClick = { if (!favoritesOnly) vm.toggleFavoritesOnly() },
                            label = { Text(stringResource(R.string.p15_starred)) },
                            leadingIcon = { Icon(Icons.Default.Star, contentDescription = stringResource(R.string.p15_starred)) }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (!selectionMode) {
                ExtendedFloatingActionButton(
                    onClick = onAdd,
                    icon = { Icon(Icons.Default.Add, contentDescription = stringResource(R.string.p15_add)) },
                    text = { Text(stringResource(R.string.mobiles_add_entry)) }
                )
            }
        },
        bottomBar = {
            if (selectionMode) {
                SelectionBottomBar(
                    selectedCount = selectedIds.size,
                    onDelete = { confirmBulkDelete = true },
                    onShare = { onShareSelected(selectedIds.toList()) },
                    onFavorite = vm::favoriteSelected
                )
            }
        }
    ) { padding ->
        AppScreenState(loading = loading, errorMessage = errorMessage, onRetry = onRetry) {
        if (entries.isEmpty()) {
            AppEmptyState(
                stringResource(R.string.p15_no_mobile_entries),
                stringResource(R.string.mobiles_empty_message),
                Modifier.padding(padding).fillMaxWidth()
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).focusGroup().padding(horizontal = AppDimens.ScreenHorizontal),
                verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)
            ) {
                items(entries, key = { it.id }, contentType = { "mobile" }) { entry ->
                    MobileItem(
                        entry = entry,
                        selectionMode = selectionMode,
                        selected = entry.id in selectedIds,
                        onClick = {
                            if (selectionMode) vm.toggleSelection(entry.id)
                            else onEdit(entry.id)
                        },
                        onLongClick = { vm.beginSelection(entry.id) },
                        onEdit = { onEdit(entry.id) },
                        onToggleFavorite = { vm.toggleFavorite(entry.id) },
                        onCopy = { vm.copy(entry.mobile.ifBlank { entry.phone }) },
                        onDelete = { vm.delete(entry.id) },
                        onShare = { onShare(entry.id) }
                    )
                }
            }
        }
    
        }}

    if (confirmBulkDelete && selectedIds.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { confirmBulkDelete = false },
            title = { Text(stringResource(R.string.selection_delete_title)) },
            text = { Text(stringResource(R.string.selection_delete_text, selectedIds.size)) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmBulkDelete = false
                        vm.deleteSelected()
                    }
                ) { Text(stringResource(R.string.p15_delete)) }
            },
            dismissButton = {
                TextButton(onClick = { confirmBulkDelete = false }) {
                    Text(stringResource(R.string.p15_cancel))
                }
            }
        )
    }
}

@Composable
private fun MobileItem(
    entry: VaultEntry,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onEdit: () -> Unit,
    onToggleFavorite: () -> Unit,
    onCopy: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    var menu by remember(entry.id) { mutableStateOf(false) }
    var detail by remember(entry.id) { mutableStateOf(false) }
    var confirmDelete by remember(entry.id) { mutableStateOf(false) }
    val number = entry.mobile.ifBlank { entry.phone }
    val operator = remember(entry.customFields) {
        entry.customFields.firstOrNull { it.k == "operator" }?.v.orEmpty()
    }
    val subtitle = remember(number, operator) {
        listOf(number, operator).filter { it.isNotBlank() }.joinToString(" · ")
    }

    Box(Modifier.fillMaxWidth()) {
        Card(
            Modifier
                .fillMaxWidth()
                .combinedClickable(onClick = {
                    if (selectionMode) onClick() else detail = true
                }, onLongClick = onLongClick)
        ) {
            Row(
                Modifier.padding(AppDimens.Medium),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (selectionMode) {
                    Checkbox(checked = selected, onCheckedChange = { onClick() })
                }
                Avatar(entry.title.ifBlank { number })
                Column(Modifier.weight(1f).padding(start = AppDimens.Small)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            entry.title.ifBlank { stringResource(R.string.mobiles_entry) },
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.weight(1f)
                        )
                        if (entry.starred) {
                            Icon(
                                Icons.Default.Star,
                                contentDescription = stringResource(R.string.vault_starred),
                                modifier = Modifier.size(pro.babasitaram.vault.presentation.components.AppDimens.SmallIconSize),
                                tint = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                    Text(subtitle)
                }
                if (!selectionMode) {
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            Icons.Default.Star,
                            contentDescription = stringResource(
                                if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite
                            ),
                            tint = if (entry.starred) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onCopy) {
                        Icon(
                            Icons.Default.ContentCopy,
                            contentDescription = stringResource(R.string.mobiles_copy_number)
                        )
                    }
                    IconButton(onClick = { menu = true }) {
                        Icon(
                            Icons.Default.MoreVert,
                            contentDescription = stringResource(R.string.notes_more)
                        )
                    }
                } else if (selected) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(AppDimens.IconSize))
                }
            }
        }

        if (!selectionMode) {
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.p15_edit)) },
                    onClick = { menu = false; onEdit() }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.p15_copy)) },
                    onClick = { menu = false; onCopy() }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.p15_share)) },
                    onClick = { menu = false; onShare() }
                )
                DropdownMenuItem(
                    text = {
                        Text(
                            stringResource(
                                if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite
                            )
                        )
                    },
                    onClick = { menu = false; onToggleFavorite() }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.p15_delete)) },
                    onClick = { menu = false; confirmDelete = true }
                )
            }
        }
    }

    if (detail) {
        AlertDialog(
            onDismissRequest = { detail = false },
            title = { Text(entry.title.ifBlank { stringResource(R.string.mobiles_entry) }) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(number)
                    if (operator.isNotBlank()) Text(operator)
                    if (entry.notes.isNotBlank()) Text(entry.notes)
                }
            },
            confirmButton = {
                TextButton(onClick = { detail = false; onEdit() }) {
                    Text(stringResource(R.string.p15_edit))
                }
            },
            dismissButton = {
                TextButton(onClick = { detail = false; onCopy() }) {
                    Text(stringResource(R.string.p15_copy))
                }
            }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.mobiles_move_bin_title)) },
            text = { Text(stringResource(R.string.mobiles_move_bin_text)) },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; onDelete() }) {
                    Text(stringResource(R.string.mobiles_move_bin))
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.p15_cancel))
                }
            }
        )
    }
}
