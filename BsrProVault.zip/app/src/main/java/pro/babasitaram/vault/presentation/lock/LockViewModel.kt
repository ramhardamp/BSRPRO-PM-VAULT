package pro.babasitaram.vault.presentation.lock

import androidx.fragment.app.FragmentActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.security.AuthResult
import pro.babasitaram.vault.core.security.ActivityLogStore
import pro.babasitaram.vault.core.security.BiometricAuthenticator
import pro.babasitaram.vault.core.security.BiometricAvailability
import pro.babasitaram.vault.core.security.BiometricSessionKeyStore
import pro.babasitaram.vault.core.util.VaultError
import pro.babasitaram.vault.core.util.VaultResult
import pro.babasitaram.vault.domain.repository.AuthRepository
import pro.babasitaram.vault.domain.repository.SettingsRepository
import pro.babasitaram.vault.domain.usecase.UnlockVaultUseCase
import pro.babasitaram.vault.domain.usecase.EmergencyAccessUseCase
import pro.babasitaram.vault.domain.usecase.RecoverMasterPasswordUseCase
import pro.babasitaram.vault.presentation.util.toUserMessage
import pro.babasitaram.vault.presentation.util.launchCatching
import androidx.compose.runtime.Stable
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.L


@Stable
data class LockUiState(
    val busy: Boolean = false,
    val error: String? = null,
    val lockedSeconds: Int = 0,
    val biometricAvailable: Boolean = false,
    val deviceCredentialAvailable: Boolean = false,
    val biometricMigrationRequired: Boolean = false,
    val emergencyConfigured: Boolean = false,
    val emergencyRequestTime: Long = 0L
)

@HiltViewModel
class LockViewModel @Inject constructor(
    private val unlockVault: UnlockVaultUseCase,
    private val auth: AuthRepository,
    private val settings: SettingsRepository,
    private val biometric: BiometricAuthenticator,
    private val biometricStore: BiometricSessionKeyStore,
    private val emergency: EmergencyAccessUseCase,
    private val recoverMasterPassword: RecoverMasterPasswordUseCase,
    private val activityLog: ActivityLogStore
) : ViewModel() {
    private val _state = MutableStateFlow(LockUiState())
    val state: StateFlow<LockUiState> = _state.asStateFlow()
    private var countdown: Job? = null

    init {
        launchCatching {
            val s = settings.current()
            val legacy = biometricStore.hasLegacyCredential()
            val secure = biometricStore.hasSecureCredential()
            val usable = s.biometricEnabled && secure && biometric.availability() == BiometricAvailability.Available
            val emergencyStatus = emergency.status()
            _state.update {
                it.copy(
                    biometricAvailable = usable,
                    deviceCredentialAvailable = usable,
                    biometricMigrationRequired = s.biometricEnabled && legacy && !secure,
                    emergencyConfigured = emergencyStatus.configured,
                    emergencyRequestTime = emergencyStatus.requestTime
                )
            }
            val remaining = auth.lockoutState().lockedUntilMs - System.currentTimeMillis()
            if (remaining > 0) startCountdown(remaining)
        }
    }

    fun unlock(password: String) {
        val pw = password.toCharArray()
        launchCatching {
            try { attemptUnlock(pw) }
            finally { pw.fill('\u0000') }
        }
    }

    private suspend fun attemptUnlock(pw: CharArray, method: String = "Master password"): VaultResult<Unit> {
        _state.update { it.copy(busy = true, error = null) }
        val r = unlockVault(pw)
        if (r is VaultResult.Failure) {
            if (r.error == VaultError.InvalidMasterPassword) activityLog.record("Failed login attempt", "Master password verification failed")
            val e = r.error
            val message = when {
                e == VaultError.InvalidMasterPassword -> {
                    val ls = auth.lockoutState()
                    if (ls.lockedUntilMs > System.currentTimeMillis()) {
                        startCountdown(ls.lockedUntilMs - System.currentTimeMillis())
                        "Too many attempts"
                    } else {
                        val left = auth.remainingAttempts(ls)
                        "Incorrect password. $left attempt${if (left == 1) "" else "s"} left."
                    }
                }
                e is VaultError.RateLimited -> { startCountdown(e.retryAfterMs); "Too many attempts" }
                else -> e.toUserMessage()
            }
            _state.update { it.copy(busy = false, error = message) }
        } else {
            activityLog.record("Vault unlocked", "$method authentication succeeded")
            _state.update { it.copy(busy = false, error = null) }
        }
        return r
    }

    fun unlockWithBiometric(activity: FragmentActivity) {
        launchCatching {
            if (_state.value.biometricMigrationRequired) {
                _state.update { it.copy(error = L.s(R.string.p18_lock_enter_your_master_password_once)) }
                return@launchCatching
            }
            if (!biometricStore.hasSecureCredential()) {
                _state.update { it.copy(error = L.s(R.string.p18_lock_biometric_setup_is_incomplete_enter)) }
                return@launchCatching
            }
            try {
                val strongBiometricAvailable = BiometricManager.from(activity).canAuthenticate(BIOMETRIC_STRONG) == BiometricManager.BIOMETRIC_SUCCESS
                // CryptoObject + DEVICE_CREDENTIAL is rejected by Android. On phones without a usable
                // biometric (common on some Realme/Redmi models), use the combined prompt first so the
                // system immediately offers the device PIN/pattern/password instead of asking for master password.
                if (!strongBiometricAvailable) {
                    unlockWithDeviceCredential(activity)
                    return@launchCatching
                }
                val prepared = biometricStore.prepareDecryptCipher()
                if (prepared == null) {
                    _state.update { it.copy(error = L.s(R.string.p18_lock_biometric_credential_is_unavailable)) }
                    return@launchCatching
                }
                biometric.authenticateWithCipher(
                    activity = activity,
                    cipher = prepared.cipher,
                    title = L.s(R.string.autofill_unlock_title),
                    negativeButtonText = L.s(R.string.p18_common_use_device_pin),
                    subtitle = L.s(R.string.p18_lock_confirm_your_identity_to_unlock)
                ).collect { result ->
                    when (result) {
                        is AuthResult.Success -> unlockFromCipher(prepared)
                        AuthResult.FallbackRequested -> unlockWithDeviceCredential(activity)
                        is AuthResult.Error -> _state.update { it.copy(error = result.message) }
                        AuthResult.Failed, AuthResult.Cancelled -> Unit
                    }
                }
            } catch (_: android.security.keystore.UserNotAuthenticatedException) {
                // Key B has an authentication window. Authorize it through the normal biometric/device-credential prompt, then decrypt.
                unlockWithDeviceCredential(activity)
            } catch (_: android.security.keystore.KeyPermanentlyInvalidatedException) {
                biometricStore.resetForSecurityChange()
                settings.update { it.copy(biometricEnabled = false) }
                _state.update { it.copy(biometricAvailable = false, biometricMigrationRequired = false, error = L.s(R.string.p18_lock_biometric_security_changed_enter_you)) }
            } catch (ce: kotlinx.coroutines.CancellationException) {
                throw ce
            } catch (t: Throwable) {
                _state.update { it.copy(error = t.message ?: L.s(R.string.p18_lock_biometric_unlock_failed)) }
            }
        }
    }

    private suspend fun unlockWithDeviceCredential(activity: FragmentActivity) {
        biometric.authenticate(activity, "Unlock BSRPRO Vault", "Use fingerprint, face or device PIN").collect { result ->
            when (result) {
                is AuthResult.Success -> {
                    try {
                        val prepared = biometricStore.prepareDecryptCipher()
                        if (prepared == null) throw IllegalStateException("Missing biometric credential")
                        unlockFromCipher(prepared)
                    } catch (t: Throwable) {
                        _state.update { it.copy(error = t.message ?: L.s(R.string.p18_lock_quick_unlock_failed)) }
                    }
                }
                is AuthResult.Error -> _state.update { it.copy(error = result.message) }
                AuthResult.Failed, AuthResult.Cancelled, AuthResult.FallbackRequested -> Unit
            }
        }
    }

    private suspend fun unlockFromCipher(prepared: BiometricSessionKeyStore.PreparedDecrypt) {
        val pw = try {
            biometricStore.decryptPrepared(prepared)
        } catch (_: android.security.keystore.UserNotAuthenticatedException) {
            _state.update { it.copy(error = L.s(R.string.p18_common_authentication_expired_try_again)) }
            return
        } catch (_: android.security.keystore.KeyPermanentlyInvalidatedException) {
            biometricStore.resetForSecurityChange()
            settings.update { it.copy(biometricEnabled = false) }
            _state.update { it.copy(biometricAvailable = false, error = L.s(R.string.p18_common_biometric_security_changed_enter_you)) }
            return
        }
        try {
            val r = attemptUnlock(pw, "Biometric / device credential")
            if (r is VaultResult.Failure && r.error == VaultError.InvalidMasterPassword) {
                biometricStore.clearSecureCredential()
                settings.update { it.copy(biometricEnabled = false) }
                _state.update { it.copy(biometricAvailable = false, error = L.s(R.string.p18_lock_stored_biometric_credential_is_stale)) }
            }
        } finally {
            pw.fill('\u0000')
        }
    }

    fun recoverMasterPassword(key: String, newPassword: String, confirm: String) {
        val k = key.toCharArray(); val n = newPassword.toCharArray(); val c = confirm.toCharArray()
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            try {
                when (val r = recoverMasterPassword(k, n, c)) {
                    is VaultResult.Success -> _state.update { it.copy(busy = false, error = null, biometricAvailable = false) }
                    is VaultResult.Failure -> _state.update { it.copy(busy = false, error = r.error.toUserMessage()) }
                    VaultResult.Loading -> Unit
                }
            } finally {
                k.fill('\u0000'); n.fill('\u0000'); c.fill('\u0000')
            }
        }
    }

    fun requestEmergency(key: String) {
        launchCatching {
            when (val r = emergency.request(key)) {
                is VaultResult.Success -> _state.update { it.copy(error = L.s(R.string.p18_lock_emergency_request_submitted_unlock_a), emergencyRequestTime = r.value - EmergencyAccessUseCase.WAIT_MS) }
                is VaultResult.Failure -> _state.update { it.copy(error = r.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }

    fun unlockEmergency(key: String) {
        launchCatching {
            _state.update { it.copy(busy = true, error = null) }
            when (val r = emergency.unlock(key)) {
                is VaultResult.Success -> _state.update { it.copy(busy = false) }
                is VaultResult.Failure -> _state.update { it.copy(busy = false, error = r.error.toUserMessage()) }
                VaultResult.Loading -> Unit
            }
        }
    }

    private fun startCountdown(ms: Long) {
        countdown?.cancel()
        countdown = launchCatching {
            var left = ((ms + 999) / 1000).toInt()
            while (left > 0) {
                _state.update { it.copy(lockedSeconds = left) }
                delay(1_000); left--
            }
            _state.update { it.copy(lockedSeconds = 0, error = null) }
        }
    }
}
