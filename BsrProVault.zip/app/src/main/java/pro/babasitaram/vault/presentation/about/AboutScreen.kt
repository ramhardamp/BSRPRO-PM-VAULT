@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.about

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.foundation.clickable
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppEmptyState
import pro.babasitaram.vault.presentation.components.AppErrorState
import pro.babasitaram.vault.presentation.components.AppLoadingState
import androidx.compose.foundation.Image
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import pro.babasitaram.vault.BuildConfig
import pro.babasitaram.vault.core.constants.AppLinks

/** Spec §2.9 — tokenized About screen with localized links, heading semantics, dark-mode-safe MaterialTheme colors and Hilt wiring. */
@Composable
fun AboutScreen(onBack: () -> Unit = {}, vm: AboutScreenViewModel = hiltViewModel()) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { loading = false }
    fun open(url: String) { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }.onFailure { error = it.message } }
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_174), style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }
            )
        }
    ) { padding ->
        when {
            loading -> AppLoadingState(stringResource(R.string.b5_state_loading))
            error != null -> AppErrorState(stringResource(R.string.b5_state_error), error ?: stringResource(R.string.b5_state_error_message), stringResource(R.string.b5_state_retry)) { error = null }
            AppLinks.DEVELOPER.isBlank() -> AppEmptyState(stringResource(R.string.b5_state_empty), stringResource(R.string.b5_state_empty_message))
            else -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(AppDimens.Medium).focusGroup(), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                        Image(painterResource(pro.babasitaram.vault.R.drawable.brand_logo), contentDescription = null, modifier = Modifier.fillMaxWidth().height(AppDimens.LogoMedium))
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_175), style = MaterialTheme.typography.titleLarge)
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_about_version, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE), style = MaterialTheme.typography.bodyMedium)
                        Spacer(Modifier.height(AppDimens.Xs))
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_176))
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = AppDimens.Xs)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_177), style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(AppDimens.Medium, AppDimens.Xs, AppDimens.Medium, AppDimens.Xxs))
                        Text(AppLinks.DEVELOPER, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.padding(horizontal = AppDimens.Medium))
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_178), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(AppDimens.Medium, AppDimens.Zero, AppDimens.Medium, AppDimens.Xs))
                        HorizontalDivider()
                        LinkRow(stringResource(R.string.b5_about_website), AppLinks.WEBSITE) { open(AppLinks.WEBSITE) }
                        LinkRow(stringResource(R.string.b5_about_email), AppLinks.EMAIL) { open("mailto:${AppLinks.EMAIL}") }
                        LinkRow(stringResource(R.string.b5_about_github), AppLinks.GITHUB) { open(AppLinks.GITHUB) }
                        LinkRow(stringResource(R.string.b5_about_support_upi), AppLinks.UPI_ID) { open("upi://pay?pa=${AppLinks.UPI_ID}&pn=BabaSitaRam%20Pro") }
                    }
                }
            }
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(vertical = AppDimens.Xs)) {
                        LinkRow(stringResource(R.string.b5_about_license), stringResource(R.string.b5_about_license_value)) { open(AppLinks.GITHUB_LICENSE) }
                        LinkRow(stringResource(R.string.b5_about_changelog), stringResource(R.string.b5_about_changelog_value)) { open(AppLinks.CHANGELOG) }
                        LinkRow(stringResource(R.string.b5_about_privacy), stringResource(R.string.b5_about_privacy_value)) { open(AppLinks.PRIVACY) }
                    }
                }
            }
            item { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_179), style = MaterialTheme.typography.bodyMedium, modifier = Modifier.fillMaxWidth().padding(AppDimens.Xs)) }
            }
        }
    }
}

@Composable
private fun LinkRow(title: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = AppDimens.Medium, vertical = AppDimens.Small)) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(value, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}
