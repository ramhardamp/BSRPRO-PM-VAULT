package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow

/**
 * Full list item from UI/UX spec §2.3 and §4 Consistency Rules.
 * Includes a 40dp leading circle, 16sp primary text, 14sp secondary text,
 * optional trailing action, optional copy action, and optional three-dot menu.
 */
@Composable
fun AppListItem(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    leadingIcon: ImageVector,
    leadingBackground: Color = MaterialTheme.colorScheme.primaryContainer,
    leadingIconTint: Color = MaterialTheme.colorScheme.onPrimaryContainer,
    onClick: (() -> Unit)? = null,
    trailingActionIcon: ImageVector? = null,
    trailingActionContentDescription: String? = null,
    onTrailingAction: (() -> Unit)? = null,
    onMenu: (() -> Unit)? = null,
    menuContentDescription: String? = null
) {
    val itemModifier = modifier
        .fillMaxWidth()
        .heightIn(min = AppDimens.ListItemMinHeight)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(horizontal = AppDimens.Medium, vertical = AppDimens.Small)

    AnimatedListItem(modifier = itemModifier) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
        Box(
            modifier = Modifier
                .size(AppDimens.EntryIcon)
                .background(leadingBackground, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = leadingIcon,
                contentDescription = null,
                tint = leadingIconTint,
                modifier = Modifier.size(AppDimens.IconSize)
            )
        }
        Spacer(modifier = Modifier.width(AppDimens.Medium))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!subtitle.isNullOrEmpty()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = AppTokens.SecondaryContentAlpha),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        if (trailingActionIcon != null && onTrailingAction != null) {
            IconButton(onClick = onTrailingAction) {
                Icon(
                    imageVector = trailingActionIcon,
                    contentDescription = trailingActionContentDescription,
                    modifier = Modifier.size(AppDimens.IconSize)
                )
            }
        }
        if (onMenu != null) {
            IconButton(onClick = onMenu) {
                Icon(
                    imageVector = Icons.Default.MoreVert,
                    contentDescription = menuContentDescription,
                    modifier = Modifier.size(AppDimens.IconSize)
                )
            }
            }
        }
    }
}
