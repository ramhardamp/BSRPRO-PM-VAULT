package pro.babasitaram.vault.presentation.components

import androidx.annotation.StringRes
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Delete/confirmation dialog variant with optional retention message, spec §2.11. */
@Composable
fun AppConfirmDialog(
    visible: Boolean,
    title: String,
    message: String,
    @StringRes confirmLabelRes: Int,
    @StringRes dismissLabelRes: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    retentionMessage: String? = null
) {
    AppDialog(
        visible = visible,
        title = title,
        message = if (retentionMessage.isNullOrBlank()) message else "$message\n\n$retentionMessage",
        confirmLabelRes = confirmLabelRes,
        dismissLabelRes = dismissLabelRes,
        onConfirm = onConfirm,
        onDismiss = onDismiss,
        destructive = true,
        modifier = modifier
    )
}

/** Convenience wrapper for localized 30-day retention messaging, spec §2.11. */
@Composable
fun AppConfirmDialogWithRetention(
    visible: Boolean,
    title: String,
    message: String,
    @StringRes confirmLabelRes: Int,
    @StringRes dismissLabelRes: Int,
    retentionMessage: String,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) = AppConfirmDialog(
    visible = visible,
    title = title,
    message = message,
    confirmLabelRes = confirmLabelRes,
    dismissLabelRes = dismissLabelRes,
    onConfirm = onConfirm,
    onDismiss = onDismiss,
    modifier = modifier,
    retentionMessage = retentionMessage
)
