package pro.babasitaram.vault.presentation.vault

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.L
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.AppCard
import pro.babasitaram.vault.presentation.components.AppCopyField
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppIconCircle
import pro.babasitaram.vault.presentation.components.AppIconCircleVariant
import pro.babasitaram.vault.presentation.components.AppButton
import pro.babasitaram.vault.presentation.components.AppButtonVariant
import pro.babasitaram.vault.presentation.components.AppEmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

/** Full entry-detail UI migration, spec §2.4. Existing Hilt ViewModel remains the sole data/action owner. */
@Composable
fun EntryDetailScreen(onBack: () -> Unit, onEdit: (String) -> Unit, onShare: () -> Unit = {}, vm: EntryDetailViewModel = hiltViewModel()) {
    val entry by vm.entry.collectAsStateWithLifecycle()
    var confirmDelete by remember { mutableStateOf(false) }
    val context = LocalContext.current
    BackHandler(onBack = onBack)
    CollectMessages(vm.messages)
    LaunchedEffect(entry) { if (entry == null) onBack() }
    val e = entry
    if (e == null) {
        AppEmptyState(stringResource(R.string.vault_no_matches), stringResource(R.string.vault_no_matches_message), actionLabel = stringResource(R.string.common_back), onAction = onBack)
        return
    }
    val variant = when { e.isAppLogin -> AppIconCircleVariant.APP_LOGIN; e.recordType.equals("card", true) -> AppIconCircleVariant.CARDS; e.recordType.equals("identity", true) -> AppIconCircleVariant.IDENTITIES; else -> AppIconCircleVariant.VAULT }
    val primaryCopyLabel = stringResource(if (e.password.isNotBlank()) R.string.type_password else R.string.p15_username)
    Scaffold { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(AppDimens.ScreenHorizontal).focusGroup(), verticalArrangement = Arrangement.spacedBy(AppDimens.Medium)) {
            AppCard(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    AppIconCircle(Icons.Default.Star, variant)
                    Column(Modifier.weight(1f).padding(start = AppDimens.Medium)) {
                        Text(e.title.ifEmpty { stringResource(R.string.p17_untitled_paren) }, style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() })
                        Text(e.category.replaceFirstChar { it.uppercase() }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = vm::toggleStar) { Icon(if (e.starred) Icons.Default.Star else Icons.Default.StarBorder, stringResource(if (e.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite)) }
                }
            }
            FieldCard(e, vm)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                AppButton(label = stringResource(R.string.p15_copy), onClick = { val value = e.password.ifBlank { e.username }; vm.copy(primaryCopyLabel, value) }, variant = AppButtonVariant.SECONDARY, modifier = Modifier.weight(1f))
                AppButton(label = stringResource(R.string.p15_edit), onClick = { onEdit(e.id) }, variant = AppButtonVariant.PRIMARY, modifier = Modifier.weight(1f))
                AppButton(label = stringResource(R.string.p15_share), onClick = onShare, variant = AppButtonVariant.TEXT, modifier = Modifier.weight(1f))
                AppButton(label = stringResource(R.string.p15_delete), onClick = { confirmDelete = true }, variant = AppButtonVariant.TEXT, modifier = Modifier.weight(1f))
            }
        }
    }
    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text(stringResource(R.string.p17_loc_032), style = MaterialTheme.typography.titleLarge) },
        text = { Text(stringResource(R.string.p17_entry_bin_restore, e.title)) },
        confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete() }) { Text(stringResource(R.string.p17_loc_033)) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun FieldCard(e: VaultEntry, vm: EntryDetailViewModel) {
    AppCard(Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
            if (e.username.isNotBlank()) AppCopyField(e.username, stringResource(R.string.p15_username), { vm.copy(L.s(R.string.p15_username), e.username) })
            if (e.password.isNotBlank()) AppCopyField(e.password, stringResource(R.string.type_password), { vm.copy(L.s(R.string.type_password), e.password) })
            if (e.url.isNotBlank()) AppCopyField(e.url, stringResource(R.string.p17_loc_131), { vm.copy(L.s(R.string.p17_loc_131), e.url) })
            if (e.mobile.isNotBlank()) AppCopyField(e.mobile, stringResource(R.string.p15_mobile), { vm.copy(L.s(R.string.p15_mobile), e.mobile) })
            if (e.email.isNotBlank()) AppCopyField(e.email, stringResource(R.string.p15_email), { vm.copy(L.s(R.string.p15_email), e.email) })
            if (e.cardNumber.isNotBlank()) AppCopyField(e.cardNumber, stringResource(R.string.p18_entry_detail_card_number), { vm.copy(L.s(R.string.p18_entry_detail_card_number), e.cardNumber) })
            if (e.cardholder.isNotBlank()) AppCopyField(e.cardholder, stringResource(R.string.p18_entry_detail_cardholder), { vm.copy(L.s(R.string.p18_entry_detail_cardholder), e.cardholder) })
            if (e.cardExpiry.isNotBlank()) AppCopyField(e.cardExpiry, stringResource(R.string.p15_expiry), { vm.copy(L.s(R.string.p15_expiry), e.cardExpiry) })
            if (e.cardCvv.isNotBlank()) AppCopyField(e.cardCvv, stringResource(R.string.p15_cvv), { vm.copy(L.s(R.string.p15_cvv), e.cardCvv) })
            if (e.fullName.isNotBlank()) AppCopyField(e.fullName, stringResource(R.string.p18_entry_detail_full_name), { vm.copy(L.s(R.string.p18_entry_detail_full_name), e.fullName) })
            if (e.phone.isNotBlank()) AppCopyField(e.phone, stringResource(R.string.p15_phone), { vm.copy(L.s(R.string.p15_phone), e.phone) })
            if (e.address.isNotBlank()) AppCopyField(e.address, stringResource(R.string.p15_address), { vm.copy(L.s(R.string.p15_address), e.address) })
            if (e.idNumber.isNotBlank()) AppCopyField(e.idNumber, stringResource(R.string.p18_entry_detail_id_number), { vm.copy(L.s(R.string.p18_entry_detail_id_number), e.idNumber) })
            if (e.idExpiry.isNotBlank()) AppCopyField(e.idExpiry, stringResource(R.string.p18_entry_detail_id_expiry), { vm.copy(L.s(R.string.p18_entry_detail_id_expiry), e.idExpiry) })
            if (e.notes.isNotBlank()) AppCopyField(e.notes, stringResource(R.string.p15_notes), { vm.copy(L.s(R.string.p15_notes), e.notes) })
            if (e.tags.isNotEmpty()) AppCopyField(e.tags.joinToString(", "), stringResource(R.string.p15_tags), {})
            if (e.passwordHistory.isNotEmpty()) PasswordHistory(e, vm)
            if (e.editHistory.isNotEmpty()) EditHistory(e)
            if (e.updatedAt > 0) Text(L.s(R.string.p18_entry_detail_updated, DateFormat.getDateTimeInstance().format(Date(e.updatedAt))), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DetailField(label: String, value: String, secret: Boolean = false, extraIcon: (@Composable () -> Unit)? = null, onCopy: (() -> Unit)? = null) {
    if (value.isEmpty()) return
    AppCopyField(value, label, onCopy ?: {}, Modifier.fillMaxWidth())
}

@Composable
private fun TotpField(entry: VaultEntry, vm: EntryDetailViewModel) {
    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(250)
        }
    }
    val code = vm.totp(entry.totp, now)
    if (code == null) {
        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_034), color = MaterialTheme.colorScheme.error)
        return
    }
    // fraction of the period left, computed from wall-clock milliseconds so the ring is smooth and flips exactly at the boundary
    val periodMs = code.periodSeconds * 1000L
    val fraction = 1f - ((now % periodMs).toFloat() / periodMs)
    val expiring = code.secondsRemaining <= 5
    Row(
        Modifier.fillMaxWidth().clickable { vm.copy(L.s(R.string.notes_code), code.code) }.padding(vertical = AppDimens.Xxs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_035), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                code.code.chunked(3).joinToString(" "),
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Monospace,
                color = if (expiring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        }
        Box(contentAlignment = Alignment.Center) {
            CircularProgressIndicator(
                progress = { fraction },
                modifier = Modifier.size(AppDimens.TotpRingSize),
                strokeWidth = AppDimens.Xxs,
                color = if (expiring) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            )
            Text("${code.secondsRemaining}", style = MaterialTheme.typography.labelLarge)
        }
        IconButton(onClick = { vm.copy(L.s(R.string.notes_code), code.code) }) { Icon(Icons.Default.ContentCopy, stringResource(R.string.p15_copy)) }
    }
}

@Composable
private fun PasswordHistory(entry: VaultEntry, vm: EntryDetailViewModel) {
    var open by remember { mutableStateOf(false) }
    Column {
        TextButton(onClick = { open = !open }) { Text(if (open) stringResource(pro.babasitaram.vault.R.string.p17_hide_password_history) else stringResource(pro.babasitaram.vault.R.string.p17_password_history_count, entry.passwordHistory.size)) }
        if (open) {
            entry.passwordHistory.forEach { h ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_036), fontFamily = FontFamily.Monospace)
                        if (h.changedAt > 0) {
                            Text(DateFormat.getDateInstance().format(Date(h.changedAt)), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    IconButton(onClick = { vm.copy(L.s(R.string.p18_entry_detail_old_password), h.pw) }) { Icon(Icons.Default.ContentCopy, stringResource(R.string.p15_copy)) }
                }
            }
        }
    }
}

@Composable
private fun EditHistory(entry: VaultEntry) {
    var open by remember { mutableStateOf(false) }
    Column {
        TextButton(onClick = { open = !open }) { Text(if (open) stringResource(pro.babasitaram.vault.R.string.p17_hide_edit_history) else stringResource(pro.babasitaram.vault.R.string.p17_edit_history_count, entry.editHistory.size)) }
        if (open) {
            entry.editHistory.forEach { h ->
                Column(Modifier.fillMaxWidth().padding(vertical = AppDimens.Xxs)) {
                    Text(
                        if (h.changedAt > 0) DateFormat.getDateTimeInstance().format(Date(h.changedAt)) else stringResource(R.string.p18_entry_detail_unknown_time),
                        style = MaterialTheme.typography.labelMedium
                    )
                    val what = h.fields.joinToString(", ").ifEmpty { stringResource(R.string.entry_details) }
                    Text(
                        L.s(R.string.p18_entry_detail_changed, what) + if (h.source.isNotEmpty()) " · ${h.source}" else "",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
