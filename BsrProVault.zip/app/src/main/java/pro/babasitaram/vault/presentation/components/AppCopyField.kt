package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.R

/** Read-only outlined field with copy action/snackbar trigger callback, spec §2.3. */
@Composable
fun AppCopyField(
    value: String,
    label: String,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    var copyPulse by remember { mutableStateOf(false) }
    LaunchedEffect(copyPulse) {
        if (copyPulse) {
            kotlinx.coroutines.delay(AppMotion.CopyPulseMs.toLong())
            copyPulse = false
        }
    }
    OutlinedTextField(
        value = value,
        onValueChange = {},
        modifier = modifier.fillMaxWidth(),
        readOnly = true,
        enabled = enabled,
        singleLine = true,
        label = { Text(label) },
        trailingIcon = {
            IconButton(onClick = { copyPulse = true; onCopy() }, enabled = enabled) {
                androidx.compose.animation.AnimatedContent(
                    targetState = copyPulse,
                    transitionSpec = {
                        androidx.compose.animation.scaleIn(androidx.compose.animation.core.tween(AppMotion.CopyPulseMs)) +
                            androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(AppMotion.CopyPulseMs)) togetherWith
                            androidx.compose.animation.scaleOut(androidx.compose.animation.core.tween(AppMotion.CopyPulseMs)) +
                            androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(AppMotion.CopyPulseMs))
                    },
                    label = "copyPulse"
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.p15_copy))
                }
            }
        }
    )
}
