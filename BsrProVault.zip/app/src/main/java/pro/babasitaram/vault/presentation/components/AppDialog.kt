package pro.babasitaram.vault.presentation.components

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

/** Confirmation dialog from UI/UX spec §2.11 and §4 Consistency Rules. */
@Composable
fun AppDialog(
    visible: Boolean,
    title: String,
    message: String,
    @StringRes confirmLabelRes: Int,
    @StringRes dismissLabelRes: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    destructive: Boolean = false
) {
    if (!visible) return

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        AnimatedDialogContent(visible = true) {
            Surface(
                modifier = modifier
                    .fillMaxWidth()
                    .widthIn(max = AppDimens.DialogMaxWidth),
            shape = RoundedCornerShape(AppShapes.ExtraLarge),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = AppElevation.Dialog
        ) {
            Column(
                modifier = Modifier.padding(AppDimens.Large)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = AppDimens.Medium)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = AppDimens.Large),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Spacer(modifier = Modifier.weight(1f))
                    TextButton(onClick = onDismiss) {
                        Text(stringResource(dismissLabelRes))
                    }
                    Spacer(modifier = Modifier.width(AppDimens.Xs))
                    TextButton(onClick = onConfirm) {
                        Text(
                            text = stringResource(confirmLabelRes),
                            color = if (destructive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )
                    }
                }
                }
            }
        }
    }
}
