package pro.babasitaram.vault.presentation.components

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource

/**
 * Full drawer component from UI/UX spec §2.7 and §4 Consistency Rules.
 *
 * The screen supplies the exact 15 localized destinations, their icons, selection state,
 * and navigation callbacks. This keeps routes out of the reusable component and avoids
 * inventing navigation behavior inside the design-system layer.
 */
data class AppDrawerItem(
    val key: String,
    @StringRes val labelRes: Int,
    val icon: ImageVector,
    val selected: Boolean = false,
    val badge: String? = null,
    val dividerBefore: Boolean = false
)

@Composable
fun AppDrawer(
    appName: String,
    versionText: String,
    userEmail: String,
    items: List<AppDrawerItem>,
    @StringRes lockLabelRes: Int,
    @StringRes lockContentDescriptionRes: Int,
    onItemClick: (AppDrawerItem) -> Unit,
    onLockClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    ModalDrawerSheet(
        modifier = modifier.width(AppDimens.DrawerWidth)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = appName,
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(
                    start = AppDimens.Medium,
                    top = AppDimens.Medium,
                    end = AppDimens.Medium
                )
            )
            Text(
                text = versionText,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = AppTokens.SecondaryContentAlpha),
                modifier = Modifier.padding(
                    start = AppDimens.Medium,
                    top = AppDimens.Xs,
                    end = AppDimens.Medium
                )
            )
            Text(
                text = userEmail,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = AppTokens.SecondaryContentAlpha),
                modifier = Modifier.padding(
                    start = AppDimens.Medium,
                    top = AppDimens.Xs,
                    bottom = AppDimens.Medium,
                    end = AppDimens.Medium
                )
            )

            items.forEach { item ->
                if (item.dividerBefore) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = AppDimens.Xs))
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(AppDimens.DrawerItemHeight)
                        .padding(horizontal = AppDimens.Medium)
                        .clip(RoundedCornerShape(AppShapes.Small))
                        .background(
                            if (item.selected) MaterialTheme.colorScheme.primaryContainer
                            else MaterialTheme.colorScheme.surface
                        )
                        .clickable(onClick = { onItemClick(item) }),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = stringResource(item.labelRes),
                        modifier = Modifier.size(AppDimens.IconSize),
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.width(AppDimens.Medium))
                    Text(
                        text = stringResource(item.labelRes),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.weight(1f)
                    )
                    item.badge?.let { value ->
                        Text(value, style = MaterialTheme.typography.labelMedium)
                    }
                }
            }
            Spacer(modifier = Modifier.weight(1f))
            HorizontalDivider()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(AppDimens.DrawerItemHeight)
                    .padding(horizontal = AppDimens.Medium)
                    .clip(RoundedCornerShape(AppShapes.Small))
                    .clickable(onClick = onLockClick),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = stringResource(lockContentDescriptionRes),
                    modifier = Modifier.size(AppDimens.IconSize)
                )
                Spacer(modifier = Modifier.width(AppDimens.Medium))
                Text(
                    text = stringResource(lockLabelRes),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
