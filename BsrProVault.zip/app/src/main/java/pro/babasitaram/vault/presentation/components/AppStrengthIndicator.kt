package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.core.util.StrengthLevel

/** Four-level password strength indicator using semantic theme colors, spec §2.3. */
@Composable
fun AppStrengthIndicator(
    value: String,
    modifier: Modifier = Modifier
) {
    if (value.isEmpty()) return
    val level = PasswordStrength.level(value)
    val progress = (PasswordStrength.score(value) / 5f).coerceIn(0.05f, 1f)
    val color = when (level) {
        StrengthLevel.VERY_WEAK, StrengthLevel.WEAK -> MaterialTheme.colorScheme.error
        StrengthLevel.FAIR -> MaterialTheme.colorScheme.tertiary
        StrengthLevel.GOOD -> MaterialTheme.colorScheme.secondary
        StrengthLevel.VERY_STRONG -> MaterialTheme.colorScheme.primary
    }
    Column(modifier.fillMaxWidth()) {
        LinearProgressIndicator(
            progress = { progress },
            color = color,
            modifier = Modifier.fillMaxWidth().height(AppDimens.StrengthIndicatorHeight)
        )
        Text(level.label, style = MaterialTheme.typography.labelSmall, color = color)
    }
}
