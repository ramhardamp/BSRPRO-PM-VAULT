package pro.babasitaram.vault.presentation.sharing

import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import pro.babasitaram.vault.R
import pro.babasitaram.vault.domain.repository.VaultRepository

/** Reads one entry from the already-unlocked in-memory vault to build the plain-text share body. */
@HiltViewModel
class QuickShareViewModel @Inject constructor(
    private val repository: VaultRepository
) : ViewModel() {

    /** True only for login-like records that have something sensible to put in a text message. */
    fun supportsPlainText(id: String): Boolean {
        val e = repository.entries.value.firstOrNull { it.id == id } ?: return false
        return !e.isFolderMarker && !e.isNote && e.recordType == "login" && (e.password.isNotBlank() || e.username.isNotBlank())
    }

    /** "Username: x / Password: x / URL: x" (blank fields are skipped). */
    fun plainText(id: String, usernameLabel: String, passwordLabel: String, urlLabel: String): String? {
        val e = repository.entries.value.firstOrNull { it.id == id } ?: return null
        return buildList {
            if (e.username.isNotBlank()) add("$usernameLabel: ${e.username}")
            if (e.password.isNotBlank()) add("$passwordLabel: ${e.password}")
            if (e.url.isNotBlank()) add("$urlLabel: ${e.url}")
        }.joinToString("\n").ifBlank { null }
    }
}

/**
 * Single-entry Share: no intermediate screen. A tiny chooser offers
 *  - "Share Secure Link" -> the existing encrypted share flow (PIN/biometric, expiry, view limit)
 *  - "Share as Text"     -> plain text straight into the Android share sheet, after a warning.
 * Entries that cannot be sent as plain text (notes, cards, TOTP...) go straight to the secure flow.
 */
@Composable
fun QuickShareDialogs(
    entryId: String?,
    onDismiss: () -> Unit,
    onSecureLink: (String) -> Unit,
    vm: QuickShareViewModel = hiltViewModel()
) {
    val id = entryId ?: return
    val context = LocalContext.current
    val plainOk = remember(id) { vm.supportsPlainText(id) }
    var warn by remember(id) { mutableStateOf(false) }

    if (!plainOk) {
        // Nothing to choose: go directly to the encrypted flow.
        LaunchedEffect(id) { onSecureLink(id); onDismiss() }
        return
    }

    val uLabel = stringResource(R.string.p16c_share_label_username)
    val pLabel = stringResource(R.string.p16c_share_label_password)
    val rLabel = stringResource(R.string.p16c_share_label_url)
    val chooserTitle = stringResource(R.string.p16c_share_chooser)

    if (!warn) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(chooserTitle) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { onSecureLink(id); onDismiss() }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.p16c_share_secure_link))
                    }
                    OutlinedButton(onClick = { warn = true }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.p16c_share_as_text))
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.p15_cancel)) } }
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text(stringResource(R.string.p16c_share_as_text)) },
            text = { Text(stringResource(R.string.p16c_share_plain_warning), color = MaterialTheme.colorScheme.error) },
            confirmButton = {
                TextButton(onClick = {
                    val body = vm.plainText(id, uLabel, pLabel, rLabel)
                    if (body != null) {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, body)
                        }
                        runCatching {
                            context.startActivity(Intent.createChooser(send, chooserTitle).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        }
                    }
                    onDismiss()
                }) { Text(stringResource(R.string.p16c_share_continue)) }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}
