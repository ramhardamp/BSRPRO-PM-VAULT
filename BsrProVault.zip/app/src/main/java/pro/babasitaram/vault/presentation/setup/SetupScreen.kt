@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.setup

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.util.PasswordStrength
import pro.babasitaram.vault.presentation.components.AppButton
import pro.babasitaram.vault.presentation.components.AppButtonVariant
import pro.babasitaram.vault.presentation.components.AppCard
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppPasswordField
import pro.babasitaram.vault.presentation.components.AutofillSetupCard
import pro.babasitaram.vault.presentation.components.BackupFolderCard
import pro.babasitaram.vault.presentation.settings.printRecoveryKey
import pro.babasitaram.vault.presentation.settings.RecoveryKeyPdf
import pro.babasitaram.vault.core.util.L

/** Full setup UI, spec §2.1. Existing Hilt ViewModel/repository wiring is preserved. */
@Composable
fun SetupScreen(vm: SetupViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val setupKeyCopyLabel = stringResource(R.string.p17_loc_151)
    var password by rememberSaveable { mutableStateOf("") }
    var confirm by rememberSaveable { mutableStateOf("") }
    var backupPassword by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current
    val recoveryPdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        val key = state.recoveryKey
        if (uri != null && key != null) runCatching { RecoveryKeyPdf.write(context, uri, key) }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.onBackupPicked(uri) }
    val backupTreePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) runCatching {
            context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }.onSuccess { vm.onBackupFolderSelected(uri) }
    }
    LaunchedEffect(state.requestPicker) {
        if (state.requestPicker) { vm.pickerRequestHandled(); picker.launch(arrayOf("*/*")) }
    }
    val autofillEnabled = pro.babasitaram.vault.presentation.components.rememberAutofillEnabled()
    val enableAutofill = pro.babasitaram.vault.presentation.components.rememberAutofillEnableAction(autofillEnabled)

    Scaffold { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(AppDimens.ScreenHorizontal).focusGroup(),
            verticalArrangement = Arrangement.spacedBy(AppDimens.Medium, Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(painterResource(R.drawable.brand_logo), stringResource(R.string.p17_brand_accessibility), Modifier.size(AppDimens.LogoLarge))
            Text(stringResource(R.string.p17_loc_148), style = MaterialTheme.typography.headlineMedium, textAlign = TextAlign.Center, modifier = Modifier.semantics { heading() })
            Text(stringResource(R.string.p18_setup_your_master_password_encrypts_everyt), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            AppPasswordField(password, { password = it }, stringResource(R.string.p17_loc_074), enabled = !state.busy)
            AppPasswordField(confirm, { confirm = it }, stringResource(R.string.p18_setup_confirm_master_password), enabled = !state.busy)
            Text(L.s(R.string.p18_setup_minimum_characters_with_upper_lower, PasswordStrength.MIN_MASTER_LENGTH), style = MaterialTheme.typography.bodySmall, modifier = Modifier.fillMaxWidth())
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth()) }
            AppButton(
                label = stringResource(R.string.p17_loc_149),
                onClick = { vm.create(password, confirm) },
                enabled = !state.busy && password.isNotEmpty(),
                variant = AppButtonVariant.PRIMARY,
                modifier = Modifier.fillMaxWidth()
            )
            if (state.busy) CircularProgressIndicator(modifier = Modifier.size(AppDimens.IconSize))
            AppCard(Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                    Text(stringResource(R.string.p16c_restore_from_backup), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.p17_loc_155), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    AppButton(label = stringResource(R.string.p16c_restore_from_backup), onClick = { vm.restoreFromBackup() }, enabled = !state.busy, variant = AppButtonVariant.SECONDARY, modifier = Modifier.fillMaxWidth())
                    BackupFolderCard(
                        folderUri = state.backupFolderUri,
                        enabled = !state.busy,
                        onChange = { backupTreePicker.launch(null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
            AutofillSetupCard(enabled = autofillEnabled.value, onEnable = enableAutofill)
        }
    }

    state.recoveryKey?.let { key ->
        AlertDialog(
            onDismissRequest = vm::dismissRecoveryKey,
            title = { Text(stringResource(R.string.p17_loc_151), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                    Text(stringResource(R.string.p17_loc_152))
                    Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(AppDimens.Medium), verticalAlignment = Alignment.CenterVertically) {
                            Text(key.chunked(4).joinToString(" "), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                            IconButton(onClick = { vm.copySecret(key, setupKeyCopyLabel) }) { Icon(Icons.Default.ContentCopy, stringResource(R.string.p15_copy)) }
                        }
                    }
                    Text(stringResource(R.string.p17_loc_153), color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = { TextButton(onClick = { recoveryPdf.launch(context.getString(R.string.p17_loc_018)) }) { Text(stringResource(R.string.p17_loc_019)) } },
            dismissButton = { TextButton(onClick = { printRecoveryKey(context, key) }) { Text(stringResource(R.string.p17_loc_020)) } }
        )
    }
    if (state.awaitingBackupPassword) {
        AlertDialog(
            onDismissRequest = { vm.cancelRestore(); backupPassword = "" },
            title = { Text(stringResource(R.string.p17_loc_154), style = MaterialTheme.typography.titleLarge) },
            text = { AppPasswordField(backupPassword, { backupPassword = it }, stringResource(R.string.p17_loc_154), enabled = !state.busy) },
            confirmButton = { TextButton(onClick = { vm.restore(backupPassword); backupPassword = "" }, enabled = backupPassword.isNotEmpty() && !state.busy) { Text(stringResource(R.string.p15_restore)) } },
            dismissButton = { TextButton(onClick = { vm.cancelRestore(); backupPassword = "" }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}
