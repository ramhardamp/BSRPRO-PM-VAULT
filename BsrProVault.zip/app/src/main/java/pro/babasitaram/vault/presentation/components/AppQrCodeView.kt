package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

/** QR display wrapper for sharing screens; QR generation remains owned by the caller, spec §2.11. */
@Composable
fun AppQrCodeView(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(AppDimens.Large),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Surface(
            shape = RoundedCornerShape(AppShapes.ExtraLarge),
            color = MaterialTheme.colorScheme.surfaceContainer,
            tonalElevation = AppElevation.Card
        ) {
            Box(modifier = Modifier.padding(AppDimens.Large), contentAlignment = Alignment.Center) {
                content()
            }
        }
    }
}
