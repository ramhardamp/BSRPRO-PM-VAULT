package pro.babasitaram.vault.presentation.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import pro.babasitaram.vault.R

/** Shared loading/error contract for migrated screens. Defaults preserve existing callers. */
@Composable
fun AppScreenState(
    loading: Boolean,
    errorMessage: String?,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    when {
        loading -> AppLoadingState(stringResource(R.string.b5_state_loading), modifier)
        errorMessage != null -> AppErrorState(
            title = stringResource(R.string.b5_state_error),
            message = errorMessage,
            retryLabel = stringResource(R.string.b5_state_retry),
            onRetry = onRetry,
            modifier = modifier
        )
        else -> content()
    }
}

/** Heading semantics shared by screen titles so TalkBack exposes one navigable heading. */
@Composable
fun AppHeadingText(text: String, modifier: Modifier = Modifier) {
    androidx.compose.material3.Text(
        text = text,
        style = androidx.compose.material3.MaterialTheme.typography.titleLarge,
        color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
        modifier = modifier.semantics { heading() }
    )
}
