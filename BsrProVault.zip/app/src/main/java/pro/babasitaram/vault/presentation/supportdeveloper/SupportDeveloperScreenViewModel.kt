package pro.babasitaram.vault.presentation.supportdeveloper

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import pro.babasitaram.vault.domain.repository.SettingsRepository

/** Hilt wiring for Support; no vault data is mutated by this screen. */
@HiltViewModel
class SupportDeveloperScreenViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel()
