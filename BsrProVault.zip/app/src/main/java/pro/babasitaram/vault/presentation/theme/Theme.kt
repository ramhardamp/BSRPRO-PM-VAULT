package pro.babasitaram.vault.presentation.theme

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.foundation.shape.RoundedCornerShape
import pro.babasitaram.vault.presentation.components.AppShapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = BrandPrimary,
    onPrimary = BrandOnPrimary,
    primaryContainer = BrandPrimaryContainer,
    onPrimaryContainer = BrandOnPrimaryContainer,
    secondary = BrandSecondary,
    onSecondary = BrandOnSecondary,
    secondaryContainer = BrandSecondaryContainer,
    background = BrandDarkBackground,
    surface = BrandDarkSurface,
    onBackground = BrandDarkOnSurface,
    onSurface = BrandDarkOnSurface,
    outline = BrandOutline,
    error = BrandError
)

private val LightColors = lightColorScheme(
    primary = BrandPrimary,
    onPrimary = BrandOnPrimary,
    primaryContainer = BrandPrimaryContainer,
    onPrimaryContainer = BrandOnPrimaryContainer,
    secondary = BrandSecondary,
    onSecondary = BrandOnSecondary,
    secondaryContainer = BrandSecondaryContainer,
    background = BrandLightBackground,
    surface = BrandLightSurface,
    onBackground = BrandLightOnSurface,
    onSurface = BrandLightOnSurface,
    outline = BrandOutline,
    error = BrandError
)

private val VaultShapes = Shapes(
    small = RoundedCornerShape(AppShapes.Small),
    medium = RoundedCornerShape(AppShapes.Medium),
    large = RoundedCornerShape(AppShapes.Large),
    extraLarge = RoundedCornerShape(AppShapes.ExtraLarge)
)

@Composable
fun VaultTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    Crossfade(
        targetState = darkTheme,
        animationSpec = tween(pro.babasitaram.vault.presentation.components.AppMotion.ThemeCrossfadeMs),
        label = "themeCrossfade"
    ) { isDark ->
        MaterialTheme(
            colorScheme = if (isDark) DarkColors else LightColors,
            typography = VaultTypography,
            shapes = VaultShapes,
            content = content
        )
    }
}
