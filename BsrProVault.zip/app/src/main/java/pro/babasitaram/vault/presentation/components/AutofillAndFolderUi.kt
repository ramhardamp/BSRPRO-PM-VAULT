package pro.babasitaram.vault.presentation.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import pro.babasitaram.vault.R
import pro.babasitaram.vault.autofill.AutofillStatus

/** Re-reads the system autofill selection every time the screen resumes (e.g. after the system picker). */
@Composable
fun rememberAutofillEnabled(): MutableState<Boolean> {
    val context = LocalContext.current
    val state = remember { mutableStateOf(AutofillStatus.isEnabled(context)) }
    LifecycleResumeEffect(Unit) {
        state.value = AutofillStatus.isEnabled(context)
        onPauseOrDispose { }
    }
    return state
}

/** Opens the system "choose autofill service" screen with BSRPRO preselected. */
@Composable
fun rememberAutofillEnableAction(enabled: MutableState<Boolean>): () -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        enabled.value = AutofillStatus.isEnabled(context)
    }
    return {
        runCatching { launcher.launch(AutofillStatus.enableIntent(context)) }
            .onFailure { runCatching { launcher.launch(AutofillStatus.fallbackIntent()) } }
    }
}

/** Setup-screen card: "Autofill Service" + status + one [Enable Autofill] button (recommended: ON). */
@Composable
fun AutofillSetupCard(enabled: Boolean, onEnable: () -> Unit, modifier: Modifier = Modifier) {
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(stringResource(R.string.p16c_autofill_title), style = MaterialTheme.typography.titleMedium)
            Text(
                stringResource(if (enabled) R.string.p16c_autofill_active else R.string.p16c_autofill_recommended),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (!enabled) Button(onClick = onEnable, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.p16c_autofill_enable))
            }
        }
    }
}

/** One-time dialog shown right after the first successful unlock when BSRPRO is not yet the autofill service. */
@Composable
fun AutofillEnablePrompt() {
    val context = LocalContext.current
    var show by remember {
        mutableStateOf(AutofillStatus.isSupported(context) && !AutofillStatus.promptSeen(context) && !AutofillStatus.isEnabled(context))
    }
    val enabled = remember { mutableStateOf(false) }
    val launchEnable = rememberAutofillEnableAction(enabled)
    if (!show) return
    AlertDialog(
        onDismissRequest = { AutofillStatus.markPromptSeen(context); show = false },
        title = { Text(stringResource(R.string.p16c_autofill_dialog_title)) },
        text = { Text(stringResource(R.string.p16c_autofill_dialog_body)) },
        confirmButton = {
            TextButton(onClick = { AutofillStatus.markPromptSeen(context); show = false; launchEnable() }) {
                Text(stringResource(R.string.p16c_enable_now))
            }
        },
        dismissButton = {
            TextButton(onClick = { AutofillStatus.markPromptSeen(context); show = false }) { Text(stringResource(R.string.p16c_skip)) }
        }
    )
}

/** Shared by Setup and Backup screens: current folder, Selected / Not selected status, one Change/Choose button. */
@Composable
fun BackupFolderCard(folderUri: String, enabled: Boolean, onChange: () -> Unit, modifier: Modifier = Modifier) {
    val selected = folderUri.isNotBlank()
    val shownPath = if (selected) {
        runCatching { android.net.Uri.parse(folderUri).lastPathSegment?.substringAfter(':') }.getOrNull().orEmpty()
    } else ""
    Card(modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(stringResource(R.string.p16c_folder_title), style = MaterialTheme.typography.titleMedium)
            Text(
                if (selected && shownPath.isNotBlank()) shownPath else stringResource(R.string.p16c_folder_default),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                stringResource(if (selected) R.string.p16c_folder_selected else R.string.p16c_folder_not_selected),
                style = MaterialTheme.typography.bodySmall,
                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = onChange, enabled = enabled, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(if (selected) R.string.bk_change_folder else R.string.bk_choose_folder))
            }
        }
    }
}
