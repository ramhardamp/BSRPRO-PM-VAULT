package pro.babasitaram.vault.presentation.vaulthealth

import pro.babasitaram.vault.R

import pro.babasitaram.vault.presentation.components.AppDimens

import pro.babasitaram.vault.presentation.components.AppScreenState
import pro.babasitaram.vault.presentation.components.AppHeadingText
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Row

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.AppEmptyState

/** Phase16G Batch6 migration: tokenized UI, Hilt ViewModel reuse, state contract, dark-mode and accessibility semantics. */
@Composable
fun VaultHealthScreen(
    onBack: () -> Unit = {},
    onOpenEntry: (String) -> Unit = {},
    loading: Boolean = false,
    errorMessage: String? = null,
    onRetry: () -> Unit = {},
    vm: VaultHealthViewModel = hiltViewModel()
) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    val breach by vm.breach.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { AppHeadingText(stringResource(R.string.p15_vault_health)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p15_back))
                    }
                }
            )
        }
    ) { padding ->
        AppScreenState(loading = loading, errorMessage = errorMessage, onRetry = onRetry) {
        if (state.total == 0) {
            Column(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(AppDimens.Large),
                verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
            ) {
                HealthScoreCard(state)
                AppEmptyState(
                    stringResource(R.string.health_no_entries),
                    stringResource(R.string.health_no_entries_message),
                    Modifier.weight(1f)
                )
            }
        } else {
            LazyColumn(
                Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(AppDimens.Medium),
                verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
            ) {
                item { HealthScoreCard(state) }
                if (state.weakPasswords.isNotEmpty()) {
                    item {
                        BreachIssueCard(stringResource(R.string.p15_weak_passwords), state.weakPasswords, breach, vm, onOpenEntry)
                    }
                }
                if (state.reusedPasswords.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.p15_reused_passwords), state.reusedPasswords) }
                }
                if (state.duplicateLogins.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.health_duplicate_logins), state.duplicateLogins) }
                }
                if (state.oldPasswords.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.health_old_passwords), state.oldPasswords, onOpenEntry, stringResource(R.string.health_review_rotate)) }
                }
                if (state.missingUsernames.isNotEmpty()) {
                    item { IssueCard(stringResource(R.string.health_missing_usernames), state.missingUsernames) }
                }
                if (
                    state.weakPasswords.isEmpty() &&
                    state.reusedPasswords.isEmpty() &&
                    state.duplicateLogins.isEmpty() &&
                    state.oldPasswords.isEmpty() &&
                    state.missingUsernames.isEmpty()
                ) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Text(stringResource(R.string.health_no_findings), modifier = Modifier.padding(AppDimens.Large))
                        }
                    }
                }
            }
        }
    
        }}
}

@Composable
private fun HealthScoreCard(state: VaultHealthState) {
    Card(Modifier.fillMaxWidth()) {
        Column(
            Modifier.padding(AppDimens.Large),
            verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
        ) {
            Icon(Icons.Default.Shield, contentDescription = null)
            Text(stringResource(R.string.health_score), style = MaterialTheme.typography.titleMedium)
            Text(
                "${state.score}/100",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            LinearProgressIndicator(
                progress = { state.score / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Text(stringResource(R.string.health_total_entries, state.total))
            Text(stringResource(R.string.health_total_unique_issues, state.uniqueIssueCount))
            Text(
                stringResource(R.string.health_breakdown, state.weakPasswords.size, state.reusedPasswords.size, state.oldPasswords.size, state.duplicateLogins.size, state.missingUsernames.size),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun IssueCard(
    title: String,
    entries: List<VaultEntry>,
    onOpenEntry: (String) -> Unit = {},
    actionLabel: String? = null
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            entries.take(20).forEach { entry ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Text(entry.title.ifBlank { stringResource(R.string.health_untitled) }, modifier = Modifier.weight(1f))
                    TextButton(onClick = { onOpenEntry(entry.id) }) {
                        Text(actionLabel ?: stringResource(R.string.health_view))
                    }
                }
            }
            if (entries.size > 20) Text(stringResource(R.string.health_more, entries.size - 20))
        }
    }
}


@Composable
private fun BreachIssueCard(
    title: String,
    entries: List<VaultEntry>,
    breach: Map<String, String>,
    vm: VaultHealthViewModel,
    onOpenEntry: (String) -> Unit
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            entries.take(20).forEach { entry ->
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Text(entry.title.ifBlank { stringResource(R.string.health_untitled) }, modifier = Modifier.weight(1f))
                        TextButton(onClick = { onOpenEntry(entry.id) }) { Text(stringResource(R.string.health_view)) }
                    }
                    TextButton(onClick = { vm.checkBreach(entry) }) {
                        Text(breach[entry.id] ?: stringResource(R.string.health_check_breach))
                    }
                }
            }
            if (entries.size > 20) Text(stringResource(R.string.health_more, entries.size - 20))
        }
    }
}
