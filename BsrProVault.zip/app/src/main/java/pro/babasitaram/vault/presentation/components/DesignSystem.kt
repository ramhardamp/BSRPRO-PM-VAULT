package pro.babasitaram.vault.presentation.components

import androidx.compose.material3.Shapes
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/** Single source of truth for the BSRPRO UI specification. */
object AppDimens {
    val ScreenHorizontal = 16.dp
    val Zero = 0.dp
    val Xxs = 4.dp
    val Xs = 8.dp
    val Small = 12.dp
    val Medium = 16.dp
    val Large = 24.dp
    val XLarge = 32.dp
    val XxLarge = 48.dp
    val ItemSpacing = Xs
    val CardPadding = Medium
    val CompactPadding = Xs
    val IconSize = 24.dp
    val SmallIconSize = 20.dp
    val AvatarSize = 40.dp
    val TopBarHeight = 56.dp
    val BottomBarHeight = 64.dp
    val ListItemMinHeight = 72.dp
    val ButtonHeight = 48.dp
    val PrimaryButtonHeight = 56.dp
    val LogoLarge = 120.dp
    val LogoMedium = 100.dp
    val EntryIcon = 40.dp
    val DetailIcon = 64.dp
    val DrawerWidth = 280.dp
    val DrawerItemHeight = 48.dp
    val SettingRowHeight = 64.dp
    val ChipHeight = 40.dp
    val DialogMaxWidth = 320.dp
    val BottomSheetHandleWidth = 32.dp
    val BottomSheetHandleHeight = 4.dp
    val StrengthIndicatorHeight = 4.dp
    val TotpRingSize = 44.dp
    val SmallFieldIcon = 28.dp
    val AppPickerIcon = 32.dp
    val AppPickerMaxHeight = 360.dp
    val NotePreviewMaxHeight = 420.dp
    val QrPreviewSize = 280.dp
    val TotpQrSize = 200.dp
    val TotpProgressSize = 36.dp
    val ProgressStroke = 4.dp
    val GeneratorLabelWidth = 96.dp
}

object AppColors {
    val TotpSafe = Color(0xFF10B981)
    val TotpWarning = Color(0xFFF59E0B)
    val TotpCritical = Color(0xFFEF4444)
    val EntryPassword = Color(0xFF3B82F6)
    val EntryNote = Color(0xFFF59E0B)
    val EntryTotp = Color(0xFFA78BFA)
    val EntryCard = Color(0xFFEC4899)
    val EntryIdentity = Color(0xFF10B981)
    val EntryAppLogin = Color(0xFF6366F1)
    val EntryMobile = Color(0xFF06B6D4)
}

object AppShapes {
    val Small = 8.dp
    val Medium = 12.dp
    val Large = 16.dp
    val ExtraLarge = 28.dp
    val Pill = 20.dp
    val Button = 28.dp
}

object AppTokens {
    const val SecondaryContentAlpha = 0.60f
    const val LoadingIndicatorWidthFraction = 0.58f
}

object AppElevation {
    val Flat = 0.dp
    val Card = 2.dp
    val Fab = 4.dp
    val Dropdown = 8.dp
    val Dialog = 16.dp
}
