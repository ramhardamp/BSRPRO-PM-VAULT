package pro.babasitaram.vault.core.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn

sealed interface AuthResult {
    data class Success(val cryptoObject: BiometricPrompt.CryptoObject? = null) : AuthResult

    /** A single rejected attempt (e.g. wrong finger). The prompt stays open; more results may follow. */
    data object Failed : AuthResult
    data class Error(val code: Int, val message: String) : AuthResult
    data object Cancelled : AuthResult
    /** The biometric prompt negative button was used; caller may launch device-credential fallback. */
    data object FallbackRequested : AuthResult
}

enum class BiometricAvailability {
    Available, NoHardware, HardwareUnavailable, NotEnrolled, SecurityUpdateRequired, Unsupported
}

interface BiometricAuthenticator {
    fun availability(): BiometricAvailability

    /** BIOMETRIC_WEAK or DEVICE_CREDENTIAL. Collect from the main thread. */
    fun authenticate(activity: FragmentActivity, title: String, subtitle: String? = null): Flow<AuthResult>

    /**
     * Crypto-bound variant for BIOMETRIC_STRONG. Device credential is handled by the non-crypto prompt because Android does not allow
     * DEVICE_CREDENTIAL to be combined with a CryptoObject.
     * [cipher] must already be initialised with a Keystore key that requires user authentication.
     */
    fun authenticateWithCipher(
        activity: FragmentActivity,
        cipher: Cipher,
        title: String,
        negativeButtonText: String,
        subtitle: String? = null
    ): Flow<AuthResult>
}

internal fun mapAuthError(code: Int, message: String): AuthResult = when (code) {
    BiometricPrompt.ERROR_USER_CANCELED,
    BiometricPrompt.ERROR_CANCELED -> AuthResult.Cancelled
    BiometricPrompt.ERROR_NEGATIVE_BUTTON -> AuthResult.FallbackRequested
    else -> AuthResult.Error(code, message)
}

/** Pure adapter from the callback API to a Flow; [start] creates+launches the prompt, [cancel] dismisses it. */
internal fun <P> authCallbackFlow(
    start: (BiometricPrompt.AuthenticationCallback) -> P,
    cancel: (P) -> Unit
): Flow<AuthResult> = callbackFlow {
    val finished = AtomicBoolean(false)
    val callback = object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            finished.set(true)
            trySend(AuthResult.Success(result.cryptoObject))
            close()
        }

        override fun onAuthenticationFailed() {
            trySend(AuthResult.Failed)
        }

        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            finished.set(true)
            trySend(mapAuthError(errorCode, errString.toString()))
            close()
        }
    }
    val prompt = start(callback)
    awaitClose { if (!finished.get()) cancel(prompt) }
}

class AndroidBiometricAuthenticator(private val context: Context) : BiometricAuthenticator {

    override fun availability(): BiometricAvailability =
        when (BiometricManager.from(context).canAuthenticate(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)) {
            BiometricManager.BIOMETRIC_SUCCESS -> BiometricAvailability.Available
            BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> BiometricAvailability.NoHardware
            BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> BiometricAvailability.HardwareUnavailable
            BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> BiometricAvailability.NotEnrolled
            BiometricManager.BIOMETRIC_ERROR_SECURITY_UPDATE_REQUIRED -> BiometricAvailability.SecurityUpdateRequired
            else -> BiometricAvailability.Unsupported
        }

    override fun authenticate(activity: FragmentActivity, title: String, subtitle: String?): Flow<AuthResult> {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .apply { subtitle?.let { setSubtitle(it) } }
            .setAllowedAuthenticators(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)
            .build()
        return authCallbackFlow(
            start = { cb ->
                BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), cb).also { it.authenticate(info) }
            },
            cancel = { it.cancelAuthentication() }
        ).flowOn(Dispatchers.Main.immediate)
    }

    override fun authenticateWithCipher(
        activity: FragmentActivity,
        cipher: Cipher,
        title: String,
        negativeButtonText: String,
        subtitle: String?
    ): Flow<AuthResult> {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .apply { subtitle?.let { setSubtitle(it) } }
            .setNegativeButtonText(negativeButtonText)
            .setAllowedAuthenticators(BIOMETRIC_STRONG)
            .build()
        return authCallbackFlow(
            start = { cb ->
                BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), cb)
                    .also { it.authenticate(info, BiometricPrompt.CryptoObject(cipher)) }
            },
            cancel = { it.cancelAuthentication() }
        ).flowOn(Dispatchers.Main.immediate)
    }
}
