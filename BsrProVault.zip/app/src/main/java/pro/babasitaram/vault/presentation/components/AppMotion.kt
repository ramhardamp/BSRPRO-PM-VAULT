package pro.babasitaram.vault.presentation.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

/** Motion tokens from Phase16G Batch 5: no screen-local animation timings. */
object AppMotion {
    const val ScreenTransitionMs = 300
    const val ListEnterMs = 200
    const val DialogMs = 150
    const val CopyPulseMs = 200
    const val ThemeCrossfadeMs = 300
}

private val ListEnter: EnterTransition =
    fadeIn(tween(AppMotion.ListEnterMs)) +
        slideInVertically(tween(AppMotion.ListEnterMs)) { it / 6 }

/** One-shot list item enter: fade + slide up. */
@Composable
fun AnimatedListItem(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible = true }
    AnimatedVisibility(
        visible = visible,
        enter = ListEnter,
        exit = fadeOut(tween(AppMotion.ListEnterMs)) + slideOutVertically(tween(AppMotion.ListEnterMs)) { it / 6 },
        modifier = modifier
    ) { content() }
}

/** Dialog enter/exit motion: scale + fade. */
@Composable
fun AnimatedDialogContent(
    visible: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    AnimatedVisibility(
        visible = visible,
        enter = scaleIn(tween(AppMotion.DialogMs)) + fadeIn(tween(AppMotion.DialogMs)),
        exit = scaleOut(tween(AppMotion.DialogMs)) + fadeOut(tween(AppMotion.DialogMs)),
        modifier = modifier
    ) { content() }
}
