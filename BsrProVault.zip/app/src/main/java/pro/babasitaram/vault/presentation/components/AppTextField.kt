package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType

/** Outlined text field with leading/trailing icon slots from UI/UX spec §2.1 and §4. */
@Composable
fun AppTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isError: Boolean = false,
    supportingText: String? = null,
    leadingIcon: ImageVector? = null,
    leadingContentDescription: String? = null,
    trailingIcon: ImageVector? = null,
    trailingContentDescription: String? = null,
    onTrailingIconClick: (() -> Unit)? = null,
    singleLine: Boolean = true,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Default,
    onImeAction: (() -> Unit)? = null
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier,
        enabled = enabled,
        isError = isError,
        singleLine = singleLine,
        leadingIcon = leadingIcon?.let { image ->
            {
                Icon(
                    imageVector = image,
                    contentDescription = leadingContentDescription,
                    modifier = Modifier.size(AppDimens.SmallIconSize)
                )
            }
        },
        trailingIcon = trailingIcon?.let { image ->
            {
                if (onTrailingIconClick != null) {
                    IconButton(onClick = onTrailingIconClick) {
                        Icon(
                            imageVector = image,
                            contentDescription = trailingContentDescription,
                            modifier = Modifier.size(AppDimens.SmallIconSize)
                        )
                    }
                } else {
                    Icon(
                        imageVector = image,
                        contentDescription = trailingContentDescription,
                        modifier = Modifier.size(AppDimens.SmallIconSize)
                    )
                }
            }
        },
        supportingText = supportingText?.let { text -> { Text(text) } },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType, imeAction = imeAction),
        keyboardActions = if (onImeAction != null) {
            KeyboardActions(onAny = { onImeAction() })
        } else {
            KeyboardActions.Default
        },
        textStyle = MaterialTheme.typography.bodyLarge
    )
}
