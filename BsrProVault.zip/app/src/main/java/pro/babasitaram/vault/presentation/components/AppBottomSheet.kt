package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.BottomSheetDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color

/** Shared modal bottom-sheet base with XL top corners and drag handle, spec §1.4. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppBottomSheet(
    visible: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.Unspecified,
    content: @Composable ColumnScope.() -> Unit
) {
    if (!visible) return
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        modifier = modifier,
        shape = RoundedCornerShape(topStart = AppShapes.ExtraLarge, topEnd = AppShapes.ExtraLarge),
        containerColor = if (containerColor == Color.Unspecified) androidx.compose.material3.MaterialTheme.colorScheme.surface else containerColor,
        dragHandle = {
            Surface(
                modifier = Modifier
                    .width(AppDimens.BottomSheetHandleWidth)
                    .height(AppDimens.BottomSheetHandleHeight)
                    .clip(RoundedCornerShape(AppShapes.Pill)),
                color = BottomSheetDefaults.dragHandleColor
            ) {}
        },
        content = content
    )
}
