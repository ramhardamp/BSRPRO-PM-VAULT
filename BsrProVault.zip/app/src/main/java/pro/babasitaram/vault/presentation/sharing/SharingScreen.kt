@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.sharing

import pro.babasitaram.vault.R

import pro.babasitaram.vault.presentation.components.AppDimens

import pro.babasitaram.vault.presentation.components.AppScreenState
import pro.babasitaram.vault.presentation.components.AppHeadingText
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics

import androidx.compose.ui.res.stringResource
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.launch
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.security.SecureShareManager
import pro.babasitaram.vault.presentation.components.AppEmptyState
import pro.babasitaram.vault.presentation.util.findFragmentActivity

/** Phase16G Batch6 migration: tokenized UI, Hilt ViewModel reuse, state contract, dark-mode and accessibility semantics. */
@Composable
fun SharingScreen(
    onBack: () -> Unit = {},
    initialEntryIds: List<String> = emptyList(),
    loading: Boolean = false,
    errorMessage: String? = null,
    onRetry: () -> Unit = {},
    vm: SharingViewModel = hiltViewModel()
) {
    BackHandler { onBack() }

    val entries by vm.entries.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val activity = context.findFragmentActivity()
    val initialEntries = entries.filter { it.id in initialEntryIds }

    var pinDialog by rememberSaveable { mutableStateOf(false) }
    // saved across activity recreation, otherwise the PIN dialog could stay open with nothing to share
    var pendingIdsRaw by rememberSaveable { mutableStateOf("") }
    val pendingEntryIds: List<String> = if (pendingIdsRaw.isEmpty()) emptyList() else pendingIdsRaw.split('\u0001')
    var masterDialog by rememberSaveable { mutableStateOf(false) }
    var masterPw by remember { mutableStateOf("") }
    var pin by rememberSaveable { mutableStateOf("") }
    val defaultShareLabel = stringResource(R.string.p15_share)
    val shareActionLabel = stringResource(R.string.p15_share)
    val copyActionLabel = stringResource(R.string.p15_copy)
    val qrActionLabel = stringResource(R.string.b6_sharing_qr)
    val secureLinkCopyLabel = stringResource(R.string.b6_sharing_secure_link)
    val qrForegroundColor = MaterialTheme.colorScheme.onSurface.toArgb()
    val qrBackgroundColor = MaterialTheme.colorScheme.surface.toArgb()
    var actionLabel by rememberSaveable { mutableStateOf(defaultShareLabel) }
    var message by rememberSaveable { mutableStateOf<String?>(null) }
    var expiryMinutes by rememberSaveable { mutableStateOf(10f) }
    var maxViews by rememberSaveable { mutableStateOf(1f) }
    var linkPassword by rememberSaveable { mutableStateOf("") }
    var qrLink by rememberSaveable { mutableStateOf<String?>(null) }
    var revokeTarget by rememberSaveable { mutableStateOf<String?>(null) }
    var confirmRevokeAll by rememberSaveable { mutableStateOf(false) }
    var confirmClearAll by rememberSaveable { mutableStateOf(false) }
    var selectedShareTab by rememberSaveable { mutableStateOf(0) }

    fun options() = SecureShareManager.ShareOptions(
        ttlMs = expiryMinutes.toLong() * 60_000L,
        maxViews = maxViews.toInt(),
        password = linkPassword
    )

    suspend fun performAuthorizedAction(selectedEntries: List<VaultEntry>, label: String) {
        if (selectedEntries.isEmpty()) return
        if (label == context.getString(R.string.b6_sharing_direct)) {
            // Fix.md 2.1: single item -> OS share sheet at once (after the usual authorisation), no intermediate page
            shareText(context, directShareText(context, selectedEntries.first()), context.getString(R.string.p15_share))
            onBack()
            return
        }
        val opts = options()
        val links = selectedEntries.map { entry ->
            entry to vm.createLink(entry, opts)
        }
        val content = links.joinToString("\n") { (entry, link) ->
            val title = entry.title.ifBlank { context.getString(pro.babasitaram.vault.R.string.p17_secure_entry) }
            "$title: $link"
        }
        when (label) {
            context.getString(R.string.p15_share) -> shareText(context, content, context.getString(R.string.p15_share))
            context.getString(R.string.p15_copy) -> vm.copySecret(content, context.getString(R.string.b6_sharing_secure_link))
            context.getString(R.string.b6_sharing_qr) -> if (links.size == 1) qrLink = links.first().second
        }
    }

    fun requestShare(selectedEntries: List<VaultEntry>, label: String) {
        if (selectedEntries.isEmpty()) return
        scope.launch {
            if (vm.biometricAvailable() && activity != null) {
                if (vm.authenticateBiometric(activity)) {
                    performAuthorizedAction(selectedEntries, label)
                    return@launch
                }
            }

            pendingIdsRaw = selectedEntries.joinToString("\u0001") { it.id }
            actionLabel = label
            if (vm.isPinConfigured()) {
                pinDialog = true
            } else {
                // no biometric and no App PIN (e.g. phones without fingerprint/face): master password authorises it
                masterDialog = true
            }
        }
    }

    var searchQuery by rememberSaveable { mutableStateOf("") }
    val shownEntries = remember(entries, searchQuery) { pro.babasitaram.vault.core.util.EntrySearch.filter(entries, searchQuery) }
    var directStarted by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(initialEntryIds, entries) {
        if (initialEntryIds.size == 1 && initialEntries.size == 1 && !directStarted) {
            directStarted = true
            requestShare(initialEntries, context.getString(R.string.b6_sharing_direct))
        }
    }
    LaunchedEffect(initialEntryIds, entries) {
        if (initialEntryIds.size > 1 && initialEntries.size == initialEntryIds.size) {
            requestShare(initialEntries, context.getString(R.string.p15_share))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { AppHeadingText(stringResource(R.string.p15_secure_sharing)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037))
                    }
                }
            )
        }
    ) { padding ->
        AppScreenState(loading = loading, errorMessage = errorMessage, onRetry = onRetry) {
        if (entries.isEmpty()) {
            AppEmptyState(
                stringResource(R.string.p15_nothing_to_share),
                stringResource(R.string.p17_secure_share_empty_message),
                Modifier.padding(padding).fillMaxWidth()
            )
        } else {
            LazyColumn(
                Modifier.fillMaxSize().padding(padding).focusGroup().padding(AppDimens.Medium),
                verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(AppDimens.Medium),
                            verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, contentDescription = stringResource(R.string.p15_secure_sharing))
                                Text(
                                    stringResource(R.string.p15_link_protection),
                                    style = MaterialTheme.typography.titleMedium,
                                    modifier = Modifier.padding(start = AppDimens.Xs)
                                )
                            }
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_expiry_minutes, expiryMinutes.toInt()))
                            Slider(
                                value = expiryMinutes,
                                onValueChange = { expiryMinutes = it },
                                valueRange = 1f..60f,
                                steps = 58
                            )
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_view_limit, maxViews.toInt()))
                            Slider(
                                value = maxViews,
                                onValueChange = { maxViews = it },
                                valueRange = 1f..10f,
                                steps = 8
                            )
                            OutlinedTextField(
                                value = linkPassword,
                                onValueChange = { linkPassword = it.take(128) },
                                label = { Text(stringResource(R.string.p15_optional_link_password)) },
                                supportingText = {
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_094))
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Text(
                                stringResource(R.string.p18_sharing_anyone_who_has_the_link) +
                                    stringResource(R.string.p18_sharing_a_link_that_has_already),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                stringResource(R.string.share_limits_advisory_note),
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                message?.let { text ->
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Text(
                                text,
                                modifier = Modifier.padding(AppDimens.Medium),
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }

                if (initialEntries.size > 1) {
                    item {
                        Card(Modifier.fillMaxWidth()) {
                            Column(
                                Modifier.padding(AppDimens.Medium),
                                verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
                            ) {
                                Text(
                                    stringResource(R.string.selection_selected_count, initialEntries.size),
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(stringResource(R.string.selection_bulk_share_message))
                                Button(onClick = { requestShare(initialEntries, context.getString(R.string.p15_share)) }) {
                                    Icon(Icons.Default.Security, contentDescription = null)
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_095))
                                }
                            }
                        }
                    }
                }

                item {
                    val shares by vm.shares.collectAsStateWithLifecycle()
                    val nowMs = System.currentTimeMillis()
                    val active = shares.filter { it.isActive(nowMs) }
                    val revoked = shares.filter { it.revoked }
                    val expired = shares.filter { it.isExpired(nowMs) || it.expiredAt > 0L }
                    Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            listOf(stringResource(R.string.b6_sharing_active), stringResource(R.string.b6_sharing_revoked), stringResource(R.string.b6_sharing_expired)).forEachIndexed { index, label ->
                                if (selectedShareTab == index) Button(onClick = { selectedShareTab = index }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_tab_count, label, listOf(active, revoked, expired)[index].size)) }
                                else OutlinedButton(onClick = { selectedShareTab = index }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_tab_count, label, listOf(active, revoked, expired)[index].size)) }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            OutlinedButton(onClick = { confirmRevokeAll = true }, enabled = active.isNotEmpty()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_096)) }
                            OutlinedButton(onClick = { confirmClearAll = true }, enabled = shares.isNotEmpty()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_097)) }
                        }
                        Text(
                            stringResource(R.string.p15_offline_revoke_receiver_app_sync_link_invalid),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        val visible = when (selectedShareTab) { 1 -> revoked; 2 -> expired; else -> active }
                        if (visible.isEmpty()) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_098), style = MaterialTheme.typography.bodySmall)
                        visible.forEach { rec ->
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(AppDimens.Small), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                                    Text(rec.title, style = MaterialTheme.typography.titleMedium)
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_created, java.text.DateFormat.getDateTimeInstance().format(java.util.Date(rec.createdAt))), style = MaterialTheme.typography.bodySmall)
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_expiry_date, java.text.DateFormat.getDateTimeInstance().format(java.util.Date(rec.expiresAt))), style = MaterialTheme.typography.bodySmall)
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_views, rec.viewCount), style = MaterialTheme.typography.bodySmall)
                                    if (rec.revoked) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_revoked, java.text.DateFormat.getDateTimeInstance().format(java.util.Date(rec.revokedAt))), style = MaterialTheme.typography.bodySmall)
                                    if (rec.isActive(nowMs)) {
                                        val mins = ((rec.expiresAt - nowMs) / 60_000L).coerceAtLeast(0)
                                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_share_expires_min, mins + 1), style = MaterialTheme.typography.bodySmall)
                                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_099), style = MaterialTheme.typography.bodySmall)
                                        TextButton(onClick = { revokeTarget = rec.id }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_100)) }
                                    }
                                }
                            }
                        }
                        if (selectedShareTab == 1) TextButton(onClick = vm::clearRevokedShares) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_101)) }
                        if (selectedShareTab == 2) TextButton(onClick = { vm.cleanupShares(); vm.clearExpiredShares() }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_102)) }
                    }
                }

                item {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it.take(100) },
                        label = { Text(stringResource(R.string.sh_search)) },
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                items(shownEntries, key = { it.id  }, contentType = { "item" }) { entry ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(
                            Modifier.padding(AppDimens.Medium),
                            verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)
                        ) {
                            Text(
                                entry.title.ifBlank { stringResource(R.string.p17_untitled) },
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                entry.username.ifBlank { entry.url },
                                style = MaterialTheme.typography.bodySmall
                            )
                            Button(
                                onClick = { requestShare(listOf(entry), shareActionLabel) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(stringResource(R.string.p15_share_encrypted_link))
                            }
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)
                            ) {
                                OutlinedButton(
                                    onClick = { requestShare(listOf(entry), copyActionLabel) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.p15_copy))
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_103))
                                }
                                OutlinedButton(
                                    onClick = { requestShare(listOf(entry), qrActionLabel) },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.QrCode2, contentDescription = stringResource(R.string.b6_sharing_qr))
                                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_104))
                                }
                            }
                        }
                    }
                }
            }
        }
    
        }}

    if (pinDialog) {
        AlertDialog(
            onDismissRequest = {
                pinDialog = false
                pin = ""
            },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_105)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_106))
                    OutlinedTextField(
                        value = pin,
                        onValueChange = { pin = it.filter(Char::isDigit).take(6) },
                        label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_107)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    enabled = pin.length in 4..6,
                    onClick = {
                        scope.launch {
                            val selectedEntries = entries.filter { it.id in pendingEntryIds }
                            if (selectedEntries.isEmpty()) {
                                pinDialog = false
                                pin = ""
                                message = pro.babasitaram.vault.core.util.L.s(R.string.p19_nothing_selected)
                                return@launch
                            }
                            val ok = vm.verifyPin(pin)
                            if (!ok) {
                                message = context.getString(pro.babasitaram.vault.R.string.p17_incorrect_sharing_pin)
                                return@launch
                            }
                            pinDialog = false
                            pin = ""
                            performAuthorizedAction(selectedEntries, actionLabel)
                        }
                    }
                ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_073)) }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { pinDialog = false; pin = ""; masterDialog = true }) { Text(stringResource(R.string.sh_use_master)) }
                    TextButton(
                        onClick = {
                            pinDialog = false
                            pin = ""
                        }
                    ) { Text(stringResource(R.string.p15_cancel)) }
                }
            }
        )
    }

    if (masterDialog) {
        AlertDialog(
            onDismissRequest = { masterDialog = false; masterPw = "" },
            title = { Text(stringResource(R.string.p18_common_confirm_it_s_you)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(stringResource(R.string.p18_sharing_enter_your_master_password_to))
                    pro.babasitaram.vault.presentation.components.PasswordField(masterPw, { masterPw = it }, stringResource(R.string.p17_loc_074))
                }
            },
            confirmButton = {
                TextButton(
                    enabled = masterPw.isNotEmpty(),
                    onClick = {
                        scope.launch {
                            val selectedEntries = entries.filter { it.id in pendingEntryIds }
                            if (selectedEntries.isEmpty()) {
                                masterDialog = false
                                masterPw = ""
                                message = pro.babasitaram.vault.core.util.L.s(R.string.p19_nothing_selected)
                                return@launch
                            }
                            if (!vm.verifyMasterPassword(masterPw)) {
                                message = pro.babasitaram.vault.core.util.L.s(R.string.p19_wrong_master)
                                masterPw = ""
                                return@launch
                            }
                            masterDialog = false
                            masterPw = ""
                            performAuthorizedAction(selectedEntries, actionLabel)
                        }
                    }
                ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_073)) }
            },
            dismissButton = { TextButton(onClick = { masterDialog = false; masterPw = "" }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }

    revokeTarget?.let { id ->
        AlertDialog(
            onDismissRequest = { revokeTarget = null },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_108)) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_109)) },
            confirmButton = { TextButton(onClick = { vm.revokeShare(id); revokeTarget = null }) { Text(stringResource(R.string.p15_revoke)) } },
            dismissButton = { TextButton(onClick = { revokeTarget = null }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_110)) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_111)) },
            confirmButton = { TextButton(onClick = { vm.clearAllShares(); confirmClearAll = false }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_097)) } },
            dismissButton = { TextButton(onClick = { confirmClearAll = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    if (confirmRevokeAll) {
        AlertDialog(
            onDismissRequest = { confirmRevokeAll = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_112)) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_113)) },
            confirmButton = { TextButton(onClick = { vm.revokeAllShares(); confirmRevokeAll = false }) { Text(stringResource(R.string.p15_revoke_all)) } },
            dismissButton = { TextButton(onClick = { confirmRevokeAll = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }

    qrLink?.let { link ->
        AlertDialog(
            onDismissRequest = { qrLink = null },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_114)) },
            text = {
                Column(
                    Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
                ) {
                    QrCodeBitmap(link, qrForegroundColor, qrBackgroundColor)?.let { bitmap ->
                        androidx.compose.foundation.Image(
                            bitmap = bitmap,
                            contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_115),
                            modifier = Modifier.size(AppDimens.QrPreviewSize)
                        )
                    }
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_116))
                    if (linkPassword.isNotBlank()) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_117))
                    }
                    OutlinedButton(onClick = { vm.copySecret(link, secureLinkCopyLabel) }) {
                        Icon(Icons.Default.ContentCopy, contentDescription = stringResource(R.string.p15_copy))
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_118))
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { qrLink = null }) { Text(stringResource(R.string.p15_close)) }
            }
        )
    }
}

private fun QrCodeBitmap(value: String, foreground: Int, background: Int): androidx.compose.ui.graphics.ImageBitmap? = runCatching {
    val matrix = QRCodeWriter().encode(value, BarcodeFormat.QR_CODE, 768, 768)
    val bitmap = Bitmap.createBitmap(matrix.width, matrix.height, Bitmap.Config.ARGB_8888)
    for (x in 0 until matrix.width) {
        for (y in 0 until matrix.height) {
            bitmap.setPixel(x, y, if (matrix[x, y]) foreground else background)
        }
    }
    bitmap.asImageBitmap()
}.getOrNull()

/** Plain text for the OS share sheet: Username, Password, URL (or app package), plus the App PIN when one is saved. */
private fun directShareText(context: Context, e: VaultEntry): String {
    val title = e.title.ifBlank { context.getString(R.string.b6_sharing_entry) }
    if (e.isNote || e.recordType.equals("note", true)) return "$title\n${e.notes}"
    return buildList {
        add(title)
        if (e.username.isNotBlank()) add(context.getString(R.string.b6_sharing_username, e.username))
        if (e.password.isNotBlank()) add(context.getString(R.string.b6_sharing_password, e.password))
        if (e.appPin.isNotBlank()) add(context.getString(R.string.b6_sharing_pin, e.appPin))
        if (e.url.isNotBlank()) add(context.getString(R.string.b6_sharing_url, e.url)) else if (e.appPackage.isNotBlank()) add(context.getString(R.string.b6_sharing_app, e.appPackage))
    }.joinToString("\n")
}

private fun shareText(context: Context, value: String, chooserTitle: String) {
    context.startActivity(
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, value)
            },
            chooserTitle
        )
    )
}

