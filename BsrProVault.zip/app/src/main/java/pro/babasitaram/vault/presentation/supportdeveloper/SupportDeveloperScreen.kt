@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.supportdeveloper

import pro.babasitaram.vault.R
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AnimatedListItem
import pro.babasitaram.vault.presentation.components.AppErrorState
import pro.babasitaram.vault.presentation.components.AppLoadingState
import pro.babasitaram.vault.presentation.components.AppEmptyState

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.foundation.Image
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

private const val WEBSITE_URL = "https://ramhardamp.github.io/babasitaram-pro/"
private const val SUPPORT_UPI_ID = "Totalpay@upi"

/** Spec §2.9 — tokenized Support screen with theme-derived QR colors, actions, heading semantics and Hilt wiring. */
@Composable
fun SupportScreen(onBack: () -> Unit = {}, vm: SupportDeveloperScreenViewModel = hiltViewModel()) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { loading = false }
    val upiUri = "upi://pay?pa=${Uri.encode(SUPPORT_UPI_ID)}&pn=${Uri.encode(context.getString(R.string.p17_support_developer))}"
    val qrDark = MaterialTheme.colorScheme.onSurface.toArgb()
    val qrLight = MaterialTheme.colorScheme.surface.toArgb()
    val upiQr = rememberQr(upiUri, qrDark, qrLight)
    val websiteQr = rememberQr(WEBSITE_URL, qrDark, qrLight)
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_support_developer), style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p17_loc_037)) } }
            )
        }
    ) { padding ->
        when {
            loading -> AppLoadingState(stringResource(R.string.b5_state_loading))
            upiQr == null || websiteQr == null -> AppErrorState(stringResource(R.string.b5_state_error), stringResource(R.string.b5_state_error_message), stringResource(R.string.b5_state_retry))
            WEBSITE_URL.isBlank() -> AppEmptyState(stringResource(R.string.b5_state_empty), stringResource(R.string.b5_state_empty_message))
            else -> LazyColumn(Modifier.fillMaxSize().padding(padding).padding(AppDimens.Medium).focusGroup(), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs), horizontalAlignment = Alignment.CenterHorizontally) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            Icon(Icons.Default.VolunteerActivism, contentDescription = null)
                            Text(stringResource(R.string.p17_loc_207), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                            Text(stringResource(R.string.p17_loc_208))
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(AppDimens.Medium), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            Text(stringResource(R.string.p17_loc_209), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                            Text(SUPPORT_UPI_ID, style = MaterialTheme.typography.headlineMedium)
                            upiQr.let { Image(it.asImageBitmap(), stringResource(R.string.b5_support_qr), Modifier.size(AppDimens.DetailIcon)) }
                            Button(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(upiUri))) } }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p17_loc_210)) }
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(AppDimens.Medium), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            Icon(Icons.Default.QrCode2, contentDescription = null)
                            Text(stringResource(R.string.p17_loc_131), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                            websiteQr.let { Image(it.asImageBitmap(), stringResource(R.string.p17_loc_211), Modifier.size(AppDimens.DetailIcon)) }
                            Text(WEBSITE_URL, style = MaterialTheme.typography.bodySmall)
                            OutlinedButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(WEBSITE_URL))) }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.Language, contentDescription = null)
                                Text(stringResource(R.string.p17_loc_212))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun rememberQr(value: String, darkColor: Int, lightColor: Int): Bitmap? = androidx.compose.runtime.remember(value, darkColor, lightColor) {
    runCatching {
        val matrix: BitMatrix = MultiFormatWriter().encode(value, BarcodeFormat.QR_CODE, 600, 600)
        val bitmap = Bitmap.createBitmap(600, 600, Bitmap.Config.ARGB_8888)
        for (x in 0 until 600) for (y in 0 until 600) bitmap.setPixel(x, y, if (matrix[x, y]) darkColor else lightColor)
        bitmap
    }.getOrNull()
}
