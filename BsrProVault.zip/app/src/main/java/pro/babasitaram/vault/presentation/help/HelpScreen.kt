@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.help

import pro.babasitaram.vault.R
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AnimatedListItem
import pro.babasitaram.vault.presentation.components.AppErrorState
import pro.babasitaram.vault.presentation.components.AppLoadingState
import pro.babasitaram.vault.presentation.components.AppEmptyState

import androidx.compose.ui.res.stringResource
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import pro.babasitaram.vault.core.constants.AppLinks

data class HelpFaq(val question: String, val answer: String)

private val faqRes = (1..16).toList()
private val faqTitles = listOf(R.string.b5_help_q1_title,R.string.b5_help_q2_title,R.string.b5_help_q3_title,R.string.b5_help_q4_title,R.string.b5_help_q5_title,R.string.b5_help_q6_title,R.string.b5_help_q7_title,R.string.b5_help_q8_title,R.string.b5_help_q9_title,R.string.b5_help_q10_title,R.string.b5_help_q11_title,R.string.b5_help_q12_title,R.string.b5_help_q13_title,R.string.b5_help_q14_title,R.string.b5_help_q15_title,R.string.b5_help_q16_title)
private val faqBodies = listOf(R.string.b5_help_q1_body,R.string.b5_help_q2_body,R.string.b5_help_q3_body,R.string.b5_help_q4_body,R.string.b5_help_q5_body,R.string.b5_help_q6_body,R.string.b5_help_q7_body,R.string.b5_help_q8_body,R.string.b5_help_q9_body,R.string.b5_help_q10_body,R.string.b5_help_q11_body,R.string.b5_help_q12_body,R.string.b5_help_q13_body,R.string.b5_help_q14_body,R.string.b5_help_q15_body,R.string.b5_help_q16_body)

/** Spec §2.9 — tokenized Help/FAQ screen with localized FAQ resources, list-enter motion, heading semantics and Hilt wiring. */
@Composable
fun HelpScreen(onBack: () -> Unit = {}, vm: HelpScreenViewModel = hiltViewModel()) {
    val context = LocalContext.current
    var loading by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { loading = false }
    BackHandler { onBack() }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.p15_help), style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.p17_loc_037))
                    }
                }
            )
        }
    ) { padding ->
        when {
            loading -> AppLoadingState(stringResource(R.string.b5_state_loading))
            faqRes.isEmpty() -> AppEmptyState(stringResource(R.string.b5_state_empty), stringResource(R.string.b5_state_empty_message))
            else -> LazyColumn(
                Modifier.fillMaxSize().padding(padding).padding(AppDimens.Medium).focusGroup(),
                verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
            ) {
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            Icon(Icons.Default.HelpOutline, contentDescription = null)
                            Text(stringResource(R.string.p17_loc_126), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                            Text(stringResource(R.string.p17_loc_127))
                        }
                    }
                }
                item { Text(stringResource(R.string.p17_loc_128), style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) }
                items(faqRes, key = { it }, contentType = { "item" }) { id ->
                    AnimatedListItem {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                                Text(stringResource(faqTitles[id - 1]), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                                Text(stringResource(faqBodies[id - 1]))
                            }
                        }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            Text(stringResource(R.string.p17_loc_129), style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                            Text(stringResource(R.string.p17_loc_130))
                        }
                    }
                }
                item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppLinks.WEBSITE))) } }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p17_loc_131)) } }
                item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppLinks.GITHUB_ISSUES))) } }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p17_loc_132)) } }
                item { OutlinedButton(onClick = { runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${AppLinks.EMAIL}"))) } }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p17_email_support, AppLinks.EMAIL)) } }
            }
        }
    }
}
