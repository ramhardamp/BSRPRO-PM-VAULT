package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight

/** Four button variants from UI/UX spec §4 Consistency Rules. */
enum class AppButtonVariant {
    PRIMARY,
    SECONDARY,
    TEXT,
    ICON
}

@Composable
fun AppButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: AppButtonVariant = AppButtonVariant.PRIMARY,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    contentDescription: String? = null
) {
    if (variant == AppButtonVariant.ICON) {
        IconButton(
            onClick = onClick,
            enabled = enabled,
            modifier = modifier.size(AppDimens.ButtonHeight)
        ) {
            if (icon == null) return@IconButton
            Icon(
                imageVector = icon,
                contentDescription = contentDescription ?: label,
                modifier = Modifier.size(AppDimens.SmallIconSize)
            )
        }
        return
    }

    val buttonModifier = modifier
        .height(if (variant == AppButtonVariant.PRIMARY) AppDimens.PrimaryButtonHeight else AppDimens.ButtonHeight)

    val textStyle = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold)
    val shape = RoundedCornerShape(AppShapes.Button)

    when (variant) {
        AppButtonVariant.PRIMARY -> Button(
            onClick = onClick,
            enabled = enabled,
            modifier = buttonModifier,
            shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            contentPadding = PaddingValues(horizontal = AppDimens.Large)
        ) { AppButtonContent(label, icon, textStyle) }

        AppButtonVariant.SECONDARY -> OutlinedButton(
            onClick = onClick,
            enabled = enabled,
            modifier = buttonModifier,
            shape = shape,
            contentPadding = PaddingValues(horizontal = AppDimens.Large)
        ) { AppButtonContent(label, icon, textStyle) }

        AppButtonVariant.TEXT -> TextButton(
            onClick = onClick,
            enabled = enabled,
            modifier = buttonModifier,
            contentPadding = PaddingValues(horizontal = AppDimens.Large)
        ) { AppButtonContent(label, icon, textStyle) }

        AppButtonVariant.ICON -> Unit
    }
}

@Composable
private fun RowScope.AppButtonContent(
    label: String,
    icon: ImageVector?,
    textStyle: androidx.compose.ui.text.TextStyle
) {
    if (icon != null) {
        Icon(icon, contentDescription = null, modifier = Modifier.size(AppDimens.SmallIconSize))
    }
    Text(label, style = textStyle)
}
