package pro.babasitaram.vault.presentation.help

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import pro.babasitaram.vault.domain.repository.SettingsRepository

/** Hilt wiring for Help; existing repository infrastructure is reused without vault-data mutation. */
@HiltViewModel
class HelpScreenViewModel @Inject constructor(
    private val settingsRepository: SettingsRepository
) : ViewModel()
