package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import pro.babasitaram.vault.presentation.theme.CategoryAppLogin
import pro.babasitaram.vault.presentation.theme.CategoryCards
import pro.babasitaram.vault.presentation.theme.CategoryIdentities
import pro.babasitaram.vault.presentation.theme.CategoryNotes
import pro.babasitaram.vault.presentation.theme.CategoryVault

/** 40dp circular category icon container with four semantic category variants, spec §2.3. */
enum class AppIconCircleVariant { VAULT, APP_LOGIN, CARDS, IDENTITIES, NOTES }

@Composable
fun AppIconCircle(
    icon: ImageVector,
    variant: AppIconCircleVariant,
    modifier: Modifier = Modifier,
    contentDescription: String? = null
) {
    val color: Color = when (variant) {
        AppIconCircleVariant.VAULT -> CategoryVault
        AppIconCircleVariant.APP_LOGIN -> CategoryAppLogin
        AppIconCircleVariant.CARDS -> CategoryCards
        AppIconCircleVariant.IDENTITIES -> CategoryIdentities
        AppIconCircleVariant.NOTES -> CategoryNotes
    }
    Box(
        modifier = modifier.size(AppDimens.EntryIcon).background(color, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = androidx.compose.material3.MaterialTheme.colorScheme.onPrimary)
    }
}
