package pro.babasitaram.vault.presentation.components

import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Shared determinate/indeterminate progress bar, spec §2.10. */
@Composable
fun AppProgressBar(
    modifier: Modifier = Modifier,
    progress: Float? = null
) {
    if (progress == null) {
        LinearProgressIndicator(modifier = modifier)
    } else {
        LinearProgressIndicator(
            progress = { progress.coerceIn(0f, 1f) },
            modifier = modifier
        )
    }
}
