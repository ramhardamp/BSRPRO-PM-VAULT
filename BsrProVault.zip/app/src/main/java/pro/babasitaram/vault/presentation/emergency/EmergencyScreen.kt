@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.emergency

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContactEmergency
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.R

import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppEmptyState

import pro.babasitaram.vault.presentation.components.AppScreenState
import pro.babasitaram.vault.presentation.components.AppHeadingText
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.delay

/** Phase16G Batch6 migration: tokenized UI, Hilt ViewModel reuse, state contract, dark-mode and accessibility semantics. */
@Composable
fun EmergencyScreen(
    onBack: () -> Unit = {},
    loading: Boolean = false,
    errorMessage: String? = null,
    onRetry: () -> Unit = {},
    vm: EmergencyViewModel = hiltViewModel()
) {
    val status by vm.status.collectAsStateWithLifecycle()
    val key by vm.generatedKey.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val contactName by vm.contactName.collectAsStateWithLifecycle()
    val contactPhone by vm.contactPhone.collectAsStateWithLifecycle()
    val now by vm.now.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var requestKey by remember { mutableStateOf("") }
    var timer by remember { mutableStateOf(now) }
    BackHandler { onBack() }
    LaunchedEffect(Unit) { while (true) { timer = System.currentTimeMillis(); delay(1_000L) } }
    val unlockAt = status?.unlockAt ?: 0L
    val remaining = (unlockAt - timer).coerceAtLeast(0L)
    val hours = remaining / 3_600_000L
    val minutes = (remaining % 3_600_000L) / 60_000L

    Scaffold(topBar = { TopAppBar(title = { AppHeadingText(stringResource(R.string.emergency_access_title)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.common_back)) } }) }) { padding ->
        AppScreenState(loading = loading, errorMessage = errorMessage, onRetry = onRetry) {
        if (status == null) {
            AppEmptyState(
                stringResource(R.string.emergency_not_configured),
                stringResource(R.string.emergency_setup_note),
                Modifier.fillMaxSize().padding(padding),
                actionLabel = stringResource(R.string.emergency_create_key),
                onAction = vm::setup
            )
        } else {
        LazyColumn(Modifier.fillMaxSize().padding(padding).focusGroup().padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                Icon(Icons.Default.ContactEmergency, contentDescription = stringResource(R.string.emergency_trusted_contact))
                Text(stringResource(R.string.emergency_trusted_contact), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.emergency_contact_storage_note))
                OutlinedTextField(contactName, vm::setContactName, label = { Text(stringResource(R.string.emergency_contact_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(contactPhone, vm::setContactPhone, label = { Text(stringResource(R.string.emergency_contact_phone)) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), singleLine = true, modifier = Modifier.fillMaxWidth())
                Button(onClick = vm::saveContact, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.emergency_save_contact)) }
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                Text(if (status?.configured == true) stringResource(R.string.emergency_configured) else stringResource(R.string.emergency_not_configured), style = MaterialTheme.typography.titleMedium)
                Text(stringResource(R.string.emergency_setup_note))
                Button(onClick = vm::setup, modifier = Modifier.fillMaxWidth()) { Text(if (status?.configured == true) stringResource(R.string.emergency_regenerate_key) else stringResource(R.string.emergency_create_key)) }
                if (status?.configured == true) Button(onClick = vm::revoke, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.emergency_revoke)) }
            } } }
            if (key.isNotBlank()) item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) { Text(stringResource(R.string.emergency_recovery_key), style = MaterialTheme.typography.titleMedium); Text(key, style = MaterialTheme.typography.headlineMedium); Text(stringResource(R.string.emergency_key_safety)) } } }
            if (status?.configured == true) item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                Text(stringResource(R.string.emergency_recovery_request), style = MaterialTheme.typography.titleMedium)
                OutlinedTextField(requestKey, { requestKey = it.uppercase().filter(Char::isLetterOrDigit).take(24) }, label = { Text(stringResource(R.string.emergency_key_24_label)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (status?.pending == true) {
                    if (status?.ready == true) Text(stringResource(R.string.emergency_wait_complete), color = MaterialTheme.colorScheme.primary)
                    else Text(stringResource(R.string.emergency_unlock_in, hours, minutes))
                    Button(onClick = { vm.unlock(requestKey) }, enabled = status?.ready == true && requestKey.length == 24, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.emergency_unlock)) }
                    TextButton(onClick = vm::cancelRequest) { Text(stringResource(R.string.common_cancel_request)) }
                } else {
                    Button(onClick = { vm.request(requestKey) }, enabled = requestKey.length == 24, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.emergency_start_recovery)) }
                }
            } } }
            message?.let { item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) { Text(it); TextButton(onClick = vm::clearMessage) { Text(stringResource(R.string.common_dismiss)) } } } } }
        }
        }
        }
}
}
