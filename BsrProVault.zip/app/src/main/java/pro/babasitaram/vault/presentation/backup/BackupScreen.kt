package pro.babasitaram.vault.presentation.backup

import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.layout.size
import pro.babasitaram.vault.R
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AnimatedListItem
import pro.babasitaram.vault.presentation.components.AppErrorState
import pro.babasitaram.vault.presentation.components.AppLoadingState
import pro.babasitaram.vault.presentation.components.AppEmptyState

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import androidx.compose.ui.semantics.Role
import androidx.compose.material3.RadioButton
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.selectable
import pro.babasitaram.vault.presentation.components.PasswordField
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import pro.babasitaram.vault.data.transfer.DuplicateAction
import pro.babasitaram.vault.data.transfer.ExportFormat
import pro.babasitaram.vault.data.transfer.ExportKind
import pro.babasitaram.vault.data.transfer.ExportOptions
import pro.babasitaram.vault.data.transfer.ImportMode
import pro.babasitaram.vault.data.transfer.MapField
import pro.babasitaram.vault.core.util.L

@OptIn(ExperimentalMaterial3Api::class)
/** Spec §2.5 — tokenized backup/restore/import/export screen; existing BackupViewModel and transfer state are preserved. */
@Composable
fun BackupScreen(onBack: () -> Unit, onImportContacts: () -> Unit = {}, vm: BackupViewModel = hiltViewModel()) {
    BackHandler { onBack() }
    val state by vm.state.collectAsStateWithLifecycle()
    val backupPasswordCopyLabel = stringResource(R.string.p17_backup_password)
    val context = LocalContext.current
    var saveMime by remember { mutableStateOf("application/octet-stream") }

    val importPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> vm.onImportFile(uri) }
    val exportTarget = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? -> vm.onExportTarget(uri) }
    val backupFolderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            }.onSuccess { vm.setBackupFolder(uri) }
                .onFailure { android.widget.Toast.makeText(context, context.getString(pro.babasitaram.vault.R.string.p17_folder_access_failed), android.widget.Toast.LENGTH_LONG).show() }
        }
    }

    LaunchedEffect(vm) {
        vm.events.collect { e ->
            when (e) {
                is BackupEvent.Message -> android.widget.Toast.makeText(context, e.text, android.widget.Toast.LENGTH_LONG).show()
                is BackupEvent.SaveFile -> { saveMime = e.mime; exportTarget.launch(e.fileName) }
            }
        }
    }

    val review = state.importing as? ImportStage.Review
    val mapStage = state.importing as? ImportStage.MapFields
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (review != null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_review_import) else if (mapStage != null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_map_columns) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_import_title), modifier = Modifier.semantics { heading() }) },
                navigationIcon = {
                    IconButton(onClick = { if (review != null || mapStage != null) vm.cancelImport() else onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037))
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().focusGroup()) {
            if (state.busy) CircularProgressIndicator(Modifier.padding(AppDimens.Medium).align(Alignment.CenterHorizontally))
            when {
                review != null -> ReviewPane(review, vm)
                mapStage != null -> MapPane(mapStage, vm)
                else -> MainPane(
                    state, vm,
                    onPick = { importPicker.launch(arrayOf("*/*")) },
                    onPickMapped = { vm.requestMappedImport(); importPicker.launch(arrayOf("*/*")) },
                    onContacts = onImportContacts,
                    onChooseBackupFolder = { backupFolderPicker.launch(null) }
                )
            }
        }
    }

    state.exportOptions?.let { o ->
        ExportOptionsDialog(o, onChange = vm::updateExportOptions, onContinue = vm::continueExport, onCancel = vm::dismissExportOptions)
    }
    state.exportProgress?.let { p ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_038)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(if (p.total > 0) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export_progress, p.done, p.total) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_preparing_export))
                    if (p.total > 0 && p.done < p.total) LinearProgressIndicator(progress = { p.done / p.total.toFloat() }, modifier = Modifier.fillMaxWidth())
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    if (p.total > 0 && p.done >= p.total) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_039), style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelRunningExport) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    state.exportAsk?.takeIf { state.exportProgress == null }?.let { format ->
        val plain = state.activeExport?.isPlainText ?: format.plaintext
        PasswordDialog(
            title = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export_title, state.activeExport?.kind?.label ?: format.label),
            message = if (plain) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_plain_export_warning)
            else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_encrypted_export_prompt),
            confirmLabel = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_export),
            error = state.exportError,
            busy = state.busy,
            onConfirm = vm::confirmExport,
            onCancel = vm::cancelExport
        )
    }
    state.smartBackupPassword?.let { smart ->
        AlertDialog(
            onDismissRequest = vm::dismissSmartBackupPassword,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_040)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_041))
                    OutlinedTextField(
                        value = smart,
                        onValueChange = {},
                        readOnly = true,
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        label = { Text(stringResource(R.string.p17_backup_password)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    TextButton(
                        onClick = {
                            vm.copySecret(smart, backupPasswordCopyLabel)
                        }
                    ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_042)) }
                }
            },
            confirmButton = { TextButton(onClick = vm::dismissSmartBackupPassword) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_043)) } }
        )
    }

    if (state.restoreAsk) {
        AlertDialog(
            onDismissRequest = { if (!state.busy) vm.cancelFolderRestore() },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_044), style = MaterialTheme.typography.titleLarge) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_045))
                var restorePassword by remember(state.restoreAsk) { mutableStateOf("") }
                PasswordField(value = restorePassword, onValueChange = { restorePassword = it }, label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_046), enabled = !state.busy)
                state.restoreError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Button(onClick = { vm.confirmFolderRestore(restorePassword); restorePassword = "" }, enabled = restorePassword.isNotEmpty() && !state.busy, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_047)) }
            } },
            confirmButton = {},
            dismissButton = { TextButton(onClick = vm::cancelFolderRestore, enabled = !state.busy) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
    (state.importing as? ImportStage.NeedsBackupPassword)?.let { s ->
        PasswordDialog(
            title = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_041),
            message = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_backup_password_message),
            confirmLabel = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_047),
            error = s.error,
            busy = state.busy,
            onConfirm = vm::submitBackupPassword,
            onCancel = vm::cancelImport
        )
    }
}

private enum class BackupTab(@androidx.annotation.StringRes val label: Int) { AUTO(R.string.bk_tab_auto), RESTORE(R.string.bk_tab_restore), EXPORT(R.string.bk_tab_export) }

/** Card with a bold title, a small info icon that reveals the long explanation, and the content below. */
@Composable
private fun InfoCard(title: String, info: String, content: @Composable () -> Unit) {
    var showInfo by rememberSaveable(title) { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                IconButton(onClick = { showInfo = !showInfo }) { Icon(Icons.Default.Info, contentDescription = stringResource(R.string.bk_info)) }
            }
            if (showInfo) Text(info, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            content()
        }
    }
}

@Composable
private fun MainPane(state: BackupUiState, vm: BackupViewModel, onPick: () -> Unit, onPickMapped: () -> Unit, onContacts: () -> Unit, onChooseBackupFolder: () -> Unit) {
    // One calm page, three sections: Backup Status -> Restore -> Import / Export (no tabs).
    var importDialog by rememberSaveable { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(AppDimens.Medium),
        verticalArrangement = Arrangement.spacedBy(AppDimens.Medium)
    ) {
        // ── Backup Status ──
        InfoCard(stringResource(R.string.p16c_backup_status), stringResource(pro.babasitaram.vault.R.string.p17_backup_security_note)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(pro.babasitaram.vault.data.backup.AutoBackupManager.FINAL_NAME, style = MaterialTheme.typography.titleSmall)
                    Text(
                        if (state.lastAutoBackupAt > 0)
                            stringResource(pro.babasitaram.vault.R.string.p17_backup_last, DateFormat.getDateTimeInstance().format(Date(state.lastAutoBackupAt)))
                        else stringResource(R.string.p16c_backup_no_file),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        if (state.backupFolderUri.isBlank()) stringResource(R.string.p16c_backup_where)
                        else stringResource(pro.babasitaram.vault.R.string.p17_uses_selected_backup_folder),
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = state.autoBackupEnabled, onCheckedChange = vm::setAutoBackup)
            }
            Button(onClick = vm::backupNow, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.bk_now)) }
        }
        pro.babasitaram.vault.presentation.components.BackupFolderCard(
            folderUri = state.backupFolderUri, enabled = !state.busy, onChange = onChooseBackupFolder
        )

        // ── Restore ──
        if (state.noBackupFound) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(AppDimens.Large).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                    Icon(Icons.Default.Info, null, modifier = Modifier.size(AppDimens.EntryIcon), tint = MaterialTheme.colorScheme.primary)
                    Text(stringResource(R.string.bk_no_backup_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.bk_no_backup_body), style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { vm.dismissNoBackup(); vm.backupNow() }, enabled = !state.busy, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.bk_create_first)) }
                    TextButton(onClick = vm::dismissNoBackup) { Text(stringResource(R.string.p15_close)) }
                }
            }
        }
        InfoCard(stringResource(R.string.p16c_restore_section), stringResource(R.string.bk_restore_info)) {
            OutlinedButton(onClick = vm::startFolderRestore, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) {
                Text(stringResource(R.string.p16c_restore_from_backup))
            }
        }

        // ── Import / Export ──
        InfoCard(stringResource(R.string.p16c_ie_section), stringResource(R.string.bk_import_info)) {
            Button(onClick = { importDialog = true }, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Text(stringResource(R.string.p16c_import_data)) }
            OutlinedButton(onClick = vm::openExportOptions, modifier = Modifier.fillMaxWidth(), enabled = !state.busy) { Text(stringResource(R.string.p16c_export_data)) }
        }
    }

    if (importDialog) {
        AlertDialog(
            onDismissRequest = { importDialog = false },
            title = { Text(stringResource(R.string.p16c_import_dialog_title)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    // Each row keeps the existing, tested import path; only the entry point is unified.
                    OutlinedButton(onClick = { importDialog = false; onPickMapped() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p16c_import_fmt_csv)) }
                    OutlinedButton(onClick = { importDialog = false; onPick() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p16c_import_fmt_json)) }
                    OutlinedButton(onClick = { importDialog = false; onPick() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p16c_import_fmt_vcard)) }
                    OutlinedButton(onClick = { importDialog = false; onContacts() }, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.p16c_import_fmt_contacts)) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { importDialog = false }) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun ReviewPane(review: ImportStage.Review, vm: BackupViewModel) {
    val p = review.preview
    Column(Modifier.fillMaxSize()) {
        Column(Modifier.padding(horizontal = AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
            Text(p.format.label, style = MaterialTheme.typography.titleSmall)
            Text(
                stringResource(R.string.p18_backup_preview_counts, p.newCount, p.duplicateCount) +
                    if (p.skippedRows > 0) L.s(R.string.p18_backup_row_s_skipped, p.skippedRows) else "",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                ImportMode.values().forEach { m ->
                    FilterChip(
                        selected = review.mode == m,
                        onClick = { vm.setImportMode(m) },
                        label = { Text(if (m == ImportMode.MERGE) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_merge) else androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_replace)) }
                    )
                }
            }
            Text(
                if (review.mode == ImportMode.MERGE) stringResource(R.string.p18_backup_merge_your_current_entries_stay)
                else stringResource(R.string.p18_backup_replace_every_current_entry_moves),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (p.duplicateCount > 0 && review.mode == ImportMode.MERGE) {
                Row(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xxs), verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.SKIP) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_062)) }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.REPLACE) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_063)) }
                    TextButton(onClick = { vm.setAllDuplicates(DuplicateAction.KEEP_BOTH) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_064)) }
                }
                Row(Modifier.clickable { vm.setApplyToAll(!review.applyToAll) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = review.applyToAll, onCheckedChange = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_065), modifier = Modifier.padding(start = AppDimens.Xs), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        HorizontalDivider()
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(p.items, key = { index, _ -> index }) { index, item ->
                Column(Modifier.fillMaxWidth().padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xs)) {
                    Text(item.entry.title, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        listOf(item.entry.username.ifEmpty { item.entry.mobile }, item.entry.url).filter { it.isNotEmpty() }.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (item.duplicateOf != null && review.mode == ImportMode.MERGE) {
                        val action = review.actions[index] ?: DuplicateAction.SKIP
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_066), style = MaterialTheme.typography.labelSmall)
                        Column(Modifier.selectableGroup()) {
                            DuplicateAction.values().forEach { a ->
                                Row(
                                    Modifier.fillMaxWidth().selectable(
                                        selected = action == a,
                                        onClick = { vm.setAction(index, a) },
                                        role = Role.RadioButton
                                    ).padding(vertical = AppDimens.Xxs),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(selected = action == a, onClick = null)
                                    Text(
                                        when (a) { DuplicateAction.SKIP -> stringResource(R.string.b5_backup_skip); DuplicateAction.REPLACE -> stringResource(R.string.b5_backup_replace_existing); DuplicateAction.KEEP_BOTH -> stringResource(R.string.b5_backup_keep_both) },
                                        modifier = Modifier.padding(start = AppDimens.Xs)
                                    )
                                }
                            }
                        }
                    } else {
                        Text(stringResource(R.string.p15_new), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
                HorizontalDivider()
            }
        }
        Row(Modifier.fillMaxWidth().padding(AppDimens.Medium), horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text(stringResource(R.string.p15_cancel)) }
            Button(onClick = vm::askConfirmImport, Modifier.weight(1f)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056)) }
        }
    }
    if (review.confirm) {
        AlertDialog(
            onDismissRequest = vm::dismissConfirmImport,
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_import_entries_count, p.items.size)) },
            text = {
                Text(
                    stringResource(R.string.p18_backup_entries_found, p.items.size, p.newCount, p.duplicateCount) +
                        if (review.mode == ImportMode.REPLACE) stringResource(R.string.p18_backup_all_current_entries_will_first) else ""
                )
            },
            confirmButton = { TextButton(onClick = vm::confirmImport) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_056)) } },
            dismissButton = { TextButton(onClick = vm::dismissConfirmImport) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun MapPane(s: ImportStage.MapFields, vm: BackupViewModel) {
    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f).padding(horizontal = AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
            item {
                Text(
                    stringResource(R.string.p18_backup_match_each_bsrpro_field_to),
                    style = MaterialTheme.typography.bodySmall
                )
            }
            items(MapField.values().toList(), key = { it.name  }, contentType = { "item" }) { f -> ColumnPicker(f, s, vm) }
            item {
                Row(Modifier.clickable { vm.setSaveTemplate(!s.saveTemplate) }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = s.saveTemplate, onCheckedChange = null)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_067), modifier = Modifier.padding(start = AppDimens.Xs))
                }
            }
            s.error?.let { item { Text(it, color = MaterialTheme.colorScheme.error) } }
        }
        Row(Modifier.fillMaxWidth().padding(AppDimens.Medium), horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
            OutlinedButton(onClick = vm::cancelImport, Modifier.weight(1f)) { Text(stringResource(R.string.p15_cancel)) }
            Button(onClick = vm::confirmMapping, Modifier.weight(1f)) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_068)) }
        }
    }
}

@Composable
private fun ColumnPicker(f: MapField, s: ImportStage.MapFields, vm: BackupViewModel) {
    var open by remember { mutableStateOf(false) }
    val idx = s.mapping[f]
    val secret = f == MapField.PASSWORD || f == MapField.TOTP || f == MapField.APP_PIN
    Column {
        Text(f.label, style = MaterialTheme.typography.labelLarge)
        Box {
            OutlinedButton(onClick = { open = true }, Modifier.fillMaxWidth()) {
                Text(if (idx == null) androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_069) else s.headers.getOrElse(idx) { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, idx + 1) }.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, idx + 1) })
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                DropdownMenuItem(text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_069)) }, onClick = { open = false; vm.setColumn(f, null) })
                s.headers.forEachIndexed { i, h ->
                    DropdownMenuItem(text = { Text(h.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_column, i + 1) }) }, onClick = { open = false; vm.setColumn(f, i) })
                }
            }
        }
        if (idx != null) {
            val value = s.sample.getOrNull(idx).orEmpty()
            if (value.isNotEmpty()) Text(
                stringResource(R.string.b5_backup_example) + " " + if (secret) stringResource(R.string.b5_backup_secret_mask) else value.take(40),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ExportOptionsDialog(
    o: ExportOptions,
    onChange: ((ExportOptions) -> ExportOptions) -> Unit,
    onContinue: () -> Unit,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_070)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_071), style = MaterialTheme.typography.bodySmall)
                OptionCheck(stringResource(R.string.b5_backup_cards), o.includeCards) { v -> onChange { it.copy(includeCards = v) } }
                OptionCheck(stringResource(R.string.b5_backup_notes), o.includeNotes) { v -> onChange { it.copy(includeNotes = v) } }
                OptionCheck(stringResource(R.string.b5_backup_identities), o.includeIdentities) { v -> onChange { it.copy(includeIdentities = v) } }
                OptionCheck(stringResource(R.string.b5_backup_app_logins), o.includeAppLogins) { v -> onChange { it.copy(includeAppLogins = v) } }
                OptionCheck(stringResource(R.string.b5_backup_mobiles), o.includeMobiles) { v -> onChange { it.copy(includeMobiles = v) } }
                OptionCheck(stringResource(R.string.b5_backup_totp), o.includeTotp) { v -> onChange { it.copy(includeTotp = v) } }
                OptionCheck(stringResource(R.string.b5_backup_attachments), o.includeAttachments) { v -> onChange { it.copy(includeAttachments = v) } }
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_072), style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = AppDimens.Xs))
                ExportKind.values().forEach { k ->
                    Row(
                        Modifier.fillMaxWidth().selectable(selected = o.kind == k, onClick = { onChange { it.copy(kind = k) } }, role = Role.RadioButton).padding(vertical = AppDimens.Xxs),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = o.kind == k, onClick = null)
                        Text(k.label, modifier = Modifier.padding(start = AppDimens.Xs))
                    }
                }
                if (o.kind == ExportKind.CSV) {
                    OptionCheck(stringResource(R.string.b5_backup_encrypt_csv), o.encrypt) { v -> onChange { it.copy(encrypt = v) } }
                }
                Text(
                    when {
                        o.kind == ExportKind.VAULT -> stringResource(R.string.b5_backup_vault_note)
                        o.kind == ExportKind.CSV && o.encrypt -> stringResource(R.string.b5_backup_csv_note)
                        else -> stringResource(R.string.b5_backup_plain_note)
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (o.isPlainText) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = AppDimens.Xs)
                )
            }
        },
        confirmButton = { TextButton(onClick = onContinue) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_073)) } },
        dismissButton = { TextButton(onClick = onCancel) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun OptionCheck(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = AppDimens.Xxs), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = null)
        Text(label, modifier = Modifier.padding(start = AppDimens.Xs))
    }
}

@Composable
internal fun PasswordDialog(
    title: String,
    message: String,
    confirmLabel: String,
    error: String?,
    busy: Boolean,
    onConfirm: (String) -> Unit,
    onCancel: () -> Unit
) {
    var pw by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { if (!busy) onCancel() },
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                Text(message, style = MaterialTheme.typography.bodyMedium)
                PasswordField(value = pw, onValueChange = { pw = it }, label = androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_074), enabled = !busy)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(pw); pw = "" }, enabled = pw.isNotEmpty() && !busy) { Text(confirmLabel) } },
        dismissButton = { TextButton(onClick = onCancel, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}
