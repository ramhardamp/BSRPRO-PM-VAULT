@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.history

import pro.babasitaram.vault.R

import pro.babasitaram.vault.presentation.components.AppScreenState
import pro.babasitaram.vault.presentation.components.AppHeadingText
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.DateFormat
import java.util.Date
import pro.babasitaram.vault.core.model.PasswordHistoryItem
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.components.AppEmptyState
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.core.util.L

/** Phase16G Batch6 migration: tokenized UI, Hilt ViewModel reuse, state contract, dark-mode and accessibility semantics. */
@Composable
fun HistoryScreen(
    onBack: () -> Unit = {},
    loading: Boolean = false,
    errorMessage: String? = null,
    onRetry: () -> Unit = {},
    vm: HistoryViewModel = hiltViewModel()
) {
    val entries by vm.entries.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current
    val filter by vm.filterState.collectAsStateWithLifecycle()
    var selected by remember { mutableStateOf<Pair<VaultEntry, PasswordHistoryItem>?>(null) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    Scaffold(topBar = { TopAppBar(title = { AppHeadingText(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_137)) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }) }) { padding ->
        AppScreenState(loading = loading, errorMessage = errorMessage, onRetry = onRetry) {
        Column(Modifier.fillMaxSize().padding(padding).focusGroup()) {
            Row(Modifier.fillMaxWidth().padding(AppDimens.ScreenHorizontal), horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                HistoryViewModel.Filter.values().forEach { item ->
                    FilterChip(selected = filter == item, onClick = { vm.setFilter(item) }, label = { Text(item.name.lowercase().replaceFirstChar { it.uppercase() }) })
                }
            }
            if (entries.isEmpty()) {
                AppEmptyState(stringResource(R.string.p18_history_no_history_yet), stringResource(R.string.p18_history_password_changes_and_entry_edits), Modifier.fillMaxWidth())
            } else {
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = AppDimens.ScreenHorizontal), verticalArrangement = Arrangement.spacedBy(AppDimens.ItemSpacing)) {
                    items(entries, key = { it.id  }, contentType = { "item" }) { entry ->
                        HistoryItem(entry, onView = { h -> selected = entry to h }, onCopy = { h -> vm.copy(h.pw, L.s(R.string.p17_loc_141)) })
                    }
                }
            }
        }
    
        }}
    selected?.let { (entry, history) ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_138)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(entry.title.ifBlank { stringResource(pro.babasitaram.vault.R.string.p17_untitled) }, style = MaterialTheme.typography.titleMedium)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_history_changed, DateFormat.getDateTimeInstance().format(Date(history.changedAt))))
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_139))
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.restorePassword(entry, history.pw)
                    selected = null
                }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_140)) }
            },
            dismissButton = { TextButton(onClick = { selected = null; vm.copy(history.pw, context.getString(pro.babasitaram.vault.R.string.p17_loc_141)) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_142)) } }
        )
    }
}

@Composable
private fun HistoryItem(entry: VaultEntry, onView: (PasswordHistoryItem) -> Unit, onCopy: (PasswordHistoryItem) -> Unit) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
            Text(entry.title.ifBlank { stringResource(pro.babasitaram.vault.R.string.p17_untitled) }, style = MaterialTheme.typography.titleMedium)
            entry.passwordHistory.take(5).forEach { history ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(DateFormat.getDateTimeInstance().format(Date(history.changedAt)), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row {
                        TextButton(onClick = { onView(history) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_138)) }
                        TextButton(onClick = { onCopy(history) }) { Text(stringResource(R.string.p15_copy)) }
                    }
                }
            }
            if (entry.editHistory.isNotEmpty()) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_history_edit_count, entry.editHistory.size), style = MaterialTheme.typography.bodySmall)
        }
    }
}
