package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector

/** Shared snackbar variants defined by the UI specification. */
enum class AppSnackbarVariant { INFO, SUCCESS, WARNING, ERROR }

data class AppSnackbarData(
    val message: String,
    val variant: AppSnackbarVariant,
    val actionLabel: String? = null,
    val onAction: (() -> Unit)? = null
)

class AppSnackbarHostState {
    var current by mutableStateOf<AppSnackbarData?>(null)
        private set

    fun showSnackbar(
        message: String,
        variant: AppSnackbarVariant = AppSnackbarVariant.INFO,
        actionLabel: String? = null,
        onAction: (() -> Unit)? = null
    ) {
        current = AppSnackbarData(message, variant, actionLabel, onAction)
    }

    fun dismiss() {
        current = null
    }
}

@Composable
fun rememberAppSnackbarHostState(): AppSnackbarHostState = remember { AppSnackbarHostState() }

/** Shared snackbar host/helper surface with 12dp radius, spec §2.10. */
@Composable
fun AppSnackbarHost(
    state: AppSnackbarHostState,
    modifier: Modifier = Modifier
) {
    val data = state.current ?: return
    val icon: ImageVector = when (data.variant) {
        AppSnackbarVariant.INFO -> Icons.Default.Info
        AppSnackbarVariant.SUCCESS -> Icons.Default.CheckCircle
        AppSnackbarVariant.WARNING -> Icons.Default.Warning
        AppSnackbarVariant.ERROR -> Icons.Default.Error
    }
    Snackbar(
        modifier = modifier.padding(AppDimens.Medium),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(AppShapes.Medium),
        containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
        contentColor = MaterialTheme.colorScheme.onSurface,
        action = data.actionLabel?.let { label ->
            { androidx.compose.material3.TextButton(onClick = { data.onAction?.invoke(); state.dismiss() }) { Text(label) } }
        }
    ) {
        androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Icon(icon, contentDescription = null, modifier = Modifier.padding(end = AppDimens.Xs))
            Text(data.message)
        }
    }
}

fun AppSnackbarHostState.showInfo(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) =
    showSnackbar(message, AppSnackbarVariant.INFO, actionLabel, onAction)

fun AppSnackbarHostState.showSuccess(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) =
    showSnackbar(message, AppSnackbarVariant.SUCCESS, actionLabel, onAction)

fun AppSnackbarHostState.showWarning(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) =
    showSnackbar(message, AppSnackbarVariant.WARNING, actionLabel, onAction)

fun AppSnackbarHostState.showError(message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) =
    showSnackbar(message, AppSnackbarVariant.ERROR, actionLabel, onAction)
