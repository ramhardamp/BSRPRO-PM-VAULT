package pro.babasitaram.vault.presentation.settings

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Spacer
import pro.babasitaram.vault.presentation.components.PasswordField
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import pro.babasitaram.vault.R
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppShapes
import pro.babasitaram.vault.presentation.components.AnimatedListItem
import pro.babasitaram.vault.presentation.components.AppErrorState
import pro.babasitaram.vault.presentation.components.AppLoadingState
import pro.babasitaram.vault.presentation.components.AppEmptyState
import androidx.compose.ui.res.stringResource
import pro.babasitaram.vault.core.constants.AppLinks
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.foundation.background
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.focusGroup
import androidx.compose.foundation.focusable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.LifecycleResumeEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import pro.babasitaram.vault.BuildConfig
import pro.babasitaram.vault.autofill.AutofillStatus
import pro.babasitaram.vault.core.model.AppIconColor
import pro.babasitaram.vault.core.model.ThemeMode
import pro.babasitaram.vault.core.model.VaultSettings
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import pro.babasitaram.vault.core.util.L

private val AUTO_LOCK = listOf(R.string.b5_settings_never to VaultSettings.AUTO_LOCK_NEVER, R.string.b5_settings_30_seconds to 30, R.string.b5_settings_1_minute to 60, R.string.b5_settings_5_minutes to 300, R.string.b5_settings_15_minutes to 900)
private val LOCKOUT_ATTEMPTS = listOf(R.string.b5_settings_3_attempts to 3, R.string.b5_settings_5_attempts to 5, R.string.b5_settings_10_attempts to 10)
private val LOCKOUT_DURATION = listOf(R.string.b5_settings_30_seconds to 30, R.string.b5_settings_1_minute to 60, R.string.b5_settings_5_minutes to 300, R.string.b5_settings_15_minutes to 900)
private val CLIPBOARD = listOf(R.string.b5_settings_never to 0, R.string.b5_settings_15_minutes to 15, R.string.b5_settings_30_seconds to 30, R.string.b5_settings_60_seconds to 60)

@OptIn(ExperimentalMaterial3Api::class)
/** Spec §2.8 — tokenized settings hub and sections; existing SettingsViewModel and repository wiring are preserved. */
@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenBackup: () -> Unit, onOpenActivityLog: () -> Unit = {}, onOpenHidden: () -> Unit = {}, vm: SettingsViewModel = hiltViewModel()) {
    var category by remember { mutableStateOf<SettingsCategory?>(null) }
    var query by remember { mutableStateOf("") }
    BackHandler { if (category != null) category = null else onBack() }
    val s by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    CollectMessages(vm.messages)

    var autofillOn by remember { mutableStateOf(AutofillStatus.isEnabled(context)) }
    LifecycleResumeEffect(Unit) {
        autofillOn = AutofillStatus.isEnabled(context)
        onPauseOrDispose { }
    }

    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }
    var appPinConfigured by remember { mutableStateOf(false) }

    LaunchedEffect(dialog) {
        if (dialog == SettingsDialog.AppPin) appPinConfigured = vm.isAppPinConfigured()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(category?.title ?: R.string.settings_title), style = MaterialTheme.typography.titleLarge, modifier = Modifier.semantics { heading() }) },
                navigationIcon = { IconButton(onClick = { if (category != null) category = null else onBack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } }
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).focusGroup()) {
            val cat = category
            if (cat == null) {
                SettingsHub(query = query, onQuery = { query = it }, onOpen = { category = it; query = "" })
            } else when (cat) {
                SettingsCategory.SECURITY -> {
            ActionRow(stringResource(R.string.p17_loc_021), stringResource(R.string.p18_settings_re_encrypts_your_vault_the)) { dialog = SettingsDialog.ChangePassword }
            ChoiceRow(stringResource(R.string.b5_settings_vault_auto_lock), VAULT_SESSION, s.vaultSessionSeconds, vm::setVaultSession)
            ChoiceRow(stringResource(R.string.b5_settings_background_timeout), BACKGROUND_GRACE, s.backgroundGraceSeconds, vm::setBackgroundGrace)
            SwitchRow(stringResource(R.string.p18_settings_biometric_face_quick_unlock), stringResource(R.string.p18_settings_use_android_biometricprompt_with_dev), s.biometricEnabled) {
                context.findFragmentActivity()?.let(vm::toggleBiometric)
            }
            SwitchRow(stringResource(R.string.p18_settings_quick_autofill_session), stringResource(R.string.p18_settings_reuse_a_valid_vault_session), s.quickAutofillEnabled, vm::setQuickAutofill)
            SwitchRow(stringResource(R.string.p18_settings_sensitive_action_re_authentication), stringResource(R.string.p18_settings_ask_for_fresh_authentication_before), s.sensitiveActionReauth, vm::setSensitiveActionReauth)
            SwitchRow(stringResource(R.string.p18_settings_block_weak_passwords), stringResource(R.string.p18_settings_prevent_weak_login_passwords_from), s.blockWeakPasswords, vm::setBlockWeakPasswords)
            ActionRow(stringResource(R.string.p18_settings_entry_pins), stringResource(R.string.p18_settings_each_login_can_have_its)) { dialog = SettingsDialog.EntryPinInfo }
            ActionRow(stringResource(R.string.p18_common_app_pin), stringResource(R.string.p18_settings_one_4_6_digit_pin)) { dialog = SettingsDialog.AppPin }
            ActionRow(stringResource(R.string.emergency_recovery_key), stringResource(R.string.p18_settings_view_or_save_the_24)) { dialog = SettingsDialog.RecoveryKey }
            ChoiceRow(stringResource(R.string.b5_settings_clipboard_clear), CLIPBOARD, s.clipboardClearSeconds, vm::setClipboardClear)
                    ChoiceRow(stringResource(R.string.b5_settings_failed_attempts), LOCKOUT_ATTEMPTS, s.lockoutMaxAttempts, vm::setLockoutAttempts)
                    ChoiceRow(stringResource(R.string.b5_settings_lockout_duration), LOCKOUT_DURATION, s.lockoutSeconds, vm::setLockoutSeconds)
            SwitchRow(
                stringResource(R.string.p18_settings_allow_screenshots),
                if (s.allowScreenshots) stringResource(R.string.p18_settings_on_screenshots_and_screen_recording)
                else stringResource(R.string.p18_settings_off_secure_screenshots_and_screen),
                s.allowScreenshots,
                vm::setAllowScreenshots
            )
            SwitchRow(
                stringResource(R.string.p18_settings_hide_sensitive_recent_app_screenshot),
                stringResource(R.string.p18_settings_keeps_vault_content_out_of),
                s.hideSensitiveContentInRecents,
                vm::setHideSensitiveRecents
            )
            Card(Modifier.fillMaxWidth().padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xxs)) {
                Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_001), style = MaterialTheme.typography.titleMedium)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_device_model, android.os.Build.MANUFACTURER, android.os.Build.MODEL))
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_android_api, android.os.Build.VERSION.RELEASE, android.os.Build.VERSION.SDK_INT), style = MaterialTheme.typography.bodySmall)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_build_version, BuildConfig.VERSION_NAME), style = MaterialTheme.typography.bodySmall)
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_002), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = vm::lockDevice, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_003)) }
                }
            }
                }
                SettingsCategory.AUTOFILL -> {
            ActionRow(
                stringResource(R.string.p18_settings_autofill_service),
                if (autofillOn) stringResource(R.string.p18_settings_bsrpro_vault_is_your_autofill) else stringResource(R.string.p18_settings_off_tap_to_choose_bsrpro)
            ) {
                val primary = AutofillStatus.enableIntent(context)
                runCatching { context.startActivity(primary) }.onFailure { runCatching { context.startActivity(AutofillStatus.fallbackIntent()) } }
            }
            ActionRow(stringResource(R.string.p17_loc_027), stringResource(R.string.p18_settings_see_what_happened_on_the)) {
                dialog = SettingsDialog.AutofillDiagnostics
            }
            SwitchRow(stringResource(R.string.p18_settings_show_suggestions_above_the_keyboard), stringResource(R.string.p18_settings_inline_suggestions_android_11), s.autofillInline, vm::setAutofillInline)
            SwitchRow(stringResource(R.string.p18_settings_use_autofill_regex_rules), stringResource(R.string.p18_settings_match_an_entry_custom_field), s.autofillRegexEnabled, vm::setAutofillRegex)
            ActionRow(stringResource(R.string.p17_loc_008), if (s.autofillExcludedPackages.isEmpty()) stringResource(R.string.p17_loc_186) else L.s(R.string.p18_settings_packages_excluded, s.autofillExcludedPackages.size)) { dialog = SettingsDialog.ExcludedApps }
                    SwitchRow(stringResource(R.string.p18_settings_save_prompts), stringResource(R.string.p18_settings_offer_to_save_a_login), s.autofillSavePrompts, vm::setSavePrompts)
                }
                SettingsCategory.BACKUP -> {
                    SwitchRow(stringResource(R.string.p18_settings_auto_backup), stringResource(R.string.p18_settings_keeps_one_file_downloads_bsrpro), s.autoBackupEnabled, vm::setAutoBackup)
                    ActionRow(
                        stringResource(R.string.p18_settings_last_backup),
                        if (s.lastAutoBackupAt > 0) java.text.DateFormat.getDateTimeInstance().format(java.util.Date(s.lastAutoBackupAt)) else stringResource(R.string.p18_settings_no_backup_yet)
                    ) { }
                    ActionRow(stringResource(R.string.p15_back_up_now), stringResource(R.string.p18_settings_overwrites_bsrpro_vault_with_the)) { vm.backupNow() }
            ActionRow(stringResource(R.string.p18_settings_backup_folder_location), stringResource(R.string.p18_settings_downloads_bsrpro_backups_automatic_e)) { onOpenBackup() }
            ActionRow(stringResource(R.string.p17_loc_050), stringResource(R.string.p18_settings_open_backup_tools_to_select)) { onOpenBackup() }
            ActionRow(stringResource(R.string.p18_settings_export_encrypted_backup), stringResource(R.string.p18_settings_also_csv_and_json_exports)) { onOpenBackup() }
            ActionRow(stringResource(R.string.p18_settings_import_from_backup), ".Vault files") { onOpenBackup() }
            ActionRow(stringResource(R.string.p18_settings_import_from_csv), stringResource(R.string.p18_settings_chrome_bitwarden_lastpass_1password)) { onOpenBackup() }
                    ActionRow(stringResource(R.string.p18_settings_import_from_contacts), stringResource(R.string.p18_settings_choose_phone_contacts_to_save)) { onOpenBackup() }
                }
                SettingsCategory.INTERFACE -> {
            run {
                var language by remember { mutableStateOf(pro.babasitaram.vault.core.util.LocaleHelper.read(context)) }
                ChoiceRow(
                    stringResource(R.string.settings_language),
                    listOf(
                        R.string.settings_language_system to pro.babasitaram.vault.core.util.LocaleHelper.SYSTEM,
                        R.string.b5_settings_english to pro.babasitaram.vault.core.util.LocaleHelper.ENGLISH,
                        R.string.b5_settings_hindi to pro.babasitaram.vault.core.util.LocaleHelper.HINDI
                    ),
                    language
                ) { code ->
                    if (code != language) {
                        pro.babasitaram.vault.core.util.LocaleHelper.save(context, code)
                        language = code
                        context.findFragmentActivity()?.recreate()
                    }
                }
            }
            ChoiceRowText(stringResource(R.string.b5_settings_theme), ThemeMode.values().map { it.name.lowercase().replaceFirstChar(Char::uppercase) to it }, s.theme, vm::setTheme)
            ChoiceRowText(stringResource(R.string.b5_settings_app_icon_colour), AppIconColor.values().map { it.label to it }, s.appIcon, vm::setAppIcon)
            Column(Modifier.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xs)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_font_size, s.fontScalePercent), style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = s.fontScalePercent.toFloat(),
                    onValueChange = { vm.setFontScale(it.toInt()) },
                    valueRange = 80f..200f,
                    steps = 11
                )
            }
                    SwitchRow(stringResource(R.string.p18_settings_show_category_chips), stringResource(R.string.p18_settings_work_personal_banking_chips_on), s.showCategoryChips, vm::setShowCategoryChips)
                }
                SettingsCategory.GENERATOR -> {
            Column(Modifier.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xs)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_default_length, s.generatorDefaultLength), style = MaterialTheme.typography.bodyLarge)
                Slider(
                    value = s.generatorDefaultLength.toFloat(),
                    onValueChange = { vm.setGeneratorLength(it.toInt()) },
                    valueRange = 8f..256f
                )
                OutlinedTextField(
                    value = s.generatorKeyword,
                    onValueChange = vm::setGeneratorKeyword,
                    label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_004)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            SwitchRow(stringResource(R.string.p18_settings_exclude_similar_characters), stringResource(R.string.p18_settings_skips_i_l_1_o), s.generatorExcludeSimilar, vm::setExcludeSimilar)
                    SwitchRow(stringResource(R.string.p18_settings_lowercase_a_z), null, s.generatorLower) { vm.setGeneratorSets(lower = it) }
                    SwitchRow(stringResource(R.string.p18_settings_uppercase_a_z), null, s.generatorUpper) { vm.setGeneratorSets(upper = it) }
                    SwitchRow(stringResource(R.string.p18_settings_numbers_0_9), null, s.generatorDigits) { vm.setGeneratorSets(digits = it) }
                    SwitchRow(stringResource(R.string.p18_settings_symbols), stringResource(R.string.p18_settings_at_least_one_character_set), s.generatorSymbols) { vm.setGeneratorSets(symbols = it) }
                }
                SettingsCategory.ADVANCED -> {
                    ActionRow(stringResource(R.string.hidden_vault), stringResource(R.string.p18_settings_pin_protected_area_for_entries)) { onOpenHidden() }
            SwitchRow(stringResource(R.string.p18_settings_travel_mode), stringResource(R.string.p18_settings_disable_automatic_autofill_suggestio), s.travelMode, vm::setTravelMode)
            ActionRow(stringResource(R.string.p17_loc_089), if (s.emergencyEncryptedMaster.isNotBlank()) stringResource(R.string.p18_settings_configured_manage_recovery_from_the) else stringResource(R.string.p18_settings_create_a_24_character_recovery)) { if (s.emergencyEncryptedMaster.isBlank()) vm.setupEmergency() }
            if (s.emergencyEncryptedMaster.isNotBlank()) {
                ActionRow(stringResource(R.string.emergency_revoke), stringResource(R.string.p18_settings_deletes_the_encrypted_recovery_secre), danger = true) { vm.revokeEmergency() }
            }
            ActionRow(stringResource(R.string.p18_settings_activity_log), stringResource(R.string.p18_settings_local_history_of_security_actions)) { onOpenActivityLog() }
            ActionRow(stringResource(R.string.p18_settings_clear_recent_searches), null) { vm.clearRecentSearches() }
                    ActionRow(stringResource(R.string.p18_settings_reset_settings_to_defaults), stringResource(R.string.p18_settings_keeps_your_vault_recovery_key)) { dialog = SettingsDialog.ResetDefaults }
            ActionRow(stringResource(R.string.p18_settings_clear_all_data_reset_vault), stringResource(R.string.p18_settings_deletes_everything_on_this_device), danger = true) { dialog = SettingsDialog.Reset }
                }
                SettingsCategory.ABOUT -> {
                    ActionRow(stringResource(R.string.p18_settings_version), L.s(R.string.p18_settings_code, BuildConfig.VERSION_NAME, BuildConfig.VERSION_CODE)) { }
                    ActionRow(stringResource(R.string.p17_loc_177), AppLinks.DEVELOPER) { }
                    ActionRow(stringResource(R.string.p17_loc_131), AppLinks.WEBSITE) { openLink(context, AppLinks.WEBSITE) }
                    ActionRow(stringResource(R.string.p18_settings_github), AppLinks.GITHUB) { openLink(context, AppLinks.GITHUB) }
                    ActionRow(stringResource(R.string.p15_email), AppLinks.EMAIL) { openLink(context, "mailto:${AppLinks.EMAIL}") }
                    ActionRow(stringResource(R.string.p18_settings_license), stringResource(R.string.p18_settings_source_code_license)) { openLink(context, AppLinks.GITHUB_LICENSE) }
                    ActionRow(stringResource(R.string.p18_settings_changelog), null) { dialog = SettingsDialog.Changelog }
                    ActionRow(stringResource(R.string.p18_settings_privacy_policy), null) { dialog = SettingsDialog.Privacy }
                    ActionRow(stringResource(R.string.p18_settings_open_source_licenses), null) { dialog = SettingsDialog.Licenses }
                }
            }
        }
    }

    when (dialog) {
        SettingsDialog.ChangePassword -> ChangePasswordDialog(
            onSubmit = { o, n, c -> vm.changeMasterPassword(o, n, c) },
            onDone = { dialog = null }
        )
        SettingsDialog.Reset -> ResetDialog(
            onSubmit = { pw -> vm.resetVault(pw) },
            onDone = { dialog = null }
        )
        SettingsDialog.ResetDefaults -> androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_005)) },
            text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_006)) },
            confirmButton = { TextButton(onClick = { vm.resetToDefaults(); dialog = null }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_007)) } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(stringResource(R.string.p15_cancel)) } }
        )
        SettingsDialog.ExcludedApps -> ExcludedAppsDialog(
            current = s.autofillExcludedPackages,
            onSave = { vm.setExcludedPackages(it); dialog = null },
            onDone = { dialog = null }
        )
        SettingsDialog.AutofillDiagnostics -> AutofillDiagnosticsDialog(context) { dialog = null }
        SettingsDialog.AppPin -> AppPinDialog(
            configured = appPinConfigured,
            onSave = { master, pin, confirm -> vm.setAppPin(master, pin, confirm) },
            onRemove = { master -> vm.removeAppPin(master) },
            onDone = { dialog = null }
        )
        SettingsDialog.EntryPinInfo -> InfoDialog(
            stringResource(R.string.b5_settings_entry_pin_title),
            stringResource(R.string.b5_settings_entry_pin_body)
        ) { dialog = null }
        SettingsDialog.RecoveryKey -> {
            val recoveryKeyCopyLabel = stringResource(R.string.b5_settings_recovery_key_copy)
            RecoveryKeyDialog(
                keyLoader = { vm.recoveryKey() },
                onClose = { dialog = null },
                onCopy = { vm.copySecret(it, recoveryKeyCopyLabel) },
                context = context
            )
        }
        SettingsDialog.Changelog -> InfoDialog(stringResource(R.string.b5_settings_changelog), CHANGELOG) { dialog = null }
        SettingsDialog.Privacy -> InfoDialog(stringResource(R.string.b5_settings_privacy), PRIVACY) { dialog = null }
        SettingsDialog.Licenses -> InfoDialog(stringResource(R.string.b5_settings_licenses), LICENSES) { dialog = null }
        null -> Unit
    }
}

private enum class SettingsDialog {
    ExcludedApps, ChangePassword, Reset, ResetDefaults, Changelog, Privacy, Licenses, AutofillDiagnostics, AppPin, EntryPinInfo, RecoveryKey }

@Composable
private fun Section(title: String) {
    HorizontalDivider(Modifier.padding(top = AppDimens.Xs))
    Text(title, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = AppDimens.Medium, top = AppDimens.Medium, bottom = AppDimens.Xxs).semantics { heading() })
}

@Composable
private fun ActionRow(title: String, subtitle: String?, danger: Boolean = false, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = AppDimens.Medium, vertical = AppDimens.Small)) {
        Text(title, style = MaterialTheme.typography.bodyLarge, color = if (danger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Small), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun <T> ChoiceRow(title: String, options: List<Pair<Int, T>>, selected: T, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val labelRes = options.firstOrNull { it.second == selected }?.first
    val label = labelRes?.let { stringResource(it) } ?: stringResource(pro.babasitaram.vault.R.string.settings_custom)
    Column(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Small)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (name, value) ->
                DropdownMenuItem(text = { Text(stringResource(name)) }, onClick = { open = false; onSelect(value) })
            }
        }
    }
}
@Composable
private fun <T> ChoiceRowText(title: String, options: List<Pair<String, T>>, selected: T, onSelect: (T) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.second == selected }?.first ?: stringResource(R.string.settings_custom)
    Column(Modifier.fillMaxWidth().clickable { open = true }.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Small)) {
        Text(title, style = MaterialTheme.typography.bodyLarge)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (name, value) -> DropdownMenuItem(text = { Text(name) }, onClick = { open = false; onSelect(value) }) }
        }
    }
}


@Composable
private fun ExcludedAppsDialog(
    current: List<String>,
    onSave: (String) -> Unit,
    onDone: () -> Unit
) {
    var text by remember(current) { mutableStateOf(current.joinToString("\n")) }
    AlertDialog(
        onDismissRequest = onDone,
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_008)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_009))
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    minLines = 5,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_010)) }
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text(stringResource(R.string.p15_save)) } },
        dismissButton = { TextButton(onClick = onDone) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun InfoDialog(title: String, body: String, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState())) { Text(body, style = MaterialTheme.typography.bodyMedium) } },
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.p15_close)) } }
    )
}

@Composable
private fun PinInput(label: String, value: String, enabled: Boolean, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(6)) },
        label = { Text(label) },
        enabled = enabled,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun AppPinDialog(
    configured: Boolean,
    onSave: suspend (String, String, String) -> String?,
    onRemove: suspend (String) -> String?,
    onDone: () -> Unit
) {
    var master by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text(if (configured) stringResource(R.string.b5_settings_change_pin) else stringResource(R.string.b5_settings_set_pin), style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                Text(stringResource(R.string.p18_settings_one_4_6_digit_pin_2))
                PwField(stringResource(R.string.b5_settings_master_password), master, !busy) { master = it }
                PinInput(stringResource(R.string.b5_settings_new_pin), pin, !busy) { pin = it }
                PinInput(stringResource(R.string.b5_settings_confirm_pin), confirm, !busy) { confirm = it }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && master.isNotEmpty() && pin.length in 4..6 && confirm.length in 4..6,
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSave(master, pin, confirm)
                        busy = false
                        if (r == null) { master = ""; pin = ""; confirm = ""; onDone() } else error = r
                    }
                }
            ) { Text(if (configured) stringResource(R.string.b5_settings_change_pin) else stringResource(R.string.b5_settings_set_pin)) }
        },
        dismissButton = {
            Row {
                TextButton(
                    enabled = !busy && master.isNotEmpty(),
                    onClick = {
                        busy = true; error = null
                        scope.launch {
                            val r = onRemove(master)
                            busy = false
                            if (r == null) { master = ""; onDone() } else error = r
                        }
                    }
                ) { Text(stringResource(R.string.p15_remove)) }
                TextButton(onClick = onDone, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) }
            }
        }
    )
}

@Composable
private fun RecoveryKeyDialog(
    keyLoader: suspend () -> String?,
    onClose: () -> Unit,
    onCopy: (String) -> Unit,
    context: android.content.Context
) {
    var key by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    val pdfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null && key != null) {
            scope.launch {
                try {
                    RecoveryKeyPdf.write(context, uri, key!!)
                } catch (ce: kotlinx.coroutines.CancellationException) {
                    throw ce
                } catch (e: Exception) {
                    error = L.s(R.string.p20_pdf_failed, e.message ?: L.s(R.string.p20_write_failed))
                }
            }
        }
    }

    LaunchedEffect(Unit) {
        key = keyLoader()
        loading = false
    }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_014)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                when {
                    loading -> Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_015))
                    key == null -> Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_016), color = MaterialTheme.colorScheme.error)
                    else -> {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_017))
                        Card(Modifier.fillMaxWidth()) {
                            Text(
                                key!!,
                                modifier = Modifier.padding(AppDimens.Medium),
                                style = MaterialTheme.typography.titleMedium
                            )
                        }
                        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = key != null, onClick = {
                key?.let(onCopy)
            }) { Text(stringResource(R.string.p15_copy)) }
        },
        dismissButton = {
            Row {
                TextButton(enabled = key != null, onClick = { pdfLauncher.launch(context.getString(pro.babasitaram.vault.R.string.p17_loc_018)) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_019)) }
                TextButton(enabled = key != null, onClick = { printRecoveryKey(context, key!!) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_020)) }
                TextButton(onClick = onClose) { Text(stringResource(R.string.p15_close)) }
            }
        }
    )
}

@Composable
private fun ChangePasswordDialog(onSubmit: suspend (String, String, String) -> String?, onDone: () -> Unit) {
    var old by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_021), style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                PwField(stringResource(R.string.b5_settings_current_password), old, !busy) { old = it }
                PwField(stringResource(R.string.b5_settings_new_password), new, !busy) { new = it }
                PwField(stringResource(R.string.b5_settings_confirm_new_password), confirm, !busy) { confirm = it }
                if (busy) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_022), style = MaterialTheme.typography.bodySmall)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && old.isNotEmpty() && new.isNotEmpty() && confirm.isNotEmpty(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSubmit(old, new, confirm)
                        busy = false
                        if (r == null) { old = ""; new = ""; confirm = ""; onDone() } else error = r
                    }
                }
            ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_023)) }
        },
        dismissButton = { TextButton(onClick = onDone, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun ResetDialog(onSubmit: suspend (String) -> String?, onDone: () -> Unit) {
    var pw by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    AlertDialog(
        onDismissRequest = { if (!busy) onDone() },
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_024), style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_025))
                PwField(stringResource(R.string.b5_settings_master_password), pw, !busy) { pw = it }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !busy && pw.isNotEmpty(),
                onClick = {
                    busy = true; error = null
                    scope.launch {
                        val r = onSubmit(pw)
                        busy = false
                        if (r == null) { pw = ""; onDone() } else error = r
                    }
                }
            ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_026), color = MaterialTheme.colorScheme.error) }
        },
        dismissButton = { TextButton(onClick = onDone, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
    )
}

@Composable
private fun PwField(label: String, value: String, enabled: Boolean, onChange: (String) -> Unit) {
    PasswordField(value = value, onValueChange = onChange, label = label, enabled = enabled)
}

private const val CHANGELOG = """0.2.12
• Save works for entries made with the Android app picker: title is filled from the app name or website
• Validation message is shown at the top of the form; website is optional for native apps
• Native autofill: after unlock the login is filled directly (dataset authentication) or you pick one
• More diagnostics for the unlock step (adb logcat -s BSRPROAutofill)

0.2.1
• Autofill diagnostics, compatibility mode for Chrome and other browsers
• Real BSRPRO app icon, eye icon on every password field, edit history, import options as radio buttons

0.2.0
• Autofill service with inline suggestions, biometric unlock and "save password" prompt
• Settings screen
• Encrypted .Vault backup, CSV / JSON export, import from Chrome, Bitwarden, LastPass, 1Password, Dashlane, KeePass, Firefox, generic CSV and vCard
• Daily auto-backup
• One-time codes (TOTP) with a live countdown, also offered by autofill

0.1.0
• Vault, lock screen, biometric unlock, generator, entry editor"""

private const val PRIVACY = """BSRPRO Vault keeps your passwords only on this device, encrypted with a key derived from your master password (PBKDF2-HMAC-SHA256, 600,000 iterations, AES-256-GCM).

The app is offline-first. Normal vault storage does not upload your data. An optional password-breach check sends only the first 5 characters of a SHA-1 password hash to the Pwned Passwords range service; the full password and full hash are not sent.

Your master password is never stored as plaintext. When biometric quick unlock is enabled, a sealed credential is encrypted by an authentication-protected key in the Android Keystore.

Backups and exports are written only where you choose (or to Downloads/BSRPRO_Backups if you enable auto-backup). Plain CSV / JSON exports are not encrypted, so keep them safe or delete them."""

private const val LICENSES = """Kotlin, kotlinx.coroutines, kotlinx.serialization — Apache License 2.0
AndroidX (Core, Activity, Lifecycle, Navigation, Room, DataStore, WorkManager, Biometric, Autofill, Security) and Jetpack Compose — Apache License 2.0
Dagger Hilt — Apache License 2.0
Google Tink — Apache License 2.0
ZXing core — Apache License 2.0
Coil — Apache License 2.0
Timber — Apache License 2.0"""

@Composable
private fun AutofillDiagnosticsDialog(context: android.content.Context, onClose: () -> Unit) {
    val lines = remember { pro.babasitaram.vault.autofill.AutofillDiagnostics.snapshot() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_027), style = MaterialTheme.typography.titleLarge) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "Autofill: " + (if (AutofillStatus.isEnabled(context)) "BSRPRO is the selected service" else "BSRPRO is NOT the selected service") +
                        "\nVersion: " + pro.babasitaram.vault.BuildConfig.VERSION_NAME,
                    style = MaterialTheme.typography.labelMedium
                )
                Spacer(Modifier.height(AppDimens.Xs))
                if (lines.isEmpty()) {
                    Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_028))
                } else {
                    lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text(stringResource(R.string.p15_close)) } },
        dismissButton = {
            TextButton(onClick = {
                val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText(context.getString(pro.babasitaram.vault.R.string.p17_loc_029), pro.babasitaram.vault.autofill.AutofillDiagnostics.report()))
            }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_030)) }
        }
    )
}


private val VAULT_SESSION: List<Pair<Int, Int>> = listOf(
    R.string.b5_settings_5_minutes to 5 * 60,
    R.string.b5_settings_15_minutes to 15 * 60,
    R.string.b5_settings_30_minutes to 30 * 60,
    R.string.b5_settings_1_hour to 60 * 60,
    R.string.b5_settings_4_hours to 4 * 60 * 60,
    R.string.b5_settings_12_hours to 12 * 60 * 60,
    R.string.b5_settings_24_hours to 24 * 60 * 60,
    R.string.b5_settings_manual_lock to pro.babasitaram.vault.core.model.VaultSettings.AUTO_LOCK_NEVER
)

private val BACKGROUND_GRACE: List<Pair<Int, Int>> = listOf(
    R.string.b5_settings_5_minutes to 5 * 60,
    R.string.b5_settings_15_minutes to 15 * 60,
    R.string.b5_settings_30_minutes to 30 * 60,
    R.string.b5_settings_1_hour to 60 * 60,
    R.string.b5_settings_4_hours to 4 * 60 * 60
)

private enum class SettingsCategory(
    @androidx.annotation.StringRes val title: Int,
    @androidx.annotation.StringRes val subtitle: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    SECURITY(R.string.settings_cat_security, R.string.settings_cat_security_sub, Icons.Default.Lock),
    AUTOFILL(R.string.settings_cat_autofill, R.string.settings_cat_autofill_sub, Icons.Default.AutoAwesome),
    BACKUP(R.string.settings_cat_backup, R.string.settings_cat_backup_sub, Icons.Default.Backup),
    INTERFACE(R.string.settings_cat_interface, R.string.settings_cat_interface_sub, Icons.Default.Palette),
    GENERATOR(R.string.settings_cat_generator, R.string.settings_cat_generator_sub, Icons.Default.Key),
    ADVANCED(R.string.settings_cat_advanced, R.string.settings_cat_advanced_sub, Icons.Default.Settings),
    ABOUT(R.string.settings_cat_about, R.string.settings_cat_about_sub, Icons.Default.Info)
}

/** Searchable index: setting title → the category that contains it. */
private val SETTINGS_INDEX: List<Pair<String, SettingsCategory>> = listOf(
    "Change master password" to SettingsCategory.SECURITY,
    "Vault auto-lock" to SettingsCategory.SECURITY, "Background timeout" to SettingsCategory.SECURITY,
    "Biometric / face quick unlock" to SettingsCategory.SECURITY, "Quick Autofill session" to SettingsCategory.SECURITY,
    "Sensitive action re-authentication" to SettingsCategory.SECURITY,
    "Block weak passwords" to SettingsCategory.SECURITY, "App PIN" to SettingsCategory.SECURITY, "Entry PINs" to SettingsCategory.SECURITY,
    "Recovery key" to SettingsCategory.SECURITY, "Clipboard auto-clear" to SettingsCategory.SECURITY,
    "Allow screenshots" to SettingsCategory.SECURITY, "Hide sensitive recent-app screenshots" to SettingsCategory.SECURITY,
    "Lock vault now" to SettingsCategory.SECURITY,
    "Autofill service" to SettingsCategory.AUTOFILL, "Autofill diagnostics" to SettingsCategory.AUTOFILL,
    "Show suggestions above the keyboard" to SettingsCategory.AUTOFILL, "Autofill regex rules" to SettingsCategory.AUTOFILL,
    "Excluded apps" to SettingsCategory.AUTOFILL, "Save prompts" to SettingsCategory.AUTOFILL,
    "Auto-backup" to SettingsCategory.BACKUP, "Last backup" to SettingsCategory.BACKUP, "Back up now" to SettingsCategory.BACKUP,
    "Backup folder location" to SettingsCategory.BACKUP, "Restore from backup folder" to SettingsCategory.BACKUP,
    "Export encrypted backup" to SettingsCategory.BACKUP, "Import from backup" to SettingsCategory.BACKUP,
    "Import from CSV" to SettingsCategory.BACKUP, "Import from contacts" to SettingsCategory.BACKUP,
    "Theme dark light system" to SettingsCategory.INTERFACE, "App icon colour" to SettingsCategory.INTERFACE,
    "App font size" to SettingsCategory.INTERFACE, "Show category chips" to SettingsCategory.INTERFACE,
    "Default length" to SettingsCategory.GENERATOR, "Custom keyword prefix" to SettingsCategory.GENERATOR,
    "Exclude similar characters" to SettingsCategory.GENERATOR, "Lowercase uppercase numbers symbols" to SettingsCategory.GENERATOR,
    "Failed attempts before lockout duration" to SettingsCategory.SECURITY, "Language hindi english" to SettingsCategory.INTERFACE,
    "Travel mode" to SettingsCategory.ADVANCED, "Emergency access" to SettingsCategory.ADVANCED,
    "Activity log" to SettingsCategory.ADVANCED, "Clear recent searches" to SettingsCategory.ADVANCED,
    "Reset settings to defaults" to SettingsCategory.ADVANCED, "Clear all data reset vault" to SettingsCategory.ADVANCED,
    "Version" to SettingsCategory.ABOUT, "Developer" to SettingsCategory.ABOUT, "Website" to SettingsCategory.ABOUT,
    "GitHub" to SettingsCategory.ABOUT, "Email" to SettingsCategory.ABOUT, "License" to SettingsCategory.ABOUT,
    "Changelog" to SettingsCategory.ABOUT, "Privacy policy" to SettingsCategory.ABOUT
)

@Composable
private fun SettingsHub(query: String, onQuery: (String) -> Unit, onOpen: (SettingsCategory) -> Unit) {
    OutlinedTextField(
        value = query,
        onValueChange = onQuery,
        placeholder = { Text(stringResource(R.string.settings_search)) },
        label = { Text(stringResource(R.string.settings_search)) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth().padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xs)
    )
    val q = query.trim()
    val ctx = androidx.compose.ui.platform.LocalContext.current
    if (q.isEmpty()) {
        SettingsCategory.values().forEach { c ->
            Row(
                Modifier.fillMaxWidth().clickable { onOpen(c) }.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(AppDimens.EntryIcon).clip(androidx.compose.foundation.shape.RoundedCornerShape(AppShapes.Medium)).background(MaterialTheme.colorScheme.primaryContainer),
                    contentAlignment = Alignment.Center
                ) { Icon(c.icon, contentDescription = stringResource(c.title), tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(AppDimens.Medium)) }
                Column(Modifier.weight(1f).padding(start = AppDimens.Medium)) {
                    Text(stringResource(c.title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(c.subtitle), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    } else {
        val hits = SETTINGS_INDEX.filter { it.first.contains(q, ignoreCase = true) || ctx.getString(it.second.title).contains(q, ignoreCase = true) }
        if (hits.isEmpty()) Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_no_settings_match_dynamic, q), modifier = Modifier.padding(AppDimens.Medium), color = MaterialTheme.colorScheme.onSurfaceVariant)
        hits.forEach { (_, c) ->
            ActionRow(ctx.getString(c.title), stringResource(R.string.b5_settings_in_category, ctx.getString(c.title))) { onOpen(c) }
        }
    }
}

private fun openLink(context: android.content.Context, url: String) {
    runCatching {
        context.startActivity(android.content.Intent(
            if (url.startsWith("mailto:")) android.content.Intent.ACTION_SENDTO else android.content.Intent.ACTION_VIEW,
            android.net.Uri.parse(url)
        ))
    }
}
