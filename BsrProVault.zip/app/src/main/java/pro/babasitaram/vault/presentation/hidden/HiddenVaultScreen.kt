@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.hidden

import pro.babasitaram.vault.presentation.components.AppDimens
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.R
import pro.babasitaram.vault.presentation.components.PasswordField
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

@Composable
fun HiddenVaultScreen(onBack: () -> Unit, onOpenEntry: (String) -> Unit, vm: HiddenVaultViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val entries by vm.entries.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current
    var pinDialog by remember { mutableStateOf(false) }
    BackHandler { onBack() }
    LaunchedEffect(state.message) {
        state.message?.let { android.widget.Toast.makeText(context, it, android.widget.Toast.LENGTH_SHORT).show(); vm.clearMessage() }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.hidden_vault), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } },
                actions = {
                    if (state.stage == HiddenStage.OPEN) {
                        TextButton(onClick = { pinDialog = true }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_075)) }
                        IconButton(onClick = vm::lock) { Icon(Icons.Default.Lock, "Lock hidden vault") }
                    }
                }
            )
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (state.stage) {
                HiddenStage.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                HiddenStage.SETUP -> SetupPane(state.error, onSave = vm::setupPin)
                HiddenStage.LOCKED -> UnlockPane(state.error, onUnlock = vm::unlock)
                HiddenStage.OPEN -> {
                    if (entries.isEmpty()) {
                        Column(Modifier.padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_076), style = MaterialTheme.typography.titleMedium)
                            Text(
                                stringResource(R.string.p18_hidden_vault_open_any_entry_s_editor) +
                                    stringResource(R.string.p18_hidden_vault_hidden_entries_are_still_included),
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(entries, key = { it.id  }, contentType = { "item" }) { e ->
                                Row(Modifier.fillMaxWidth().clickable { onOpenEntry(e.id) }.padding(horizontal = AppDimens.Medium, vertical = AppDimens.Xs), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(e.title.ifBlank { stringResource(pro.babasitaram.vault.R.string.p17_untitled) }, style = MaterialTheme.typography.bodyLarge)
                                        Text(
                                            listOf(e.username, e.url).filter { it.isNotBlank() }.joinToString(" · "),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    TextButton(onClick = { vm.unhide(e) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_077)) }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }
    if (pinDialog) {
        var newPin by remember { mutableStateOf("") }
        var master by remember { mutableStateOf("") }
        var pinError by remember { mutableStateOf<String?>(null) }
        var busy by remember { mutableStateOf(false) }
        val scope = rememberCoroutineScope()
        AlertDialog(
            onDismissRequest = { if (!busy) pinDialog = false },
            title = { Text(stringResource(R.string.p18_common_app_pin), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    Text(stringResource(R.string.p18_hidden_vault_this_pin_is_also_used))
                    PasswordField(master, { master = it }, stringResource(R.string.p17_loc_074), enabled = !busy)
                    PinField("New PIN (4–6 digits)", newPin) { newPin = it }
                    pinError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                    OutlinedButton(
                        enabled = !busy && master.isNotEmpty(),
                        onClick = {
                            busy = true; pinError = null
                            scope.launch {
                                val r = vm.removePin(master)
                                busy = false
                                if (r == null) pinDialog = false else pinError = r
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_080)) }
                }
            },
            confirmButton = {
                TextButton(
                    enabled = !busy && master.isNotEmpty() && newPin.length in 4..6,
                    onClick = {
                        busy = true; pinError = null
                        scope.launch {
                            val r = vm.changePin(master, newPin)
                            busy = false
                            if (r == null) pinDialog = false else pinError = r
                        }
                    }
                ) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_081)) }
            },
            dismissButton = { TextButton(onClick = { pinDialog = false }, enabled = !busy) { Text(stringResource(R.string.p15_cancel)) } }
        )
    }
}

@Composable
private fun SetupPane(error: String?, onSave: (String, String, String) -> Unit) {
    var master by remember { mutableStateOf("") }
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_082), style = MaterialTheme.typography.titleMedium)
        Text(
            stringResource(R.string.p18_hidden_vault_entries_you_hide_are_removed) +
                stringResource(R.string.p18_hidden_vault_it_is_the_same_app) +
                stringResource(R.string.p18_hidden_vault_if_you_forget_it_hidden),
            style = MaterialTheme.typography.bodyMedium
        )
        PasswordField(master, { master = it }, stringResource(R.string.p17_loc_074))
        PinField("PIN (4–6 digits)", pin) { pin = it }
        PinField("Confirm PIN", confirm) { confirm = it }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = { onSave(master, pin, confirm) }, enabled = master.isNotEmpty() && pin.length in 4..6, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_083)) }
    }
}

@Composable
private fun UnlockPane(error: String?, onUnlock: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(AppDimens.Large), verticalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_084), style = MaterialTheme.typography.titleMedium)
        PinField("PIN", pin) { pin = it }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(onClick = { onUnlock(pin); pin = "" }, enabled = pin.length in 4..6, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_085)) }
    }
}

@Composable
private fun PinField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { onChange(it.filter(Char::isDigit).take(6)) },
        label = { Text(label) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        modifier = Modifier.fillMaxWidth()
    )
}
