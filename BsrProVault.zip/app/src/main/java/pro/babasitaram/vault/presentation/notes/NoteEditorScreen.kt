@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.notes

import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.presentation.vault.CATEGORIES

@Composable
fun NoteEditorScreen(
    onDone: () -> Unit,
    vm: NoteEditorViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    BackHandler(enabled = !state.saving) { onDone() }
    val context = androidx.compose.ui.platform.LocalContext.current
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (state.existing == null) stringResource(pro.babasitaram.vault.R.string.p17_new_note) else stringResource(pro.babasitaram.vault.R.string.p17_edit_note), style = MaterialTheme.typography.titleLarge) },
                navigationIcon = {
                    IconButton(onClick = onDone, enabled = !state.saving) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037))
                    }
                },
                actions = {
                    Button(onClick = vm::save, enabled = !state.saving && !state.saved) { Text(stringResource(R.string.p15_save)) }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).padding(AppDimens.Medium),
            verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
        ) {
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            OutlinedTextField(
                value = state.title,
                onValueChange = vm::setTitle,
                label = { Text(stringResource(R.string.p15_title)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Row(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                OutlinedButton(onClick = { vm.insertToken(context.getString(pro.babasitaram.vault.R.string.p17_loc_133)) }) { Text("B") }
                OutlinedButton(onClick = { vm.insertToken(context.getString(pro.babasitaram.vault.R.string.p17_loc_134)) }) { Text("I") }
                OutlinedButton(onClick = { vm.insertToken(context.getString(pro.babasitaram.vault.R.string.p17_loc_135)) }) { Text("•") }
                OutlinedButton(onClick = { vm.insertToken("`code`") }) { Text(stringResource(R.string.notes_code)) }
                OutlinedButton(onClick = { vm.insertToken(context.getString(pro.babasitaram.vault.R.string.p17_loc_136)) }) { Text("H") }
            }
            OutlinedTextField(
                value = state.content,
                onValueChange = vm::setContent,
                label = { Text(stringResource(R.string.notes_content)) },
                minLines = 10,
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
            Text(stringResource(R.string.p15_category), style = MaterialTheme.typography.labelLarge)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                items(CATEGORIES) { category ->
                    FilterChip(
                        selected = state.category == category,
                        onClick = { vm.setCategory(category) },
                        label = { Text(category.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }
    }
}
