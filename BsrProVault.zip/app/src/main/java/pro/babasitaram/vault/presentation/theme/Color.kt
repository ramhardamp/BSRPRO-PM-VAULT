package pro.babasitaram.vault.presentation.theme

import androidx.compose.ui.graphics.Color

// BSRPRO UI specification — do not introduce screen-specific brand colors.
val BrandPrimary = Color(0xFF6C4CE0)
val BrandPrimaryContainer = Color(0xFFE8DEFF)
val BrandOnPrimary = Color(0xFFFFFFFF)
val BrandOnPrimaryContainer = Color(0xFF1A0066)
val BrandSecondary = Color(0xFF00B5A5)
val BrandSecondaryContainer = Color(0xFFC5F2ED)
val BrandOnSecondary = Color(0xFFFFFFFF)

val BrandLightBackground = Color(0xFFFDFBFF)
val BrandDarkBackground = Color(0xFF131318)
val BrandLightSurface = Color(0xFFFFFFFF)
val BrandDarkSurface = Color(0xFF1E1E24)
val BrandLightOnSurface = Color(0xFF1A1A1F)
val BrandDarkOnSurface = Color(0xFFE6E1E5)
val BrandOutline = Color(0xFFCAC4D0)

val BrandSuccess = Color(0xFF2E7D32)
val BrandWarning = Color(0xFFF57C00)
val BrandError = Color(0xFFBA1A1A)
val BrandInfo = Color(0xFF1976D2)

val CategoryVault = Color(0xFF1976D2)
val CategoryAppLogin = Color(0xFF6C4CE0)
val CategoryCards = Color(0xFFF57C00)
val CategoryIdentities = Color(0xFF00B5A5)
val CategoryNotes = Color(0xFFFFA000)
val CategoryTotp = Color(0xFF2E7D32)
val CategoryHealth = Color(0xFFBA1A1A)

// Compatibility aliases retained for existing code.
val AccentPurple = BrandPrimary
val AccentPurpleLight = BrandPrimary
val AccentOrange = BrandWarning
val DarkBackground = BrandDarkBackground
val DarkSurface = BrandDarkSurface
val LightBackground = BrandLightBackground
val LightSurface = BrandLightSurface
