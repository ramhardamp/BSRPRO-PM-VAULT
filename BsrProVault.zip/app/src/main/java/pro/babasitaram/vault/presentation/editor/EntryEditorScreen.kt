@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package pro.babasitaram.vault.presentation.editor

import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.activity.compose.BackHandler

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.LaunchedEffect
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import android.util.LruCache
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.focus.onFocusChanged
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.presentation.components.AppButton
import pro.babasitaram.vault.presentation.components.AppButtonVariant
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppPasswordField
import pro.babasitaram.vault.presentation.components.AppTextField
import pro.babasitaram.vault.presentation.vault.CATEGORIES
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import pro.babasitaram.vault.core.util.L

private fun modeLabelRes(mode: String) = when (mode) {
    "app" -> R.string.type_app_login
    "card" -> R.string.type_card
    "identity" -> R.string.type_identity
    "note" -> R.string.type_note
    else -> R.string.type_password
}
private object AppIconCache {
    val icons = LruCache<String, android.graphics.Bitmap>(64)
}

@Composable
fun EntryEditorScreen(onDone: () -> Unit, vm: EntryEditorViewModel = hiltViewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val form = state.form
    var confirmationVisible by remember { mutableStateOf(false) }
    val scroll = rememberScrollState()
    LaunchedEffect(state.error) { if (state.error != null) scroll.animateScrollTo(0) }
    LaunchedEffect(state.saved) {
        if (state.saved) { confirmationVisible = true; delay(SAVE_CONFIRMATION_DURATION_MS); if (confirmationVisible) { confirmationVisible = false; delay(220L); onDone() } }
    }
    BackHandler { if (!state.saving) onDone() }

    Scaffold(topBar = {
        TopAppBar(
            title = { Text(if (state.isEdit) stringResource(R.string.p17_edit_entry_title) else stringResource(R.string.p17_new_entry_title), modifier = Modifier.semantics { heading() }) },
            navigationIcon = { IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.common_back)) } },
            actions = { TextButton(onClick = vm::save, enabled = !state.saving && !state.saved) { Text(stringResource(R.string.p15_save)) } }
        )
    }) { padding ->
        Column(Modifier.padding(padding).fillMaxSize().verticalScroll(scroll).padding(AppDimens.ScreenHorizontal).focusGroup(), verticalArrangement = Arrangement.spacedBy(AppDimens.Medium)) {
            state.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.fillMaxWidth()) }
            if (confirmationVisible) Text(saveConfirmationLabel(state.isEdit), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.titleMedium)
            Text(L.s(R.string.p18_entry_editor_type, stringResource(modeLabelRes(state.mode))), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            AppTextField(value = form.title, onValueChange = { v -> vm.update { it.copy(title = v) } }, label = stringResource(if (state.mode == "app") R.string.p17_title_optional else R.string.p17_title))
            when (state.mode) {
                "login" -> {
                    AppTextField(form.url, { v -> vm.update { it.copy(url = v) } }, stringResource(R.string.p17_loc_131), keyboardType = KeyboardType.Uri)
                    AppTextField(form.username, { v -> vm.update { it.copy(username = v) } }, stringResource(R.string.p15_username), keyboardType = KeyboardType.Email)
                    AppPasswordField(form.password, { v -> vm.update { it.copy(password = v) } }, stringResource(R.string.type_password), showStrength = true, )
                }
                "app" -> {
                    AndroidAppPicker(form.appName, form.appPackage, { name, pkg -> vm.pickApp(name, pkg) }, { vm.update { it.copy(appName = "", appPackage = "") } })
                    AppTextField(form.username, { v -> vm.update { it.copy(username = v) } }, stringResource(R.string.p17_loc_162))
                    AppPasswordField(form.password, { v -> vm.update { it.copy(password = v) } }, stringResource(R.string.type_password), showStrength = true, )
                    AppPasswordField(form.appPin, { v -> vm.update { it.copy(appPin = v.filter(Char::isDigit).take(6)) } }, stringResource(R.string.p18_common_app_pin))
                }
                "card" -> {
                    AppTextField(form.cardholder, { v -> vm.update { it.copy(cardholder = v) } }, stringResource(R.string.p18_entry_detail_cardholder))
                    AppTextField(form.cardNumber, { v -> vm.update { it.copy(cardNumber = v) } }, stringResource(R.string.p18_entry_detail_card_number), keyboardType = KeyboardType.Number)
                    AppTextField(form.cardExpiry, { v -> vm.update { it.copy(cardExpiry = v) } }, stringResource(R.string.p15_expiry))
                    AppPasswordField(form.cardCvv, { v -> vm.update { it.copy(cardCvv = v) } }, stringResource(R.string.p15_cvv))
                    AppTextField(form.customValue("Bank"), { v -> vm.update { it.withCustomValue("Bank", v) } }, stringResource(R.string.entry_bank))
                }
                "identity" -> {
                    AppTextField(form.fullName, { v -> vm.update { it.copy(fullName = v) } }, stringResource(R.string.p18_entry_detail_full_name))
                    AppTextField(form.email, { v -> vm.update { it.copy(email = v) } }, stringResource(R.string.p15_email), keyboardType = KeyboardType.Email)
                    AppTextField(form.phone, { v -> vm.update { it.copy(phone = v) } }, stringResource(R.string.p15_phone), keyboardType = KeyboardType.Phone)
                    AppTextField(form.address, { v -> vm.update { it.copy(address = v) } }, stringResource(R.string.p15_address), singleLine = false)
                    AppTextField(form.idNumber, { v -> vm.update { it.copy(idNumber = v) } }, stringResource(R.string.p18_entry_detail_id_number))
                    AppTextField(form.idExpiry, { v -> vm.update { it.copy(idExpiry = v) } }, stringResource(R.string.p18_entry_detail_id_expiry))
                }
                else -> Text(stringResource(R.string.p17_loc_184), style = MaterialTheme.typography.bodyMedium)
            }
            AppTextField(form.notes, { v -> vm.update { it.copy(notes = v) } }, stringResource(R.string.p15_notes), singleLine = false)
            Text(stringResource(R.string.p15_category), style = MaterialTheme.typography.titleMedium)
            var categoryOpen by remember { mutableStateOf(false) }
            Box {
                OutlinedButton(onClick = { categoryOpen = true }, modifier = Modifier.fillMaxWidth()) {
                    Text(form.category.replaceFirstChar { it.uppercase() }, modifier = Modifier.weight(1f))
                }
                DropdownMenu(expanded = categoryOpen, onDismissRequest = { categoryOpen = false }) {
                    CATEGORIES.forEach { c ->
                        DropdownMenuItem(
                            text = { Text(c.replaceFirstChar { it.uppercase() }) },
                            onClick = { categoryOpen = false; vm.update { it.copy(category = c) } }
                        )
                    }
                }
            }
            if (state.folders.isNotEmpty()) {
                var open by remember { mutableStateOf(false) }
                Box {
                    OutlinedButton(onClick = { open = true }) { Text(stringResource(R.string.p17_folder_value, state.folders.firstOrNull { it.id == form.folderId }?.name ?: stringResource(R.string.p17_loc_186))) }
                    DropdownMenu(open, { open = false }) {
                        DropdownMenuItem({ Text(stringResource(R.string.p17_loc_186)) }, { open = false; vm.update { it.copy(folderId = "") } })
                        state.folders.forEach { folder -> DropdownMenuItem({ Text(folder.name) }, { open = false; vm.update { it.copy(folderId = folder.id) } }) }
                    }
                }
            }
            AppTextField(form.tags, { v -> vm.update { it.copy(tags = v) } }, stringResource(R.string.p15_tags))
            form.customFields.forEachIndexed { index, field ->
                Row(horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    AppTextField(field.k, { v -> vm.update { f -> f.copy(customFields = f.customFields.replaceAt(index, field.copy(k = v))) } }, stringResource(R.string.p17_loc_190), Modifier.weight(1f))
                    AppTextField(field.v, { v -> vm.update { f -> f.copy(customFields = f.customFields.replaceAt(index, field.copy(v = v))) } }, stringResource(R.string.p17_loc_191), Modifier.weight(1f))
                    IconButton(onClick = { vm.update { f -> f.copy(customFields = f.customFields.filterIndexed { i, _ -> i != index }) } }) { Icon(Icons.Default.Close, stringResource(R.string.p17_loc_192)) }
                }
            }
            TextButton(onClick = { vm.update { it.copy(customFields = it.customFields + CustomField()) } }) { Text(stringResource(R.string.p17_loc_192)) }
            AppButton(label = stringResource(R.string.p15_save), onClick = vm::save, enabled = !state.saving && !state.saved, variant = AppButtonVariant.PRIMARY, modifier = Modifier.fillMaxWidth())
        }
    }
    state.duplicate?.let { dup ->
        AlertDialog(onDismissRequest = vm::dismissDuplicate, title = { Text(stringResource(R.string.p17_loc_193), style = MaterialTheme.typography.titleLarge) }, text = { Text(stringResource(R.string.p17_dup_entry_message, dup.title)) }, confirmButton = { TextButton(onClick = { vm.save(overwrite = dup) }) { Text(stringResource(R.string.p17_loc_194)) } }, dismissButton = { TextButton(onClick = { vm.save(skipDuplicateCheck = true) }) { Text(stringResource(R.string.p17_loc_195)) } })
    }
}

private fun <T> List<T>.replaceAt(index: Int, value: T): List<T> =
    mapIndexed { i, old -> if (i == index) value else old }

@Composable
private fun AndroidAppPicker(
    selectedName: String,
    selectedPackage: String,
    onSelected: (String, String) -> Unit,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    data class PickerApp(val name: String, val packageName: String)
    val apps = remember(context) {
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN)
            .addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        runCatching {
            context.packageManager.queryIntentActivities(intent, 0)
                .map { it.activityInfo.applicationInfo to context.packageManager.getApplicationLabel(it.activityInfo.applicationInfo).toString() }
                .distinctBy { it.first.packageName }
                .map { (info, label) -> PickerApp(label, info.packageName) }
                .sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        }.getOrDefault(emptyList())
    }
    var dialogOpen by remember { mutableStateOf(false) }
    var query by remember(selectedPackage, selectedName) { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter {
            it.name.contains(query.trim(), ignoreCase = true) ||
                it.packageName.contains(query.trim(), ignoreCase = true)
        }
    }

    Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
        OutlinedTextField(
            value = when {
                selectedPackage.isNotBlank() && selectedName.isNotBlank() -> "$selectedName · $selectedPackage"
                selectedPackage.isNotBlank() -> selectedPackage
                selectedName.isNotBlank() -> "$selectedName · Not linked"
                else -> ""
            },
            onValueChange = {},
            readOnly = true,
            leadingIcon = {
                if (selectedPackage.isNotBlank()) {
                    val selectedIcon = remember(context, selectedPackage) {
                        runCatching {
                            context.packageManager
                                .getApplicationIcon(selectedPackage)
                                .toBitmap(96, 96)
                        }.getOrNull()
                    }
                    if (selectedIcon != null) {
                        Image(
                            selectedIcon.asImageBitmap(),
                            contentDescription = selectedName.ifBlank { selectedPackage },
                            modifier = Modifier.size(AppDimens.SmallFieldIcon)
                        )
                    }
                }
            },
            label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_196)) },
            placeholder = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_197)) },
            supportingText = {
                Text(when {
                    selectedPackage.isNotBlank() -> androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_package_linked)
                    selectedName.isNotBlank() -> androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_relink_app)
                    else -> androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_entry_select_android_app)
                })
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().clickable { dialogOpen = true }.onFocusChanged { if (it.isFocused) dialogOpen = true }
        )
        OutlinedButton(onClick = { query = ""; dialogOpen = true }, modifier = Modifier.fillMaxWidth()) {
            Text(if (selectedPackage.isBlank()) stringResource(pro.babasitaram.vault.R.string.p17_choose_android_app) else stringResource(pro.babasitaram.vault.R.string.p17_change_android_app))
        }
        if (selectedPackage.isNotBlank()) {
            TextButton(onClick = onClear) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_198)) }
        }
    }

    if (dialogOpen) {
        AlertDialog(
            onDismissRequest = { dialogOpen = false },
            title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_199), style = MaterialTheme.typography.titleLarge) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        label = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_200)) },
                        placeholder = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_201)) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (filtered.isEmpty()) {
                        Text(
                            if (apps.isEmpty()) stringResource(R.string.p18_entry_editor_no_launchable_apps_found_check)
                            else stringResource(R.string.p18_entry_editor_no_apps_match_your_search),
                            style = MaterialTheme.typography.bodyMedium
                        )
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = AppDimens.AppPickerMaxHeight)) {
                            items(filtered, key = { it.packageName  }, contentType = { "item" }) { app ->
                                val icon by produceState<android.graphics.Bitmap?>(initialValue = AppIconCache.icons.get(app.packageName), key1 = context, key2 = app.packageName) {
                                    if (value == null) {
                                        value = withContext(Dispatchers.IO) {
                                            runCatching { context.packageManager.getApplicationIcon(app.packageName).toBitmap(96, 96) }.getOrNull()
                                        }?.also { AppIconCache.icons.put(app.packageName, it) }
                                    }
                                }
                                TextButton(
                                    onClick = { onSelected(app.name, app.packageName); dialogOpen = false },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(AppDimens.Small)) {
                                        val bitmap = icon
                                        if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = null, modifier = Modifier.size(AppDimens.AppPickerIcon))
                                        else Box(Modifier.size(AppDimens.AppPickerIcon), contentAlignment = androidx.compose.ui.Alignment.Center) { Icon(Icons.Default.Android, contentDescription = null, modifier = Modifier.size(AppDimens.IconSize)) }
                                        Column(Modifier.weight(1f)) {
                                            Text(app.name, style = MaterialTheme.typography.bodyLarge)
                                            Text(app.packageName, style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dialogOpen = false }) { Text(stringResource(R.string.p15_close)) } },
            dismissButton = {
                if (selectedPackage.isNotBlank()) TextButton(onClick = { onClear(); dialogOpen = false }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_202)) }
            }
        )
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    keyboardType: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    onChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth()
    )
}
