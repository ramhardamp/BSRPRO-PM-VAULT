package pro.babasitaram.vault.presentation.components

import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

/** Filter/category chip family from UI/UX spec §2.3 and §4 Consistency Rules. */
enum class AppChipVariant { FILTER, CATEGORY }

/** Selected/unselected filter chip variant, spec §2.3. */
@Composable
fun AppFilterChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    leadingContent: (@Composable () -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        modifier = modifier.height(AppDimens.ChipHeight),
        shape = RoundedCornerShape(AppShapes.Pill),
        leadingIcon = leadingContent,
        trailingIcon = trailingContent
    )
}

/** Category chip variant, spec §2.3. */
@Composable
fun AppCategoryChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingContent: (@Composable () -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null
) {
    AssistChip(
        onClick = onClick,
        label = { Text(label, style = MaterialTheme.typography.labelLarge) },
        modifier = modifier.height(AppDimens.ChipHeight),
        shape = RoundedCornerShape(AppShapes.Pill),
        leadingIcon = leadingContent,
        trailingIcon = trailingContent
    )
}

/** Backward-compatible dispatcher for callers that need either chip variant. */
@Composable
fun AppChip(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    variant: AppChipVariant = AppChipVariant.FILTER,
    selected: Boolean = false,
    leadingContent: (@Composable () -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null
) {
    when (variant) {
        AppChipVariant.FILTER -> AppFilterChip(label, onClick, modifier, selected, leadingContent, trailingContent)
        AppChipVariant.CATEGORY -> AppCategoryChip(label, onClick, modifier, leadingContent, trailingContent)
    }
}
