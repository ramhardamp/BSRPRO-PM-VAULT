@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
package pro.babasitaram.vault.presentation.totpmanager

import pro.babasitaram.vault.presentation.components.AppColors
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.R

import androidx.compose.ui.res.stringResource
import androidx.compose.ui.graphics.toArgb
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.delay
import pro.babasitaram.vault.core.util.Totp
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.core.util.L

/** TOTP-specific detail: live code, countdown, service, username, hidden secret, QR, edit/copy/delete. */
@Composable
fun TotpDetailScreen(onBack: () -> Unit, onEdit: (String) -> Unit, vm: TotpDetailViewModel = hiltViewModel()) {
    val entry by vm.entry.collectAsStateWithLifecycle()
    val context = androidx.compose.ui.platform.LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var reveal by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    BackHandler { onBack() }
    CollectMessages(vm.messages)
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1_000L) } }
    // entry deleted (here or elsewhere): leave the screen
    LaunchedEffect(entry == null) { if (entry == null) onBack() }

    val e = entry
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_168)) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_037)) } },
                actions = {
                    if (e != null) {
                        IconButton(onClick = { onEdit(e.id) }) { Icon(Icons.Default.Edit, androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_173)) }
                        IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Default.Delete, "Delete") }
                    }
                }
            )
        }
    ) { padding ->
        if (e == null) { Box(Modifier.fillMaxSize().padding(padding)); return@Scaffold }
        val cfg = Totp.parse(e.totp)
        val code = Totp.current(e.totp, now)
        Column(
            Modifier.fillMaxSize().padding(padding).padding(AppDimens.Medium).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(AppDimens.Small)
        ) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(e.title.ifBlank { stringResource(pro.babasitaram.vault.R.string.p17_untitled) }, style = MaterialTheme.typography.titleLarge)
                    if (code == null) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_158), color = MaterialTheme.colorScheme.error)
                    } else {
                        val pretty = if (code.code.length == 6) code.code.chunked(3).joinToString(" ") else code.code.chunked(4).joinToString(" ")
                        Text(pretty, style = MaterialTheme.typography.headlineMedium, fontFamily = FontFamily.Monospace)
                        val frac = code.secondsRemaining.coerceAtLeast(0) / code.periodSeconds.toFloat()
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                            CircularProgressIndicator(
                                progress = { frac },
                                modifier = Modifier.size(AppDimens.TotpProgressSize),
                                strokeWidth = AppDimens.ProgressStroke,
                                color = when {
                                    code.secondsRemaining > 10 -> AppColors.TotpSafe
                                    code.secondsRemaining > 5 -> AppColors.TotpWarning
                                    else -> AppColors.TotpCritical
                                }
                            )
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_totp_expires, code.secondsRemaining))
                        }
                        Button(onClick = { vm.copy(code.code, L.s(R.string.p18_common_totp_code)) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.ContentCopy, null); Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_169))
                        }
                    }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                    InfoRow(stringResource(R.string.p18_totp_detail_service), e.url.ifBlank { e.title })
                    if (e.username.isNotBlank()) InfoRow(stringResource(R.string.p17_loc_162), e.username)
                    if (cfg != null) {
                        InfoRow(stringResource(R.string.p17_loc_164), cfg.algorithm)
                        InfoRow(stringResource(R.string.p18_totp_detail_digits_period), L.s(R.string.p18_totp_detail_digits_s, cfg.digits, cfg.periodSeconds))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_170), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(if (reveal) cfg.secret else "•".repeat(16), fontFamily = FontFamily.Monospace)
                            }
                            IconButton(onClick = { reveal = !reveal }) {
                                Icon(if (reveal) Icons.Default.VisibilityOff else Icons.Default.Visibility, if (reveal) "Hide secret" else "Show secret")
                            }
                            IconButton(onClick = { vm.copy(cfg.secret, context.getString(pro.babasitaram.vault.R.string.p17_loc_170)) }) { Icon(Icons.Default.ContentCopy, "Copy secret") }
                        }
                    }
                }
            }
            if (reveal && e.totp.isNotBlank()) {
                val qrForegroundColor = MaterialTheme.colorScheme.onSurface.toArgb()
                val qrBackgroundColor = MaterialTheme.colorScheme.surface.toArgb()
                val qr = remember(e.totp, qrForegroundColor, qrBackgroundColor) { qrBitmap(e.totp, qrForegroundColor, qrBackgroundColor) }
                if (qr != null) {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(AppDimens.Medium).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_171), style = MaterialTheme.typography.labelLarge)
                            Image(qr.asImageBitmap(), "TOTP QR code", Modifier.size(AppDimens.TotpQrSize).padding(top = AppDimens.Xs))
                        }
                    }
                }
            }
            if (e.notes.isNotBlank()) {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(AppDimens.Medium), verticalArrangement = Arrangement.spacedBy(AppDimens.Xxs)) {
                        Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_172), style = MaterialTheme.typography.labelLarge)
                        Text(if (reveal) e.notes else stringResource(pro.babasitaram.vault.R.string.p17_totp_reveal_hint), fontFamily = FontFamily.Monospace)
                    }
                }
            }
            OutlinedButton(onClick = { onEdit(e.id) }, modifier = Modifier.fillMaxWidth()) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_173)) }
        }
        if (confirmDelete) {
            AlertDialog(
                onDismissRequest = { confirmDelete = false },
                title = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_159)) },
                text = { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_totp_bin_restore, e.title.ifBlank { androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_totp_default_entry) })) },
                confirmButton = { TextButton(onClick = { confirmDelete = false; vm.delete(onBack) }) { Text(androidx.compose.ui.res.stringResource(pro.babasitaram.vault.R.string.p17_loc_033)) } },
                dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text(stringResource(R.string.p15_cancel)) } }
            )
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyLarge)
    }
}

private fun qrBitmap(text: String, foreground: Int, background: Int, size: Int = 512): Bitmap? = runCatching {
    val matrix = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    for (x in 0 until size) for (y in 0 until size) bmp.setPixel(x, y, if (matrix.get(x, y)) foreground else background)
    bmp
}.getOrNull()
