@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package pro.babasitaram.vault.presentation.vault

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.foundation.focusGroup
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import pro.babasitaram.vault.R
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.core.util.UrlUtils
import pro.babasitaram.vault.presentation.components.AppCategory
import pro.babasitaram.vault.presentation.components.AppCategoryChip
import pro.babasitaram.vault.presentation.components.AppDimens
import pro.babasitaram.vault.presentation.components.AppEmptyState
import pro.babasitaram.vault.presentation.components.AppFilterTabs
import pro.babasitaram.vault.presentation.components.AppIconCircle
import pro.babasitaram.vault.presentation.components.AppIconCircleVariant
import pro.babasitaram.vault.presentation.components.AppSearchBar
import pro.babasitaram.vault.presentation.components.AppSelectionTopBar
import pro.babasitaram.vault.presentation.components.SelectionBottomBar
import pro.babasitaram.vault.presentation.util.CollectMessages
import pro.babasitaram.vault.presentation.util.findFragmentActivity

private sealed interface ListRow {
    data class Header(val key: String, val count: Int, val expanded: Boolean) : ListRow
    data class Item(val entry: VaultEntry, val indented: Boolean) : ListRow
}

private fun groupKey(e: VaultEntry): String = UrlUtils.domainOf(e.url).ifEmpty { e.appName.ifEmpty { e.title.ifEmpty { "other" } } }
private fun buildRows(entries: List<VaultEntry>, grouped: Boolean, expanded: Set<String>): List<ListRow> {
    if (!grouped) return entries.map { ListRow.Item(it, false) }
    return entries.groupBy(::groupKey).flatMap { (key, list) ->
        if (list.size == 1) listOf<ListRow>(ListRow.Item(list.first(), false)) else buildList<ListRow> {
            val open = key in expanded
            add(ListRow.Header(key, list.size, open))
            if (open) list.forEach { add(ListRow.Item(it, true)) }
        }
    }
}

/** Full Vault UI migration, spec §2.3. Search, type tabs, strength chips and entry rows reuse the existing Hilt ViewModel. */
@Composable
fun VaultListScreen(
    onOpen: (String) -> Unit,
    onAdd: () -> Unit,
    onGenerator: () -> Unit,
    onSettings: () -> Unit,
    onEdit: (String) -> Unit = {},
    onShare: (String) -> Unit = {},
    onShareSelected: (List<String>) -> Unit = { ids -> ids.forEach(onShare) },
    vm: VaultListViewModel = hiltViewModel()
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val selectedIds by vm.selectedIds.collectAsStateWithLifecycle()
    val selectionMode by vm.selectionMode.collectAsStateWithLifecycle()
    val selectableIds by vm.selectableIds.collectAsStateWithLifecycle()
    var confirmBulkDelete by remember { mutableStateOf(false) }
    var expanded by remember { mutableStateOf(emptySet<String>()) }
    var sortOpen by remember { mutableStateOf(false) }
    CollectMessages(vm.messages)
    val rows = remember(state.entries, state.grouped, expanded) { buildRows(state.entries, state.grouped, expanded) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().focusGroup()) {
            if (selectionMode) {
                AppSelectionTopBar(
                    selectedCount = selectedIds.size,
                    allSelected = selectableIds.isNotEmpty() && selectedIds.containsAll(selectableIds),
                    onBack = vm::exitSelection,
                    onToggleSelectAll = vm::toggleSelectAll,
                    onDelete = { confirmBulkDelete = true },
                    onShare = { onShareSelected(selectedIds.toList()) }
                )
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = AppDimens.ScreenHorizontal, vertical = AppDimens.Xs).semantics { heading() }, verticalAlignment = Alignment.CenterVertically) {
                    AppSearchBar(state.query, vm::setQuery, Modifier.weight(1f), stringResource(R.string.vault_search_passwords))
                    IconButton(onClick = { sortOpen = true }) { Icon(Icons.Default.Sort, stringResource(R.string.vault_sort)) }
                    IconButton(onClick = vm::toggleGrouped) { Icon(Icons.AutoMirrored.Filled.ViewList, stringResource(R.string.vault_group_by_site)) }
                    DropdownMenu(sortOpen, { sortOpen = false }) {
                        SortMode.values().forEach { option -> DropdownMenuItem({ Text(stringResource(option.labelRes())) }, { sortOpen = false; vm.setSort(option) }) }
                    }
                }
                val typeLabels = VaultTypeFilter.values().map { stringResource(it.labelRes()) }
                AppFilterTabs(typeLabels, state.typeFilter.ordinal, { vm.setTypeFilter(VaultTypeFilter.values()[it]) }, Modifier.padding(horizontal = AppDimens.ScreenHorizontal))
                val strengthLabels = StrengthFilter.values().map { stringResource(it.labelRes()) }
                AppFilterTabs(strengthLabels, state.strengthFilter.ordinal, { vm.setStrengthFilter(StrengthFilter.values()[it]) }, Modifier.padding(horizontal = AppDimens.ScreenHorizontal))
                if (state.showCategories) {
                    LazyRow(contentPadding = PaddingValues(horizontal = AppDimens.ScreenHorizontal), horizontalArrangement = Arrangement.spacedBy(AppDimens.Xs)) {
                        items(CATEGORIES) { category ->
                            val kind = when (category) { "work" -> AppCategory.VAULT; "personal" -> AppCategory.VAULT; "banking" -> AppCategory.CARDS; else -> AppCategory.VAULT }
                            AppCategoryChip(kind, stringResource(categoryLabelRes(category)), onClick = { vm.setCategory(category) })
                        }
                    }
                }
            }
            when {
                state.totalCount == 0 -> AppEmptyState(stringResource(R.string.vault_no_passwords), stringResource(R.string.vault_no_passwords_message), actionLabel = stringResource(R.string.vault_add_entry), onAction = onAdd)
                rows.isEmpty() -> AppEmptyState(stringResource(R.string.vault_no_matches), stringResource(R.string.vault_no_matches_message), actionLabel = stringResource(R.string.common_clear), onAction = { vm.setQuery("") })
                else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = AppDimens.XxLarge)) {
                    items(rows, key = { row -> if (row is ListRow.Header) "h:${row.key}" else "e:${(row as ListRow.Item).entry.id}" }, contentType = { row -> if (row is ListRow.Header) "header" else "entry" }) { row ->
                        when (row) {
                            is ListRow.Header -> ListItem(
                                headlineContent = { Text(row.key) },
                                supportingContent = { Text(stringResource(R.string.vault_entries_count, row.count)) },
                                leadingContent = { Icon(Icons.Default.Folder, null) },
                                trailingContent = { Icon(if (row.expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null) },
                                modifier = Modifier.combinedClickable(onClick = { expanded = if (row.key in expanded) expanded - row.key else expanded + row.key }, onLongClick = {})
                            )
                            is ListRow.Item -> EntryRow(row.entry, row.indented, selectionMode, row.entry.id in selectedIds,
                                onClick = { onOpen(row.entry.id) }, onLongClick = { vm.beginSelection(row.entry.id) },
                                onToggleSelection = { vm.toggleSelection(row.entry.id) }, onCopy = { vm.copyPassword(row.entry) },
                                onCopyUsername = { vm.copyUsername(row.entry) }, onCopyTotp = { vm.copyTotp(row.entry) },
                                onEdit = { onEdit(row.entry.id) }, onDelete = { vm.delete(row.entry) }, onShare = { onShare(row.entry.id) }, onToggleStar = { vm.toggleStar(row.entry) })
                        }
                    }
                    if (state.canLoadMore && !state.grouped) item { TextButton(onClick = vm::loadMore, Modifier.fillMaxWidth()) { Text(stringResource(R.string.load_more_entries)) } }
                }
            }
        }
        if (selectionMode) SelectionBottomBar(selectedIds.size, { confirmBulkDelete = true }, { onShareSelected(selectedIds.toList()) }, vm::favoriteSelected, Modifier.align(Alignment.BottomCenter))
        if (!selectionMode) FloatingActionButton(onClick = onAdd, Modifier.align(Alignment.BottomEnd).padding(AppDimens.Large).navigationBarsPadding()) { Icon(Icons.Default.Add, stringResource(R.string.vault_add_entry)) }
    }
    if (confirmBulkDelete) AlertDialog(onDismissRequest = { confirmBulkDelete = false }, title = { Text(stringResource(R.string.selection_delete_title)) }, text = { Text(stringResource(R.string.selection_delete_text, selectedIds.size)) }, confirmButton = { TextButton(onClick = { confirmBulkDelete = false; vm.deleteSelected() }) { Text(stringResource(R.string.p15_delete)) } }, dismissButton = { TextButton(onClick = { confirmBulkDelete = false }) { Text(stringResource(R.string.p15_cancel)) } })
}

@Composable
private fun EntryRow(entry: VaultEntry, indented: Boolean, selectionMode: Boolean, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit, onToggleSelection: () -> Unit, onCopy: () -> Unit, onCopyUsername: () -> Unit, onCopyTotp: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit, onShare: () -> Unit, onToggleStar: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val variant = when { entry.isAppLogin -> AppIconCircleVariant.APP_LOGIN; entry.recordType.equals("card", true) -> AppIconCircleVariant.CARDS; entry.recordType.equals("identity", true) -> AppIconCircleVariant.IDENTITIES; else -> AppIconCircleVariant.VAULT }
    ListItem(
        headlineContent = { Text(entry.title.ifEmpty { stringResource(R.string.health_untitled) }, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        supportingContent = { Text(entry.username.ifEmpty { UrlUtils.domainOf(entry.url).ifEmpty { entry.appName } }, style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        leadingContent = { AppIconCircle(Icons.Default.Star, variant, contentDescription = null) },
        trailingContent = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!selectionMode && entry.password.isNotEmpty()) IconButton(onClick = onCopy) { Icon(Icons.Default.ContentCopy, stringResource(R.string.vault_copy_password)) }
                if (!selectionMode) IconButton(onClick = onToggleStar) { Icon(Icons.Default.Star, stringResource(if (entry.starred) R.string.vault_remove_favorite else R.string.vault_add_favorite)) }
                if (selectionMode) androidx.compose.material3.Checkbox(selected, { onToggleSelection() })
                if (!selectionMode) Box { IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, stringResource(R.string.vault_more_options)) }; DropdownMenu(menu, { menu = false }) {
                    if (entry.username.isNotBlank()) DropdownMenuItem({ Text(stringResource(R.string.vault_copy_username)) }, { menu = false; onCopyUsername() })
                    if (entry.totp.isNotBlank()) DropdownMenuItem({ Text(stringResource(R.string.vault_copy_totp)) }, { menu = false; onCopyTotp() })
                    DropdownMenuItem({ Text(stringResource(R.string.p15_edit)) }, { menu = false; onEdit() })
                    DropdownMenuItem({ Text(stringResource(R.string.vault_move_to_bin)) }, { menu = false; onDelete() })
                    DropdownMenuItem({ Text(stringResource(R.string.vault_share_securely)) }, { menu = false; onShare() })
                } }
            }
        },
        modifier = Modifier.combinedClickable(onClick = { if (selectionMode) onToggleSelection() else onClick() }, onLongClick = { if (!selectionMode) onLongClick() }).padding(start = if (indented) AppDimens.Large else AppDimens.Zero)
    )
}

private fun VaultTypeFilter.labelRes(): Int = when (this) {
    VaultTypeFilter.ALL -> R.string.p15_all
    VaultTypeFilter.PASSWORDS -> R.string.type_password
    VaultTypeFilter.APP_LOGIN -> R.string.filter_app_login
    VaultTypeFilter.CARDS -> R.string.type_card
    VaultTypeFilter.IDENTITIES -> R.string.type_identity
}
private fun StrengthFilter.labelRes(): Int = when (this) {
    StrengthFilter.ALL -> R.string.p15_all
    StrengthFilter.STRONG -> R.string.p15_strong
    StrengthFilter.WEAK -> R.string.p15_weak
    StrengthFilter.STARRED -> R.string.p15_starred
}
private fun SortMode.labelRes(): Int = when (this) { SortMode.NAME -> R.string.sort_name; SortMode.UPDATED -> R.string.sort_recently_updated; SortMode.USED -> R.string.sort_recently_used; SortMode.STRENGTH -> R.string.sort_strength }
private fun categoryLabelRes(category: String): Int = when (category.lowercase()) { "work" -> R.string.p15_work; "personal" -> R.string.p15_personal; "banking" -> R.string.p15_banking; "social" -> R.string.p15_social; else -> R.string.p15_other }
