package pro.babasitaram.vault.presentation.components

import androidx.annotation.StringRes
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import pro.babasitaram.vault.R

/**
 * Shared top bar from UI/UX spec §2.3 and §4 Consistency Rules.
 *
 * The spec defines the title area as text, so [title] remains a String rather than
 * an undocumented title slot. Custom [navigationIcon] takes precedence over [onBack]
 * when both are supplied; this permits the Vault drawer icon while keeping the standard
 * 24dp back button for normal child screens.
 */
@Composable
fun AppTopBar(
    title: String,
    modifier: Modifier = Modifier,
    onBack: (() -> Unit)? = null,
    onMenu: (() -> Unit)? = null,
    @StringRes menuContentDescriptionRes: Int? = null,
    navigationIcon: (@Composable () -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    TopAppBar(
        modifier = modifier
            .fillMaxWidth()
            .height(AppDimens.TopBarHeight),
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        navigationIcon = {
            when {
                // Explicit custom navigation always wins over the standard back action.
                navigationIcon != null -> navigationIcon()
                onBack != null -> {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.common_back),
                            modifier = Modifier.size(AppDimens.IconSize)
                        )
                    }
                }
            }
        },
        actions = {
            actions()
            if (onMenu != null) {
                IconButton(onClick = onMenu) {
                    Icon(
                        imageVector = Icons.Default.MoreVert,
                        contentDescription = menuContentDescriptionRes?.let { resId -> stringResource(resId) },
                        modifier = Modifier.size(AppDimens.IconSize)
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface,
            navigationIconContentColor = MaterialTheme.colorScheme.onSurface,
            actionIconContentColor = MaterialTheme.colorScheme.onSurface
        )
    )
}
