package pro.babasitaram.vault.data.transfer

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import pro.babasitaram.vault.core.model.CustomField
import pro.babasitaram.vault.core.model.VaultEntry
import pro.babasitaram.vault.presentation.contacts.ContactItem
import pro.babasitaram.vault.presentation.contacts.ContactsLogic
import pro.babasitaram.vault.presentation.navigation.DrawerCountsCalc
import pro.babasitaram.vault.presentation.navigation.drawerBadgeText

class ImportExportOptionsTest {
    private val login = VaultEntry(id = "1", title = "Site", url = "https://a.com", username = "u", password = "pw")
    private val card = VaultEntry(id = "2", title = "Card", recordType = "card")
    private val note = VaultEntry(id = "3", title = "N", recordType = "note", isNote = true)
    private val totp = VaultEntry(id = "4", title = "T", recordType = "totp", totp = "otpauth://totp/x?secret=ABC")
    private val mobile = VaultEntry(id = "5", title = "M", recordType = "mobile", mobile = "9876543210")
    private val all = listOf(login, card, note, totp, mobile)

    @Test fun `selective export drops unchecked types but always keeps logins`() {
        val o = ExportOptions(includeCards = false, includeNotes = false, includeTotp = false, includeMobiles = true)
        assertEquals(listOf("1", "5"), ExportFilter.apply(all, o).map { it.id })
    }

    @Test fun `totp secret is stripped from logins when excluded`() {
        val withTotp = login.copy(totp = "otpauth://totp/x?secret=ABC")
        val out = ExportFilter.apply(listOf(withTotp), ExportOptions(includeTotp = false))
        assertEquals("", out.single().totp)
    }

    @Test fun `attachment references are stripped when excluded`() {
        val e = login.copy(customFields = listOf(CustomField("attachment_name", "a.pdf"), CustomField("keep", "1")))
        val out = ExportFilter.apply(listOf(e), ExportOptions(includeAttachments = false)).single()
        assertEquals(listOf("keep"), out.customFields.map { it.k })
    }

    @Test fun `plain text flag follows format and encrypt choice`() {
        assertFalse(ExportOptions(kind = ExportKind.VAULT).isPlainText)
        assertTrue(ExportOptions(kind = ExportKind.JSON).isPlainText)
        assertTrue(ExportOptions(kind = ExportKind.CSV, encrypt = false).isPlainText)
        assertFalse(ExportOptions(kind = ExportKind.CSV, encrypt = true).isPlainText)
    }

    @Test fun `progress reports done of total and finishes at total`() = runBlocking {
        val many = (1..45).map { login.copy(id = "id$it") }
        val seen = ArrayList<Pair<Int, Int>>()
        ExportFilter.applyWithProgress(many, ExportOptions()) { d, t -> seen.add(d to t) }
        assertEquals(0 to 45, seen.first())
        assertEquals(45 to 45, seen.last())
    }

    @Test fun `csv mapping auto detects columns and parses rows`() {
        val csv = "Site,Login,Secret,Remarks\nExample,me@x.com,hunter2,hello\n"
        val headers = CsvMapping.headers(csv)
        val m = CsvMapping.autoDetect(headers)
        assertEquals(0, m[MapField.TITLE])
        assertEquals(1, m[MapField.USERNAME])
        assertEquals(2, m[MapField.PASSWORD])
        val parsed = CsvMapping.parse(csv, m)
        assertEquals(1, parsed.entries.size)
        assertEquals("hunter2", parsed.entries[0].password)
    }

    @Test fun `manual mapping override is honoured`() {
        val csv = "a,b\nuser1,pass1\n"
        val parsed = CsvMapping.parse(csv, mapOf(MapField.USERNAME to 0, MapField.PASSWORD to 1))
        assertEquals("user1", parsed.entries.single().username)
        assertEquals("pass1", parsed.entries.single().password)
    }

    @Test fun `contact phone keys match across formatting`() {
        assertEquals(ContactsLogic.key("+91 98765-43210"), ContactsLogic.key("09876543210"))
        val e = ContactsLogic.toEntry(ContactItem(1, "Asha", listOf("+919876543210", "0112233445"), false), 1000L)
        assertEquals("mobile", e.recordType)
        assertEquals("+919876543210", e.mobile)
        assertEquals(1, e.customFields.size)
    }

    @Test fun `drawer counts use each feature's own filter`() {
        val noteWithBody = note.copy(notes = "body")
        val c = DrawerCountsCalc.compute(all + noteWithBody.copy(id = "6"), trashed = listOf(login.copy(id = "9")), mobileCount = 1)
        assertEquals(2, c.vault)      // login + card; notes, totp and mobile have their own screens
        assertEquals(2, c.notes)
        assertEquals(1, c.totp)
        assertEquals(1, c.mobiles)
        assertEquals(1, c.bin)
    }
    @Test fun `drawer mobile count ignores blank, hidden and trashed entries and counts phone field too`() {
        val withPhoneOnly = VaultEntry(id = "p", title = "Phone", phone = "9876543210")
        val blankMobileType = VaultEntry(id = "blank-type", title = "Blank mobile type", recordType = "mobile")
        val hidden = VaultEntry(id = "hidden", title = "Hidden", mobile = "9999999999", tags = listOf("hidden-vault"))
        val trashed = VaultEntry(id = "trash", title = "Trash", mobile = "8888888888", deletedAt = 1234L)
        val visible = listOf(mobile, withPhoneOnly, blankMobileType, hidden, trashed)

        val count = visible.count {
            it.deletedAt == 0L && !it.isFolderMarker && !it.tags.any { tag -> tag.equals("hidden-vault", true) } &&
                (it.mobile.isNotBlank() || it.phone.isNotBlank())
        }
        assertEquals(2, count)

        val c = DrawerCountsCalc.compute(visible, trashed = listOf(trashed), mobileCount = count)
        assertEquals(2, c.mobiles)
    }

    @Test fun `drawer mobile badge format is exact through one thousand threshold`() {
        assertEquals(null, drawerBadgeText(0))
        assertEquals("1", drawerBadgeText(1))
        assertEquals("378", drawerBadgeText(378))
        assertEquals("999", drawerBadgeText(999))
        assertEquals("1000", drawerBadgeText(1000))
        assertEquals("3780", drawerBadgeText(3780))
    }

}
