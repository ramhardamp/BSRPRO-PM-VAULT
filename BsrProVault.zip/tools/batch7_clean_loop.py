from pathlib import Path
import subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
for i in range(1,11):
    r=subprocess.run(['python3','tools/batch7_audit.py'],cwd=ROOT,capture_output=True,text=True)
    if r.returncode!=0:
        print(f'CLEAN {i}/10 FAIL — counter reset to 0')
        print(r.stdout)
        print(r.stderr)
        raise SystemExit(1)
    print(f'CLEAN {i}/10 PASS')
print('10 CLEAN AUDITS PASS')
