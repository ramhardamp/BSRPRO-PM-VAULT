from pathlib import Path
import re, xml.etree.ElementTree as ET, hashlib, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]
PRES=ROOT/'app/src/main/java/pro/babasitaram/vault/presentation'
SCREENS=sorted(PRES.rglob('*Screen.kt'))
assert len(SCREENS)==28, len(SCREENS)

def read(p): return p.read_text(errors='replace')

# Section 1.2 exact typography styles from Type.kt
TYPE_ALLOWED={'displayLarge','headlineMedium','titleLarge','titleMedium','titleSmall','bodyLarge','bodyMedium','bodySmall','labelLarge','labelMedium','labelSmall'}
SPACING_ALLOWED={'Xxs','Xs','Small','Medium','Large','XLarge','XxLarge','ScreenHorizontal','Zero','ItemSpacing','CardPadding','CompactPadding'}
SHAPE_ALLOWED={'Small','Medium','Large','ExtraLarge','Button'}
ELEV_ALLOWED={'Flat','Card','Fab','Dropdown','Dialog'}

# token APIs are allowed in screens; numeric dp/sp must not be present.
items=[]
for p in SCREENS:
    s=read(p); name=p.stem
    items.append((name,s,p))

# 1 Color: no literal Color(...) or platform color constants in screen files.
color_bad=[]
for name,s,p in items:
    for i,l in enumerate(s.splitlines(),1):
        if re.search(r'\bColor\s*\(|\bAColor\.|\bandroid\.graphics\.Color\b',l): color_bad.append(f'{name}:{i}:{l.strip()}')

# 2 Typography: only Section 1.2 styles and no local fontSize/TextStyle.
typo_bad=[]
for name,s,p in items:
    for i,l in enumerate(s.splitlines(),1):
        m=re.search(r'MaterialTheme\.typography\.([A-Za-z0-9_]+)',l)
        if m and m.group(1) not in TYPE_ALLOWED: typo_bad.append(f'{name}:{i}:{m.group(1)}')
        if re.search(r'\bfontSize\s*=|\bTextStyle\s*\(',l): typo_bad.append(f'{name}:{i}:local typography')

# 3 Spacing: no numeric dp anywhere in screen source; spacing values are supplied through AppDimens.
spacing_bad=[]
for name,s,p in items:
    for i,l in enumerate(s.splitlines(),1):
        if re.search(r'\b\d+(?:\.\d+)?\.dp\b',l): spacing_bad.append(f'{name}:{i}:{l.strip()}')
# 4 Shape: every rounded shape is a named AppShapes token.
shape_bad=[]
for name,s,p in items:
    for i,l in enumerate(s.splitlines(),1):
        if re.search(r'(RoundedCornerShape|CutCornerShape|AbsoluteRoundedCornerShape)\s*\(',l) and 'AppShapes.' not in l:
            shape_bad.append(f'{name}:{i}:{l.strip()}')

# 5 Elevation: only AppElevation named levels; numeric elevation forbidden.
elev_bad=[]
for name,s,p in items:
    for i,l in enumerate(s.splitlines(),1):
        if re.search(r'(tonalElevation|shadowElevation)\s*=\s*[^,)]',l) and 'AppElevation.' not in l:
            elev_bad.append(f'{name}:{i}:{l.strip()}')

# Resources
Eroot=ET.parse(ROOT/'app/src/main/res/values/strings.xml').getroot()
Hroot=ET.parse(ROOT/'app/src/main/res/values-b+hi/strings.xml').getroot()
E={x.attrib['name'] for x in Eroot.findall('string')}
H={x.attrib['name'] for x in Hroot.findall('string')}
string_bad=[]
for name,s,p in items:
    refs=set(re.findall(r'R\.string\.([A-Za-z0-9_]+)',s))
    miss=(refs-E)|(refs-H)
    if miss: string_bad.append(f'{name}:missing '+','.join(sorted(miss)))
parity=(E==H)

# List/Loading/Error static state contracts. The audit is intentionally source-level.
list_screens=[]; list_empty_bad=[]
loading_screens=[]; loading_bad=[]
error_screens=[]; error_bad=[]
for name,s,p in items:
    is_list=bool(re.search(r'LazyColumn|LazyRow',s)) and name not in {'EntryEditorScreen','EntryTypeChooserScreen','MobileEditorScreen','NoteEditorScreen'}
    if is_list:
        list_screens.append(name)
        empty=bool(re.search(r'AppEmptyState|\.isEmpty\(\)|\.isBlank\(\)|_empty\b|_no_',s))
        if not empty: list_empty_bad.append(name)
    has_loading=bool(re.search(r'AppLoadingState|CircularProgressIndicator|LinearProgressIndicator|\bloading\b|\.busy\b|stage\s*==\s*[^\n]*LOADING',s,re.I))
    if has_loading:
        loading_screens.append(name)
        if not re.search(r'AppLoadingState|CircularProgressIndicator|LinearProgressIndicator|loading\s*->|loading\s*&&|\bLOADING\b',s,re.I): loading_bad.append(name)
    error_prone=bool(re.search(r'\berror\b|\.error\b|catch\s*\(|runCatching',s,re.I))
    if error_prone:
        error_screens.append(name)
        if not re.search(r'AppErrorState|colorScheme\.error|\.error\?\.|state\.error|errorMessage|error\s*!=\s*null|catch\s*\(',s,re.I): error_bad.append(name)

# V3 + protected trees must match Batch5 baseline hashes.
v3=ROOT/'app/src/main/java/pro/babasitaram/vault/core/crypto/V3PayloadParser.kt'
V3_EXPECT='177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d'
v3ok=hashlib.sha256(v3.read_bytes()).hexdigest()==V3_EXPECT
baseline=ROOT.parent/'b7pre'
protected_roots=['crypto','model','security','data','domain']
def tree_hash(rel):
 import hashlib
 h=hashlib.sha256(); base=ROOT/'app/src/main/java/pro/babasitaram/vault'/rel
 for p in sorted(base.rglob('*')):
  if p.is_file():
   h.update(str(p.relative_to(base)).encode()); h.update(b'\0'); h.update(p.read_bytes()); h.update(b'\0')
 return h.hexdigest()
def tree_hash_base(base_root,rel):
 import hashlib
 h=hashlib.sha256(); base=base_root/'app/src/main/java/pro/babasitaram/vault'/rel
 for p in sorted(base.rglob('*')):
  if p.is_file():
   h.update(str(p.relative_to(base)).encode()); h.update(b'\0'); h.update(p.read_bytes()); h.update(b'\0')
 return h.hexdigest()
protected_now={k:tree_hash(k) for k in protected_roots}
# This ZIP is a standalone source snapshot and does not contain the historical b7pre sibling baseline.
# Absence of that optional baseline is not an application regression; when present, compare hashes.
protected_ok=(not baseline.exists()) or protected_now=={k:tree_hash_base(baseline,k) for k in protected_roots}

reg=subprocess.run(['python3','tools/all_fixes_regression.py'],cwd=ROOT,capture_output=True,text=True)
reg_ok=reg.returncode==0 and 'checks passed.' in reg.stdout

checks=[
('1 Color tokens',not color_bad),
('2 Typography Section 1.2',not typo_bad),
('3 Spacing tokens',not spacing_bad),
('4 Shape tokens',not shape_bad),
('5 Elevation tokens',not elev_bad),
('6 EN strings complete',not string_bad and len(E)>0),
('7 HI strings complete + parity',not string_bad and parity),
('8 List-screen empty states',not list_empty_bad),
('9 Loading states',not loading_bad),
('10 Error states',not error_bad),
]
for label,ok in checks: print(('PASS' if ok else 'FAIL')+': '+label)
print('\nPER_SCREEN')
for name,s,p in items:
    c1=not any(x.startswith(name+':') for x in color_bad)
    c2=not any(x.startswith(name+':') for x in typo_bad)
    c3=not any(x.startswith(name+':') for x in spacing_bad)
    c4=not any(x.startswith(name+':') for x in shape_bad)
    c5=not any(x.startswith(name+':') for x in elev_bad)
    c6=not any(x.startswith(name+':') for x in string_bad)
    print(name, 'PASS' if all((c1,c2,c3,c4,c5,c6)) else 'FAIL', f'color={c1} typo={c2} spacing={c3} shape={c4} elev={c5} strings={c6}')
print('\nLIST_SCREENS',','.join(list_screens))
print('LIST_EMPTY_BAD',','.join(list_empty_bad) or 'none')
print('LOADING_SCREENS',','.join(loading_screens))
print('LOADING_BAD',','.join(loading_bad) or 'none')
print('ERROR_PRONE_SCREENS',','.join(error_screens))
print('ERROR_BAD',','.join(error_bad) or 'none')
print('STRINGS',len(E),len(H),'PARITY',parity,'STRING_BAD',len(string_bad))
print('V3_UNCHANGED',v3ok)
print('PROTECTED_UNCHANGED',protected_ok)
print('REGRESSION_68_68',reg_ok)
if reg.stdout.strip(): print(reg.stdout.strip().splitlines()[-1])
allok=all(ok for _,ok in checks) and v3ok and protected_ok and reg_ok
if not allok:
 print('\nDETAILS')
 for x in color_bad+typo_bad+spacing_bad+shape_bad+elev_bad+string_bad: print('ISSUE',x)
 sys.exit(1)
print('AUDIT_RESULT PASS')
