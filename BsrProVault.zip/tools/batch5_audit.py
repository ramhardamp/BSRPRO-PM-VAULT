#!/usr/bin/env python3
from pathlib import Path
import hashlib,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'app/src/main/java/pro/babasitaram/vault/presentation'
BASE=Path('/mnt/data/batch5baseline/b4redo')
EXPECTED_V3='177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d'
SCREENS={
'BackupScreen':'backup/BackupScreen.kt','SettingsScreen':'settings/SettingsScreen.kt','AboutScreen':'about/AboutScreen.kt','HelpScreen':'help/HelpScreen.kt','SupportScreen':'supportdeveloper/SupportDeveloperScreen.kt'
}
DARK={
'SetupScreen':'setup/SetupScreen.kt','LockScreen':'lock/LockScreen.kt','VaultListScreen':'vault/VaultListScreen.kt','EntryDetailScreen':'vault/EntryDetailScreen.kt','SettingsScreen':'settings/SettingsScreen.kt'
}
ALL_SCREEN_FILES=[
'setup/SetupScreen.kt','lock/LockScreen.kt','vault/VaultListScreen.kt','vault/EntryDetailScreen.kt','editor/EntryEditorScreen.kt',
'backup/BackupScreen.kt','settings/SettingsScreen.kt','about/AboutScreen.kt','help/HelpScreen.kt','supportdeveloper/SupportDeveloperScreen.kt']

def fail(msg): print('FAIL:',msg); return False
def check(cond,msg): return True if cond else fail(msg)

def strings():
    en=re.findall(r'<string name="([^"]+)"', (ROOT/'app/src/main/res/values/strings.xml').read_text())
    hi=re.findall(r'<string name="([^"]+)"', (ROOT/'app/src/main/res/values-b+hi/strings.xml').read_text())
    return len(en),len(hi),set(en)==set(hi)

def run_regression():
    p=subprocess.run([sys.executable,str(ROOT/'tools/all_fixes_regression.py')],cwd=ROOT,text=True,capture_output=True)
    ok=p.returncode==0 and '68/68 checks passed.' in p.stdout
    return ok,p.stdout.strip().splitlines()[-2:] if p.stdout.strip() else [p.stderr.strip()]

def screen_contract(name,rel):
    p=SRC/rel; s=p.read_text() if p.exists() else ''
    ok=True
    ok &= check(p.exists(),f'{name}: file exists')
    ok &= check('/**' in s and 'Spec §' in s,f'{name}: KDoc spec contract')
    ok &= check('hiltViewModel()' in s,f'{name}: Hilt ViewModel wiring')
    ok &= check('AppDimens.' in s,f'{name}: token dimensions')
    ok &= check(not re.search(r'\b\d+(?:\.\d+)?\.dp\b|\b\d+(?:\.\d+)?\.sp\b|Color\s*\(',s),f'{name}: no raw dp/sp/Color')
    refs=set(re.findall(r'R\.string\.([A-Za-z0-9_]+)',s))
    en=set(re.findall(r'<string name="([^"]+)"',(ROOT/'app/src/main/res/values/strings.xml').read_text()))
    ok &= check(not (refs-en),f'{name}: all R.string refs resolve')
    ok &= check('heading()' in s,f'{name}: heading semantics')
    ok &= check('focusGroup()' in s,f'{name}: focus order group')
    return ok

def animation_contracts():
    ok=True
    motion=(SRC/'components/AppMotion.kt').read_text()
    nav=(SRC/'navigation/VaultNavHost.kt').read_text()
    dialog=(SRC/'components/AppDialog.kt').read_text()
    copy=(SRC/'components/AppCopyField.kt').read_text()
    listitem=(SRC/'components/AppListItem.kt').read_text()
    theme=(SRC/'theme/Theme.kt').read_text()
    tests=[
      ('Screen transition','ScreenTransitionMs = 300' in motion and 'enterTransition' in nav and 'slideInHorizontally' in nav and 'fadeIn' in nav),
      ('List item enter','ListEnterMs = 200' in motion and 'AnimatedListItem' in listitem and 'slideInVertically' in motion and 'fadeIn' in motion),
      ('Dialog appear','DialogMs = 150' in motion and 'AnimatedDialogContent' in dialog and 'scaleIn' in motion and 'fadeIn' in motion),
      ('Copy feedback','CopyPulseMs = 200' in motion and 'copyPulse' in copy and 'scaleIn' in copy),
      ('Theme change','ThemeCrossfadeMs = 300' in motion and 'Crossfade(' in theme and 'ThemeCrossfadeMs' in theme),
    ]
    for n,c in tests: ok &= check(c,f'Animation: {n}')
    return ok

def accessibility():
    ok=True
    for rel in ALL_SCREEN_FILES:
        s=(SRC/rel).read_text()
        # Every IconButton in these screens is required to expose a nearby contentDescription.
        for m in re.finditer(r'IconButton\(',s):
            chunk=s[m.start():m.start()+900]
            if 'contentDescription' not in chunk and not re.search(r'Icon\([^\n]+,\s*[^\n]*(?:stringResource|R\.string)', chunk):
                ok &= fail(f'Accessibility: missing IconButton contentDescription in {rel}')
        ok &= check('heading()' in s,f'Accessibility: heading semantics {rel}')
        ok &= check('focusGroup()' in s,f'Accessibility: focus order {rel}')
    search=(SRC/'components/AppSearchBar.kt').read_text()
    ok &= check('label = { Text(placeholder) }' in search,'Accessibility: Vault search field label')
    for rel in ['backup/BackupScreen.kt','settings/SettingsScreen.kt','editor/EntryEditorScreen.kt']:
        s=(SRC/rel).read_text();
        for m in re.finditer(r'OutlinedTextField\(',s):
            chunk=s[m.start():m.start()+1100]
            ok &= check('label =' in chunk,f'Accessibility: TextField label in {rel}')
    # Static TalkBack contract: headings + labels + button descriptions exist; no runtime/device claim.
    return ok

def dark_contracts():
    ok=True
    for n,rel in DARK.items():
        s=(SRC/rel).read_text()
        ok &= check('Color(' not in s and not re.search(r'\b\d+(?:\.\d+)?\.dp\b|\b\d+(?:\.\d+)?\.sp\b',s),f'Dark mode: {n} token-only')
        ok &= check('MaterialTheme' in s,f'Dark mode: {n} MaterialTheme usage')
    return ok

def protected_unchanged():
    ok=True
    for d in ['app/src/main/java/pro/babasitaram/vault/core/crypto','app/src/main/java/pro/babasitaram/vault/core/model','app/src/main/java/pro/babasitaram/vault/core/security','app/src/main/java/pro/babasitaram/vault/data','app/src/main/java/pro/babasitaram/vault/domain']:
        w=ROOT/d; b=BASE/d
        for p in w.rglob('*') if w.exists() else []:
            if p.is_file():
                q=b/p.relative_to(w)
                if not q.exists() or hashlib.sha256(p.read_bytes()).digest()!=hashlib.sha256(q.read_bytes()).digest(): ok &= fail(f'Protected changed: {p.relative_to(ROOT)}')
        for q in b.rglob('*') if b.exists() else []:
            if q.is_file() and not (w/q.relative_to(b)).exists(): ok &= fail(f'Protected deleted: {q.relative_to(BASE)}')
    v=ROOT/'app/src/main/java/pro/babasitaram/vault/core/crypto/V3PayloadParser.kt'
    ok &= check(hashlib.sha256(v.read_bytes()).hexdigest()==EXPECTED_V3,'V3 hash unchanged')
    return ok

def adapter_removed():
    ok=True
    for d in ['BackupScreen','SettingsScreen','AboutScreen','HelpScreen','SupportScreen']:
        ok &= check(not (SRC/'screens'/d).exists(),f'Adapter removed: {d}')
    return ok

def main():
    en,hi,par=strings(); ok=True
    ok &= check(en==hi and par,f'String parity {en}/{hi}')
    reg,_=run_regression(); ok &= check(reg,'Regression 68/68')
    ok &= check(subprocess.run([sys.executable,str(ROOT/'tools/bracket_check.py')],cwd=ROOT,capture_output=True).returncode==0,'Bracket check 0')
    ok &= protected_unchanged(); ok &= adapter_removed(); ok &= animation_contracts(); ok &= dark_contracts(); ok &= accessibility()
    for n,r in SCREENS.items(): ok &= screen_contract(n,r)
    print('BATCH5 AUDIT', 'PASS' if ok else 'FAIL')
    return 0 if ok else 1

if __name__=='__main__': raise SystemExit(main())
