from pathlib import Path
import re, xml.etree.ElementTree as ET, hashlib, subprocess, sys
root=Path('.')
base='app/src/main/java/pro/babasitaram/vault/presentation'
targets={
'TOTPManagerScreen':'totpmanager/TotpManagerScreen.kt','NotesScreen':'notes/NotesScreen.kt','FilesScreen':'files/FilesScreen.kt','MobilesScreen':'mobiles/MobilesScreen.kt','HistoryScreen':'history/HistoryScreen.kt','BinScreen':'bin/BinScreen.kt','VaultHealthScreen':'vaulthealth/VaultHealthScreen.kt','SharingScreen':'sharing/SharingScreen.kt','EmergencyAccessScreen':'emergency/EmergencyScreen.kt'}
issues=[]
for name,rel in targets.items():
 p=root/base/rel; s=p.read_text()
 checks={
  'Hilt ViewModel':'hiltViewModel()',
  'state contract':'AppScreenState',
  'heading semantics':'AppHeadingText',
  'focus order':'focusGroup',
  'dark-mode tokens':'MaterialTheme.colorScheme',
  'localized UI':'stringResource(',
 }
 # Empty states: list screens use AppEmptyState; health/emergency have explicit empty paths.
 checks['empty state']= 'AppEmptyState' if name not in ('VaultHealthScreen','EmergencyAccessScreen') else ('health_no_entries' if name=='VaultHealthScreen' else 'emergency_not_configured')
 for label,needle in checks.items():
  if needle not in s: issues.append(f'{name}: missing {label}')
 for i,line in enumerate(s.splitlines(),1):
  if not line.strip().startswith('import ') and re.search(r'\b\d+(?:\.\d+)?\.dp\b|\b\d+(?:\.\d+)?\.sp\b|\bColor\s*\(',line):
   issues.append(f'{name}: hardcoded token at line {i}')
print('PER_SCREEN_CONTRACTS')
for name in targets: print(name, 'PASS' if not any(x.startswith(name+':') for x in issues) else 'FAIL')
# Localization resolution/parity
E={x.attrib['name'] for x in ET.parse(root/'app/src/main/res/values/strings.xml').getroot().findall('string')}
H={x.attrib['name'] for x in ET.parse(root/'app/src/main/res/values-b+hi/strings.xml').getroot().findall('string')}
refs=set()
for rel in targets.values(): refs |= set(re.findall(r'R\.string\.([A-Za-z0-9_]+)',(root/base/rel).read_text()))
missing=(refs-E)|(refs-H)
if missing: issues.append('Missing string refs: '+','.join(sorted(missing)))
if E!=H: issues.append('EN/HI string-name parity mismatch')
print('STRINGS',len(E),len(H),'PARITY',E==H,'MISSING',len(missing))
# V3 hash
v3=root/base.replace('presentation','../crypto') if False else root/'app/src/main/java/pro/babasitaram/vault/core/crypto/V3PayloadParser.kt'
h=hashlib.sha256(v3.read_bytes()).hexdigest(); expected='177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d'
print('V3_HASH',h,'UNCHANGED',h==expected)
if h!=expected: issues.append('V3 hash changed')
# Regression
r=subprocess.run(['python3','tools/all_fixes_regression.py'],capture_output=True,text=True)
print(r.stdout.strip().splitlines()[-1] if r.stdout.strip() else 'regression no output')
if r.returncode!=0: issues.append('Regression failed')
print('AUDIT_RESULT', 'PASS' if not issues else 'FAIL')
if issues:
 for x in issues: print('ISSUE',x)
 sys.exit(1)
