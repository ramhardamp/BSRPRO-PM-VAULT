from pathlib import Path
import hashlib, subprocess, sys, xml.etree.ElementTree as ET, re
ROOT=Path('.')
BASE=Path('/mnt/data/b6baseline/b4redo')
EXT=Path('/mnt/data/extwork/BSRPRO-Password-Manager')
EXPECTED_V3='177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d'
PROTECTED=['app/src/main/java/pro/babasitaram/vault/core/crypto','app/src/main/java/pro/babasitaram/vault/core/model','app/src/main/java/pro/babasitaram/vault/core/security','app/src/main/java/pro/babasitaram/vault/data','app/src/main/java/pro/babasitaram/vault/domain']
TARGETS=['totpmanager/TotpManagerScreen.kt','notes/NotesScreen.kt','files/FilesScreen.kt','mobiles/MobilesScreen.kt','history/HistoryScreen.kt','bin/BinScreen.kt','vaulthealth/VaultHealthScreen.kt','sharing/SharingScreen.kt','emergency/EmergencyScreen.kt']

def tree_hash(root, rel):
 p=root/rel; h=hashlib.sha256()
 for f in sorted(p.rglob('*')):
  if f.is_file(): h.update(str(f.relative_to(p)).encode()); h.update(hashlib.sha256(f.read_bytes()).digest())
 return h.hexdigest()

def run(cmd,cwd=ROOT):
 r=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True)
 if r.returncode: raise RuntimeError((r.stdout+r.stderr)[-3000:])
 return r.stdout

def main():
 # Android regression.
 out=run(['python3','tools/all_fixes_regression.py'])
 if '68/68 checks passed.' not in out: raise RuntimeError('regression not 68/68')
 # Strings + refs.
 E={x.attrib['name'] for x in ET.parse(ROOT/'app/src/main/res/values/strings.xml').getroot().findall('string')}
 H={x.attrib['name'] for x in ET.parse(ROOT/'app/src/main/res/values-b+hi/strings.xml').getroot().findall('string')}
 if E!=H: raise RuntimeError('string parity failed')
 refs=set()
 for rel in TARGETS: refs |= set(re.findall(r'R\.string\.([A-Za-z0-9_]+)',(ROOT/'app/src/main/java/pro/babasitaram/vault/presentation'/rel).read_text()))
 if not refs <= E: raise RuntimeError('missing string ref')
 # V3 + protected.
 v3=hashlib.sha256((ROOT/'app/src/main/java/pro/babasitaram/vault/core/crypto/V3PayloadParser.kt').read_bytes()).hexdigest()
 if v3!=EXPECTED_V3: raise RuntimeError('V3 hash changed')
 for rel in PROTECTED:
  if tree_hash(ROOT,rel)!=tree_hash(BASE,rel): raise RuntimeError('protected tree changed: '+rel)
 # Target token/contract scan.
 for rel in TARGETS:
  s=(ROOT/'app/src/main/java/pro/babasitaram/vault/presentation'/rel).read_text()
  for needle in ['AppScreenState','hiltViewModel()','AppHeadingText','focusGroup','stringResource(']:
   if needle not in s: raise RuntimeError(f'{rel} missing {needle}')
  if any(re.search(pat,line) for line in s.splitlines() if not line.strip().startswith('import ') for pat in [r'\b\d+(?:\.\d+)?\.dp\b',r'\b\d+(?:\.\d+)?\.sp\b',r'\bColor\s*\(']):
   raise RuntimeError(f'{rel} hardcoded token')
 # Font scaling static contract across all 28 screen files.
 run(['python3','tools/font_scaling_audit.py'])
 # Extension syntax + fixture compatibility.
 for f in ['src/import-export.js','setup.js','src/background.js']:
  run(['node','--check',f],cwd=EXT)
 run(['node','/mnt/data/extwork/test_batch6_backup.js'],cwd=EXT)
 s=(EXT/'src/background.js').read_text()
 if "schema:'BSRPRO.Vault.Payload', version:3, entries, folders" not in s: raise RuntimeError('extension auto-backup folders missing')
 s=(EXT/'src/import-export.js').read_text()
 if "app === 'BABASITARAMPro'" not in s: raise RuntimeError('extension manual V3 compatibility missing')
 return len(E)

if __name__=='__main__':
 try: print('CLEAN',main())
 except Exception as e: print('FAIL',e); sys.exit(1)
