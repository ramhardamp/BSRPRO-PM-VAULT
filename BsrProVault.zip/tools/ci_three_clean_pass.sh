#!/usr/bin/env bash
set -uo pipefail
PASS_ID="${1:?pass number required}"
LOG="ci-pass-${PASS_ID}.log"
: > "$LOG"
run() {
  echo ">>> $*" | tee -a "$LOG"
  "$@" 2>&1 | tee -a "$LOG"
  local rc=${PIPESTATUS[0]}
  if [[ $rc -ne 0 ]]; then
    echo "COMMAND FAILED rc=$rc: $*" | tee -a "$LOG"
    return "$rc"
  fi
}

run python3 tools/strict_compiler_hazard_audit.py || exit 1
run python3 tools/bracket_check.py || exit 1
run python3 tools/symbol_check.py || exit 1
run python3 tools/static_audit.py || exit 1
run python3 tools/all_fixes_regression.py || exit 1
run python3 tools/batch6_contract_audit.py || exit 1
run python3 tools/phase15m_regression.py || exit 1
run python3 tools/batch7_audit.py || exit 1
run python3 tools/font_scaling_audit.py || exit 1
run python3 tools/phase_smart_session_audit.py || exit 1

run ./gradlew compileDebugKotlin --no-daemon --stacktrace || exit 1
run ./gradlew compileReleaseKotlin --no-daemon --stacktrace || exit 1
run ./gradlew testDebugUnitTest --no-daemon --stacktrace || exit 1
run ./gradlew assembleDebug --no-daemon --stacktrace || exit 1
run ./gradlew assembleRelease --no-daemon --stacktrace || exit 1

DEBUG_APK="app/build/outputs/apk/debug/app-debug.apk"
RELEASE_APK="app/build/outputs/apk/release/app-release-unsigned.apk"
[[ -s "$DEBUG_APK" ]] || { echo "Missing $DEBUG_APK" | tee -a "$LOG"; exit 1; }
[[ -s "$RELEASE_APK" ]] || { echo "Missing $RELEASE_APK" | tee -a "$LOG"; exit 1; }
APKSIGNER="$ANDROID_HOME/build-tools/35.0.0/apksigner"
AAPT="$ANDROID_HOME/build-tools/35.0.0/aapt"
run "$APKSIGNER" verify --verbose "$DEBUG_APK" || exit 1
run "$AAPT" dump badging "$DEBUG_APK" || exit 1
run "$AAPT" dump badging "$RELEASE_APK" || exit 1
unzip -t "$DEBUG_APK" >/dev/null || exit 1
unzip -t "$RELEASE_APK" >/dev/null || exit 1

echo "PASS $PASS_ID CLEAN" | tee -a "$LOG"
