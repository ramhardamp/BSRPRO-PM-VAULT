from pathlib import Path
import hashlib,re,subprocess,xml.etree.ElementTree as ET
root=Path('/mnt/data/b4redo'); base=Path('/mnt/data/phase16f')
protected=['app/src/main/java/pro/babasitaram/vault/core/crypto','app/src/main/java/pro/babasitaram/vault/core/model','app/src/main/java/pro/babasitaram/vault/core/security','app/src/main/java/pro/babasitaram/vault/data','app/src/main/java/pro/babasitaram/vault/domain']
migrated=['setup/SetupScreen.kt','lock/LockScreen.kt','vault/VaultListScreen.kt','vault/EntryDetailScreen.kt','editor/EntryEditorScreen.kt']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def check():
    results=[]
    r=subprocess.run(['python3','tools/all_fixes_regression.py'],cwd=root,text=True,capture_output=True); results.append(r.returncode==0)
    r2=subprocess.run(['python3','tools/bracket_check.py'],cwd=root,text=True,capture_output=True); results.append(r2.returncode==0 and 'files with issues: 0' in r2.stdout)
    en={x.attrib['name'] for x in ET.parse(root/'app/src/main/res/values/strings.xml').getroot().findall('string')}; hi={x.attrib['name'] for x in ET.parse(root/'app/src/main/res/values-b+hi/strings.xml').getroot().findall('string')}; results.append(len(en)==947 and len(hi)==947 and en==hi)
    for rel in migrated:
        s=(root/'app/src/main/java/pro/babasitaram/vault/presentation'/rel).read_text(); refs=set(re.findall(r'R\.string\.([A-Za-z0-9_]+)',s)); results += [not (refs-en), not re.search(r'\b\d+\.dp\b',s), not re.search(r'\b\d+\.sp\b',s), 'Color(' not in s]
    results.append(sha(root/'app/src/main/java/pro/babasitaram/vault/core/crypto/V3PayloadParser.kt')=='177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d')
    changed=[]
    for pref in protected:
        bdir=base/pref; rdir=root/pref; files=set()
        if bdir.exists(): files |= {str(x.relative_to(base)) for x in bdir.rglob('*') if x.is_file()}
        if rdir.exists(): files |= {str(x.relative_to(root)) for x in rdir.rglob('*') if x.is_file()}
        for rel in files:
            bp=base/rel; rp=root/rel
            if bp.exists()!=rp.exists() or (bp.exists() and sha(bp)!=sha(rp)): changed.append(rel)
    results.append(not changed)
    results.append(all(not (root/'app/src/main/java/pro/babasitaram/vault/presentation/screens'/d).exists() for d in ['SetupScreen','LockScreen','VaultListScreen','EntryDetailScreen','EntryEditorScreen']))
    return all(results), r.stdout, r2.stdout, changed
for i in range(1,11):
    ok,reg,br,changed=check(); print(f'CLEAN AUDIT {i}/10: '+('PASS' if ok else 'FAIL'))
    if not ok:
        print(reg); print(br); print('protected',changed); raise SystemExit(1)
print('10 consecutive clean audits PASS')
