from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manager = (ROOT / 'app/src/main/java/pro/babasitaram/vault/data/backup/AutoBackupManager.kt').read_text()
settings = (ROOT / 'app/src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt').read_text()
model = (ROOT / 'app/src/main/java/pro/babasitaram/vault/core/model/VaultSettings.kt').read_text()
viewmodel = (ROOT / 'app/src/main/java/pro/babasitaram/vault/presentation/backup/BackupViewModel.kt').read_text()
screen = (ROOT / 'app/src/main/java/pro/babasitaram/vault/presentation/backup/BackupScreen.kt').read_text()
notes = (ROOT / 'app/src/main/java/pro/babasitaram/vault/presentation/notes/NotesScreen.kt').read_text()

checks = {
    'SAF tree URI is part of settings model': 'backupFolderUri: String' in model,
    'SAF tree URI is persisted and restored': 'BACKUP_FOLDER_URI' in settings and 'backupFolderUri = this[BACKUP_FOLDER_URI]' in settings,
    'folder picker persists grant': 'OpenDocumentTree()' in screen and 'takePersistableUriPermission' in screen,
    'selected folder URI can be saved from UI': 'fun setBackupFolder(uri: Uri)' in viewmodel,
    'SAF staged write is validated before publish': manager.index('verifySafDocument(staged)') < manager.index('renameDocument(resolver, staged, name)'),
    'SAF previous backup has recovery rename path': 'BSRPRO-Recovery-' in manager and 'oldRenamed' in manager,
    'revoked tree permission clears stale selection': 'backupFolderUri = ""' in manager,
    'MediaStore does not truncate existing backup in place': 'overwriteInPlace(' not in manager,
    'automatic backup cleans managed duplicates only after verified publish': (
        'cleanupOldBackups()' in manager and
        'isManagedOldName' in manager and
        'verifyPersistedBackup()' in manager and
        manager[manager.index('suspend fun backupNow()'):manager.index('private suspend fun write(')].index('verifyPersistedBackup()') <
        manager[manager.index('suspend fun backupNow()'):manager.index('private suspend fun write(')].index('cleanupOldBackups()')
    ),
    'Notes detail has bounded scroll region': 'verticalScroll(rememberScrollState())' in notes,
}
for label, passed in checks.items():
    print(('PASS' if passed else 'FAIL') + ': ' + label)
if not all(checks.values()):
    raise SystemExit(1)
print(f'{len(checks)} targeted static regression checks passed (not an Android compile/device test).')


# FIX6/FIX7 focused source checks
root = Path(__file__).resolve().parents[1]
repo = (root / "app/src/main/java/pro/babasitaram/vault/data/repository/VaultRepositoryImpl.kt").read_text()
contract = (root / "app/src/main/java/pro/babasitaram/vault/domain/repository/VaultRepository.kt").read_text()
drawer = (root / "app/src/main/java/pro/babasitaram/vault/presentation/navigation/DrawerCountsViewModel.kt").read_text()
nav = (root / "app/src/main/java/pro/babasitaram/vault/presentation/navigation/VaultNavHost.kt").read_text()
mob = (root / "app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesViewModel.kt").read_text()
notes_screen = (root / "app/src/main/java/pro/babasitaram/vault/presentation/notes/NotesScreen.kt").read_text()
mobiles_screen = (root / "app/src/main/java/pro/babasitaram/vault/presentation/mobiles/MobilesScreen.kt").read_text()
assertion_checks = [
    ("FIX6 repository count contract", 'val mobileCount: StateFlow<Int>' in contract and '(mobile.isNotBlank() || phone.isNotBlank())' in repo and '!isHiddenVault' in repo),
    ("FIX6 recordType-only mobile excluded", 'recordType.equals("mobile", true)' not in repo.split('isCountableMobile', 1)[1].split('private suspend fun persist', 1)[0]),
    ("FIX6 drawer consumes canonical mobile count", 'repository.mobileCount' in drawer and 'mobiles = mobileCount' in drawer),
    ("FIX6 badge contract", 'count.takeIf { it > 0 }?.toString()' in drawer),
    ("FIX6 mobiles screen excludes hidden/blank", '!it.isHiddenVault' in mob and '(it.mobile.isNotBlank() || it.phone.isNotBlank())' in mob),
    ("FIX7 notes row-anchored menu", 'Box(Modifier.fillMaxWidth()) {' in notes_screen and 'stringResource(R.string.p15_copy)' in notes_screen),
    ("FIX7 mobiles row-anchored menu", 'Box(Modifier.fillMaxWidth()) {' in mobiles_screen and 'stringResource(R.string.p15_share)' in mobiles_screen),
    ("FIX7 mobile share uses QuickShare dialog", 'onShare = { id -> quickShareId = id }' in nav),
]
for label, ok in assertion_checks:
    print(('PASS' if ok else 'FAIL') + ': ' + label)
if not all(ok for _, ok in assertion_checks):
    raise SystemExit(1)
print(f"{len(assertion_checks)} focused FIX6/FIX7 checks passed.")
