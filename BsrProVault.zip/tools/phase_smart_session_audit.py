from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT=Path('.')
JAVA=ROOT/'app/src/main/java/pro/babasitaram/vault'
TEST=ROOT/'app/src/test/java/pro/babasitaram/vault'
checks=[]

def ok(name, cond, detail=''):
    checks.append((name, bool(cond), detail))

def read(rel):
    return (ROOT/rel).read_text()

vault_settings=read('app/src/main/java/pro/babasitaram/vault/core/model/VaultSettings.kt')
settings_ds=read('app/src/main/java/pro/babasitaram/vault/data/local/preferences/SettingsDataStore.kt')
session=read('app/src/main/java/pro/babasitaram/vault/core/crypto/SessionKeyStore.kt')
autolock=read('app/src/main/java/pro/babasitaram/vault/core/security/AutoLockController.kt')
bio_store=read('app/src/main/java/pro/babasitaram/vault/core/security/BiometricSessionKeyStore.kt')
bio=read('app/src/main/java/pro/babasitaram/vault/core/security/BiometricAuthenticator.kt')
autofill_act=read('app/src/main/java/pro/babasitaram/vault/autofill/AutofillAuthActivity.kt')
autofill_service=read('app/src/main/java/pro/babasitaram/vault/autofill/VaultAutofillService.kt')
root_vm=read('app/src/main/java/pro/babasitaram/vault/presentation/root/RootViewModel.kt')
lock_vm=read('app/src/main/java/pro/babasitaram/vault/presentation/lock/LockViewModel.kt')
settings_screen=read('app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsScreen.kt')
settings_vm=read('app/src/main/java/pro/babasitaram/vault/presentation/settings/SettingsViewModel.kt')
settings_use=read('app/src/main/java/pro/babasitaram/vault/domain/usecase/SettingsUseCases.kt')
vault_use=read('app/src/main/java/pro/babasitaram/vault/domain/usecase/VaultSessionUseCases.kt')
app=read('app/src/main/java/pro/babasitaram/vault/BsrApplication.kt')

# Defaults/configuration
ok('24h normal session default', 'val vaultSessionSeconds: Int = 24 * 60 * 60' in vault_settings)
ok('30m background grace default', 'val backgroundGraceSeconds: Int = 30 * 60' in vault_settings)
ok('Quick Autofill default enabled', 'val quickAutofillEnabled: Boolean = true' in vault_settings)
ok('Sensitive reauth default enabled', 'val sensitiveActionReauth: Boolean = true' in vault_settings)
ok('Manual lock option', 'R.string.b5_settings_manual_lock' in settings_screen and 'VaultSettings.AUTO_LOCK_NEVER' in settings_screen)
vault_pairs=[('5 minutes','R.string.b5_settings_5_minutes','5 * 60'),('15 minutes','R.string.b5_settings_15_minutes','15 * 60'),('30 minutes','R.string.b5_settings_30_minutes','30 * 60'),('1 hour','R.string.b5_settings_1_hour','60 * 60'),('4 hours','R.string.b5_settings_4_hours','4 * 60 * 60'),('12 hours','R.string.b5_settings_12_hours','12 * 60 * 60'),('24 hours','R.string.b5_settings_24_hours','24 * 60 * 60')]
for label, res, seconds in vault_pairs:
    ok(f'Vault setting {label}', f'{res} to {seconds}' in settings_screen)
for label, res, seconds in vault_pairs[:5]:
    ok(f'Background setting {label}', f'{res} to {seconds}' in settings_screen)

# Session correctness
ok('Session password remains process-local', 'private var password: CharArray? = null' in session)
ok('Absolute session expiry tracked', 'expiresAtElapsedMs' in session and 'expiresAtWallMs' in session)
ok('Session validation clears expired state', 'clearLocked()' in session and 'if (nowElapsedMs < expiresAtElapsedMs)' in session)
ok('Temporary password copies wiped', "copy.fill('\\u0000')" in session)
ok('Process restore method exists', 'fun restore(' in session)

# Lifecycle/expiry
ok('Process lifecycle observer exists', 'ProcessLifecycleOwner.get().lifecycle.addObserver' in app)
ok('Background starts grace handling', 'autoLock.onBackgrounded()' in app and 'autoLock.onForegrounded()' in app)
ok('Activity destroy does not lock session', 'scope.cancel()' in autofill_act and 'session.lock()' not in autofill_act)
ok('Absolute expiry locks vault', 'if (!session.hasValidSession(clock()))' in autolock and 'lockVault("Session expired")' in autolock)
ok('Background expiry locks vault', autolock.count('lockVault("Session expired")') >= 2)

# Key A/Key B separation
ok('Key A alias untouched', 'bsrpro_master_wrap_key_v1' in read('app/src/main/java/pro/babasitaram/vault/core/crypto/MasterKeyManager.kt'))
ok('Key B dedicated alias', 'bsrpro_biometric_session_key_v2' in bio_store)
ok('Key B requires auth', '.setUserAuthenticationRequired(true)' in bio_store)
ok('Key B invalidates on biometric enrollment', '.setInvalidatedByBiometricEnrollment(true)' in bio_store)
ok('CryptoObject used for biometric unlock', 'BiometricPrompt.CryptoObject(cipher)' in bio)
ok('Device credential fallback is available', 'DEVICE_CREDENTIAL' in bio and 'FallbackRequested' in bio and 'p18_common_use_device_pin' in lock_vm)
ok('Legacy credential not used by Autofill', 'loadBiometricCredential' not in autofill_act and 'hasBiometricCredential' not in autofill_act)
ok('Legacy credential only cleanup/migration', 'hasLegacyCredential' in bio_store and 'clearLegacyCredential' in bio_store)
ok('No plaintext master password persistence in Key B store', 'biometric_credential_v2' in bio_store and 'cipher.doFinal(bytes)' in bio_store and 'SECURE_CREDENTIAL] = Base64.getEncoder().encodeToString(envelope)' in bio_store)

# Persistent restore
ok('Persistent restore use case present', (ROOT/'app/src/main/java/pro/babasitaram/vault/domain/usecase/RestorePersistedSessionUseCase.kt').exists())
restore=read('app/src/main/java/pro/babasitaram/vault/domain/usecase/RestorePersistedSessionUseCase.kt')
ok('Restore checks expiry', 'now >= metadata.expiresAtWallMs' in restore)
ok('Restore checks background grace', 'backgroundedAtWallMs' in restore and 'backgroundGraceSeconds' in restore)
ok('Restore can require auth', 'Result.RequiresAuthentication' in restore)
ok('Root invokes persistent restore', 'restoreSession()' in root_vm)
ok('Root startup cannot stick on restore error', 'runCatching' in root_vm and 'withTimeoutOrNull' in root_vm and 'restoreSession()' in root_vm)

# Autofill behavior
ok('Autofill reuses valid in-memory session', 'cfg.quickAutofillEnabled && session.hasValidSession()' in autofill_act)
ok('Autofill attempts persisted session restore', 'restoreSession(forAutofill = true)' in autofill_act)
ok('Autofill biometric decrypt path uses Key B', 'prepareDecryptCipher()' in autofill_act and 'decryptPrepared(prepared)' in autofill_act)
ok('Autofill cancel never locks', 'cancelAndFinish()' in autofill_act and 'session.lock()' not in autofill_act)
ok('Autofill service respects quick session toggle', 'cfg.quickAutofillEnabled && wasUnlocked && session.hasValidSession()' in autofill_service)
ok('Autofill service locks expired session', 'lockVault("Session expired")' in autofill_service)

# Settings persistence
for key in ['VAULT_SESSION','BACKGROUND_GRACE','QUICK_AUTOFILL','SENSITIVE_REAUTH']:
    ok(f'DataStore persists {key}', key in settings_ds)
ok('Settings UI has session controls', 'Vault auto-lock' in settings_screen and 'Background timeout' in settings_screen)
ok('Quick Autofill UI toggle', 'Quick Autofill session' in settings_screen)
ok('Sensitive reauth UI toggle', 'Sensitive action re-authentication' in settings_screen)

# Reset / password change cleanup
ok('Reset clears Key B + session metadata', 'biometricStore.clearAllCredentials()' in settings_use)
ok('Master password change clears Key B', 'biometricStore.clearSecureCredential()' in settings_use and 'biometricEnabled = false' in settings_use)
ok('Unlock stores session metadata for biometric restore', 'persistedSession.saveSessionMetadata' in vault_use)
ok('Manual lock clears persisted session metadata', 'persistedSession.clearSessionMetadata()' in vault_use)

# Secret logging
sensitive_logs=[]
for p in JAVA.rglob('*.kt'):
    txt=re.sub(r'//[^\n]*','',p.read_text())   # trailing comments may mention "password"; only code counts
    # activityLog.record(...) takes fixed English labels only (no values), so it is not a secret-logging site
    for m in re.finditer(r'(?<![A-Za-z])(Timber|Log)\.[a-zA-Z]+\([^\n]*(password|secret|credential|token)', txt, re.I):
        sensitive_logs.append(f'{p}:{txt.count(chr(10),0,m.start())+1}')
ok('No obvious sensitive debug logging', not sensitive_logs, '; '.join(sensitive_logs[:5]))

# Required test updates
bio_test=read('app/src/test/java/pro/babasitaram/vault/core/security/BiometricAuthenticatorTest.kt')
auto_test=read('app/src/test/java/pro/babasitaram/vault/core/security/AutoLockControllerTest.kt')
sess_test=read('app/src/test/java/pro/babasitaram/vault/core/crypto/SessionKeyStoreTest.kt')
ok('Biometric fallback regression test updated', 'negative button requests device credential fallback' in bio_test and 'AuthResult.FallbackRequested' in bio_test)
ok('Session absolute expiry test', 'session expires at the configured absolute lifetime' in sess_test)
ok('Session restore test', 'process restore recomputes remaining session from wall clock' in sess_test)
ok('AutoLock constructor tests updated', 'BiometricSessionKeyStore>(relaxed = true)' in auto_test)
ok('AutoLock absolute expiry test', 'absolute session expiry locks even without a background transition' in auto_test)

# Structural balance, simple lexical check.
for p in list(JAVA.rglob('*.kt')):
    txt=p.read_text()
    # strip strings/comments loosely for brace count sanity
    code=re.sub(r'"""(.*?)"""','',txt,flags=re.S)
    code=re.sub(r"'(?:\\.|[^'\\\n])'","''",code)
    code=re.sub(r'"(?:\\.|[^"\\\n])*"','""',code)
    code=re.sub(r'//.*','',code)
    if code.count('{') != code.count('}'):
        checks.append((f'brace balance: {p}', False, f"{{={code.count('{')}}}={code.count('}')}") )
# XML parse of manifest/resources modified around settings
for rel in ['app/src/main/AndroidManifest.xml','app/src/main/res/values/strings.xml']:
    try:
        ET.parse(ROOT/rel)
        ok(f'XML valid: {rel}', True)
    except Exception as e:
        ok(f'XML valid: {rel}', False, str(e))

failed=[c for c in checks if not c[1]]
print(f'checks={len(checks)} passed={len(checks)-len(failed)} failed={len(failed)}')
for name, good, detail in checks:
    print(('PASS' if good else 'FAIL')+' | '+name+((' | '+detail) if detail else ''))
raise SystemExit(1 if failed else 0)
