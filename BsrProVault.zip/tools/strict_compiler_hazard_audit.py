from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'app' / 'src' / 'main' / 'java'
issues = []

KOTLIN_FILES = list(SRC.rglob('*.kt'))

# 1) Composable calls must not be placed in ordinary callback/remember lambdas.
# These patterns caused real GitHub compiler failures in this project.
callback_keys = (
    'onClick = {', 'onCheckedChange = {', 'onValueChange = {',
    'onDismissRequest = {', 'onRetry = {', 'onConfirm = {',
    'onShare = {', 'onEdit = {', 'onBack = {', 'onOpen = {', 'onAdd = {'
)
for p in KOTLIN_FILES:
    text = p.read_text(encoding='utf-8', errors='replace')
    for key in callback_keys:
        start = 0
        while True:
            i = text.find(key, start)
            if i < 0:
                break
            # Check the immediate lambda body only, accounting for nested parentheses very conservatively.
            depth = 0
            j = i + len(key)
            while j < len(text) and j < i + 900:
                ch = text[j]
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    if depth == 0:
                        break
                    depth -= 1
                j += 1
            body = text[i:j]
            for bad in ('stringResource(', 'MaterialTheme.', 'LocalContext.current', 'rememberScrollState('):
                if bad in body:
                    line = text.count('\n', 0, i) + 1
                    issues.append(f'{p.relative_to(ROOT)}:{line}: {key.strip()} contains {bad}')
            start = i + len(key)

    # remember lambdas
    for m in re.finditer(r'\bremember(?:Saveable)?\s*(?:\([^\n{}]*\))?\s*\{', text):
        i = m.start()
        j = i + m.group(0).__len__()
        depth = 0
        while j < len(text) and j < i + 900:
            ch = text[j]
            if ch == '{':
                depth += 1
            elif ch == '}':
                if depth == 0:
                    break
                depth -= 1
            j += 1
        body = text[i:j]
        for bad in ('stringResource(', 'MaterialTheme.', 'LocalContext.current'):
            if bad in body:
                line = text.count('\n', 0, i) + 1
                issues.append(f'{p.relative_to(ROOT)}:{line}: remember lambda contains {bad}')

    # 2) Extension import hygiene that directly caused recent compiler failures.
    if 'toArgb()' in text and not re.search(r'^import\s+androidx\.compose\.ui\.graphics\.toArgb\s*$', text, re.M):
        line = text.count('\n', 0, text.find('toArgb()')) + 1
        issues.append(f'{p.relative_to(ROOT)}:{line}: toArgb() used without androidx.compose.ui.graphics.toArgb import')

    if re.search(r'^import\s+androidx\.compose\.foundation\.lazy\.item\s*$', text, re.M):
        issues.append(f'{p.relative_to(ROOT)}: invalid LazyColumn item import')

    # 3) Known top-level AppScreenState mistake: the state content lambda is zero-arg.
    if re.search(r'AppScreenState\([^\n]*\)\s*\{\s*[A-Za-z_]\w*\s*->', text):
        line = text.count('\n', 0, text.find('AppScreenState(')) + 1
        issues.append(f'{p.relative_to(ROOT)}:{line}: AppScreenState content lambda must be parameterless')

    # 4) Heterogeneous six-flow combine inference trap in this codebase.
    if re.search(r'combine\s*\([^\n]*,[^\n]*,[^\n]*,[^\n]*,[^\n]*,[^\n]*\)\s*\{\s*[^\n,]+\s*,\s*[^\n,]+\s*,\s*[^\n,]+\s*,\s*[^\n,]+\s*,\s*[^\n,]+\s*,', text):
        line = text.count('\n', 0, text.find('combine')) + 1
        issues.append(f'{p.relative_to(ROOT)}:{line}: six-input heterogeneous combine lambda; group inputs into typed combines')

    # 5) Kotlin local delegated-property smart-cast hazard. Kotlin does not allow
    # smart casts on local delegated properties (e.g. `val icon by produceState<Bitmap?>`).
    # Snapshot the delegated value into a normal local before a null-check/use pair.
    delegated_names = re.findall(r'\bval\s+([A-Za-z_]\w*)\s+by\s+(?:produceState|derivedStateOf|remember)\b', text)
    for name in delegated_names:
        if re.search(rf'\bif\s*\(\s*{re.escape(name)}\s*!=\s*null\s*\)\s*(?:[A-Za-z_][A-Za-z0-9_]*\s*=\s*)?(?:[A-Za-z_][A-Za-z0-9_]*\.)*{re.escape(name)}\.', text):
            line = text.count('\n', 0, text.find(f'val {name}')) + 1
            issues.append(f'{p.relative_to(ROOT)}:{line}: delegated local `{name}` is used via null-check + member access; snapshot it into a plain local first')

    # 6) Project shared composables must be imported when referenced outside their
    # declaring package. This catches the exact missing AppEmptyState/AppErrorState
    # class of compile failures before GitHub CI.
    shared_composables = {
        'AppEmptyState', 'AppErrorState', 'AppLoadingState', 'AppScreenState',
    }
    if 'package pro.babasitaram.vault.presentation.components' not in text:
        for symbol in shared_composables:
            if re.search(rf'\b{symbol}\s*\(', text) and not re.search(rf'^import\s+pro\.babasitaram\.vault\.presentation\.components\.{symbol}\s*$', text, re.M):
                line = text.count('\n', 0, text.find(symbol)) + 1
                issues.append(f'{p.relative_to(ROOT)}:{line}: {symbol}() used without its project-component import')

# 5) Exact-count regression: tests and production code must agree; no 999+ cap in code.
all_code = '\n'.join(p.read_text(encoding='utf-8', errors='replace') for p in ROOT.rglob('*.kt'))
if '999+' in all_code:
    issues.append('project: hardcoded 999+ found in Kotlin source/tests')
for n, expected in ((0, 'null'), (1, '"1"'), (999, '"999"'), (1000, '"1000"'), (3780, '"3780"')):
    if n == 0:
        continue
    # Only enforce presence of exact boundary expectations when a badge test exists.

# 6) VaultList row typing regression.
vault_list = ROOT / 'app/src/main/java/pro/babasitaram/vault/presentation/vault/VaultListScreen.kt'
if vault_list.exists():
    t = vault_list.read_text(encoding='utf-8', errors='replace')
    if 'ListRow.Header' in t and re.search(r'else\s+buildList\s*\{', t):
        issues.append('VaultListScreen.kt: heterogeneous ListRow buildList must have explicit ListRow type')

if issues:
    print('STRICT_COMPILER_HAZARD_AUDIT: FAIL')
    for issue in issues:
        print(' -', issue)
    sys.exit(1)

print(f'STRICT_COMPILER_HAZARD_AUDIT: PASS ({len(KOTLIN_FILES)} Kotlin files scanned)')
