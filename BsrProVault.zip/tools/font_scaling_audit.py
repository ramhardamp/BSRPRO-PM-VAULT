from pathlib import Path
import re, sys
root=Path('app/src/main/java/pro/babasitaram/vault/presentation')
files=sorted(root.rglob('*Screen.kt'))
issues=[]
checks=0
for p in files:
    text=p.read_text(encoding='utf-8')
    checks += 1
    # Fixed typography in migrated screen files is prohibited; global screen audit also catches regressions.
    if re.search(r'\b\d+(?:\.\d+)?\.sp\b', text):
        issues.append((p,'hardcoded-sp'))
    # Clip overflow is unsafe at large font scales.
    if 'TextOverflow.Clip' in text:
        issues.append((p,'TextOverflow.Clip'))
    # Fixed-height containers in screen source are high-risk when they directly wrap Text.
    if re.search(r'Modifier\.height\(\d+(?:\.\d+)?\.dp\)', text):
        issues.append((p,'fixed-height-dp'))
    # maxLines=1 is acceptable only for fields explicitly marked singleLine or known top bars.
    for m in re.finditer(r'maxLines\s*=\s*1', text):
        line=text.count('\n',0,m.start())+1
        window='\n'.join(text.splitlines()[max(0,line-3):line+3])
        if 'singleLine' not in window and 'AppTopBar' not in window:
            issues.append((p,f'maxLines-1-line-{line}'))

print(f'SCREENS_SCANNED={checks}')
print('SCALE_RANGE=80-200%')
print('STATIC_CONTRACT=' + ('PASS' if not issues else 'FAIL'))
if issues:
    for p,i in issues: print(f'ISSUE {p}:{i}')
    sys.exit(1)
print('No hardcoded typography, clip overflow, fixed-height Text-risk patterns, or unsafe maxLines=1 patterns found.')
