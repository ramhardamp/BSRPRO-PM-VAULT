# BSRPRO Vault — Developer Handoff (Single Documentation File)

**Audit/update date:** 5 October 2026  
**Source:** BsrProVault-Phase16G-ANDROID-SOURCE-NOWRAPPER(1).zip  
**Current version:** versionCode **30**, versionName **1.0.0**

## 1. Purpose of this file

Ye project ka **single developer documentation / handoff file** hai. Purane phase reports, roadmaps, duplicated QA/audit markdown aur report JSON ko is handoff me consolidate karke project se remove kiya gaya hai.

**Important:** documentation cleanup ke saath is final candidate me sirf compiler-fix source files aur compiler-hazard audit script update kiye gaye hain. Protected crypto/model/security/data/domain logic, test fixtures, CI workflow aur UI preview assets ko intentionally nahi badla gaya.

**MANDATORY SINGLE-DOCUMENT RULE (Developer/AI):**
- Project documentation/status ke liye **sirf `DEVELOPER_HANDOFF.md`** allowed hai.
- Koi naya `PHASE*.md`, `FIX*.md`, `*_REPORT.md`, `QA*.md`, `ROADMAP*.md`, `AUDIT*.md`, `FINAL_*.md`, `README*.md`, handoff/report `.json`, ya duplicate documentation file **create/update nahi karni hai**.
- Har future bug fix, regression, pending item, build result, test result, decision aur developer instruction **isi `DEVELOPER_HANDOFF.md` me update** करनी है.
- Purani documentation banane ki zarurat ho to naya file mat banao; isi file me dated section/update add karo.
- **Expected result: ZIP me exactly one documentation markdown file — `DEVELOPER_HANDOFF.md`.**

## 2. Current project snapshot

| Item | Current status |
|---|---|
| Android source Kotlin files | 204 |
| Unit-test Kotlin files | 47 |
| AGP | 8.5.2 |
| Kotlin | 2.0.20 |
| KSP | 2.0.20-1.0.25 |
| Java/JVM | 17 |
| Gradle | 8.7 target in CI |
| compileSdk / targetSdk | 35 / 35 |
| minSdk | 26 |
| EN / HI strings | 1089 / 1089 |
| String-key parity | PASS (1089 / 1089) |
| V3PayloadParser SHA-256 | `177529c15e0e11f5ad3ba7fbd8a0d5a8e5e20c364e3f5a189e5268084eb9d92d` |
| Gradle wrapper scripts/JAR in supplied ZIP | **Missing**; only wrapper properties present |
| Real Android compile in this cleanup environment | **Not executed** |
| Device/emulator runtime in this cleanup environment | **Not executed** |
| Latest CI error round fixed | **Round 2 — 4 reported + 1 latent sibling issue fixed** |
| Static clean passes after Round 2 | **3/3 PASS** |
| Protected crypto/model/security/data/domain hashes vs source ZIP | **UNCHANGED / PASS** |
| Documentation markdown files in final candidate | **1 — `DEVELOPER_HANDOFF.md` only** |

## 3. FIXED REPORT — source level

Neeche woh fixes hain jo current source/report history me completed hain aur current source-level audits se revalidated hain.

### 3.1 Core data / crypto safety

**Issue:** App-login aur website-login data mix hone ka risk.  
**Fix:** `type` handling, `VaultEntry.isAppLogin` derivation, app-login export filtering option and dedicated app-login UI/filter.  
**Logic:** App entry (`appPackage`) aur website entry (`url`) ko merge nahi kiya gaya; existing schema/crypto unchanged.

**Issue:** Backup duplicate files / overwrite se data-loss risk.  
**Fix:** canonical `BSRPRO.Vault`, staged `MediaStore`/SAF write, read-back validation, publish ke baad hi cleanup, undecryptable files preserve.  
**Logic:** validation fail ho to cleanup nahi hota. Existing vault ko in-place truncate nahi kiya jata.

**Issue:** Large internal vault payload.  
**Fix:** large internal plaintext ko `BSRZ1:` + gzip + Base64 form me pack kiya gaya; 64 MB unpack cap rakha gaya.  
**Logic:** marker na ho to legacy plain JSON read hota hai; V3/KDF/schema constants nahi badle.

**Issue:** Auto-restore se deleted records wapas aa sakte the.  
**Fix:** auto-import sirf empty vault + empty Bin + no pending backup condition me, merge-only aur one-time.  
**Logic:** replace/delete operation nahi hota.

### 3.2 Backup / restore

**Issue:** Backup flow confusing tha aur duplicate/recovery files badh rahe the.  
**Fix:** canonical filename, folder selection persistence, staged publish, verified cleanup, restore diagnostics, restore snapshot/journal path.  
**Logic:** failure par old data ko preserve/rollback evidence maintain karne ki design hai.

**Still important:** Android 10+ provider-specific single-file behavior, process-kill recovery boundaries aur real-device restore behavior runtime test se certify karna baaki hai.

### 3.3 Authentication / PIN / biometric

**Issue:** Biometric-less devices par Secure Share/unlock atak sakta tha.  
**Fix:** weak biometric + device credential fallback; Key B dedicated session key path; master-password fallback.  
**Logic:** Key A ko migrate/replace nahi kiya gaya.

**Issue:** Sharing aur Hidden Vault ke liye alag PIN stores.  
**Fix:** `sensitive_action_pin_v1` unified store; legacy hidden-vault PIN first valid use par migrate; set/change/remove ke liye master-password verification.  
**Logic:** Entry PIN (`appPin`) isse alag hai.

**Issue:** PIN-only app login autofill detect nahi hota tha.  
**Fix:** 4–6 digit numeric PIN detection, dedicated PIN-only dataset.  
**Logic:** positional fallback aur metadata matching preserved.

**Issue:** Startup/session loop.  
**Fix:** session restore timeout (`4s`) plus failure par Locked/Setup state.  
**Logic:** restore failure loading screen ko indefinitely block nahi karta.

### 3.4 Navigation / list / performance

**Issue:** Vault tab wrong detail screen par ja sakta tha.  
**Fix:** Vault root navigation with `popBackStack`, `launchSingleTop`, `restoreState=false`.

**Issue:** 300+ entries par list/search performance.  
**Fix:** 50-row render paging, 300ms search debounce, background filtering/sorting, `derivedStateOf`, Room indices, immutable entry model.

**Issue:** Notes content list me unnecessarily render hota tha.  
**Fix:** list me title-only; detail me full scrollable note.

**Issue:** 3-dot menus new page kholte the.  
**Fix:** row-anchored `DropdownMenu` pattern across relevant lists.

**Issue:** Drawer badge `999+` par cap tha.  
**Fix:** exact counts show hote hain, including 999, 1000, 3780.

### 3.5 UI / UX / accessibility source contracts

**Issue:** UI spacing/color/typography inconsistent thi.  
**Fix:** central color, typography, spacing, shape and elevation tokens; shared components; bottom nav/drawer sizing; dark-mode/accessibility semantics.

**Issue:** Loading/empty/error branding inconsistency.  
**Fix:** shared loading/error/empty components; BSRPRO logo/Lottie loading asset present in source.

**Issue:** Localization hardcoded English.  
**Fix:** UI literals moved to string resources; EN/HI key parity verified.

**Important:** rendered UI, font scaling and TalkBack runtime behavior are still not device-certified.

### 3.6 LATEST GITHUB COMPILE ERROR FIXES — 5 October 2026

The latest reported `:app:compileDebugKotlin` errors were reproduced at source inspection level and patched together so the same round does not leave a known sibling hazard behind.

### Error 1 — `FilesScreen.kt:165`
**Issue:** `formatSize()` was a non-`@Composable` helper but called `stringResource()`, causing `@Composable invocations can only happen from the context of a @Composable function`.

**Fix:** `formatSize(size, unavailableLabel)` now receives the already-resolved localized label from the composable caller. The separate `shareFile()` helper was audited at the same time because it had the same `stringResource()` misuse. `shareFile()` now receives the chooser title as a normal `String`.

**Status:** **FIXED (source-level)**.

### Error 2 — `StartupSplash.kt:51`
**Issue:** `R.raw.bsr_loading` failed with `Unresolved reference 'raw'` because the required `res/raw/bsr_loading.json` asset was absent from the cleaned ZIP.

**Fix:** restored the original `app/src/main/res/raw/bsr_loading.json` asset and kept the existing Lottie splash implementation.

**Status:** **FIXED (resource/source-level)**.

### Error 3 — `SettingsScreen.kt:317`
**Issue:** `stringResource()` was used directly inside the `onCopy` callback argument while building `RecoveryKeyDialog`, which is not a composable callback context.

**Fix:** resolve `b5_settings_recovery_key_copy` into `recoveryKeyCopyLabel` in the surrounding `@Composable` scope, then pass the captured `String` to the callback.

**Status:** **FIXED (source-level)**.

### Error 4 — `SetupScreen.kt:110`
**Issue:** `BackupFolderCard(state.backupFolderUri, !state.busy) { ... }` bound the trailing lambda ambiguously against the function signature, producing both `No value passed for parameter 'onChange'` and `Function0<Unit>` vs `Modifier` mismatch.

**Fix:** changed the call to explicit named arguments: `folderUri`, `enabled`, `onChange`, `modifier`.

**Status:** **FIXED (source-level)**.

**Build result after these patches:** local environment has no system `gradle` executable and the supplied project ZIP intentionally has no Gradle wrapper JAR/scripts, so a real `compileDebugKotlin` was **not executed here**. CI/GitHub must rerun the compiler gate before calling this compiler-verified.

## 3.6 Compiler-error fixes already applied

Current source contains the fixes from previous GitHub compiler-error rounds. Examples:

- `SharingScreen.kt`: `Color.toArgb()` ke liye `androidx.compose.ui.graphics.toArgb` import present.
- `VaultListViewModel.kt`: heterogeneous 6-flow `combine` ko typed 3+3 + 2-flow construction me split kiya.
- `VaultHealthScreen.kt`, `EmergencyScreen.kt`, `AboutScreen.kt`, `SupportDeveloperScreen.kt`: invalid `androidx.compose.foundation.lazy.item` import removed.
- `AppScreenState` misuse: content lambda ko zero-argument composable contract ke saath restore kiya.
- Missing imports: `AppDimens`, `stringResource`, `remember`, `viewModelScope`, layout/size/clickable/material symbols repaired.
- Non-composable callbacks me `stringResource()` misuse ko context string lookup me convert kiya.
- `return@launch` / `launchCatching` label issues repaired.
- `selection_bulk_share_message` missing resource added.
- EntryEditor folder-name argument placement corrected.
- `Color.toArgb` class of compiler errors included in source audit; current file has the required import.

**Verification level:** these are **source/static fixes**. Real Kotlin compiler/KSP/AAPT success is pending the CI gate below.

## 3.7 LATEST GITHUB COMPILE ERROR FIXES — Round 2 (5 October 2026)

Latest CI log reported these compile blockers:

1. **`EntryEditorScreen.kt:312` — delegated `Bitmap` smart-cast**  
   `val icon by produceState<Bitmap?>` cannot be smart-cast directly after `icon != null` because local delegated properties are not stable smart-cast targets. A plain local snapshot `val bitmap = icon` is now used before the null-check/member access.

2. **`EntryTypeChooserScreen.kt:48` — `Color` unresolved**  
   Added the missing `androidx.compose.ui.graphics.Color` import. The existing `type.color.copy(alpha = 0.12f)` then resolves correctly because the property is a Compose `Color`.

3. **`EntryTypeChooserScreen.kt:79` — `copy` unresolved**  
   This was a consequence of the unresolved `Color` type. No data/logic change was required; after the `Color` import, `type.color.copy(...)` is type-correct.

4. **`EmergencyScreen.kt:77` — `AppEmptyState` unresolved**  
   Added the missing project-component import for `AppEmptyState`.

5. **Latent sibling hazard found during the same audit — `AboutScreen.kt`**  
   `AppEmptyState`, `AppErrorState` and `AppLoadingState` were referenced without imports. Those imports were added proactively so the next compiler run does not stop on the same class of unresolved-reference error.

6. **Previously reported `FilesScreen.kt`, `SettingsScreen.kt`, `StartupSplash.kt`, `SetupScreen.kt` issues**  
   Current candidate already contains the earlier fixes: localized labels are resolved before non-composable callbacks, `res/raw/bsr_loading.json` is present, `RecoveryKeyDialog` receives a suspend key loader and pre-resolved copy label, and `BackupFolderCard` uses explicit named arguments. They were re-inspected in this round.

**Compiler-hazard guard strengthened:** `tools/strict_compiler_hazard_audit.py` now explicitly checks for local delegated-property smart-cast patterns and missing imports for the shared `AppEmptyState`/`AppErrorState`/`AppLoadingState`/`AppScreenState` composables.

**Status:** **SOURCE FIXED + STATIC-AUDIT GUARDS ADDED**. Real Gradle compilation must still be run by CI.

**Final Round-2 static verification:** the complete source audit suite was run in **3 consecutive clean passes** after these changes. Each pass reported 204 Kotlin files clean, 69/69 all-fixes regression, focused backup/navigation checks, font/UI static contract, session audit and XML checks passing.

**Changed source files in this final candidate:**
- `presentation/editor/EntryEditorScreen.kt`
- `presentation/editor/EntryTypeChooserScreen.kt`
- `presentation/emergency/EmergencyScreen.kt`
- `presentation/about/AboutScreen.kt`
- `presentation/files/FilesScreen.kt` (previous round fix retained)
- `presentation/settings/SettingsScreen.kt` (previous round fix retained)
- `presentation/setup/SetupScreen.kt` (previous round fix retained)
- `tools/strict_compiler_hazard_audit.py`

Protected `core/crypto`, `core/model`, `core/security`, `data` and `domain` trees remain byte-identical to the original source ZIP.

## 4. CURRENT SOURCE AUDIT — re-run during this cleanup

The cleanup run re-executed the available source-level checks against the current source tree:

| Check | Result |
|---|---|
| `tools/all_fixes_regression.py` | 69/69 PASS |
| `tools/strict_compiler_hazard_audit.py` | PASS |
| `tools/bracket_check.py` | PASS (0 files with issues) |
| `tools/font_scaling_audit.py` | PASS (28 screens, 80–200%) |
| `tools/phase_smart_session_audit.py` | PASS |
| `tools/phase15m_regression.py` | PASS |
| `tools/batch6_contract_audit.py` | PASS |
| `tools/batch7_audit.py` | PASS |
| `tools/static_audit.py` | PASS (informational wildcard/unused-symbol output only) |
| EN/HI string parity | **PASS** (1089 / 1089) |
| V3PayloadParser hash | **UNCHANGED / PASS** |

Historical project audit record also reports a **3 consecutive clean static-audit streak**. The present Round-2 candidate adds only the compiler-fix/UI import corrections documented above and does not alter protected data/crypto logic.

## 5. PENDING REPORT — developer must not mark these as fixed yet

### BLOCKER — build/compiler gate

**P-1. Real Android compile not yet re-certified after the 5 October 2026 compile-error fixes.**  
Run GitHub Actions and require Debug + Release Kotlin compile, KSP, AAPT, assemble and APK verification. Any `e:` / `error:` line becomes the next fix target.

**P-2. Unit tests not yet runtime-certified.**  
Run `testDebugUnitTest`; current repository contains 47 Kotlin test files.

**P-3. Emulator smoke not yet runtime-certified in this environment.**  
Workflow is configured for API 35 emulator smoke after build.

**P-4. Gradle wrapper files are absent from the supplied ZIP.**  
Only `gradle-wrapper.properties` exists. CI is configured to generate and verify the official wrapper; local developer builds need wrapper generation / Android Studio sync unless wrapper files are supplied separately.

### HIGH — device/runtime verification

**P-5. Realme/Redmi Autofill certification.**  4–6 digit Entry PIN detection must be tested against real `AssistStructure` / OEM Autofill behavior.

**P-6. Backup single-file guarantee on Android 10+ SAF/MediaStore.**  Repeat backup cycles on real devices and confirm only the canonical `BSRPRO.Vault` remains in the selected backup location.

**P-7. Restore crash-recovery / process-kill boundaries.**  Exercise snapshot/journal recovery around each destructive boundary and provider rename/rollback paths.

**P-8. 300+/1000+ entry performance.**  Measure launch, search, scrolling and save latency with realistic large datasets; static code proves the intended optimization, not the actual milliseconds.

**P-9. Full UI runtime review.**  Emulator screenshots vs specification, 80–200% font scale, keyboard + bottom navigation, TalkBack/content descriptions, launcher icon padding/shape and Hindi native-language review.

### MEDIUM — UI/feature follow-ups

**P-10. Backup status detail.**  Backup Status card currently lacks some size/entry-count detail referenced by earlier reports; confirm product requirement before changing.

**P-11. Import progress UX.**  Per-entry failures/counts should be reviewed during runtime testing.

**P-12. Sharing route/drawer state.**  Verify drawer highlight for `sharing?id=<built-in function id>` route.

## 6. BROWSER EXTENSION DEPENDENCIES / OPEN DECISIONS

These are outside the Android source ZIP but affect future interoperability:

**E1–E8, E11–E14:** previous extension work is documented as completed.  
**E9 — Pending:** decide whether entries tagged `hidden-vault` should remain invisible in extension UI/autofill or only be preserved during import/export. Until a product decision, preserve without changing behavior.

**Extension manual export validator issue:** prior report notes extension manual export (`version 2.0`) being rejected by its own V3 validator; this requires extension-side verification before Android export compression is enabled.

**Compression rollout:** Android source currently keeps `COMPRESS_EXPORT = false` intentionally. Do not enable it until the target extension reader is verified with `BSRZ1:`.

## 7. DATA-SAFETY / PROTECTED CODE RULES

Do not change these areas casually or replace them with regenerated logic:

- `app/src/main/java/pro/babasitaram/vault/core/crypto/`
- `app/src/main/java/pro/babasitaram/vault/core/model/`
- `app/src/main/java/pro/babasitaram/vault/core/security/`
- `app/src/main/java/pro/babasitaram/vault/data/`
- `app/src/main/java/pro/babasitaram/vault/domain/`

Keep V3 container header/AAD, PBKDF2-HMAC-SHA256 600000, AES-256-GCM and schema/backward-compatibility unchanged unless an explicit migration is designed and tested.

Never delete/replace an existing backup before the new backup has been written, validated and read back successfully.

## 8. AUTHORITATIVE BUILD / ACCEPTANCE FLOW

1. Push this source to GitHub.
2. Run `.github/workflows/native-android-build.yml` manually if no push trigger is available.
3. CI generates/verifies Gradle 8.7 wrapper when missing.
4. Run 3 complete clean build passes; any failure resets clean streak to 0.
5. Require Kotlin/KSP/AAPT/Debug+Release assemble and APK checks.
6. Run `testDebugUnitTest`.
7. Run API 35 emulator smoke.
8. Only after those pass, call the build **compiler-verified / runtime-verified**.
9. For production, separately verify signing, APK metadata and the final source archive.

Command used by the CI design:

```bash
./gradlew compileDebugKotlin compileReleaseKotlin testDebugUnitTest assembleDebug assembleRelease --no-daemon --stacktrace
```

## 9. Cleanup performed in this package

Removed the previous phase/report documentation set (root `PHASE*`, `FINAL_*`, `*_REPORT.md`, old `README*`, `ROADMAP.md`, consolidation/report artifacts, `reports/`, and text documentation under `docs/`). The package now follows the mandatory single-document rule: **only `DEVELOPER_HANDOFF.md` is documentation/status markdown**.

Retained:
- Android source, tests, Gradle configuration and CI workflow
- `tools/` audit/test scripts
- `tools/golden/vectors.json` because it is test fixture data, not a report
- `docs/ui-preview/*.png` visual preview assets because they are images, not duplicate documentation
- **This file:** `DEVELOPER_HANDOFF.md`

## 10. Final developer interpretation

**FIXED:** the latest reported compile blockers plus the earlier source-level bug fixes/static regression contracts listed above are patched in this package.  
**NOT YET PROVEN:** real Android compiler/KSP/AAPT, unit-test runtime, APK/signing, emulator/device behavior, OEM Autofill, SAF provider behavior and runtime UI/accessibility.

Do not tell the next developer “everything is production verified” until Section 8 completes successfully.

## LATEST CI COMPILER ROUND — 2026-10-05

### Repository / build evidence
- Target repository: `ramhardamp/BSRPRO-PM-VAULT`
- Latest failing CI compile was a real GitHub Actions Gradle 8.7 run against commit `bf11093094e5c8ad37f552682a48f2d876eeaba5` and failed in `:app:compileDebugKotlin`.
- `res/raw/bsr_loading.json` was present in the extracted project during this CI run, so the earlier missing-resource failure is not the current blocker.

### Fixed in this round
| File | CI error | Fix | Safety note |
| --- | --- | --- | --- |
| `core/security/BiometricAuthenticator.kt` | `BIOMETRIC_STRONG` unresolved | Added the missing AndroidX import. CryptoObject authentication explicitly uses Strong biometric. | No crypto algorithm/key schema change. |
| `core/security/BiometricSessionKeyStore.kt` | `BigInteger` vs `Int`, `AUTH_BIOMETRIC_WEAK` unresolved | Replaced unsupported `KeyProperties.AUTH_BIOMETRIC_WEAK` with Android Keystore's `AUTH_BIOMETRIC_STRONG`, combined with `AUTH_DEVICE_CREDENTIAL`. | Android Keystore exposes `AUTH_BIOMETRIC_STRONG` and `AUTH_DEVICE_CREDENTIAL` as Int constants; there is no `AUTH_BIOMETRIC_WEAK`. |
| `presentation/settings/SettingsViewModel.kt` | Strong/Weak mismatch risk | Cipher-auth availability check aligned to `BIOMETRIC_STRONG`. | Weak + device-credential remains available only to the non-CryptoObject prompt. |
| `presentation/vault/VaultListViewModel.kt` | Strong/Weak mismatch risk | Same strong-biometric check for cipher session unlock. | Prevents launching a CryptoObject flow that the Keystore key cannot satisfy. |
| `presentation/lock/LockViewModel.kt` | Strong/Weak mismatch risk | Same strong-biometric check for cipher session unlock. | Fallback paths unchanged. |
| `presentation/about/AboutScreen.kt` | `R` unresolved; lambda bound as `Modifier` | Added app `R` import and named `AppErrorState` arguments, including `onRetry`. | UI-only compile repair. |
| `presentation/components/AppBottomSheet.kt` | `dragHandleColor` unresolved | Replaced unavailable Material3 property with theme `onSurfaceVariant`. | Visual token only; no navigation/data logic. |
| `presentation/components/AppDrawer.kt` | `Lock` unresolved | Added `filled.Lock` import and used `Icons.Default.Lock`. | UI-only import repair. |
| `presentation/components/AppScreenState.kt` | `heading` unresolved | Imported the `heading` extension and invoked it inside the semantics receiver. | Accessibility semantics preserved. |
| `presentation/editor/EntryEditorScreen.kt` | `keyboardOptions` unsupported; follow-on Compose errors | Used existing `AppTextField.keyboardType` parameter and removed duplicate `label` argument in `AndroidAppPicker`. | Existing field API retained; no data model change. |

### Mandatory CI gate
After any Kotlin bulk edit, run the strict compiler-hazard audit **and a real Gradle compile** before calling the source “fixed”. Any new compiler error resets the clean streak to 0.

### Mandatory documentation rule
This `DEVELOPER_HANDOFF.md` is the **only authoritative project documentation file**. Do not create any new `PHASE*.md`, `FIX*.md`, `REPORT*.md`, `AUDIT*.md`, `QA*.md`, `ROADMAP*.md`, `README-*.md`, JSON report, or alternate handoff. Every future fixed/pending/build/test/decision update must be appended or edited **in this same file only**.

